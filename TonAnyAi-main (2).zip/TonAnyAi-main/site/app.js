'use strict';

/* Interface : rendu du design fourni, alimenté uniquement par l'API réelle.
   Aucun jeu de données de secours : un champ absent reste absent. */

const state = {
  snapshot: null,
  v2: null,
  market: '1x2',
  sort: 'score',
  tab: 'overview',
  sig: 'all',
  simulation: null,
  simError: '',
  daily: null,
  dailyError: '',
  day: '',
  exchange: null,
  xError: '',
  sSort: 'engine',
  xLoading: false,
};

const $ = (sel) => document.querySelector(sel);
const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));

const money = (n) => {
  const v = Number(n) || 0;
  if (v < 1000) return `£${Math.round(v)}`;
  if (v < 10000) return `£${(v / 1000).toFixed(1)}k`;
  return `£${Math.round(v / 1000)}k`;
};
const pc = (n, d = 0) => `${(Number(n) || 0).toFixed(d)} %`;
const signed = (n, d = 1) => `${Number(n) > 0 ? '+' : ''}${(Number(n) || 0).toFixed(d)}`;

/* Volumes Polymarket en dollars ; une valeur absente reste absente. */
const usd = (n) => {
  const v = Number(n);
  if (n == null || !Number.isFinite(v)) return 'n/d';
  if (v < 1000) return `$${Math.round(v)}`;
  if (v < 10000) return `$${(v / 1000).toFixed(1)}k`;
  return `$${Math.round(v / 1000)}k`;
};

const dF = new Intl.DateTimeFormat('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
const tF = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: 'UTC' });

/* Les dates du moteur sont en UTC sans suffixe (`2026-11-12 19:45:00`). */
function when(iso, label) {
  const raw = String(iso || '').trim();
  if (!raw) return label || '';
  let text = raw.replace(' ', 'T');
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/.test(text)) text += 'Z';
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return label || raw;
  return `${dF.format(date)} · ${tF.format(date)}`;
}

function ago(iso) {
  if (!iso) return 'inconnu';
  const seconds = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 90) return `il y a ${Math.round(seconds)} s`;
  if (seconds < 3600) return `il y a ${Math.round(seconds / 60)} min`;
  return `il y a ${(seconds / 3600).toFixed(1)} h`;
}

const norm = (s) => String(s || '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLowerCase()
  .replace(/[^a-z0-9]/g, '');

const KIND = {
  steam: 'Argent frais · cote ▼',
  reversal: 'Flux inversé',
  late: 'Afflux tardif',
  divergence: 'Divergence',
  under: '− de buts',
  over: '+ de buts',
  favorite: 'Favori soutenu',
  weight: 'Poids de marché',
  even: 'Match sans favori',
  neutral: 'Neutre',
};

/* Plancher de cote commun aux alertes et à la simulation (src/thresholds.rs). */
const MIN_BET_ODDS = 1.3;

const MATCH_STATE = {
  SCHEDULED: 'À venir',
  IN_PROGRESS: 'En cours',
  FINISHED: 'Terminé',
  POSTPONED: 'Reporté',
  CANCELLED: 'Annulé',
};

const GROUP = {
  issue: 'Issue du match',
  buts: 'Buts',
  btts: 'Les deux marquent',
  hcp: 'Handicap (DNB)',
  mt: 'Mi-temps',
  score: 'Score exact',
};

const BADGE_CLASS = {
  WHALE_ACCUMULATION: 'whale',
  SHARP_DROP: 'sharp',
  UNDERDOG_SURGE: 'dog',
  FAVORITE_STEAM: 'fav',
};

/* ------------------------------- appels API --------------------------- */

function banner(message, kind) {
  const el = $('#banner');
  if (!message) {
    el.hidden = true;
    el.textContent = '';
    el.className = 'banner';
    return;
  }
  el.hidden = false;
  el.className = `banner ${kind || ''}`.trim();
  el.textContent = message;
}

async function api(path, options) {
  const response = await fetch(path, options);
  if (response.status === 401) {
    banner('Authentification requise : rechargez la page et saisissez vos identifiants.');
    throw new Error('401');
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
  return payload;
}

/* ------------------------------ sélecteurs ---------------------------- */

const marketDef = (key) =>
  (state.snapshot?.markets || []).find((m) => m.key === key) ||
  { key, short: key, label: key, matches: [], total_volume: 0 };

const v2Signal = (id) => state.v2?.sig?.[id] || null;

function kindOf(signal) {
  const key = state.v2?.kind?.[signal.id];
  if (key) return key;
  const raw = signal.kind;
  if (typeof raw === 'string' && raw) return raw;
  if (raw && typeof raw === 'object') return raw.key || raw.label || 'neutral';
  return 'neutral';
}

function confidenceOf(signal) {
  const found = v2Signal(signal.id)?.conf;
  if (found) return found;
  const raw = signal.confidence;
  if (typeof raw === 'string') return raw;
  if (raw && typeof raw === 'object') return raw.label || '';
  return '';
}

function oddsOf(signal) {
  // L'éligibilité porte sur la proposition (premier groupe hors score), pas
  // sur la recommandation value/safety qui peut venir d'un autre marché.
  const proposal = (signal?.proposals || []).find((p) => p?.group !== 'score' && Number.isFinite(Number(p?.entry_odds)));
  if (proposal) return Number(proposal.entry_odds);
  const v = Number(signal?.value?.odds);
  if (Number.isFinite(v)) return v;
  const s = Number(signal?.safety?.odds);
  if (Number.isFinite(s)) return s;
  return 0;
}

function qualityOf(signal) {
  const found = v2Signal(signal.id)?.q;
  if (found) return found;
  const raw = signal.quality;
  if (raw && typeof raw === 'object') return { ok: raw.ok !== false, why: raw.why || '' };
  return null;
}

const flagged = () =>
  (state.snapshot?.signals || []).filter((s) => kindOf(s) !== 'neutral');

/* -------------------------------- statut ------------------------------ */

function renderStatus() {
  const snapshot = state.snapshot;
  const dot = $('#dot');
  const stamp = $('#stamp');
  if (!snapshot) {
    dot.className = 'dot off';
    stamp.textContent = 'Aucune collecte';
    return;
  }
  const warnings = snapshot.warnings || [];
  const nonLive = (snapshot.markets || []).filter((m) => m.source !== 'live').length;
  const stale = warnings.length > 0 || nonLive > 0;
  dot.className = `dot ${stale ? 'stale' : ''}`.trim();
  stamp.textContent = [
    `Collecte ${ago(snapshot.computed_at)} · ${(snapshot.signals || []).length} signaux`,
    nonLive ? `${nonLive} marché(s) non live` : 'flux Betfair recoupé',
    warnings.length ? `${warnings.length} avertissement(s)` : null,
  ].filter(Boolean).join(' · ');

  if (warnings.length) {
    banner(`Collecte terminée avec avertissements : ${warnings.join(' · ')}`, 'warn');
  } else if (!$('#banner').dataset.sticky) {
    banner(null);
  }
}

/* ------------------------------- aperçu ------------------------------- */

function renderOverview() {
  const markets = state.snapshot?.markets || [];
  const market = marketDef(state.market);
  const volume = markets.reduce((sum, m) => sum + (m.total_volume || 0), 0);
  const fixtures = new Set();
  markets.forEach((m) => (m.matches || []).forEach((x) => fixtures.add(`${x.home}|${x.away}`.toLowerCase())));
  const signals = state.snapshot?.signals || [];
  const flaggedCount = new Set();
  markets.forEach((m) => (m.matches || []).forEach((x) => {
    if (x.signal_type && x.signal_type !== 'BALANCED') flaggedCount.add(`${x.home}|${x.away}`.toLowerCase());
  }));
  const alerts = signals.filter((s) => kindOf(s) !== 'neutral').length;

  $('#heroLbl').textContent = `Volume collecté · ${markets.length} marchés`;
  $('#heroVal').textContent = `£${Math.round(volume).toLocaleString('fr-FR')}`;
  $('#heroSub').textContent = `${fixtures.size} rencontres suivies, flux Betfair recoupé entre marchés`;

  $('#kpis').innerHTML = [
    [String(fixtures.size), 'Rencontres', `${flaggedCount.size} avec un signal`],
    [String(signals.length), 'Recoupements', '≥ 2 marchés croisés'],
    [String(alerts), 'À examiner', 'hors recoupements neutres'],
  ].map(([v, l, s]) => `<div class="kpi"><div class="v">${esc(v)}</div><div class="l">${esc(l)}</div><div class="s">${esc(s)}</div></div>`).join('');

  $('#chips').innerHTML = markets.map((m) => `
    <button class="chip" data-market="${esc(m.key)}" aria-pressed="${m.key === state.market}">
      <b>${esc(m.short || m.label || m.key)}</b>
      <span>${esc(money(m.total_volume))} · ${(m.matches || []).length}</span>
    </button>`).join('') || '<div class="empty">Aucun marché collecté.</div>';

  const nonLive = markets.filter((m) => m.source !== 'live').length;
  $('#mTitle').textContent = `Rencontres · ${market.short || market.label || market.key}`;

  const rows = [...(market.matches || [])];
  if (state.sort === 'vol') rows.sort((a, b) => (b.total_volume || 0) - (a.total_volume || 0));
  else if (state.sort === 'time') rows.sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
  else rows.sort((a, b) => (b.smart_money_score || 0) - (a.smart_money_score || 0) || (b.total_volume || 0) - (a.total_volume || 0));

  $('#mList').innerHTML = rows.map((m) => {
    const share = (m.share || [0, 0, 0]).map((v) => Math.max(0, Math.round(v)));
    const dom = Number(m.dominant_index ?? 0);
    const chg = Number(m.drop?.[dom] ?? 0);
    const odds = m.coef_new?.[dom];
    const badge = m.signal_type && m.signal_type !== 'BALANCED' ? m.signal_label : '';
    const bk = BADGE_CLASS[m.signal_type] || '';
    const arrow = chg === 0 ? '' : chg < 0 ? '▼ ' : '▲ ';
    const bold = (index, text) => (dom === index ? `<b>${text}</b>` : text);
    return `
      <button class="mrow" data-match="${esc(m.id)}" data-market-key="${esc(market.key)}">
        <span class="top2">
          <span>
            <span class="teams">${esc(m.home)} — ${esc(m.away)}</span>
            <span class="sub2" style="display:block">${esc(m.league)} · ${esc(when(m.date, m.date_label))}</span>
          </span>
          <span class="vol">${esc(money(m.total_volume))}</span>
        </span>
        <span class="split" role="img" aria-label="Répartition du flux : ${share[0]} %, nul ${share[1]} %, ${share[2]} %">
          <i style="width:${share[0]}%;background:var(--h)"></i>
          <i style="width:${share[1]}%;background:var(--x)"></i>
          <i style="width:${share[2]}%;background:var(--a)"></i>
        </span>
        <span class="split-l">
          <span>${bold(0, `1 · ${share[0]} %`)}</span>
          <span>${bold(1, `N · ${share[1]} %`)}</span>
          <span>${bold(2, `2 · ${share[2]} %`)}</span>
        </span>
        <span class="tags">
          <span class="tag">Cote ${odds ? Number(odds).toFixed(2) : 'n/d'}</span>
          <span class="tag ${chg === 0 ? '' : chg < 0 ? 'in' : 'out'}">${arrow}${signed(chg)} %</span>
          ${badge ? `<span class="tag ${bk}">${esc(badge)}</span>` : ''}
          <span class="tag">Score ${Math.round(m.smart_money_score || 0)}</span>
        </span>
      </button>`;
  }).join('') || '<div class="empty">Aucune rencontre collectée pour ce marché.</div>';

  $('#mHint').textContent = [
    `${rows.length} rencontre(s)`,
    `volume ${money(market.total_volume)}`,
    `source : ${market.source}`,
    market.error ? `erreur : ${market.error}` : null,
    nonLive ? `${nonLive} marché(s) non live` : null,
    '▼ cote qui raccourcit (argent entrant), ▲ cote qui dérive. Barre : 1 domicile, N nul, 2 extérieur.',
  ].filter(Boolean).join(' · ');
}

/* ------------------------------- signaux ------------------------------ */

const FILTERS = [
  ['all', 'Tous', () => true],
  ['poly', 'Écarts Polymarket', (k, s) => Boolean(xRow(s)?.notable)],
  // La confirmation ne vaut que pour une direction 1X2/DNB, et le badge est
  // réservé aux signaux à confiance élevée.
  ['polyok', 'Confirmés Polymarket', (k, s) => k !== 'neutral' && confidenceOf(s) === 'Élevé' && Boolean(xRow(s)?.confirmed)],
  // Une confiance élevée sur un recoupement neutre ne porte pas de pari :
  // elle ne compte pas comme un match à examiner.
  ['conf', 'Confiance élevée', (k, s) => k !== 'neutral' && confidenceOf(s) === 'Élevé' && oddsOf(s) >= MIN_BET_ODDS],
  ['divergence', 'Divergences', (k) => k === 'divergence'],
  ['fresh', 'Argent frais', (k) => ['steam', 'reversal', 'late'].includes(k)],
  ['goals', 'Buts', (k) => k === 'over' || k === 'under'],
  ['favorite', 'Favori', (k) => k === 'favorite'],
  ['context', 'Observation', (k) => k === 'weight' || k === 'even'],
  ['neutral', 'Neutres', (k) => k === 'neutral'],
];

function freshBlock(signal) {
  const v2 = v2Signal(signal.id);
  if (!v2 || v2.f1 == null || v2.f3 == null) {
    return '<div class="reco"><b>À surveiller</b><span>Argent frais indisponible : l’historique des relevés ne couvre pas encore cette rencontre.</span></div>';
  }
  const bar = (label, value) => `
    <div class="fr"><span>${esc(label)}</span><span class="meter"><i style="width:${Math.max(0, Math.min(100, Number(value) || 0))}%"></i></span><b class="num">${pc(value)}</b></div>`;
  return `<div class="fresh">
    <div class="muted">Part du nouvel argent sur l’issue dominante</div>
    ${bar('1 h', v2.f1)}${bar('3 h', v2.f3)}
    ${v2.in1 != null && v2.in3 != null ? `<div class="muted num">+${esc(money(v2.in1))} en 1 h · +${esc(money(v2.in3))} en 3 h</div>` : ''}
  </div>`;
}

function proposalsBlock(signal) {
  const proposals = (signal.proposals || []).filter((p) => p.group !== 'score');
  if (!proposals.length) return '';
  const groups = new Map();
  proposals.forEach((p) => {
    if (!groups.has(p.group)) groups.set(p.group, []);
    groups.get(p.group).push(p);
  });
  return `<div class="mg">${[...groups.entries()].map(([group, list]) => {
    const allowed = list.some((p) => p.authorized);
    return `<div class="mgr">
      <div class="mgh"><span>${esc(GROUP[group] || group)}</span><span class="tag ${allowed ? 'in' : ''}">${allowed ? 'Proposition' : 'À surveiller'}</span></div>
      ${list.map((p) => `<div class="mi${p.authorized ? ' pk' : ''}"><span>${esc(p.market)} · ${esc(p.pick)}</span><b class="num">${pc(p.share)}</b></div>`).join('')}
    </div>`;
  }).join('')}</div>`;
}

/* L'explication de divergence reprend souvent le résumé : ne l'afficher que
   lorsqu'elle apporte une information supplémentaire. */
function divergenceNote(signal) {
  const note = String(signal.divergence_explanation || '').trim();
  if (!note) return '';
  const summary = String(signal.analysis_summary || '').replace(/\s+/g, ' ').trim();
  // La plupart du temps l'explication répète le résumé : on ne l'affiche que
  // si elle apporte une phrase de plus.
  if (!summary || summary.includes(note.replace(/\s+/g, ' ').trim())) return '';
  return `<div class="note"><span aria-hidden="true">⚠</span><span>${esc(note)}</span></div>`;
}

function signalCard(signal) {
  const kind = kindOf(signal);
  const confidence = confidenceOf(signal);
  const quality = qualityOf(signal);
  const conv = Math.max(0, Math.min(100, Number(signal.convergence_score) || 0));
  const polyConfirmed = confidence === 'Élevé' && Boolean(xRow(signal)?.confirmed);
  const tags = [
    confidence ? `<span class="tag cf" data-c="${esc(confidence)}">Confiance ${esc(confidence)}</span>` : '',
    polyConfirmed ? '<span class="tag in">Polymarket confirme</span>' : '',
    quality && quality.ok === false ? `<span class="tag out">⚠ ${esc(quality.why || 'données douteuses')}</span>` : '',
  ].join('');
  return `
    <article class="sig k-${esc(kind)}">
      <div class="sig-head">
        <div>
          <h3>${esc(signal.home)} — ${esc(signal.away)}</h3>
          <div class="sub2">${esc(signal.league)} · ${esc(when(signal.date, signal.date_label))} · ${esc(money(signal.total_volume))} tous marchés</div>
        </div>
        <span class="kind">${esc(KIND[kind] || signal.category_label || kind)}</span>
      </div>
      ${tags ? `<div class="tags">${tags}</div>` : ''}
      <div class="conv"><span>Convergence</span><span class="meter"><i style="width:${conv}%"></i></span><b class="num">${pc(conv)}</b></div>
      <p class="txt">${esc(signal.analysis_summary)}</p>
      <div class="tags">${(signal.markets || []).map((m) => `<span class="tag">${esc(m.market_label)} · ${esc(m.dominant_label)} ${pc(m.dominant_share)}</span>`).join('')}</div>
      ${polyBlock(signal)}
      ${proposalsBlock(signal)}
      ${freshBlock(signal)}
      ${divergenceNote(signal)}
      <div class="plays">
        <div><span>Value</span><b>${esc(signal.value?.label || 'aucun pari')}</b>${signal.value?.odds ? ` <span class="muted">@${Number(signal.value.odds).toFixed(2)}</span>` : ''}</div>
        <div><span>Sécurité</span><b>${esc(signal.safety?.label || 'aucun pari')}</b>${signal.safety?.odds ? ` <span class="muted">@${Number(signal.safety.odds).toFixed(2)}</span>` : ''}</div>
      </div>
      <button class="btn" data-sig="${esc(signal.id)}">Voir le détail</button>
    </article>`;
}

/* Ordre d'affichage : le moteur garde son classement, les autres tris
   s'appuient sur des données réellement présentes (écart Polymarket, heure). */
const SSORT = {
  engine: null,
  gap: (a, b) => xGap(b) - xGap(a),
  time: (a, b) => String(a.date || '').localeCompare(String(b.date || '')),
  conv: (a, b) => (Number(b.convergence_score) || 0) - (Number(a.convergence_score) || 0),
};

function renderSignals() {
  const signals = state.snapshot?.signals || [];
  const counts = new Map(FILTERS.map(([key, , test]) => [key, signals.filter((s) => test(kindOf(s), s)).length]));
  if (!counts.has(state.sig) || (state.sig !== 'all' && !counts.get(state.sig))) state.sig = 'all';
  const current = FILTERS.find(([key]) => key === state.sig) || FILTERS[0];

  const prices = state.exchange?.rows || [];
  const matched = prices.filter((r) => r.quote).length;
  const notable = prices.filter((r) => r.notable).length;
  const flaggedCount = signals.filter((s) => kindOf(s) !== 'neutral').length;
  const kpi = (value, label, sub) => `<div class="kpi"><div class="v">${esc(value)}</div><div class="l">${esc(label)}</div><div class="s">${esc(sub)}</div></div>`;
  $('#sKpis').innerHTML = [
    kpi(String(signals.length), 'Rencontres', `${flaggedCount} avec un signal`),
    kpi(
      state.exchange ? `${matched}/${prices.length}` : '—',
      'Prix Polymarket',
      state.exchange
        ? 'rencontres appariées au carnet'
        : state.xLoading ? 'lecture du carnet…' : state.xError ? `indisponible : ${state.xError}` : 'relancez la lecture des prix',
    ),
    kpi(state.exchange ? String(notable) : '—', 'Écarts notables', 'au-delà du seuil du moteur'),
  ].join('');

  $('#sFilters').innerHTML = FILTERS.map(([key, label]) => {
    const n = counts.get(key) || 0;
    return `<button class="pill" data-sf="${key}" aria-pressed="${state.sig === key}" ${n ? '' : 'disabled'}>${esc(label)} (${n})</button>`;
  }).join('');

  const flaggedSignals = signals.filter((s) => kindOf(s) !== 'neutral' && current[2](kindOf(s), s));
  const cmp = SSORT[state.sSort];
  if (cmp) flaggedSignals.sort(cmp);
  const neutrals = signals.filter((s) => kindOf(s) === 'neutral' && (state.sig === 'all' || state.sig === 'neutral'));

  const neutralRow = (s) => `
    <button class="nrow" data-sig="${esc(s.id)}">
      <span><span class="teams">${esc(s.home)} — ${esc(s.away)}</span><span class="sub2" style="display:block">${esc(s.league)} · ${esc(when(s.date, s.date_label))}</span></span>
      <span class="num muted">${pc(s.convergence_score)}</span>
    </button>`;

  let html = flaggedSignals.map(signalCard).join('');
  if (neutrals.length) {
    html += state.sig === 'neutral'
      ? neutrals.map(signalCard).join('')
      : `<details class="neutrals"><summary>Recoupements neutres (${neutrals.length})</summary>${neutrals.map(neutralRow).join('')}</details>`;
  }
  $('#sList').innerHTML = html || '<div class="empty">Aucun signal de ce type pour le moment.</div>';
  $('#sHint').textContent = [
    `${flaggedSignals.length} signal(aux) affiché(s)`,
    state.snapshot ? `collecte ${ago(state.snapshot.computed_at)}` : null,
    state.exchange ? `${matched} prix Polymarket sur ${prices.length} rencontres` : null,
    'prix lus à la demande et mis en cache par le serveur ; un événement non apparié n’est jamais estimé',
  ].filter(Boolean).join(' · ');
}

/* ------------------------------ simulation ---------------------------- */

const SIM_STATUS = {
  OPEN: ['Ouverte', ''],
  WON: ['Gagnée', 'in'],
  LOST: ['Perdue', 'out'],
  PUSH: ['Remboursée', ''],
  VOID: ['Annulée', ''],
};

function simRow(position) {
  const [label, cls] = SIM_STATUS[position.status] || [position.status, ''];
  const time = (when(position.match_date).split(' · ')[1] || '').trim();
  const pnl = position.pnl == null
    ? ''
    : `<b class="num ${position.pnl >= 0 ? 'up' : 'dn'}">${signed(position.pnl, 2)} pts</b>`;
  return `
    <div class="res" style="grid-template-columns:52px minmax(0,1fr) auto">
      <span class="t">${esc(time)}</span>
      <div>
        <div class="teams">${esc(position.home)} — ${esc(position.away)}</div>
        <span class="sub2" style="display:block">${esc(position.league)} · ${esc(GROUP[position.group] || position.group)} · ${esc(position.market)} · ${esc(position.pick)}</span>
        <span class="sub2" style="display:block">${esc(position.note || '')}</span>
      </div>
      <div class="st">
        <span class="tag ${cls}">${esc(label)}</span><br />
        <span class="num">@${Number(position.odds).toFixed(2)} · ${Number(position.stake).toFixed(0)} pt</span>
        ${pnl ? `<br />${pnl}` : ''}
      </div>
    </div>`;
}

function renderSimulation() {
  const sim = state.simulation;
  if (!sim) {
    $('#simRules').textContent = '';
    $('#simKpis').innerHTML = '';
    $('#simOpenHint').textContent = '';
    $('#simHistoryHint').textContent = '';
    $('#simOpen').innerHTML = `<div class="empty">${esc(state.simError || 'Chargement de la simulation…')}</div>`;
    $('#simHistory').innerHTML = '';
    $('#simHint').textContent = '';
    return;
  }

  $('#simRules').textContent =
    `${sim.starting_points} points au départ · ${sim.stake_points} point par position · `
    + `ouverture dès que le signal est éligible, jusqu’à ${sim.min_kickoff_lead_minutes} min avant le coup d’envoi · `
    + `confiance Élevé · cote ≥ ${Number(sim.min_odds).toFixed(2)} · ${sim.max_open} positions simultanées maximum.`;

  const kpi = (value, label, sub) => `<div class="kpi"><div class="v">${esc(value)}</div><div class="l">${esc(label)}</div><div class="s">${esc(sub || '')}</div></div>`;
  const roi = sim.roi_pct == null ? '—' : `${signed(sim.roi_pct)} %`;
  const win = sim.win_rate_pct == null ? '—' : `${Math.round(sim.win_rate_pct)} %`;
  $('#simKpis').innerHTML = [
    kpi(`${Number(sim.balance_points).toFixed(2)} pts`, 'Capital', `${sim.starting_points} pts au départ · ${signed(sim.realized_pnl, 2)} pts réalisés`),
    kpi(`${Number(sim.available_points).toFixed(2)} pts`, 'Disponible', `${sim.open_stakes} pts engagés sur ${sim.open_count}/${sim.max_open} positions`),
    kpi(String(sim.open_count), 'Ouvertes', `${sim.settled} position(s) réglée(s)`),
    kpi(roi, 'ROI', `${sim.won} gagnées · ${sim.lost} perdues · ${sim.push} remboursées · ${sim.void} annulées`),
    kpi(win, 'Réussite', 'gagnées / (gagnées + perdues)'),
  ].join('');

  const positions = sim.positions || [];
  const open = positions.filter((p) => p.status === 'OPEN');
  const closed = positions.filter((p) => p.status !== 'OPEN');
  $('#simOpenHint').textContent = open.length ? `${open.length} position(s) en cours` : '';
  $('#simHistoryHint').textContent = sim.settled
    ? `${sim.settled} réglée(s) · ${closed.length} affichée(s)`
    : '';
  $('#simOpen').innerHTML = open.length
    ? open.map(simRow).join('')
    : '<div class="empty">Aucune position ouverte. Une entrée est possible dès que le signal est éligible (confiance Élevé, cote ≥ 1,30, compétition avec source de score), au plus tard 1 minute avant le coup d’envoi.</div>';
  $('#simHistory').innerHTML = closed.length
    ? closed.map(simRow).join('')
    : '<div class="empty">Aucune position réglée pour l’instant.</div>';
  $('#simHint').textContent =
    'Simulation en points, aucun ordre réel n’est envoyé. La cote d’entrée est celle de la proposition du signal, '
    + 'pas un prix Polymarket exécutable ; une rencontre reportée, annulée, non couverte par ESPN ni SportScore ou sans résultat sous 48 h rend la mise.';
}

async function loadSimulation() {
  try {
    const payload = await api('/api/simulation');
    state.simulation = payload.simulation || null;
    state.simError = state.simulation ? '' : 'Simulation indisponible.';
  } catch (err) {
    state.simulation = null;
    state.simError = `Simulation indisponible : ${err.message}`;
  }
  renderSimulation();
}

/* ------------------------------ bilan du jour ------------------------- */

const OUTCOME = {
  WON: ['Gagné', 'in'],
  LOST: ['Perdu', 'out'],
  PUSH: ['Remboursé', ''],
  PENDING: ['En attente', ''],
  UNKNOWN: ['Non noté', ''],
};

function dayLabel(day, today) {
  if (day === today) return "Aujourd'hui";
  const date = new Date(`${day}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ? day : dF.format(date);
}

/* Un seul jour à la fois : le bilan du jour par défaut, les jours précédents
   au choix dans le sélecteur. Aucune ligne d'un autre jour n'est mélangée. */
function renderDaily() {
  const report = state.daily;
  const select = $('#dailyDate');
  if (!report) {
    select.innerHTML = '';
    $('#dailyTitle').textContent = 'Bilan du jour';
    $('#dailyKpis').innerHTML = '';
    $('#dailyConfidence').textContent = '';
    $('#dailyCoverage').hidden = true;
    $('#dailyBetsHead').hidden = true;
    $('#dailyBets').innerHTML = '';
    $('#dailyHint').textContent = '';
    $('#dailyList').innerHTML = `<div class="empty">${esc(state.dailyError || 'Chargement du bilan…')}</div>`;
    return;
  }

  const days = (report.days && report.days.length) ? report.days : [report.day];
  select.innerHTML = days
    .map((d) => `<option value="${esc(d)}" ${d === report.day ? 'selected' : ''}>${esc(dayLabel(d, report.today))}</option>`)
    .join('');
  $('#dailyTitle').textContent = report.is_today ? 'Bilan du jour' : `Bilan du ${report.label}`;

  const t = report.totals || {};
  const decided = (t.won || 0) + (t.lost || 0);
  const kpi = (value, label, sub) => `<div class="kpi"><div class="v">${esc(value)}</div><div class="l">${esc(label)}</div><div class="s">${esc(sub || '')}</div></div>`;
  $('#dailyKpis').innerHTML = [
    kpi(String(t.tracked ?? 0), 'Rencontres', `${t.flagged ?? 0} avec un signal · ${t.neutral ?? 0} neutres`),
    kpi(String(t.finished ?? 0), 'Jouées', `${t.awaiting ?? 0} sans score final`),
    kpi(String(t.bets ?? 0), 'Propositions', `${t.pending_bets ?? 0} en attente`),
    kpi(decided ? `${Math.round(((t.won || 0) / decided) * 100)} %` : '—', 'Réussite', decided ? `${t.won} gagnés · ${t.lost} perdus · ${t.push ?? 0} remboursés` : 'aucune proposition réglée'),
    kpi(decided ? `${signed(t.roi_pct)} %` : '—', 'ROI', decided ? `${signed(t.profit, 2)} u sur ${decided} paris` : 'rien à calculer'),
    kpi(t.clv_pct == null ? '—' : `${signed(t.clv_pct)} %`, 'CLV moyen', t.clv_pct == null ? 'cote de clôture indisponible' : 'entrée → clôture'),
  ].join('');

  // Performance du jour au niveau de confiance le plus élevé : c'est le seul
  // sous-ensemble pour lequel la confiance est enregistrée depuis cette version.
  const high = (report.by_confidence || []).find((c) => c.confidence === 'Élevé');
  const confTarget = $('#dailyConfidence');
  if (high) {
    const settled = (high.won || 0) + (high.lost || 0) + (high.push || 0);
    const roi = high.roi_pct == null ? '—' : `${signed(high.roi_pct)} %`;
    const clv = high.clv_pct == null ? '—' : `${signed(high.clv_pct)} %`;
    const skipped = high.below_odds_floor
      ? ` · ${high.below_odds_floor} écartée(s) sous ${MIN_BET_ODDS.toFixed(2)}`
      : '';
    confTarget.textContent = (high.bets || high.below_odds_floor)
      ? `Confiance élevée : ${high.bets} proposition(s) retenue(s) · ${settled} réglée(s) `
        + `(${high.won || 0} gagnées · ${high.lost || 0} perdues) · ROI ${roi} · CLV ${clv}${skipped}`
      : 'Confiance élevée : aucune proposition retenue ce jour-là.';
  } else {
    confTarget.textContent = '';
  }

  // Compétitions sans source de score : l'attente est expliquée, pas devinée.
  const uncovered = report.uncovered || [];
  const uncoveredLeagues = new Set(uncovered.map((u) => u.league));
  const coverage = $('#dailyCoverage');
  if (uncovered.length) {
    const total = uncovered.reduce((sum, u) => sum + (u.matches || 0), 0);
    coverage.hidden = false;
    coverage.textContent = `${total} rencontre(s) sans source de score : `
      + `${uncovered.map((u) => `${u.league} (${u.matches})`).join(' · ')}. `
      + 'Ces compétitions ne sont pas couvertes par ESPN ni SportScore : elles resteront en attente et ne sont jamais notées.';
  } else {
    coverage.hidden = true;
    coverage.textContent = '';
  }

  $('#dailyList').innerHTML = (report.matches || []).map((m) => {
    const played = m.state === 'FINISHED' && m.home_score != null && m.away_score != null;
    const time = (when(m.match_date).split(' · ')[1] || '').trim();
    const tag = m.flagged
      ? `<span class="tag in">${esc(KIND[m.kind] || m.kind)}</span>`
      : '<span class="tag">Neutre</span>';
    const source = m.source
      ? `source ${esc(m.source)}`
      : uncoveredLeagues.has(m.league) ? 'sans source de score' : 'score indisponible';
    return `
      <div class="res ${played ? 'finished' : m.state === 'IN_PROGRESS' ? 'live' : ''}">
        <span class="t">${esc(time)}</span>
        <div>
          <div class="teams">${esc(m.home)} — ${esc(m.away)}</div>
          <span class="sub2" style="display:block">${esc(m.league)}</span>
          <div class="tags" style="margin-top:6px">${tag}</div>
        </div>
        <div class="st">
          ${played ? `<div class="sc">${esc(m.home_score)}–${esc(m.away_score)}</div>` : ''}
          ${esc(MATCH_STATE[m.state] || m.state)}<br />
          <span class="muted">${source}</span>
        </div>
      </div>`;
  }).join('') || '<div class="empty">Aucune rencontre enregistrée dans les signaux ce jour-là.</div>';

  const bets = report.bets || [];
  $('#dailyBetsHead').hidden = !bets.length;
  $('#dailyBetsHint').textContent = bets.length ? `${bets.length} proposition(s) suivie(s)` : '';
  $('#dailyBets').innerHTML = bets.map((b) => {
    const [label, cls] = OUTCOME[b.outcome] || [b.outcome, ''];
    const closing = b.closing_odds == null ? '' : ` → ${Number(b.closing_odds).toFixed(2)}`;
    const odds = b.odds == null ? 'cote indisponible' : `cote ${Number(b.odds).toFixed(2)}${closing}`;
    const clv = b.clv_pct == null ? '' : `<b class="num ${b.clv_pct >= 0 ? 'up' : 'dn'}">CLV ${signed(b.clv_pct)} %</b>`;
    return `
      <div class="res" style="grid-template-columns:minmax(0,1fr) auto">
        <div>
          <div class="teams">${esc(b.teams)}</div>
          <div class="sub2">${esc(GROUP[b.group] || b.group)} · ${esc(b.market)} · ${esc(b.pick)}${b.confidence ? ` · confiance ${esc(b.confidence)}` : ''}<br />${esc(odds)}</div>
        </div>
        <div class="st"><span class="tag ${cls}">${esc(label)}</span>${clv ? `<br />${clv}` : ''}</div>
      </div>`;
  }).join('');

  $('#dailyHint').textContent = [
    `${(report.matches || []).length} rencontre(s) enregistrée(s) dans les signaux`,
    `scores ${String(report.score_source || '').toUpperCase()}`,
    'une rencontre sans score final reste en attente : elle n’est jamais notée par défaut.',
  ].filter(Boolean).join(' · ');
}

async function loadDaily(day) {
  try {
    const payload = await api(`/api/daily${day ? `?date=${encodeURIComponent(day)}` : ''}`);
    state.daily = payload.report || null;
    state.dailyError = state.daily ? '' : 'Bilan indisponible.';
    state.day = state.daily?.day || '';
  } catch (err) {
    state.daily = null;
    state.dailyError = `Bilan indisponible : ${err.message}`;
  }
  renderDaily();
}

/* --------------------- historique, perf, qualité ---------------------- */

/* ------------------------------- exchange ----------------------------- */

/* Écart le plus large d'une rencontre, en valeur absolue (0 si aucun écart). */
const maxGap = (row) => (row.sides || []).reduce(
  (best, side) => (side.gap_pp == null ? best : Math.max(best, Math.abs(side.gap_pp))),
  0,
);

/* Jointure exacte : chaque ligne de prix porte l'identifiant de son signal,
   donc aucune rencontre n'est rapprochée par ressemblance de nom. */
const xRow = (signal) => (state.exchange?.rows || []).find((row) => row.id === signal.id) || null;
const xGap = (signal) => {
  const row = xRow(signal);
  return row ? maxGap(row) : -1;
};

function xSideRow(side, quote) {
  const outcome = (quote.outcomes || []).find((o) => o.label === side.side) || null;
  const gap = side.gap_pp;
  // Écart négatif : Polymarket paie mieux que notre cote collectée.
  const gapClass = gap == null ? '' : gap < 0 ? 'up' : 'dn';
  const book = outcome && outcome.bid != null && outcome.ask != null
    ? `${(outcome.bid * 100).toFixed(0)}/${(outcome.ask * 100).toFixed(0)}`
    : '—';
  return `<div class="xr">
    <b>${esc(side.side)}</b>
    <span>${side.betfair_pct == null ? '—' : `${side.betfair_pct.toFixed(1)} %`}</span>
    <span>${side.polymarket_pct == null ? '—' : `${side.polymarket_pct.toFixed(1)} %`}</span>
    <span class="num ${gapClass}">${gap == null ? '—' : `${signed(gap, 1)} pt`}</span>
    <span>${book}</span>
    <span>${usd(outcome ? outcome.volume : null)}</span>
  </div>`;
}

/* Les prix Polymarket vivent dans la carte du match : un résumé toujours
   visible, le carnet replié dessous. */
function polyBlock(signal) {
  const row = xRow(signal);
  const badge = '<span class="px-badge">Polymarket</span>';
  if (!row) {
    // Deux raisons distinctes, jamais confondues : une lecture en cours ou une
    // rencontre hors du périmètre lu (neutre, terminée, hors horizon).
    const why = state.xLoading
      ? 'lecture du carnet en cours…'
      : kindOf(signal) === 'neutral'
        ? 'les prix ne sont lus que pour les signaux non neutres'
        : 'les prix sont lus pour les rencontres à venir';
    const tag = state.xLoading ? '<span class="tag">lecture…</span>' : '<span class="tag">non lu</span>';
    return `<div class="px">${badge}${tag}<span class="muted">${esc(why)}</span></div>`;
  }
  const quote = row.quote;
  if (!quote) {
    return `<div class="px">${badge}<span class="tag">aucun événement apparié</span><span class="muted">rien n’est estimé à sa place</span></div>`;
  }
  const confirmed = confidenceOf(signal) === 'Élevé' && row.confirmed
    ? '<span class="tag in">Polymarket confirme</span>'
    : '';
  const top = (row.sides || []).reduce((best, side) => {
    if (side.gap_pp == null) return best;
    return !best || Math.abs(side.gap_pp) > Math.abs(best.gap_pp) ? side : best;
  }, null);
  const headline = top
    ? `<span class="tag ${top.gap_pp < 0 ? 'in' : 'out'}">${esc(top.side)} ${signed(top.gap_pp)} pt</span>`
    : '<span class="tag">écart indisponible</span>';
  const facts = `<div class="facts">
      <div class="fact"><div class="l">Volume événement</div><div class="v">${esc(usd(quote.volume))}</div></div>
      <div class="fact"><div class="l">Sur 24 h</div><div class="v">${esc(usd(quote.volume_24h))}</div></div>
      <div class="fact"><div class="l">Liquidité carnet</div><div class="v">${esc(usd(quote.liquidity))}</div></div>
      <div class="fact"><div class="l">Intérêt ouvert</div><div class="v">${esc(usd(quote.open_interest))}</div></div>
    </div>`;
  const table = (quote.outcomes || []).length ? `
    <div class="xtable" role="table" aria-label="Probabilités Betfair et Polymarket">
      <div class="xhead" role="row"><span>Issue</span><span>Betfair</span><span>Polymarket</span><span>Écart</span><span>Bid/ask</span><span>Volume</span></div>
      ${row.sides.map((side) => xSideRow(side, quote)).join('')}
    </div>` : '';
  return `<div class="px">
    <div class="px-head">
      ${badge}
      ${headline}
      ${confirmed}
      ${row.notable ? '<span class="tag out">notable</span>' : ''}
      <span class="muted num">${esc(usd(quote.volume))} échangés</span>
      <a class="btn sm" href="${esc(quote.url)}" target="_blank" rel="noopener">Ouvrir</a>
    </div>
    <details class="px-d">
      <summary>Prix croisés et carnet</summary>
      ${facts}
      ${table}
      <p class="xnote">Bid et ask en probabilité (0-100) ; écart = Polymarket − Betfair. Négatif : Polymarket paie mieux que notre cote, positif : il paie moins.</p>
    </details>
  </div>`;
}

async function loadExchange(force) {
  if (state.xLoading) return;
  if (state.exchange && !force) return;
  state.xLoading = true;
  state.xError = '';
  renderSignals();
  try {
    state.exchange = await api('/api/exchange');
  } catch (err) {
    state.exchange = null;
    state.xError = err.message;
  } finally {
    state.xLoading = false;
    renderSignals();
  }
}

function renderHistory() {
  const hist = state.v2?.hist || [];
  if (!hist.length) {
    $('#hList').innerHTML = '<div class="empty">Aucune proposition notée pour l’instant : l’historique se remplit quand une rencontre suivie est terminée.</div>';
    return;
  }
  $('#hList').innerHTML = hist.map((h) => `
    <div class="res" style="grid-template-columns:minmax(0,1fr) auto">
      <div>
        <div class="teams">${esc(h.t)}</div>
        <div class="sub2">${esc(h.mkt || '')} · ${esc(h.type)}<br />cote ${esc(h.odds)} → clôture ${esc(h.close)}</div>
      </div>
      <div class="st">${h.clv != null ? `<b class="num ${h.clv >= 0 ? 'up' : 'dn'}">CLV ${signed(h.clv)} %</b><br />` : ''}${esc(h.res)}</div>
    </div>`).join('');
}

function renderPerf() {
  const v2 = state.v2;
  const note = '<p class="hint">Seuls les matchs flagués sont notés. Un groupe sans proposition chiffrée reste à zéro cas : rien n’est extrapolé.</p>';
  if (!v2) {
    $('#pList').innerHTML = '<div class="empty">Disponible une fois l’historisation des relevés active.</div>';
    return;
  }
  const stat = (label, value, cls) => `<div><div class="l">${esc(label)}</div><b class="num ${cls || ''}">${esc(value)}</b></div>`;
  const groups = Object.entries(v2.mstat || {});
  const perf = v2.perf || [];
  const total = groups.reduce((sum, [, s]) => sum + (s.n || 0), 0);
  const row = (name, sub, s) => `
    <div class="prow">
      <div class="ph2"><div><div class="teams">${esc(name)}</div><div class="sub2">${esc(sub)}</div></div></div>
      <div class="stats">
        ${stat('Cas', String(s.n ?? 0))}
        ${stat('Réussite', pc(s.hit))}
        ${stat('ROI', `${signed(s.roi)} %`, (s.roi || 0) >= 0 ? 'up' : 'dn')}
        ${stat('CLV', `${signed(s.clv)} %`, (s.clv || 0) > 0 ? 'up' : 'dn')}
      </div>
    </div>`;
  $('#pList').innerHTML = `
    <div class="prow">
      <div class="ph2"><div><div class="teams">Global</div><div class="sub2">Tous groupes confondus</div></div></div>
      <div class="stats">${stat('Cas notés', String(total))}</div>
    </div>
    ${groups.map(([key, s]) => row(GROUP[key] || key, 'Groupe de marché', s)).join('')}
    ${perf.length ? perf.map((p) => row(p.type, 'Type de signal', p)).join('') : ''}
    ${note}`;
}

function renderQuality() {
  const list = state.v2?.quality || [];
  $('#qList').innerHTML = list.length
    ? list.map((q) => `<div class="res" style="grid-template-columns:1fr"><div><div class="teams">${esc(q.t)}</div><div class="sub2">${esc(q.why)}</div></div></div>`).join('')
    : '<div class="empty">Aucun marché écarté sur le dernier cycle.</div>';
}

/* -------------------------------- détail ------------------------------ */

function openDetail(payload) {
  const { match, signal } = payload;
  const title = match || signal;
  if (!title) return;
  $('#dTitle').textContent = `${title.home} — ${title.away}`;
  $('#dMeta').textContent = `${title.league || ''} · ${when(title.date, title.date_label)}`;

  let html = '';
  if (match) {
    const names = ['Domicile (1)', 'Nul (N)', 'Extérieur (2)'];
    const cols = ['--h', '--x', '--a'];
    const share = (match.share || [0, 0, 0]).map((v) => Math.round(v));
    const dom = Number(match.dominant_index ?? 0);
    const odds = match.coef_new?.[dom];
    const chg = Number(match.drop?.[dom] ?? 0);
    html += `<div class="facts">
      <div class="fact"><div class="l">Volume du marché</div><div class="v">${esc(money(match.total_volume))}</div></div>
      <div class="fact"><div class="l">Cote ${esc(names[dom])}</div><div class="v">${odds ? Number(odds).toFixed(2) : 'n/d'}</div></div>
      <div class="fact"><div class="l">Variation de cote</div><div class="v ${chg === 0 ? '' : chg < 0 ? 'up' : 'dn'}">${signed(chg)} %</div></div>
      <div class="fact"><div class="l">Score smart money</div><div class="v">${Math.round(match.smart_money_score || 0)}</div></div>
    </div>
    <div class="out">${share.map((v, i) => `<span>${names[i]}</span><b class="num">${v} %</b><span class="meter"><i style="width:${Math.max(0, Math.min(100, v))}%;background:var(${cols[i]})"></i></span>`).join('')}</div>
    ${match.signal_label ? `<div class="tags"><span class="tag ${BADGE_CLASS[match.signal_type] || ''}">${esc(match.signal_label)}</span><span class="tag">liquidité ${esc(match.liquidity_tier)}</span><span class="tag">source ${esc(match.source)}</span></div>` : ''}
    <div class="acts">
      <a class="btn" href="${esc(match.betfair_market_url)}" target="_blank" rel="noopener">Marché Betfair</a>
      <a class="btn" href="${esc(match.betfair_chart_url)}" target="_blank" rel="noopener">Graphique</a>
    </div>`;
  }

  if (signal) {
    const kind = kindOf(signal);
    const conv = Math.max(0, Math.min(100, Number(signal.convergence_score) || 0));
    html += `<div class="conv"><span>${esc(KIND[kind] || signal.category_label || kind)} · convergence</span><span class="meter"><i style="width:${conv}%"></i></span><b class="num">${pc(conv)}</b></div>
      <p class="txt">${esc(signal.analysis_summary)}</p>
      <div class="tags">${(signal.markets || []).map((m) => `<span class="tag">${esc(m.market_label)} · ${esc(m.dominant_label)} ${pc(m.dominant_share)}</span>`).join('')}</div>
      ${proposalsBlock(signal)}
      ${divergenceNote(signal)}
      <div class="plays">
        <div><span>Value</span><b>${esc(signal.value?.label || 'aucun pari')}</b></div>
        <div><span>Sécurité</span><b>${esc(signal.safety?.label || 'aucun pari')}</b></div>
      </div>`;
  }

  $('#dBody').innerHTML = html;
  $('#dlg').showModal();
}

function findFixture(match) {
  const key = norm(`${match.home}${match.away}`);
  return (state.snapshot?.signals || []).find((s) => norm(`${s.home}${s.away}`) === key) || null;
}

/* ------------------------------ navigation ---------------------------- */

function show(tab) {
  // L'ancien onglet Exchange est fusionné dans Signaux : un lien gardé en
  // favori ouvre toujours la bonne vue.
  if (tab === 'exchange') {
    tab = 'signals';
    if (location.hash === '#exchange') history.replaceState(null, '', '#signals');
  }
  const views = ['overview', 'signals', 'daily', 'simulation', 'history', 'perf', 'quality'];
  if (!views.includes(tab)) tab = 'overview';
  state.tab = tab;
  document.querySelectorAll('.view').forEach((view) => { view.hidden = view.id !== `v-${tab}`; });
  document.querySelectorAll('#tabs button').forEach((button) => {
    if (button.dataset.tab === tab) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  if (tab === 'simulation') loadSimulation();
  if (tab === 'daily') loadDaily(state.day || '');
  if (tab === 'signals') loadExchange();
}

function renderAll() {
  renderStatus();
  renderOverview();
  renderSignals();
  renderSimulation();
  renderDaily();
  renderHistory();
  renderPerf();
  renderQuality();
  const alerts = flagged().length;
  const badge = $('#badge');
  badge.hidden = !alerts;
  badge.textContent = String(alerts);
}

/* -------------------------------- actions ----------------------------- */

async function loadSnapshot() {
  try {
    const [snapshot, v2] = await Promise.all([
      api('/api/snapshot'),
      api('/api/v2').catch(() => null),
    ]);
    state.snapshot = snapshot;
    state.v2 = v2?.v2 || (snapshot && snapshot.v2) || null;
    $('#banner').dataset.sticky = '';
  } catch (err) {
    state.snapshot = null;
    state.v2 = null;
    if (err.message !== '401') {
      $('#banner').dataset.sticky = '1';
      banner(`Aucune donnée collectée pour le moment. Lancez une collecte pour alimenter le tableau de bord. (${err.message})`);
    }
  }
  renderAll();
}

async function refresh() {
  const button = $('#refresh');
  button.classList.add('busy');
  button.disabled = true;
  try {
    const payload = await api('/api/refresh', { method: 'POST' });
    await loadSnapshot();
    // Le bilan du jour est recalculé à la lecture : on le récupère pour que le
    // score du match qui vient de se terminer apparaisse sans rechargement.
    if (state.tab === 'daily') await loadDaily(state.day || '');
    if (state.tab === 'simulation') await loadSimulation();
    // Les prix Polymarket ne viennent pas de la collecte : ils sont relus pour
    // que le tableau ne montre pas des prix d'avant la dernière actualisation.
    if (state.tab === 'signals') {
      state.exchange = null;
      await loadExchange(true);
    }
    if (payload.deferred) {
      const minutes = Math.max(1, Math.round((payload.schedule?.due_in_secs || 0) / 60));
      banner(`Aucune collecte : pas de rencontre imminente. Prochaine passe automatique dans ${minutes} min.`, 'warn');
      return;
    }
    if (state.snapshot) {
      const warnings = payload.warnings || [];
      banner(
        warnings.length
          ? `Collecte terminée avec avertissements : ${warnings.join(' · ')}`
          : `Collecte terminée : ${payload.signals} signaux.`,
        warnings.length ? 'warn' : 'ok',
      );
    }
  } catch (err) {
    banner(`Collecte impossible : ${err.message}`, 'error');
  } finally {
    button.classList.remove('busy');
    button.disabled = false;
  }
}

/* --------------------------------- thème ------------------------------ */

const THEMES = ['auto', 'light', 'dark'];
const THEME_NAMES = { auto: 'Auto', light: 'Clair', dark: 'Sombre' };
let themeIndex = 0;

function applyTheme(key) {
  if (key === 'auto') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', key);
  $('#thName').textContent = THEME_NAMES[key];
}

/* --------------------------------- liens ------------------------------ */

function bind() {
  const pop = $('#pop');
  const menuButton = $('#menuBtn');
  const closePop = () => {
    pop.hidden = true;
    menuButton.setAttribute('aria-expanded', 'false');
  };

  menuButton.addEventListener('click', (event) => {
    event.stopPropagation();
    pop.hidden = !pop.hidden;
    menuButton.setAttribute('aria-expanded', String(!pop.hidden));
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('#pop') && !event.target.closest('#menuBtn')) closePop();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closePop();
  });

  pop.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.go) {
      location.hash = button.dataset.go;
      closePop();
    } else if (button.dataset.theme) {
      themeIndex = (themeIndex + 1) % THEMES.length;
      applyTheme(THEMES[themeIndex]);
    }
  });

  document.addEventListener('click', (event) => {
    const target = event.target.closest('[data-tab],[data-market],[data-match],[data-sig],[data-sf],#dClose');
    if (!target) return;
    const data = target.dataset;
    if (target.id === 'dClose') {
      $('#dlg').close();
    } else if (data.tab) {
      if (location.hash.slice(1) === data.tab) show(data.tab);
      else location.hash = data.tab;
    } else if (data.market) {
      state.market = data.market;
      renderOverview();
    } else if (data.match) {
      const market = marketDef(data.marketKey || state.market);
      const match = (market.matches || []).find((m) => m.id === data.match);
      if (match) openDetail({ match, signal: findFixture(match) });
    } else if (data.sig) {
      const signal = (state.snapshot?.signals || []).find((s) => s.id === data.sig);
      if (signal) {
        const key = norm(`${signal.home}${signal.away}`);
        const markets = state.snapshot?.markets || [];
        let match = null;
        markets.some((m) => (m.matches || []).some((x) => {
          if (norm(`${x.home}${x.away}`) !== key) return false;
          match = x;
          return true;
        }));
        openDetail({ match, signal });
      }
    } else if (data.sf) {
      state.sig = data.sf;
      renderSignals();
    }
  });

  $('#sort').addEventListener('change', (event) => {
    state.sort = event.target.value;
    renderOverview();
  });
  $('#dailyDate').addEventListener('change', (event) => loadDaily(event.target.value));
  $('#xReload').addEventListener('click', () => loadExchange(true));
  $('#sSort').addEventListener('change', (event) => {
    state.sSort = event.target.value;
    renderSignals();
  });
  $('#dlg').addEventListener('click', (event) => {
    if (event.target === $('#dlg')) $('#dlg').close();
  });
  $('#refresh').addEventListener('click', refresh);
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));
}

async function start() {
  bind();
  applyTheme('auto');
  show(location.hash.slice(1));
  await loadSnapshot();
  if (state.tab === 'simulation') await loadSimulation();
}

start();
