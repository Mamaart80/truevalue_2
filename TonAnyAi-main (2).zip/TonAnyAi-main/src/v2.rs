//! Bloc `v2` du snapshot : la forme exacte attendue par la nouvelle interface.
//!
//! Il n'est **exposé que si l'historisation est active** (au moins un relevé
//! en base) : sans série temporelle, il n'y a ni argent frais ni CLV, et
//! l'interface doit afficher « indisponible » plutôt qu'un bloc vide qui
//! ressemblerait à des zéros mesurés.
//!
//! Les clés de groupes sont celles du vocabulaire commun :
//! `issue|buts|btts|hcp|mt|score`. `score` n'apparaît jamais dans `mstat` ni
//! dans les propositions : un score exact ne se note pas.

use std::collections::{BTreeMap, HashSet};

use serde::Serialize;

use crate::enrich::parse_kickoff;
use crate::model::{SignalKind, Snapshot, TrackedSignal};
use crate::proposals::MarketGroup;
use crate::quality;
use crate::track::{outcome_label, StatsBundle};

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2 {
    /// Identifiant de signal → `steam|reversal|late|divergence|under|over|favorite|neutral`.
    pub kind: BTreeMap<String, String>,
    pub sig: BTreeMap<String, V2Signal>,
    pub mk: BTreeMap<String, V2Match>,
    pub mstat: BTreeMap<String, V2Stat>,
    pub perf: Vec<V2Perf>,
    pub hist: Vec<V2Hist>,
    pub quality: Vec<V2Quality>,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Signal {
    pub conf: String,
    pub fam: Vec<String>,
    pub f1: Option<f64>,
    pub f3: Option<f64>,
    pub in1: Option<f64>,
    pub in3: Option<f64>,
    pub q: V2Flag,
    pub proposals: Vec<V2Proposal>,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Flag {
    pub ok: bool,
    pub why: String,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Proposal {
    pub group: String,
    pub market: String,
    pub pick: String,
    pub share: f64,
    pub entry_odds: Option<f64>,
    pub authorized: bool,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Match {
    pub f: Option<f64>,
    pub d: String,
    pub ok: bool,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Stat {
    pub n: usize,
    pub hit: f64,
    pub roi: f64,
    pub clv: f64,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Perf {
    #[serde(rename = "type")]
    pub kind: String,
    pub n: usize,
    pub hit: f64,
    pub roi: f64,
    pub clv: f64,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Hist {
    pub t: String,
    pub mkt: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub odds: String,
    pub close: String,
    pub clv: Option<f64>,
    pub res: String,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct V2Quality {
    pub t: String,
    pub why: String,
}

fn stat(value: &crate::model::SignalStats) -> V2Stat {
    V2Stat {
        n: value.n,
        hit: value.hit_pct,
        roi: value.roi_pct,
        clv: value.clv_pct,
    }
}

fn odds_label(value: Option<f64>) -> String {
    value
        .map(|odds| format!("{odds:.2}"))
        .unwrap_or_else(|| "—".to_string())
}

/// Construit le bloc `v2` à partir du snapshot, de l'historique noté et des
/// résultats ESPN déjà filtrés sur les matchs flagués.
pub fn build(snapshot: &Snapshot, rows: &[TrackedSignal], stats: &StatsBundle) -> V2 {
    let mut v2 = V2::default();
    let now = parse_kickoff(&snapshot.computed_at);

    for signal in &snapshot.signals {
        v2.kind
            .insert(signal.id.clone(), signal.kind.key().to_string());
        v2.sig.insert(
            signal.id.clone(),
            V2Signal {
                conf: signal.confidence.label().to_string(),
                fam: signal.families.clone(),
                f1: signal.fresh.f1,
                f3: signal.fresh.f3,
                in1: signal.fresh.in1,
                in3: signal.fresh.in3,
                q: V2Flag {
                    ok: signal.quality.ok,
                    why: signal.quality.why(),
                },
                proposals: signal
                    .proposals
                    .iter()
                    .map(|proposal| V2Proposal {
                        group: proposal.group.key().to_string(),
                        market: proposal.market.clone(),
                        pick: proposal.pick.clone(),
                        share: proposal.share,
                        entry_odds: proposal.entry_odds,
                        authorized: proposal.authorized,
                    })
                    .collect(),
            },
        );
        v2.mk.entry(signal.fixture_key.clone()).or_insert(V2Match {
            f: signal.fresh.f1,
            d: signal.direction.clone(),
            ok: signal.quality.ok,
        });
    }

    for group in MarketGroup::PROPOSABLE {
        v2.mstat.insert(
            group.key().to_string(),
            stats.by_group.get(group.key()).map(stat).unwrap_or_default(),
        );
    }

    let mut perf: Vec<V2Perf> = stats
        .by_kind
        .iter()
        .filter(|(_, value)| value.n > 0)
        .map(|(key, value)| V2Perf {
            kind: SignalKind::from_key(key)
                .map(|kind| kind.label().to_string())
                .unwrap_or_else(|| key.clone()),
            n: value.n,
            hit: value.hit_pct,
            roi: value.roi_pct,
            clv: value.clv_pct,
        })
        .collect();
    perf.sort_by(|a, b| b.n.cmp(&a.n).then_with(|| a.kind.cmp(&b.kind)));
    v2.perf = perf;

    for row in rows {
        let kind = SignalKind::from_key(&row.kind)
            .map(|kind| kind.label().to_string())
            .unwrap_or_else(|| row.category.clone());
        for proposal in &row.proposals {
            if proposal.group == MarketGroup::Score {
                continue;
            }
            v2.hist.push(V2Hist {
                t: format!("{} — {}", row.home, row.away),
                mkt: format!("{} · {}", proposal.group.label_fr(), proposal.pick),
                kind: kind.clone(),
                odds: odds_label(proposal.entry_odds),
                close: odds_label(proposal.closing_odds),
                clv: proposal.clv_pct,
                res: outcome_label(proposal.outcome).to_string(),
            });
        }
        if v2.hist.len() >= 200 {
            break;
        }
    }

    let mut seen = HashSet::new();
    for market in &snapshot.markets {
        for m in &market.matches {
            let verdict = quality::assess(m, now);
            if verdict.ok {
                continue;
            }
            let title = format!("{} — {}", m.home, m.away);
            let why = verdict.why();
            if seen.insert((title.clone(), why.clone())) {
                v2.quality.push(V2Quality { t: title, why });
            }
        }
    }

    v2
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enrich::enrich;
    use crate::market::MarketKey;
    use crate::model::{MarketSnapshot, Source};
    use serde_json::json;

    fn row(home: &str, away: &str, extra: serde_json::Value) -> serde_json::Value {
        let mut base = json!({
            "home": home, "away": away, "league": "Premier League", "country": "eng",
            "date": "2026-11-09T22:00:00Z", "market_id": 91, "selection_id": 92
        });
        for (key, value) in extra.as_object().unwrap() {
            base[key] = value.clone();
        }
        base
    }

    fn market(key: MarketKey, rows: Vec<serde_json::Value>) -> MarketSnapshot {
        let matches = enrich(&rows, key, Source::Live, 0);
        MarketSnapshot {
            market: Some(key),
            key: key.slug().to_string(),
            label: key.def().label.to_string(),
            short: key.def().short.to_string(),
            total_volume: matches.iter().map(|m| m.total_volume).sum(),
            matches,
            source: Source::Live,
            updated_at: String::new(),
            error: None,
        }
    }

    fn snapshot() -> Snapshot {
        let one_ok = row(
            "Arsenal",
            "Chelsea",
            json!({"coef_1": 1.9, "coef_x": 3.7, "coef_2": 4.4,
                   "coef_1_new": 1.8, "coef_x_new": 3.7, "coef_2_new": 4.4,
                   "volume_1": 8000, "volume_x": 1200, "volume_2": 1500}),
        );
        let dnb_ok = row(
            "Arsenal",
            "Chelsea",
            json!({"coef_1": 1.4, "coef_2": 3.0, "coef_1_new": 1.38, "coef_2_new": 3.1,
                   "volume_1": 6000, "volume_2": 1200}),
        );
        // Pile ou face : aucune conviction, donc signal neutre.
        let one_flat = row(
            "Lyon",
            "Paris",
            json!({"coef_1": 2.6, "coef_x": 3.2, "coef_2": 2.9,
                   "coef_1_new": 2.6, "coef_x_new": 3.2, "coef_2_new": 2.9,
                   "volume_1": 5000, "volume_x": 3300, "volume_2": 3300}),
        );
        let dnb_flat = row(
            "Lyon",
            "Paris",
            json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                   "volume_1": 5000, "volume_2": 5000}),
        );
        let markets = vec![
            market(MarketKey::OneXTwo, vec![one_ok, one_flat]),
            market(MarketKey::DrawNoBet, vec![dnb_ok, dnb_flat]),
        ];
        let signals = crate::signals::compute(&markets, "2026-11-09T20:00:00Z");
        Snapshot {
            computed_at: "2026-11-09T20:00:00Z".to_string(),
            markets,
            signals,
            ..Default::default()
        }
    }

    #[test]
    fn v2_has_the_expected_shape() {
        let snapshot = snapshot();
        let block = build(&snapshot, &[], &StatsBundle::default());
        let value = serde_json::to_value(&block).expect("bloc sérialisable");

        assert_eq!(value["kind"]["sig_arsenal_vs_chelsea"], "favorite");
        // Pile ou face assumé : 3.8 pts d'écart implicite entre les deux
        // équipes, donc « match sans favori » plutôt que neutre.
        assert_eq!(value["kind"]["sig_lyon_vs_paris"], "even");
        let signal = &value["sig"]["sig_arsenal_vs_chelsea"];
        assert!(signal["conf"].is_string());
        assert!(signal["fam"].is_array());
        assert_eq!(signal["q"]["ok"], true);
        let proposals = signal["proposals"].as_array().expect("propositions");
        assert!(!proposals.is_empty());
        assert!(proposals.iter().all(|p| p["group"] != "score"));
        assert_eq!(value["mk"]["arsenal_vs_chelsea"]["d"], "domicile");

        // Les cinq groupes de suivi existent, le score n'est pas suivi.
        assert_eq!(value["mstat"]["issue"]["n"], 0);
        for group in ["issue", "buts", "btts", "hcp", "mt"] {
            assert!(value["mstat"][group].is_object(), "groupe {group}");
        }
        assert!(value["mstat"]["score"].is_null());
    }

    #[test]
    fn quality_list_names_the_rejected_fixture() {
        let snapshot = snapshot();
        let block = build(&snapshot, &[], &StatsBundle::default());
        // Aucun marché n'est incohérent dans ce snapshot : la liste est vide.
        assert!(block.quality.is_empty());
    }
}
