//! Prix réels Polymarket pour les rencontres signalées.
//!
//! Ce module ne calcule aucun prix : il lit le carnet public de Polymarket
//! (meilleur bid / meilleur ask) et le compare aux probabilités implicites de la
//! collecte Betfair. Rien n'est inventé : un événement introuvable reste
//! introuvable (`quote: None`) et une probabilité absente reste `null`.
//!
//! L'appariement se fait sur les noms d'équipes **et** sur l'horaire : une
//! rencontre qui revient la saison suivante porte le même intitulé, seule la
//! date distingue les deux événements.

use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant};

use chrono::{DateTime, NaiveDateTime, SecondsFormat, Utc};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::model::{FixtureMetrics, Play, Signal, SignalKind};
use crate::thresholds as th;

const SEARCH_URL: &str = "https://gamma-api.polymarket.com/public-search";
const EVENT_BASE: &str = "https://polymarket.com/event/";

/// Mots de forme qui ne distinguent pas deux équipes. Aucun nom de club n'y
/// figure : « Nacional », « City » ou « Real » identifient bien une équipe.
const STOPWORDS: [&str; 9] = ["fc", "cf", "club", "sc", "ac", "afc", "cd", "the", "sv"];

/// Prix d'une issue sur Polymarket (carnet, en probabilité 0-1).
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct OutcomeQuote {
    /// « 1 », « N » ou « 2 ».
    pub label: String,
    /// Milieu du carnet ; à défaut dernier prix traité, à défaut prix affiché.
    pub price: Option<f64>,
    pub bid: Option<f64>,
    pub ask: Option<f64>,
    pub spread: Option<f64>,
    /// Volume traité sur ce marché, en dollars.
    pub volume: Option<f64>,
    pub volume_24h: Option<f64>,
    /// Liquidité du carnet, en dollars.
    pub liquidity: Option<f64>,
    /// Variation du prix sur 24 h (en probabilité, pas en %).
    pub change_1d: Option<f64>,
}

/// Un événement Polymarket apparié à une rencontre.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EventQuote {
    pub slug: String,
    pub url: String,
    pub title: String,
    pub volume: Option<f64>,
    pub volume_24h: Option<f64>,
    pub volume_1wk: Option<f64>,
    pub liquidity: Option<f64>,
    /// Somme des positions ouvertes : l'argent actuellement en jeu, en dollars.
    pub open_interest: Option<f64>,
    pub outcomes: Vec<OutcomeQuote>,
}

/// Comparaison d'une issue : Betfair contre Polymarket.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SideCompare {
    pub side: String,
    /// Probabilité implicite normalisée de la collecte (%).
    pub betfair_pct: Option<f64>,
    /// Probabilité Polymarket (%).
    pub polymarket_pct: Option<f64>,
    /// `polymarket - betfair`, en points de pourcentage.
    pub gap_pp: Option<f64>,
}

/// Une ligne de l'onglet Exchange.
#[derive(Debug, Clone, Serialize)]
pub struct ExchangeRow {
    pub id: String,
    pub home: String,
    pub away: String,
    pub league: String,
    pub date: String,
    pub date_label: String,
    pub kind: String,
    pub kickoff_utc: Option<String>,
    pub quote: Option<EventQuote>,
    pub sides: Vec<SideCompare>,
    /// Au moins une issue s'écarte de `EXCHANGE_NOTABLE_GAP_PP` points.
    pub notable: bool,
    /// L'issue recommandée par le signal est aussi la favorite du carnet
    /// Polymarket. Faux quand le pari n'est pas un 1X2/DNB ou quand un prix
    /// manque : aucune confirmation n'est inventée.
    pub confirmed: bool,
    pub note: Option<String>,
}

// ---------------------------------------------------------------------------
// Normalisation et appariement (pur, testable)
// ---------------------------------------------------------------------------

fn deaccent(c: char) -> char {
    match c {
        'à' | 'á' | 'â' | 'ä' | 'ã' | 'å' => 'a',
        'ç' => 'c',
        'è' | 'é' | 'ê' | 'ë' => 'e',
        'ì' | 'í' | 'î' | 'ï' => 'i',
        'ñ' => 'n',
        'ò' | 'ó' | 'ô' | 'ö' | 'õ' | 'ø' => 'o',
        'ù' | 'ú' | 'û' | 'ü' => 'u',
        'ý' | 'ÿ' => 'y',
        'æ' => 'a',
        other => other,
    }
}

/// Minuscules, sans accents, sans ponctuation : « Saint-Martin » → « saint martin ».
pub fn normalize(raw: &str) -> String {
    let lowered = raw.to_lowercase();
    let mut out = String::with_capacity(lowered.len());
    for c in lowered.chars() {
        let c = deaccent(c);
        if c.is_ascii_alphanumeric() {
            out.push(c);
        } else if !out.ends_with(' ') {
            out.push(' ');
        }
    }
    out.trim().to_string()
}

/// Jetons significatifs d'un nom d'équipe (les mots de club sont écartés).
pub fn tokens(name: &str) -> Vec<String> {
    normalize(name)
        .split(' ')
        .filter(|t| t.len() > 2 && !STOPWORDS.contains(t))
        .map(str::to_string)
        .collect()
}

/// Heure du coup d'envoi (`2026-11-13 23:00:00`, UTC sans suffixe).
fn kickoff(raw: &str) -> Option<DateTime<Utc>> {
    let text = raw.trim();
    if let Ok(at) = DateTime::parse_from_rfc3339(text) {
        return Some(at.with_timezone(&Utc));
    }
    NaiveDateTime::parse_from_str(text, "%Y-%m-%d %H:%M:%S")
        .ok()
        .map(|naive| DateTime::<Utc>::from_naive_utc_and_offset(naive, Utc))
}

/// L'événement parle-t-il bien de cette rencontre, à cet horaire ?
pub fn event_matches(
    home: &str,
    away: &str,
    kickoff_at: Option<DateTime<Utc>>,
    title: &str,
    slug: &str,
    end: &str,
) -> bool {
    let home_tokens = tokens(home);
    let away_tokens = tokens(away);
    if home_tokens.is_empty() || away_tokens.is_empty() {
        return false;
    }
    let blob = format!("{} {}", normalize(title), normalize(slug));
    if !home_tokens.iter().all(|t| blob.contains(t)) {
        return false;
    }
    if !away_tokens.iter().all(|t| blob.contains(t)) {
        return false;
    }
    match (kickoff_at, DateTime::parse_from_rfc3339(end)) {
        (Some(at), Ok(end)) => {
            let delta = end.with_timezone(&Utc) - at;
            delta.num_hours().abs() <= th::EXCHANGE_MATCH_MAX_HOURS
        }
        // Sans l'un des deux horaires, l'appariement des noms reste la seule
        // preuve disponible : on l'accepte mais on ne prétend rien de plus.
        _ => true,
    }
}

fn num(value: Option<&Value>) -> Option<f64> {
    let value = value?;
    if let Some(n) = value.as_f64() {
        return Some(n);
    }
    value.as_str()?.trim().parse::<f64>().ok()
}

/// `outcomePrices` arrive tantôt en tableau, tantôt en chaîne JSON.
fn first_price(value: Option<&Value>) -> Option<f64> {
    let value = value?;
    match value {
        Value::Array(items) => num(items.first()),
        Value::String(text) => serde_json::from_str::<Value>(text)
            .ok()
            .as_ref()
            .and_then(|inner| first_price(Some(inner))),
        _ => None,
    }
}

fn outcome_quote(market: &Value, label: &str) -> OutcomeQuote {
    let bid = num(market.get("bestBid"));
    let ask = num(market.get("bestAsk"));
    let last = num(market.get("lastTradePrice"));
    let listed = first_price(market.get("outcomePrices"));
    // Le milieu du carnet est le prix qu'un opérateur peut espérer toucher ;
    // le dernier prix traité peut dater. On documente les deux.
    let price = match (bid, ask) {
        (Some(b), Some(a)) => Some((a + b) / 2.0),
        _ => last.or(listed),
    };
    OutcomeQuote {
        label: label.to_string(),
        price,
        bid,
        ask,
        spread: num(market.get("spread")),
        volume: num(market.get("volume")),
        volume_24h: num(market.get("volume24hr")),
        liquidity: num(market.get("liquidity")),
        change_1d: num(market.get("oneDayPriceChange")),
    }
}

fn event_side(question: &str, home: &[String], away: &[String]) -> Option<&'static str> {
    let q = normalize(question);
    if q.contains("draw") {
        return Some("N");
    }
    if home.iter().any(|t| q.contains(t)) {
        return Some("1");
    }
    if away.iter().any(|t| q.contains(t)) {
        return Some("2");
    }
    None
}

/// Extrait les prix 1X2 d'un événement Gamma (les marchés de buts sont ignorés :
/// ils portent leurs propres lignes et ne se comparent pas à un triplet 1X2).
pub fn parse_event(event: &Value, home: &str, away: &str) -> EventQuote {
    let home_tokens = tokens(home);
    let away_tokens = tokens(away);
    let mut outcomes: Vec<OutcomeQuote> = Vec::new();
    for market in event
        .get("markets")
        .and_then(Value::as_array)
        .map(Vec::as_slice)
        .unwrap_or(&[])
    {
        let question = market.get("question").and_then(Value::as_str).unwrap_or("");
        let Some(label) = event_side(question, &home_tokens, &away_tokens) else {
            continue;
        };
        if outcomes.iter().any(|o| o.label == label) {
            continue;
        }
        outcomes.push(outcome_quote(market, label));
    }
    outcomes.sort_by_key(|o| match o.label.as_str() {
        "1" => 0,
        "N" => 1,
        _ => 2,
    });

    let slug = event.get("slug").and_then(Value::as_str).unwrap_or("");
    EventQuote {
        slug: slug.to_string(),
        url: format!("{EVENT_BASE}{slug}"),
        title: event
            .get("title")
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_string(),
        volume: num(event.get("volume")),
        volume_24h: num(event.get("volume24hr")),
        volume_1wk: num(event.get("volume1wk")),
        liquidity: num(event.get("liquidity")),
        open_interest: num(event.get("openInterest")),
        outcomes,
    }
}

/// Vrai si Polymarket place l'issue recommandée en tête du carnet 1X2.
///
/// Seuls les paris 1X2 et DNB peuvent être confirmés : un total de buts ou un
/// BTTS n'a pas d'issue correspondante dans le triplet Polymarket. Les trois
/// prix doivent être présents ; un prix manquant ne vaut jamais confirmation.
pub fn confirms(play: &Play, sides: &[SideCompare]) -> bool {
    let index = match play {
        Play::MatchResult { side } | Play::DrawNoBet { side } => side.index(),
        _ => return false,
    };
    let mut prices: [Option<f64>; 3] = [None; 3];
    for side in sides {
        let idx = match side.side.as_str() {
            "1" => 0,
            "N" => 1,
            "2" => 2,
            _ => return false,
        };
        let Some(price) = side
            .polymarket_pct
            .filter(|price| price.is_finite() && *price > 0.0)
        else {
            return false;
        };
        if prices[idx].is_some() {
            return false;
        }
        prices[idx] = Some(price);
    }
    let [Some(home), Some(draw), Some(away)] = prices else {
        return false;
    };
    let best = home.max(draw).max(away);
    prices[index].is_some_and(|price| price >= best - 1e-9)
}

/// Écarts Betfair / Polymarket, toujours dans l'ordre 1, N, 2.
pub fn compare(metrics: &FixtureMetrics, quote: &EventQuote) -> Vec<SideCompare> {
    let betfair = [metrics.p_home, metrics.p_draw, metrics.p_away];
    ["1", "N", "2"]
        .into_iter()
        .enumerate()
        .map(|(index, side)| {
            let polymarket = quote
                .outcomes
                .iter()
                .find(|o| o.label == side)
                .and_then(|o| o.price)
                .map(|price| price * 100.0);
            let gap = match (betfair[index], polymarket) {
                (Some(left), Some(right)) => Some(right - left),
                _ => None,
            };
            SideCompare {
                side: side.to_string(),
                betfair_pct: betfair[index],
                polymarket_pct: polymarket,
                gap_pp: gap,
            }
        })
        .collect()
}

// ---------------------------------------------------------------------------
// Réseau et cache
// ---------------------------------------------------------------------------

fn encode(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len() * 3);
    for byte in raw.bytes() {
        if byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b'~') {
            out.push(byte as char);
        } else {
            out.push_str(&format!("%{byte:02X}"));
        }
    }
    out
}

/// Cache mémoire des réponses : une rencontre consultée par l'interface ne doit
/// pas interroger Polymarket à chaque rechargement.
pub struct Book {
    cache: Mutex<HashMap<String, (Instant, Option<EventQuote>)>>,
    ttl: Duration,
}

impl Book {
    pub fn new(ttl: Duration) -> Self {
        Self {
            cache: Mutex::new(HashMap::new()),
            ttl,
        }
    }

    fn fetch(
        &self,
        home: &str,
        away: &str,
        kickoff_at: Option<DateTime<Utc>>,
    ) -> Option<EventQuote> {
        let query = format!("{home} {away}");
        let url = format!("{SEARCH_URL}?q={}&limit_per_type=12", encode(&query));
        let response = ureq::get(&url)
            .set("User-Agent", "truevalue/0.1")
            .set("Accept", "application/json")
            .timeout(Duration::from_secs(th::EXCHANGE_TIMEOUT_SECS))
            .call()
            .ok()?;
        let payload: Value = response.into_json().ok()?;
        for event in payload.get("events").and_then(Value::as_array)? {
            if event
                .get("closed")
                .and_then(Value::as_bool)
                .unwrap_or(false)
            {
                continue;
            }
            let title = event.get("title").and_then(Value::as_str).unwrap_or("");
            let slug = event.get("slug").and_then(Value::as_str).unwrap_or("");
            let end = event.get("endDate").and_then(Value::as_str).unwrap_or("");
            if !event_matches(home, away, kickoff_at, title, slug, end) {
                continue;
            }
            return Some(parse_event(event, home, away));
        }
        None
    }

    /// Prix de la rencontre, avec cache. `None` = aucun événement apparié.
    pub fn quote(
        &self,
        key: &str,
        home: &str,
        away: &str,
        kickoff_at: Option<DateTime<Utc>>,
    ) -> Option<EventQuote> {
        if let Some((at, cached)) = self.cache.lock().unwrap().get(key) {
            if at.elapsed() < self.ttl {
                return cached.clone();
            }
        }
        let fetched = self.fetch(home, away, kickoff_at);
        self.cache
            .lock()
            .unwrap()
            .insert(key.to_string(), (Instant::now(), fetched.clone()));
        fetched
    }
}

/// Construit les lignes de l'onglet pour les rencontres à venir (ou en cours),
/// dans l'ordre du calendrier. Le nombre d'appels amont est borné.
pub fn rows(signals: &[Signal], book: &Book, max: usize) -> Vec<ExchangeRow> {
    let now = Utc::now();
    let mut picked: Vec<(&Signal, DateTime<Utc>)> = signals
        .iter()
        .filter(|signal| signal.kind != SignalKind::Neutral)
        .filter_map(|signal| kickoff(&signal.date).map(|at| (signal, at)))
        .filter(|(_, at)| {
            let ahead = (*at - now).num_hours();
            (-1..=th::EXCHANGE_HORIZON_HOURS).contains(&ahead)
        })
        .collect();
    picked.sort_by_key(|(_, at)| *at);
    picked.truncate(max);

    picked
        .into_iter()
        .map(|(signal, at)| {
            let quote = book.quote(&signal.fixture_key, &signal.home, &signal.away, Some(at));
            let sides = quote
                .as_ref()
                .map(|q| compare(&signal.metrics, q))
                .unwrap_or_default();
            let notable = sides.iter().any(|side| {
                side.gap_pp
                    .map(|gap| gap.abs() >= th::EXCHANGE_NOTABLE_GAP_PP)
                    .unwrap_or(false)
            });
            ExchangeRow {
                id: signal.id.clone(),
                home: signal.home.clone(),
                away: signal.away.clone(),
                league: signal.league.clone(),
                date: signal.date.clone(),
                date_label: signal.date_label.clone(),
                kind: signal.kind.key().to_string(),
                kickoff_utc: Some(at.to_rfc3339_opts(SecondsFormat::Secs, true)),
                note: quote
                    .is_none()
                    .then(|| "Aucun événement Polymarket apparié pour cette rencontre.".to_string()),
                confirmed: confirms(&signal.value.play, &sides),
                quote,
                sides,
                notable,
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn sample_event() -> Value {
        json!({
            "title": "Argentina vs. Uruguay",
            "slug": "fif-arg-ury-2026-11-13",
            "endDate": "2026-11-13T23:00:00Z",
            "closed": false,
            "volume": 38926.16,
            "volume24hr": 1200.0,
            "volume1wk": 30000.0,
            "liquidity": 378073.65,
            "openInterest": 51234.5,
            "markets": [
                {
                    "question": "Will Argentina win on 2026-11-13?",
                    "bestBid": 0.60,
                    "bestAsk": 0.61,
                    "spread": 0.01,
                    "volume": 30612.98,
                    "volume24hr": 18735.63,
                    "liquidity": 92555.34,
                    "oneDayPriceChange": -0.02,
                    "outcomePrices": "[\"0.605\", \"0.395\"]"
                },
                {
                    "question": "Will Argentina vs. Uruguay end in a draw?",
                    "bestBid": 0.24,
                    "bestAsk": 0.25,
                    "volume": 2101.66,
                    "liquidity": 125383.98,
                    "outcomePrices": ["0.245", "0.755"]
                },
                {
                    "question": "Will Uruguay win on 2026-11-13?",
                    "bestBid": 0.16,
                    "bestAsk": 0.17,
                    "volume": 6211.52,
                    "liquidity": 151183.03
                }
            ]
        })
    }

    #[test]
    fn tokens_drop_accents_and_club_words() {
        assert_eq!(tokens("Saint-Martin"), vec!["saint", "martin"]);
        // L'accent tombe, et seul le sigle de club est écarté.
        assert_eq!(tokens("Atlético Nacional FC"), vec!["atletico", "nacional"]);
        assert!(tokens("FC").is_empty());
    }

    #[test]
    fn a_draw_market_is_read_as_the_draw() {
        let event = sample_event();
        let quote = parse_event(&event, "Argentina", "Uruguay");
        let labels: Vec<&str> = quote.outcomes.iter().map(|o| o.label.as_str()).collect();
        assert_eq!(labels, vec!["1", "N", "2"]);
        // Milieu du carnet : (0.60 + 0.61) / 2.
        assert!((quote.outcomes[0].price.unwrap() - 0.605).abs() < 1e-9);
        assert_eq!(quote.open_interest, Some(51234.5));
        assert_eq!(quote.url, "https://polymarket.com/event/fif-arg-ury-2026-11-13");
    }

    #[test]
    fn matching_requires_both_teams_and_the_kickoff_window() {
        let at = kickoff("2026-11-13 23:00:00").unwrap();
        assert!(event_matches(
            "Argentina",
            "Uruguay",
            Some(at),
            "Argentina vs. Uruguay",
            "fif-arg-ury-2026-11-13",
            "2026-11-13T23:00:00Z"
        ));
        // Même affiche une autre saison : l'horaire ne colle pas.
        assert!(!event_matches(
            "Argentina",
            "Uruguay",
            Some(at),
            "Argentina vs. Uruguay",
            "fif-arg-ury-2025-03-16",
            "2025-03-16T13:30:00Z"
        ));
        // Un seul des deux noms : ce n'est pas la rencontre.
        assert!(!event_matches(
            "Argentina",
            "Uruguay",
            None,
            "Will Argentina win the World Cup?",
            "argentina-world-cup",
            ""
        ));
    }

    #[test]
    fn confirmation_requires_all_three_prices_and_the_same_favourite() {
        use crate::model::Slot;

        let sides = |prices: [Option<f64>; 3]| -> Vec<SideCompare> {
            ["1", "N", "2"]
                .into_iter()
                .zip(prices)
                .map(|(side, polymarket_pct)| SideCompare {
                    side: side.to_string(),
                    betfair_pct: Some(50.0),
                    polymarket_pct,
                    gap_pp: polymarket_pct.map(|price| price - 50.0),
                })
                .collect()
        };

        let quoted = sides([Some(60.0), Some(25.0), Some(15.0)]);
        assert!(confirms(&Play::MatchResult { side: Slot::First }, &quoted));
        assert!(confirms(&Play::DrawNoBet { side: Slot::First }, &quoted));
        assert!(!confirms(
            &Play::MatchResult { side: Slot::Second },
            &quoted
        ));
        assert!(!confirms(
            &Play::TotalGoals {
                line: 2.5,
                over: true
            },
            &quoted
        ));
        assert!(!confirms(
            &Play::MatchResult { side: Slot::First },
            &sides([Some(60.0), None, Some(15.0)])
        ));
    }

    #[test]
    fn comparison_keeps_absent_prices_absent() {
        let quote = parse_event(&sample_event(), "Argentina", "Uruguay");
        let metrics = FixtureMetrics {
            p_home: Some(55.0),
            p_draw: Some(25.0),
            p_away: None,
            ..Default::default()
        };
        let sides = compare(&metrics, &quote);
        assert_eq!(sides.len(), 3);
        assert!((sides[0].gap_pp.unwrap() - (60.5 - 55.0)).abs() < 1e-9);
        assert!((sides[1].gap_pp.unwrap() - (24.5 - 25.0)).abs() < 1e-9);
        // Sans probabilité Betfair, l'écart n'existe pas.
        assert_eq!(sides[2].gap_pp, None);
        assert!(sides[2].polymarket_pct.is_some());
    }
}
