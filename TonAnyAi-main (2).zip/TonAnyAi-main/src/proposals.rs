//! Propositions par groupe de marché (« issue », « buts », « btts », « hcp »,
//! « mt ») — une seule logique, côté moteur.
//!
//! L'interface recalculait auparavant les propositions à partir des marchés du
//! signal ; le calcul vit désormais ici, et `Site · /api/snapshot` expose le
//! résultat tel quel.
//!
//! Règle : pour chaque groupe, on retient le marché dont la **conviction**
//! (part dominante − part neutre de la forme du marché) est la plus forte. Une
//! proposition n'existe que si cette conviction atteint
//! `MIN_PROPOSAL_CONVICTION` et si le marché passe le filtre qualité. Le groupe
//! `score` n'en produit jamais : un score exact n'est pas un pari suivi.
//!
//! `authorized` est faux par défaut : parier exige que **le groupe** et **le
//! type de signal** aient chacun un échantillon suffisant *et* un CLV moyen
//! positif. Tant que l'historique est vide, tout est donc en observation.

use std::collections::{HashMap, HashSet};

use serde::{Deserialize, Serialize};

use crate::fresh::selection_key;
use crate::market::{MarketKey, MarketShape};
use crate::model::{BetOutcome, Match, Play, SignalKind, SignalStats, Slot};
use crate::thresholds as th;

/// Groupes de marchés exposés à l'interface (clés exactes).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MarketGroup {
    Issue,
    Buts,
    Btts,
    Hcp,
    Mt,
    Score,
}

impl MarketGroup {
    /// Groupes qui peuvent porter une proposition, dans l'ordre d'affichage.
    pub const PROPOSABLE: [MarketGroup; 5] = [
        MarketGroup::Issue,
        MarketGroup::Buts,
        MarketGroup::Btts,
        MarketGroup::Hcp,
        MarketGroup::Mt,
    ];

    pub fn key(self) -> &'static str {
        match self {
            MarketGroup::Issue => "issue",
            MarketGroup::Buts => "buts",
            MarketGroup::Btts => "btts",
            MarketGroup::Hcp => "hcp",
            MarketGroup::Mt => "mt",
            MarketGroup::Score => "score",
        }
    }

    /// Libellé français (vocabulaire commun de l'interface).
    pub fn label_fr(self) -> &'static str {
        match self {
            MarketGroup::Issue => "Issue du match",
            MarketGroup::Buts => "Buts",
            MarketGroup::Btts => "Les deux marquent",
            MarketGroup::Hcp => "Handicap (DNB)",
            MarketGroup::Mt => "Mi-temps",
            MarketGroup::Score => "Score exact",
        }
    }

    pub fn markets(self) -> &'static [MarketKey] {
        match self {
            MarketGroup::Issue => &[MarketKey::OneXTwo, MarketKey::DoubleChance],
            MarketGroup::Buts => &[
                MarketKey::OverUnder15,
                MarketKey::OverUnder25,
                MarketKey::OverUnder35,
            ],
            MarketGroup::Btts => &[MarketKey::Btts],
            MarketGroup::Hcp => &[MarketKey::DrawNoBet],
            MarketGroup::Mt => &[MarketKey::HalfTime],
            MarketGroup::Score => &[MarketKey::CorrectScore, MarketKey::HalfTimeFullTime],
        }
    }

    /// Le marché appartient-il au groupe ?
    pub fn contains(self, key: MarketKey) -> bool {
        self.markets().contains(&key)
    }

    pub fn of(key: MarketKey) -> Option<MarketGroup> {
        MarketGroup::PROPOSABLE
            .into_iter()
            .find(|g| g.contains(key))
            .or_else(|| MarketGroup::Score.contains(key).then_some(MarketGroup::Score))
    }
}

/// Une proposition de pari pour un groupe de marché.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Proposal {
    pub group: MarketGroup,
    /// Marché retenu (`1X2`, `+/- 2.5`, `BTTS`, `DNB`, `Mi-temps`).
    pub market: String,
    /// Libellé du pari (« Extérieur », « Moins de 2.5 », « Non »…).
    pub pick: String,
    /// Part de volume de l'issue retenue (%).
    pub share: f64,
    /// Cote à la première détection (cote d'entrée du ROI).
    pub entry_odds: Option<f64>,
    /// Probabilité implicite sans marge à l'entrée (0-1), pour le CLV ajusté.
    #[serde(default)]
    pub entry_novig: Option<f64>,
    /// Clé de la série historique de la sélection (pour retrouver la clôture).
    #[serde(default)]
    pub series_key: String,
    /// Marché d'où vient la proposition (utile au rendu et à la notation).
    #[serde(default)]
    pub market_key: Option<MarketKey>,
    /// Pari typé : la notation ne dépend pas d'une recherche de texte.
    #[serde(default)]
    pub play: Play,
    /// Vrai seulement si groupe **et** type de signal sont validés par
    /// l'historique (échantillon suffisant + CLV moyen positif).
    pub authorized: bool,
    #[serde(default)]
    pub closing_odds: Option<f64>,
    #[serde(default)]
    pub closing_novig: Option<f64>,
    #[serde(default)]
    pub clv_pct: Option<f64>,
    #[serde(default)]
    pub clv_novig_pct: Option<f64>,
    #[serde(default)]
    pub outcome: BetOutcome,
    #[serde(default)]
    pub explanation: String,
}

impl Proposal {
    /// CLV = cote d'entrée / cote de clôture − 1, en %.
    pub fn clv(entry: Option<f64>, closing: Option<f64>) -> Option<f64> {
        match (entry, closing) {
            (Some(entry), Some(closing)) if entry > 1.0 && closing > 1.0 => {
                Some(((entry / closing - 1.0) * 1000.0).round() / 10.0)
            }
            _ => None,
        }
    }

    /// CLV sans marge : probabilité sans marge à l'entrée / à la clôture − 1.
    pub fn clv_novig(entry: Option<f64>, closing: Option<f64>) -> Option<f64> {
        match (entry, closing) {
            (Some(entry), Some(closing)) if entry > 0.0 && closing > 0.0 => {
                Some(((entry / closing - 1.0) * 1000.0).round() / 10.0)
            }
            _ => None,
        }
    }

    /// Renseigne la clôture et met à jour les CLV. Ne touche jamais à la cote
    /// d'entrée : le ROI doit rester reproductible.
    pub fn set_closing(&mut self, closing: Option<f64>, closing_novig: Option<f64>) {
        self.closing_odds = closing;
        self.closing_novig = closing_novig;
        self.clv_pct = Proposal::clv(self.entry_odds, closing);
        self.clv_novig_pct = Proposal::clv_novig(self.entry_novig, closing_novig);
    }
}

/// Historique agrégé, injecté dans le moteur pour décider `authorized`.
#[derive(Debug, Clone, Default)]
pub struct Authorizer {
    pub by_group: HashMap<String, SignalStats>,
    pub by_kind: HashMap<String, SignalStats>,
}

impl Authorizer {
    pub fn authorized(&self, group: MarketGroup, kind: SignalKind) -> bool {
        let Some(group_stats) = self.by_group.get(group.key()) else {
            return false;
        };
        let Some(kind_stats) = self.by_kind.get(kind.key()) else {
            return false;
        };
        group_stats.sample_sufficient()
            && group_stats.clv_pct > 0.0
            && kind_stats.sample_sufficient()
            && kind_stats.clv_pct > 0.0
    }
}

/// Conviction d'un marché : part dominante moins la part neutre de sa forme.
pub fn conviction(m: &Match) -> f64 {
    (m.dominant_share - m.market.def().neutral_share()).max(0.0)
}

fn no_vig(m: &Match, slot: usize) -> Option<f64> {
    no_vig_from_coefs(&m.coef_new, slot)
}

/// Probabilité implicite sans marge d'une issue, à partir des cotes du marché.
pub fn no_vig_from_coefs(coef: &[f64; 3], slot: usize) -> Option<f64> {
    if slot >= 3 || coef[slot] <= 1.0 {
        return None;
    }
    let inv: f64 = coef.iter().filter(|c| **c > 1.0).map(|c| 1.0 / c).sum();
    // Une cote manquante sur une issue d'un marché à trois issues gonflerait
    // la probabilité de l'issue retenue et donc le CLV (et l'autorisation).
    // La somme des implicites doit rester dans la plage qualité (>= 98 %).
    if inv * 100.0 < crate::thresholds::OVERROUND_MIN_PCT {
        return None;
    }
    Some((1.0 / coef[slot]) / inv)
}

/// Index de l'issue portée par un pari, quand il y en a une.
pub fn slot_of_play(play: &Play) -> Option<usize> {
    match play {
        Play::MatchResult { side } | Play::DrawNoBet { side } => Some(side.index()),
        Play::TotalGoals { over, .. } => Some(if *over { 2 } else { 0 }),
        Play::Btts { yes } => Some(if *yes { 0 } else { 2 }),
        Play::DoubleChance { home, away } => match (*home, *away) {
            (true, false) => Some(0),
            (false, true) => Some(1),
            (true, true) => Some(2),
            (false, false) => None,
        },
        Play::ExactScore { .. } | Play::NoBet => None,
    }
}

fn slot_of(m: &Match) -> Slot {
    m.dominant
}

fn pick_label(m: &Match) -> String {
    let slot = slot_of(m).index();
    match m.market {
        MarketKey::OneXTwo => ["Domicile", "Nul", "Extérieur"][slot].to_string(),
        MarketKey::DoubleChance => ["1X", "X2", "12"][slot].to_string(),
        MarketKey::OverUnder15 => ["Moins de 1.5", "Moins de 1.5", "Plus de 1.5"][slot].to_string(),
        MarketKey::OverUnder25 => ["Moins de 2.5", "Moins de 2.5", "Plus de 2.5"][slot].to_string(),
        MarketKey::OverUnder35 => ["Moins de 3.5", "Moins de 3.5", "Plus de 3.5"][slot].to_string(),
        MarketKey::Btts => ["Oui", "Non", "Non"][slot].to_string(),
        MarketKey::DrawNoBet => ["Domicile (DNB)", "Domicile (DNB)", "Extérieur (DNB)"][slot]
            .to_string(),
        MarketKey::HalfTime => ["Domicile (MT)", "Nul (MT)", "Extérieur (MT)"][slot].to_string(),
        MarketKey::CorrectScore | MarketKey::HalfTimeFullTime => m.dominant_label.clone(),
    }
}

fn play_of(m: &Match) -> Play {
    let slot = slot_of(m);
    match m.market {
        MarketKey::OneXTwo => Play::MatchResult { side: slot },
        // `slot_of_play` relit (home, away) : (true,false)=1X, (false,true)=X2,
        // (true,true)=12. L'ancienne formule transformait le « 12 » en « X2 »,
        // ce qui faussait la notation, la clôture et le CLV.
        MarketKey::DoubleChance => Play::DoubleChance {
            home: slot != Slot::Draw,
            away: slot != Slot::First,
        },
        MarketKey::OverUnder15 => Play::TotalGoals {
            line: 1.5,
            over: slot != Slot::First,
        },
        MarketKey::OverUnder25 => Play::TotalGoals {
            line: 2.5,
            over: slot != Slot::First,
        },
        MarketKey::OverUnder35 => Play::TotalGoals {
            line: 3.5,
            over: slot != Slot::First,
        },
        MarketKey::Btts => Play::Btts {
            yes: slot == Slot::First,
        },
        MarketKey::DrawNoBet => Play::DrawNoBet { side: slot },
        // La mi-temps est notée avec le score à la mi-temps, jamais avec le
        // score final : le type reste `MatchResult`, le groupe décide.
        MarketKey::HalfTime => Play::MatchResult { side: slot },
        MarketKey::CorrectScore | MarketKey::HalfTimeFullTime => Play::NoBet,
    }
}

/// Construit les propositions d'un signal à partir des marchés exploitables.
///
/// `usable` contient les marchés qui passent le filtre qualité ; les autres
/// restent visibles dans le signal mais ne peuvent pas porter de proposition.
pub fn build(
    markets: &HashMap<MarketKey, Match>,
    usable: &HashSet<MarketKey>,
    kind: SignalKind,
    authorizer: &Authorizer,
) -> Vec<Proposal> {
    if !kind.tradable() {
        return Vec::new();
    }

    let mut out = Vec::new();
    for group in MarketGroup::PROPOSABLE {
        let best = group
            .markets()
            .iter()
            .filter(|key| usable.contains(key))
            .filter_map(|key| markets.get(key))
            .filter(|m| m.shape != MarketShape::Multi)
            .max_by(|a, b| {
                conviction(a)
                    .partial_cmp(&conviction(b))
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| b.total_volume.total_cmp(&a.total_volume))
            });
        let Some(m) = best else { continue };
        if conviction(m) < th::MIN_PROPOSAL_CONVICTION {
            continue;
        }
        let slot = slot_of(m).index();
        let entry_odds = (m.coef_new[slot] > th::MIN_TRADABLE_ODDS).then_some(m.coef_new[slot]);
        out.push(Proposal {
            group,
            market: m.market.def().short.to_string(),
            pick: pick_label(m),
            share: (m.dominant_share * 10.0).round() / 10.0,
            entry_odds,
            entry_novig: no_vig(m, slot),
            series_key: selection_key(m.market, m.market_id, m.selection_id),
            market_key: Some(m.market),
            play: play_of(m),
            authorized: authorizer.authorized(group, kind),
            closing_odds: None,
            closing_novig: None,
            clv_pct: None,
            clv_novig_pct: None,
            outcome: BetOutcome::Pending,
            explanation: String::new(),
        });
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enrich::enrich;
    use crate::model::Source;
    use serde_json::json;

    fn market(key: MarketKey, extra: serde_json::Value) -> Match {
        let mut base = json!({
            "home": "A", "away": "B", "league": "L", "country": "eng",
            "date": "2026-11-12T19:45:00Z", "market_id": 10, "selection_id": 20
        });
        for (k, v) in extra.as_object().unwrap() {
            base[k] = v.clone();
        }
        enrich(&[base], key, Source::Live, 0).remove(0)
    }

    #[test]
    fn double_chance_12_is_not_mistaken_for_x2() {
        let mut m = market(
            MarketKey::DoubleChance,
            json!({
                "coef_1": 1.3, "coef_x": 5.0, "coef_2": 2.1,
                "coef_1_new": 1.3, "coef_x_new": 5.0, "coef_2_new": 2.1,
                "volume_1": 8000, "volume_x": 100, "volume_2": 6000
            }),
        );
        m.dominant = Slot::Second;
        let play = play_of(&m);
        assert_eq!(pick_label(&m), "12");
        assert_eq!(slot_of_play(&play), Some(2));
        assert!(matches!(
            play,
            Play::DoubleChance {
                home: true,
                away: true
            }
        ));
    }

    #[test]
    fn one_proposal_per_group_and_never_for_score() {
        let mut markets = HashMap::new();
        markets.insert(
            MarketKey::OneXTwo,
            market(
                MarketKey::OneXTwo,
                json!({"coef_1": 1.5, "coef_x": 4.2, "coef_2": 6.0,
                       "coef_1_new": 1.45, "coef_x_new": 4.4, "coef_2_new": 6.5,
                       "volume_1": 9000, "volume_x": 1200, "volume_2": 800}),
            ),
        );
        markets.insert(
            MarketKey::OverUnder25,
            market(
                MarketKey::OverUnder25,
                json!({"coef_1": 2.2, "coef_2": 1.7,
                       "coef_1_new": 2.1, "coef_2_new": 1.75,
                       "volume_1": 3000, "volume_2": 7000}),
            ),
        );
        let usable: HashSet<MarketKey> = markets.keys().copied().collect();
        let proposals = build(
            &markets,
            &usable,
            SignalKind::Over,
            &Authorizer::default(),
        );
        assert_eq!(proposals.len(), 2, "{proposals:?}");
        assert_eq!(proposals[0].group, MarketGroup::Issue);
        assert_eq!(proposals[0].pick, "Domicile");
        assert!(proposals.iter().all(|p| !p.authorized), "défaut = non autorisé");
        assert!(proposals.iter().all(|p| p.group != MarketGroup::Score));
    }

    #[test]
    fn a_market_below_the_conviction_threshold_produces_nothing() {
        let mut markets = HashMap::new();
        markets.insert(
            MarketKey::Btts,
            market(
                MarketKey::Btts,
                json!({"coef_1": 1.9, "coef_2": 1.95,
                       "coef_1_new": 1.9, "coef_2_new": 1.95,
                       "volume_1": 5200, "volume_2": 4800}),
            ),
        );
        let usable: HashSet<MarketKey> = markets.keys().copied().collect();
        assert!(build(&markets, &usable, SignalKind::Over, &Authorizer::default()).is_empty());
    }

    #[test]
    fn a_rejected_market_cannot_carry_a_proposal() {
        let mut markets = HashMap::new();
        markets.insert(
            MarketKey::OneXTwo,
            market(
                MarketKey::OneXTwo,
                json!({"coef_1": 1.5, "coef_x": 4.2, "coef_2": 6.0,
                       "coef_1_new": 1.45, "coef_x_new": 4.4, "coef_2_new": 6.5,
                       "volume_1": 9000, "volume_x": 1200, "volume_2": 800}),
            ),
        );
        let proposals = build(
            &markets,
            &HashSet::new(),
            SignalKind::Favorite,
            &Authorizer::default(),
        );
        assert!(proposals.is_empty());
    }

    #[test]
    fn authorization_needs_both_sample_and_positive_clv() {
        let mut authorizer = Authorizer::default();
        authorizer.by_group.insert(
            "issue".into(),
            SignalStats {
                n: 400,
                hit_pct: 52.0,
                roi_pct: 3.0,
                clv_pct: 1.8,
            },
        );
        // Type de signal jamais observé : pas d'autorisation.
        assert!(!authorizer.authorized(MarketGroup::Issue, SignalKind::Steam));
        authorizer.by_kind.insert(
            "steam".into(),
            SignalStats {
                n: 40,
                hit_pct: 51.0,
                roi_pct: 1.0,
                clv_pct: 0.4,
            },
        );
        assert!(authorizer.authorized(MarketGroup::Issue, SignalKind::Steam));
        // CLV négatif : on ne parle pas d'autorisation.
        authorizer.by_kind.insert(
            "late".into(),
            SignalStats {
                n: 400,
                hit_pct: 51.0,
                roi_pct: -1.0,
                clv_pct: -0.8,
            },
        );
        assert!(!authorizer.authorized(MarketGroup::Issue, SignalKind::Late));
    }

    #[test]
    fn clv_maths() {
        assert_eq!(Proposal::clv(Some(1.80), Some(1.84)), Some(-2.2));
        assert_eq!(Proposal::clv(Some(2.0), None), None);
        assert_eq!(Proposal::clv_novig(Some(0.55), Some(0.5)), Some(10.0));
    }
}
