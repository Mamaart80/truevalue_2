//! Point d'entrée CLI : `serve`, `refresh`, `snapshot`, `check`.

use std::path::Path;
use std::sync::Arc;

use truevalue::config::Config;
use truevalue::pipeline::{summarize, Pipeline};

fn load_dotenv() {
    let Ok(raw) = std::fs::read_to_string(Path::new(".env")) else {
        return;
    };
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        if std::env::var_os(key).is_some() {
            continue;
        }
        let value = value.trim().trim_matches('"').trim_matches('\'');
        std::env::set_var(key, value);
    }
}

fn main() {
    load_dotenv();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let command = args.first().map(String::as_str).unwrap_or("serve");

    let config = Config::from_env();
    if let Err(err) = std::fs::create_dir_all(&config.data_dir) {
        eprintln!("Impossible de créer {} : {err}", config.data_dir.display());
        std::process::exit(1);
    }
    let pipeline = Arc::new(Pipeline::new(config.clone()));
    if let Err(err) = pipeline.store.ensure_schema() {
        // Quota journalier D1 épuisé : ce n'est pas un schéma partiel, c'est
        // une panne temporaire de facturation. Refuser de démarrer laissait le
        // tableau de bord inaccessible jusqu'à minuit UTC ; on sert le dernier
        // snapshot connu et la persistance reprend d'elle-même.
        if pipeline
            .store
            .d1_usage()
            .map(|usage| usage.blocked)
            .unwrap_or(false)
        {
            eprintln!(
                "Quota D1 journalier épuisé : démarrage en mode dégradé \
                 (persistance suspendue jusqu'à minuit UTC)."
            );
        } else {
            eprintln!("Stockage impossible à initialiser ({err}) : arrêt pour éviter d'écrire dans un schéma partiel.");
            std::process::exit(1);
        }
    }

    match command {
        "serve" => {
            // Un tableau de bord sans mot de passe rend toutes les routes
            // publiques. Refusé en démarrage normal ; `ALLOW_UNAUTHENTICATED=1`
            // est l'échappatoire explicite pour le développement local.
            if !config.auth_required()
                && std::env::var("ALLOW_UNAUTHENTICATED").ok().as_deref() != Some("1")
            {
                eprintln!(
                    "Refus de démarrer sans DASHBOARD_PASSWORD : le tableau de bord serait public.\n\
                     Définissez DASHBOARD_PASSWORD, ou ALLOW_UNAUTHENTICATED=1 pour un usage local."
                );
                std::process::exit(1);
            }
            if config.refresh_token.is_none() {
                eprintln!(
                    "Attention : REFRESH_TOKEN absent, le cron ne pourra pas appeler /api/refresh."
                );
            }
            println!(
                "Truevalue — port {} · stockage {} · auth {}",
                config.port,
                pipeline.store.mode(),
                if config.auth_required() {
                    "activée"
                } else {
                    "désactivée"
                }
            );
            if let Err(err) = truevalue::web::serve(pipeline, 4) {
                eprintln!("Serveur arrêté : {err}");
                std::process::exit(1);
            }
        }
        "refresh" => match pipeline.refresh(true) {
            Ok(snapshot) => {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&summarize(&snapshot)).unwrap_or_default()
                );
                for warning in &snapshot.warnings {
                    eprintln!("⚠ {warning}");
                }
            }
            Err(err) => {
                eprintln!("Collecte échouée : {err}");
                std::process::exit(1);
            }
        },
        "snapshot" => match pipeline.snapshot() {
            Some(snapshot) => println!(
                "{}",
                serde_json::to_string_pretty(&summarize(&snapshot)).unwrap_or_default()
            ),
            None => {
                println!("Aucun snapshot : lancez `truevalue refresh`.");
                std::process::exit(1);
            }
        },
        "check" => {
            println!("mode de stockage : {}", pipeline.store.mode());
            println!("cloudflare prêt  : {}", config.cloudflare_ready());
            println!("auth             : {}", config.auth_required());
            println!("dossier données  : {}", config.data_dir.display());
            match pipeline.snapshot() {
                Some(s) => println!(
                    "snapshot         : {} ({} signaux)",
                    s.computed_at,
                    s.signals.len()
                ),
                None => println!("snapshot         : absent"),
            }
        }
        "help" | "--help" | "-h" => {
            println!(
                "Usage : truevalue [serve|refresh|snapshot|check]\n\
                 serve     démarre l'API + le tableau de bord (défaut)\n\
                 refresh   collecte Arbworld, calcule les signaux, note les paris\n\
                 snapshot  résume le dernier snapshot persisté\n\
                 check     affiche la configuration effective"
            );
        }
        other => {
            eprintln!("Commande inconnue : {other} (voir `truevalue help`)");
            std::process::exit(2);
        }
    }
}
