//! Filtre qualité des données, appliqué avant tout calcul de signal.
//!
//! Un marché rejeté reste **visible** dans le snapshot (avec un badge et ses
//! raisons), mais il ne peut ni déclencher ni confirmer un signal : une cote
//! incohérente produirait un faux raisonnement parfaitement présenté.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::enrich::parse_kickoff;
use crate::market::{MarketKey, MarketShape};
use crate::model::Match;
use crate::thresholds as th;

/// Verdict qualité d'un marché : `ok` et les raisons du rejet.
///
/// `reasons` est vide quand `ok` est vrai : l'absence de raison n'est pas une
/// donnée inventée, c'est l'absence de défaut constaté.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Quality {
    pub ok: bool,
    pub reasons: Vec<String>,
}

impl Default for Quality {
    fn default() -> Self {
        Quality::ok()
    }
}

impl Quality {
    pub fn ok() -> Self {
        Quality {
            ok: true,
            reasons: Vec::new(),
        }
    }

    pub fn rejected(reasons: Vec<String>) -> Self {
        Quality {
            ok: false,
            reasons,
        }
    }

    /// Version courte pour l'affichage (`quality.why`).
    pub fn why(&self) -> String {
        self.reasons.join(" · ")
    }
}

/// Un marché dont la somme des 1/cote doit former une partition.
///
/// La double chance (1X, X2, 12 se recouvrent) et les marchés multi-issues
/// (distribution partielle) en sont exclus : leur somme n'a pas de sens.
pub fn is_partition(m: &Match) -> bool {
    m.market != MarketKey::DoubleChance && m.shape != MarketShape::Multi
}

/// Contrôle les quatre familles de défauts : partition, cotes aberrantes,
/// fraîcheur, liquidité.
pub fn assess(m: &Match, now: Option<DateTime<Utc>>) -> Quality {
    let mut reasons = Vec::new();

    if is_partition(m) {
        let inv: f64 = m
            .coef_new
            .iter()
            .filter(|c| **c > 1.0)
            .map(|c| 1.0 / c)
            .sum();
        if inv > 0.0 {
            let pct = inv * 100.0;
            if !(th::OVERROUND_MIN_PCT..=th::OVERROUND_MAX_PCT).contains(&pct) {
                reasons.push(format!(
                    "somme des 1/cote à {pct:.1} % (attendu {:.0}–{:.0} %)",
                    th::OVERROUND_MIN_PCT,
                    th::OVERROUND_MAX_PCT
                ));
            }
        }
    }

    let odds = m.coef_new[m.dominant_index];
    if odds <= 0.0 {
        reasons.push("cote absente sur l'issue dominante".to_string());
    } else if odds < th::ABERRANT_ODDS_MIN || odds > th::ABERRANT_ODDS_MAX {
        reasons.push(format!(
            "cote {odds:.2} aberrante sur {} (plage {}–{:.0})",
            m.dominant_label, th::ABERRANT_ODDS_MIN, th::ABERRANT_ODDS_MAX
        ));
    }

    // Une date absente n'est pas un défaut : la donnée est simplement inconnue.
    if let (Some(updated), Some(now)) = (parse_kickoff(&m.last_update), now) {
        let age = (now - updated).num_minutes();
        if age > th::MAX_DATA_AGE_MINUTES {
            reasons.push(format!(
                "dernière mise à jour il y a {age} min (max {})",
                th::MAX_DATA_AGE_MINUTES
            ));
        }
    }

    if m.total_volume < th::QUALITY_MIN_VOLUME {
        reasons.push(format!(
            "volume {:.0} £ sous le seuil de liquidité ({:.0} £)",
            m.total_volume,
            th::QUALITY_MIN_VOLUME
        ));
    }

    if reasons.is_empty() {
        Quality::ok()
    } else {
        Quality::rejected(reasons)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enrich::enrich;
    use crate::model::Source;
    use serde_json::json;

    fn row(coefs: [f64; 3], volumes: [f64; 3]) -> Match {
        let raw = json!({
            "home": "Stevenage", "away": "Mansfield", "league": "League One",
            "country": "eng", "date": "2026-11-12T19:45:00Z",
            "market_id": 1, "selection_id": 2,
            "coef_1": coefs[0], "coef_x": coefs[1], "coef_2": coefs[2],
            "coef_1_new": coefs[0], "coef_x_new": coefs[1], "coef_2_new": coefs[2],
            "volume_1": volumes[0], "volume_x": volumes[1], "volume_2": volumes[2]
        });
        enrich(&[raw], MarketKey::OneXTwo, Source::Live, 0)
            .remove(0)
    }

    #[test]
    fn stevenage_mansfield_is_rejected() {
        // 1.56 / 1.21 / 1.26 : somme des 1/cote = 2.26, impossible pour un 1X2.
        let m = row([1.56, 1.21, 1.26], [4000.0, 2000.0, 3000.0]);
        let q = assess(&m, None);
        assert!(!q.ok, "le marché doit être rejeté");
        assert!(
            q.why().contains("1/cote"),
            "raison attendue sur la partition, reçue : {}",
            q.why()
        );
    }

    #[test]
    fn tavernes_valencia_is_rejected_for_aberrant_odds() {
        // 50.0 / 44.0 / 1.01 : l'issue dominante vaut 1.01, ce n'est pas un prix.
        let m = row([50.0, 44.0, 1.01], [200.0, 200.0, 9000.0]);
        let q = assess(&m, None);
        assert!(!q.ok);
        assert!(
            q.why().contains("aberrante"),
            "raison attendue sur la cote, reçue : {}",
            q.why()
        );
    }

    #[test]
    fn a_coherent_market_passes() {
        let m = row([1.90, 3.60, 4.20], [9000.0, 2500.0, 2000.0]);
        assert_eq!(assess(&m, None), Quality::ok());
    }

    #[test]
    fn a_thin_market_is_rejected() {
        let m = row([1.90, 3.60, 4.20], [120.0, 40.0, 30.0]);
        let q = assess(&m, None);
        assert!(!q.ok);
        assert!(q.why().contains("volume"), "{}", q.why());
    }
}
