//! Orchestration : un cycle de collecte, puis notation des signaux ouverts.
//!
//! Le tableau de bord ne déclenche jamais ce cycle en lecture : il lit le
//! snapshot persisté. Seuls `POST /api/refresh` et le cron Cloudflare collectent.

use std::sync::Mutex;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use chrono::{DateTime, SecondsFormat, Utc};
use serde::Serialize;
use serde_json::Value;

use crate::config::Config;
use crate::daily::{self, MatchLogRow};
use crate::enrich::{enrich, parse_kickoff};
use crate::espn::{self, ResultsClient};
use crate::market::MarketKey;
use crate::model::{
    BetOutcome, Confidence, MarketSnapshot, MatchResult, MatchState, Signal, Snapshot,
    TrackedSignal,
};
use crate::proposals::{self, no_vig_from_coefs};
use crate::scrape::{user_agent, Scraper};
use crate::signals;
use crate::simulation::{self, SimPosition};
use crate::sportscore::{self, SportScoreClient};
use crate::storage::{SnapshotRow, Store};
use crate::thresholds as th;

/// Prochaine collecte planifiée : cadence adaptative + jitter.
#[derive(Debug, Clone, Serialize)]
pub struct ScheduleInfo {
    pub due_in_secs: u64,
    pub next_at: String,
    /// Vrai si une rencontre est en cours ou démarre dans la fenêtre active.
    pub active_window: bool,
}

#[derive(Debug, Clone, Copy)]
struct NextCollection {
    at: Instant,
    active_window: bool,
}

/// Résumé de la proposition de tête, recopié dans les colonnes historiques de
/// `signals` (compatibilité) et dans le CLV du signal.
#[derive(Debug, Clone)]
struct Headline {
    outcome: BetOutcome,
    explanation: String,
    closing: Option<f64>,
    clv: Option<f64>,
    clv_novig: Option<f64>,
}

pub struct Pipeline {
    pub cfg: Config,
    pub store: Store,
    scraper: Scraper,
    results: ResultsClient,
    /// Scores de secours pour les compétitions absentes d'ESPN.
    sportscore: SportScoreClient,
    /// Prix Polymarket, avec cache : l'onglet Exchange ne doit pas marteler
    /// l'API à chaque rechargement.
    pub exchange: crate::polymarket::Book,
    /// Sérialise les collectes : deux refresh forcés ne doivent pas planifier
    /// les mêmes positions à partir du même état et dépasser le plafond.
    refresh_lock: Mutex<()>,
    last_refresh: Mutex<Option<Instant>>,
    next_at: Mutex<Option<NextCollection>>,
}

impl Pipeline {
    pub fn new(cfg: Config) -> Self {
        let scraper = Scraper::new(
            cfg.arbworld_base.clone(),
            Duration::from_secs(cfg.cache_ttl_secs),
            Duration::from_secs(cfg.stale_ttl_secs),
            user_agent(cfg.scraper_contact.as_deref()),
        );
        let store = Store::new(&cfg);
        Self {
            cfg,
            store,
            scraper,
            results: ResultsClient::new(Duration::from_secs(60)),
            sportscore: SportScoreClient::default(),
            exchange: crate::polymarket::Book::new(Duration::from_secs(
                th::EXCHANGE_CACHE_TTL_SECS,
            )),
            refresh_lock: Mutex::new(()),
            last_refresh: Mutex::new(None),
            next_at: Mutex::new(None),
        }
    }

    pub fn snapshot(&self) -> Option<Snapshot> {
        self.store.load_snapshot()
    }

    /// Bloc `v2` de la nouvelle interface.
    ///
    /// `None` tant que l'historisation n'a produit aucun relevé : l'interface
    /// affiche alors « indisponible », jamais un bloc de zéros.
    pub fn v2_block(&self, snapshot: &Snapshot) -> Option<crate::v2::V2> {
        if !self.store.history_active() {
            return None;
        }
        let rows = self.store.recent_cached(400);
        let stats = self.store.signal_stats();
        // Aucun appel ESPN ici : une lecture du tableau de bord ne doit pas
        // dépendre d'une source externe. Les rencontres déjà notées viennent de
        // l'historique (`rows`), pas du scoreboard.
        Some(crate::v2::build(snapshot, &rows, &stats))
    }

    /// Dernier refresh en cache (lecture seule).
    pub fn age_secs(&self) -> Option<u64> {
        self.last_refresh
            .lock()
            .unwrap()
            .map(|at| at.elapsed().as_secs())
    }

    /// Le cron doit-il collecter maintenant ? (un opérateur authentifié peut
    /// toujours forcer une collecte, la cadence ne vise que les appels machine.)
    pub fn is_due(&self) -> bool {
        self.next_at
            .lock()
            .unwrap()
            .as_ref()
            .map(|next| Instant::now() >= next.at)
            .unwrap_or(true)
    }

    /// État de la cadence, exposé par `/api/health` et `/api/refresh`.
    pub fn schedule_info(&self) -> Option<ScheduleInfo> {
        let next = (*self.next_at.lock().unwrap())?;
        let remaining = next.at.saturating_duration_since(Instant::now());
        Some(ScheduleInfo {
            due_in_secs: remaining.as_secs(),
            next_at: (Utc::now() + chrono::Duration::seconds(remaining.as_secs() as i64))
                .to_rfc3339_opts(SecondsFormat::Secs, true),
            active_window: next.active_window,
        })
    }

    /// Bot d'alerte, ou `None` quand les identifiants manquent : l'application
    /// n'a pas besoin de Telegram pour fonctionner.
    pub fn alerts_bot(&self) -> Option<crate::telegram::Bot> {
        crate::telegram::Bot::new(
            self.cfg.telegram_token.clone(),
            self.cfg.telegram_chat.clone(),
            self.cfg.telegram_base.clone(),
        )
    }

    pub fn alerts_configured(&self) -> bool {
        self.alerts_bot().is_some()
    }

    /// Envoie une alerte par signal à confiance élevée, une seule fois par
    /// signal. Un échec devient un avertissement de collecte : il ne fait jamais
    /// perdre le snapshot.
    fn send_alerts(&self, signals: &[Signal], warnings: &mut Vec<String>) {
        let Some(bot) = self.alerts_bot() else {
            return;
        };
        let mut seen = self.store.load_alerted();
        let known: std::collections::HashSet<String> = seen.iter().cloned().collect();
        let pending = crate::telegram::to_send(signals, &known, th::TELEGRAM_MAX_ALERTS_PER_RUN);
        if pending.is_empty() {
            return;
        }

        let mut failure: Option<String> = None;
        let mut sent = 0usize;
        for signal in pending {
            match bot.send(&crate::telegram::message(signal)) {
                Ok(()) => {
                    seen.push(signal.id.clone());
                    sent += 1;
                }
                Err(err) => {
                    // Une seule erreur par cycle : la même panne ne doit pas
                    // remplir la liste d'avertissements.
                    failure.get_or_insert(err);
                    break;
                }
            }
        }

        if sent > 0 {
            let start = seen.len().saturating_sub(th::TELEGRAM_SEEN_MAX);
            let kept = seen.split_off(start);
            if let Err(err) = self.store.save_alerted(&kept) {
                warnings.push(format!("Alertes Telegram non mémorisées : {err}"));
            }
        }
        if let Some(err) = failure {
            warnings.push(format!("Alerte Telegram non envoyée : {err}"));
        }
    }

    /// Cadence adaptative : collecte rapprochée quand des rencontres approchent,
    /// repos (avec jitter) le reste du temps.
    fn plan_next(&self, markets: &[MarketSnapshot]) {
        let now = Utc::now();
        let active = markets
            .iter()
            .flat_map(|market| market.matches.iter())
            .any(|m| within_window(&m.date, now, self.cfg.active_window_hours));
        let delay = next_delay_secs(active, &self.cfg) + pseudo_jitter(self.cfg.jitter_secs);
        *self.next_at.lock().unwrap() = Some(NextCollection {
            at: Instant::now() + Duration::from_secs(delay),
            active_window: active,
        });
    }

    /// Collecte + notation. Anti-rebond de 20 s pour éviter d'épuiser Arbworld
    /// quand plusieurs onglets déclenchent un refresh.
    pub fn refresh(&self, force: bool) -> Result<Snapshot, String> {
        let _refresh = self.refresh_lock.lock().unwrap();
        {
            let mut last = self.last_refresh.lock().unwrap();
            if let Some(at) = *last {
                if at.elapsed() < Duration::from_secs(20) && !force {
                    return Err("Collecte déjà en cours (anti-rebond 20 s).".to_string());
                }
            }
            *last = Some(Instant::now());
        }

        let now = Utc::now().to_rfc3339_opts(SecondsFormat::Secs, true);
        let mut markets = Vec::new();
        let mut warnings = Vec::new();

        // Démarrage sous quota épuisé : le schéma (et l'index sur
        // `captured_at`, qui corrige la consommation) n'a pas pu être posé.
        // On le retente dès qu'une requête passe, sans attendre un redémarrage.
        if !self.store.schema_ready()
            && self.store.d1_budget_ok()
            && self.store.schema_retry_due()
        {
            match self.store.ensure_schema() {
                Ok(()) => {}
                Err(err) => warnings.push(format!("Schéma D1 non appliqué : {err}")),
            }
        }

        for key in MarketKey::ALL {
            let fetched = self.scraper.fetch(key, force);
            if let Some(err) = &fetched.error {
                warnings.push(format!("{} : {err}", key.slug()));
            }
            let matches = enrich(&fetched.rows, key, fetched.source, fetched.age_seconds);
            let def = key.def();
            markets.push(MarketSnapshot {
                market: Some(key),
                key: key.slug().to_string(),
                label: def.label.to_string(),
                short: def.short.to_string(),
                total_volume: (matches.iter().map(|m| m.total_volume).sum::<f64>() * 100.0).round()
                    / 100.0,
                matches,
                source: fetched.source,
                updated_at: now.clone(),
                error: fetched.error.clone(),
            });
        }

        let stale_markets = markets
            .iter()
            .filter(|m| !m.source.is_live())
            .map(|m| m.key.clone())
            .collect::<Vec<_>>();
        if !stale_markets.is_empty() {
            warnings.push(format!(
                "Données non live pour : {}",
                stale_markets.join(", ")
            ));
        }

        // --- Historisation : uniquement ce qui a bougé, dans la fenêtre -------
        let now_dt = Utc::now();
        // Lu une seule fois par cycle : sert au périmètre des relevés **et** à
        // la notation, qui le relisait de son côté.
        let pending = self.store.pending_signals(300).unwrap_or_default();
        let open: std::collections::HashSet<String> =
            pending.iter().map(|row| row.fixture_key.clone()).collect();
        let rows = collect_snapshot_rows(&markets, &open, now_dt);
        // `record_snapshots` met la fenêtre en mémoire à jour : la série relue
        // ensuite contient le relevé de l'instant, sans relire la base.
        if let Err(err) = self.store.record_snapshots(&rows, now_dt) {
            warnings.push(format!("Historique des relevés non enregistré : {err}"));
        }
        let series = self.store.fresh_series(now_dt);
        if let Some(err) = self.store.take_recent_error() {
            warnings.push(format!("Historique des relevés indisponible : {err}"));
        }

        let authorizer = self.store.signal_stats().authorizer();
        let computed = signals::compute_with_context(&markets, &series, &authorizer, &now);
        // Une panne de D1 (quota, incident) ne doit jamais priver le tableau de
        // bord de son snapshot : on continue et on remonte l'avertissement.
        if let Err(err) = self.store.upsert_signals(&computed, &now) {
            warnings.push(format!("Historique D1 non enregistré : {err}"));
        }

        // Journal des rencontres suivies : tous les signaux y entrent, y
        // compris les recoupements neutres, pour que chaque match enregistré
        // ait un résultat — pas seulement ceux qui portaient un pari.
        let mut log_rows: Vec<MatchLogRow> = computed
            .iter()
            .filter_map(|signal| MatchLogRow::from_signal(signal, &now))
            .collect();
        // Les rencontres déjà persistées (nées dans un cycle précédent ou
        // sorties du snapshot parce qu'elles ont démarré) restent au journal :
        // sinon le bilan d'un jour cite des propositions sans leurs matchs.
        let since = (Utc::now().date_naive() - chrono::Duration::days(th::DAILY_BACKFILL_DAYS))
            .format("%Y-%m-%d")
            .to_string();
        // Une lecture d'historique par cycle, réutilisée pour le journal, le
        // bilan et les statistiques. Quand le budget D1 est sous pression, le
        // backfill (facultatif : les signaux du cycle suffisent) est différé.
        let mut history = match self.store.recent_signals(2_000) {
            Ok(rows) => rows,
            Err(err) => {
                warnings.push(format!("Historique des signaux indisponible : {err}"));
                Vec::new()
            }
        };
        if self.store.d1_budget_ok() {
            for row in &history {
                let Some(entry) = MatchLogRow::from_tracked(row, &now) else {
                    continue;
                };
                if entry.day.as_str() < since.as_str() {
                    continue;
                }
                let seen = log_rows.iter().any(|known| {
                    known.fixture_key == entry.fixture_key && known.match_date == entry.match_date
                });
                if !seen {
                    log_rows.push(entry);
                }
            }
        }
        if let Err(err) = self.store.upsert_match_log(&log_rows) {
            warnings.push(format!("Journal des rencontres non enregistré : {err}"));
        }

        match self.sync_results(&now, &pending) {
            Ok((_, _, sportscore_warnings, graded_rows)) => {
                warnings.extend(sportscore_warnings);
                // Les lignes notées à l'instant sont reportées dans
                // l'historique déjà lu : le bilan affiché en tient compte sans
                // relire la table.
                for row in graded_rows {
                    if let Some(existing) = history.iter_mut().find(|h| h.id == row.id) {
                        *existing = row;
                    } else {
                        history.push(row);
                    }
                }
            }
            Err(err) => warnings.push(format!("Notation : {err}")),
        }
        // La simulation s'ouvre après la notation : une position qui vient
        // d'être réglée libère immédiatement sa place et son point. La décision
        // est datée de `now`, début du cycle où les signaux et leurs cotes ont
        // été collectés. Relire l'heure après les appels réseau faisait perdre
        // l'unique cycle utile d'un match quand la collecte dépassait le coup
        // d'envoi ; `entry_lead_minutes` revérifie la marge à l'ouverture, donc
        // aucune position n'est prise après le départ.
        let opened_at = now.clone();
        if let Err(err) = self.remember_simulation_candidates(&computed, &opened_at) {
            warnings.push(format!("Candidats de simulation non mémorisés : {err}"));
        }
        if let Err(err) = self.open_simulation_positions(&computed, &opened_at) {
            warnings.push(format!("Simulation non ouverte : {err}"));
        }
        self.warn_unopenable_signals(&computed, &opened_at, &mut warnings);

        // Signaux et notes viennent d'être écrits : le bilan doit être
        // recalculé. On l'alimente avec l'historique déjà lu plutôt que de le
        // relire une troisième fois.
        if history.is_empty() {
            self.store.invalidate_stats();
        } else {
            self.store.prime_stats(history);
        }
        // Alertes : uniquement la confiance élevée, une fois par signal, et
        // seulement si Telegram est configuré.
        self.send_alerts(&computed, &mut warnings);
        // La consommation D1 doit être visible avant d'atteindre le plafond :
        // au-delà, Cloudflare refuse toutes les requêtes jusqu'à minuit UTC.
        if let Some(usage) = self.store.d1_usage() {
            if usage.blocked {
                // Huit étapes dépendent de D1 : une seule ligne suffit.
                warnings.retain(|warning| !warning.contains("quota D1"));
                warnings.push(
                    "Quota D1 journalier épuisé : persistance suspendue jusqu'à minuit UTC."
                        .to_string(),
                );
            } else if usage.read_ratio() >= th::D1_PRESSURE_RATIO
                || usage.write_ratio() >= th::D1_PRESSURE_RATIO
            {
                warnings.push(format!(
                    "Budget D1 sous pression : {} lignes lues, {} écrites aujourd'hui.",
                    usage.rows_read, usage.rows_written
                ));
            }
        }
        let snapshot = Snapshot {
            computed_at: now.clone(),
            age_seconds: 0,
            markets,
            signals: computed,
            track_record: self.store.track_record(),
            warnings,
        };

        self.store.save_snapshot(&snapshot)?;
        self.plan_next(&snapshot.markets);
        Ok(snapshot)
    }

    /// Récupère les scores une seule fois par cycle : ceux des signaux ouverts
    /// (à noter) et ceux des rencontres du journal encore sans score.
    fn sync_results(
        &self,
        now: &str,
        pending: &[TrackedSignal],
    ) -> Result<(usize, usize, Vec<String>, Vec<TrackedSignal>), String> {
        let today = Utc::now().date_naive();
        let since = (today - chrono::Duration::days(th::RESULT_SYNC_DAYS))
            .format("%Y-%m-%d")
            .to_string();
        let open = self.store.open_match_log(&since)?;
        let sim_open: Vec<SimPosition> = self.store.load_open_sim_positions()?;
        if pending.is_empty() && open.is_empty() && sim_open.is_empty() {
            return Ok((0, 0, Vec::new(), Vec::new()));
        }

        // On n'interroge que les compétitions concernées. Une compétition
        // inconnue d'ESPN n'a pas de slug : sa rencontre reste sans score,
        // plutôt que de recevoir un résultat inventé.
        let mut slugs: Vec<&'static str> = pending
            .iter()
            .map(|row| row.league.as_str())
            .chain(open.iter().map(|row| row.league.as_str()))
            .chain(sim_open.iter().map(|row| row.league.as_str()))
            .filter_map(espn::slug_for_competition)
            .collect();
        slugs.sort_unstable();
        slugs.dedup();

        // Fenêtre de notation : aujourd'hui, hier, plus les jours des
        // rencontres encore en attente. Un match joué pendant une panne de
        // collecte doit pouvoir être noté, même plusieurs jours plus tard.
        let mut days: Vec<chrono::NaiveDate> = vec![today, today - chrono::Duration::days(1)];
        for raw in pending
            .iter()
            .map(|row| row.date.as_str())
            .chain(open.iter().map(|row| row.match_date.as_str()))
            .chain(sim_open.iter().map(|row| row.match_date.as_str()))
        {
            let Some(kickoff) = parse_kickoff(raw) else {
                continue;
            };
            let day = kickoff.date_naive();
            if (day - today).num_days().abs() <= 10 && !days.contains(&day) {
                days.push(day);
            }
        }
        days.sort_by_key(|day| (*day - today).num_days().abs());

        // SportScore : uniquement les compétitions qu'il couvre, pour les
        // rencontres encore en attente. Les appels sont mis en cache par jour
        // et par compétition.
        let mut sportscore_requests: Vec<(String, &'static str)> = Vec::new();
        for (raw, league) in pending
            .iter()
            .map(|row| (row.date.as_str(), row.league.as_str()))
            .chain(open.iter().map(|row| (row.match_date.as_str(), row.league.as_str())))
            .chain(
                sim_open
                    .iter()
                    .map(|row| (row.match_date.as_str(), row.league.as_str())),
            )
        {
            let Some(kickoff) = parse_kickoff(raw) else {
                continue;
            };
            let day = kickoff.date_naive();
            if (day - today).num_days().abs() > 10 {
                continue;
            }
            let day = day.format("%Y-%m-%d").to_string();
            for slug in sportscore::competition_slugs(league) {
                sportscore_requests.push((day.clone(), *slug));
            }
        }
        sportscore_requests.sort();
        sportscore_requests.dedup();
        let (sportscore_events, sportscore_warnings) =
            self.sportscore.many(&sportscore_requests);

        let mut events: Vec<MatchResult> = Vec::new();
        let mut score_warnings = sportscore_warnings;
        if !slugs.is_empty() {
            for day in &days {
                let key = day.format("%Y%m%d").to_string();
                let (batch, errors) = self.results.many(&slugs, Some(&key));
                events.extend(batch);
                score_warnings.extend(errors);
            }
        }
        events.sort_by(|a, b| a.id.cmp(&b.id));
        events.dedup_by(|a, b| a.id == b.id);

        let (graded, graded_rows) = self.grade_signals(pending, &events, &sportscore_events, now)?;
        let recorded = self.record_match_results(&open, &events, &sportscore_events, now)?;
        self.settle_simulation(&sim_open, &events, &sportscore_events, now)?;
        Ok((graded, recorded, score_warnings, graded_rows))
    }

    /// Note les signaux en attente à partir des scores déjà récupérés.
    fn grade_signals(
        &self,
        pending: &[TrackedSignal],
        events: &[MatchResult],
        sportscore_events: &[MatchResult],
        now: &str,
    ) -> Result<(usize, Vec<TrackedSignal>), String> {
        let mut graded = 0usize;
        let mut rows = Vec::new();
        for mut row in pending.iter().cloned() {
            let Some((result, _)) = find_score(
                &row.home,
                &row.away,
                &row.date,
                &row.league,
                events,
                sportscore_events,
            ) else {
                continue;
            };
            if result.state != crate::model::MatchState::Finished {
                continue;
            }

            // La clôture est le dernier relevé de chaque sélection avant le
            // coup d'envoi. Sans relevé, le CLV reste absent.
            let closing: std::collections::HashMap<String, crate::storage::SnapshotRow> = self
                .store
                .last_before(&row.fixture_key, &row.date)
                .unwrap_or_default()
                .into_iter()
                .map(|reading| (reading.selection_key(), reading))
                .collect();

            let mut headline: Option<Headline> = None;
            for proposal in row.proposals.iter_mut() {
                let slot = proposals::slot_of_play(&proposal.play);
                let reading = closing.get(&proposal.series_key);
                let closing_odds = match (slot, reading) {
                    (Some(slot), Some(reading)) if reading.coef[slot] > 1.0 => {
                        Some(reading.coef[slot])
                    }
                    _ => None,
                };
                let closing_novig = match (slot, reading) {
                    (Some(slot), Some(reading)) => no_vig_from_coefs(&reading.coef, slot),
                    _ => None,
                };
                proposal.set_closing(closing_odds, closing_novig);

                let verdict = crate::verify::grade_proposal(
                    proposal.group.key(),
                    &proposal.play,
                    Some(result),
                );
                proposal.outcome = verdict.outcome;
                proposal.explanation = verdict.explanation;

                if headline.is_none() {
                    headline = Some(Headline {
                        outcome: proposal.outcome,
                        explanation: proposal.explanation.clone(),
                        closing: proposal.closing_odds,
                        clv: proposal.clv_pct,
                        clv_novig: proposal.clv_novig_pct,
                    });
                }
            }

            let headline = headline.unwrap_or(Headline {
                outcome: BetOutcome::Unknown,
                explanation: "Signal non tradable : aucune proposition.".to_string(),
                closing: None,
                clv: None,
                clv_novig: None,
            });
            row.value_outcome = headline.outcome;
            row.value_explanation = headline.explanation;
            row.safety_outcome = BetOutcome::Unknown;
            row.closing_odds = headline.closing;
            row.clv_pct = headline.clv;
            row.clv_novig_pct = headline.clv_novig;
            row.home_score = result.home_score;
            row.away_score = result.away_score;
            row.graded_at = Some(now.to_string());
            self.store.save_grade(&row)?;
            graded += 1;
            rows.push(row);
        }
        Ok((graded, rows))
    }

    /// Enregistre le score de chaque rencontre du journal dès qu'il est connu.
    fn record_match_results(
        &self,
        open: &[MatchLogRow],
        events: &[MatchResult],
        sportscore_events: &[MatchResult],
        now: &str,
    ) -> Result<usize, String> {
        let mut updates: Vec<MatchLogRow> = Vec::new();
        for row in open {
            let Some((result, source)) = find_score(
                &row.home,
                &row.away,
                &row.match_date,
                &row.league,
                events,
                sportscore_events,
            ) else {
                continue;
            };
            let mut updated = row.clone();
            if updated.apply_from(result, now, source) {
                updates.push(updated);
            }
        }
        self.store.update_match_results(&updates)?;
        Ok(updates.len())
    }

    /// Mémorise les positions éligibles : si la capacité est pleine ou si le
    /// signal disparaît du flux, sa chance d'ouverture ne doit pas disparaître
    /// avec lui. Le candidat est réessayé à chaque cycle.
    fn remember_simulation_candidates(
        &self,
        signals: &[Signal],
        now: &str,
    ) -> Result<usize, String> {
        let candidates: Vec<SimPosition> = signals
            .iter()
            .filter_map(simulation::candidate)
            .filter(|position| !crate::signals::has_started(&position.match_date, now))
            .collect();
        let count = candidates.len();
        self.store.save_sim_candidates(&candidates, now)?;
        Ok(count)
    }

    /// Ouvre les positions de simulation possibles pour ce cycle : signaux du
    /// cycle courant **et** candidats mémorisés lors des cycles précédents.
    fn open_simulation_positions(&self, signals: &[Signal], now: &str) -> Result<usize, String> {
        let positions = self.store.load_open_sim_positions()?;
        let realized = self.store.sim_totals()?.realized_pnl;
        let mut drafts: Vec<SimPosition> = signals
            .iter()
            .filter_map(|signal| simulation::draft(signal, now))
            .collect();
        drafts.extend(self.store.load_sim_candidates()?);
        let entries = simulation::plan_drafts_with_realized(drafts, &positions, realized, now);
        if entries.is_empty() {
            return Ok(0);
        }
        self.store.save_sim_positions(&entries)?;
        // Un candidat ouvert ne doit pas rester en attente : sinon un match
        // reporté avant son coup d'envoi est réouvert puis re-rendu VOID à
        // chaque cycle.
        let opened: Vec<String> = entries.iter().map(|entry| entry.id.clone()).collect();
        self.store.delete_sim_candidates(&opened)?;
        Ok(entries.len())
    }

    /// Un signal à confiance élevée qui ne peut pas être simulé doit le dire
    /// dans les avertissements du snapshot, sans aller fouiller D1. Il n'y a
    /// plus d'attente liée à une fenêtre horaire : les seuls motifs sont la
    /// confiance, le type, la couverture, la cote et le coup d'envoi dépassé.
    fn warn_unopenable_signals(&self, signals: &[Signal], now: &str, warnings: &mut Vec<String>) {
        let mut rejected: Vec<String> = Vec::new();
        for signal in signals
            .iter()
            .filter(|signal| signal.confidence == Confidence::Eleve && signal.kind.flagged())
        {
            if let Some(reason) = simulation::rejection_reason(signal, now) {
                rejected.push(format!("{} ({reason})", signal.home));
            }
        }
        if rejected.is_empty() {
            return;
        }
        rejected.sort_unstable();
        rejected.dedup();
        let mut parts = Vec::new();
        if !rejected.is_empty() {
            let shown = rejected
                .iter()
                .take(3)
                .cloned()
                .collect::<Vec<_>>()
                .join(", ");
            let extra = rejected.len().saturating_sub(3);
            parts.push(format!(
                "{} signal(s) Élevé non simulables : {}{}",
                rejected.len(),
                shown,
                if extra > 0 {
                    format!(" (+{extra})")
                } else {
                    String::new()
                }
            ));
        }
        warnings.push(format!("Simulation : {}", parts.join(" ; ")));
    }

    /// Règle les positions ouvertes avec les scores déjà récupérés.
    fn settle_simulation(
        &self,
        open: &[SimPosition],
        events: &[MatchResult],
        sportscore_events: &[MatchResult],
        now: &str,
    ) -> Result<usize, String> {
        // Ne régler que sur un état terminal : un match futur des mêmes équipes
        // ne doit jamais remplacer le résultat du match courant.
        let settled_events: Vec<MatchResult> = events
            .iter()
            .filter(|event| {
                matches!(
                    event.state,
                    MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
                )
            })
            .cloned()
            .collect();
        let settled_sportscore: Vec<MatchResult> = sportscore_events
            .iter()
            .filter(|event| {
                matches!(
                    event.state,
                    MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
                )
            })
            .cloned()
            .collect();
        let mut updates = Vec::new();
        for position in open {
            let mut updated = position.clone();
            // Une compétition sans source de score ne produira jamais de
            // résultat : on rend la mise tout de suite au lieu d'attendre 48 h.
            if simulation::void_uncovered(&mut updated, now) {
                updates.push(updated);
                continue;
            }
            let result = find_score(
                &position.home,
                &position.away,
                &position.match_date,
                &position.league,
                &settled_events,
                &settled_sportscore,
            )
            .map(|(result, _)| result);
            let settled = result
                .map(|result| simulation::settle(&mut updated, result, now))
                .unwrap_or(false);
            if settled || simulation::expire(&mut updated, now) {
                updates.push(updated);
            }
        }
        self.store.save_sim_positions(&updates)?;
        Ok(updates.len())
    }

    /// Bilan de la simulation, sans appel externe.
    pub fn simulation_report(&self) -> Result<simulation::SimulationReport, String> {
        let open = self.store.load_open_sim_positions()?;
        let history = self.store.load_sim_history(th::SIM_HISTORY_LIMIT)?;
        let totals = self.store.sim_totals()?;
        Ok(simulation::report_with_totals(
            open.into_iter().chain(history).collect(),
            totals,
        ))
    }

    /// Bilan d'une journée (par défaut aujourd'hui, en UTC).
    pub fn daily_report(&self, day: Option<&str>) -> Result<daily::DailyReport, String> {
        let today = Utc::now().date_naive().format("%Y-%m-%d").to_string();
        let day = day.map(str::trim).unwrap_or_default();
        let day = if day.len() == 10 && day.chars().all(|c| c.is_ascii_digit() || c == '-') {
            day.to_string()
        } else {
            today.clone()
        };
        let days = self.store.match_log_days(th::DAILY_LOOKBACK_DAYS)?;
        let rows = self.store.match_log_day(&day)?;
        let signals = self.store.recent_cached(2_000);
        let mut report = daily::report(&day, &today, &rows, &signals, &days);
        // Ce que le programme ne peut pas noter doit être dit : une compétition
        // sans source restera en attente, ce n'est pas une panne.
        report.uncovered = daily::uncovered_leagues(&report.matches, simulation::league_covered);
        report.totals.uncovered = report.uncovered.iter().map(|entry| entry.matches).sum();
        Ok(report)
    }

    /// Backtest des seuils sur les rencontres journalisées.
    ///
    /// Lit `match_log` (toutes les rencontres suivies, pas seulement celles qui
    /// portaient un pari) et compare le réalisé aux probabilités implicites
    /// enregistrées à la collecte. Aucun appel externe : c'est une lecture.
    pub fn backtest(&self, days: usize) -> Result<crate::backtest::BacktestReport, String> {
        let since = (Utc::now().date_naive() - chrono::Duration::days(days as i64))
            .format("%Y-%m-%d")
            .to_string();
        let rows = self.store.match_log_since(&since, 5_000)?;
        Ok(crate::backtest::report(&rows, days))
    }
}

/// Retrouve le score d'une rencontre : ESPN d'abord, SportScore en secours.
///
/// Si ESPN connaît la rencontre mais n'a pas encore d'état terminal, un
/// résultat terminal SportScore est préféré : c'est exactement le cas d'une
/// compétition mal suivie par ESPN.
fn find_score<'a>(
    home: &str,
    away: &str,
    date: &str,
    league: &str,
    espn_events: &'a [MatchResult],
    sportscore_events: &'a [MatchResult],
) -> Option<(&'a MatchResult, &'static str)> {
    let espn_match = espn::find_match(
        home,
        away,
        Some(date),
        espn::slug_for_competition(league),
        espn_events,
    );
    if let Some(result) = espn_match {
        if is_terminal(result.state) {
            return Some((result, daily::SCORE_SOURCE));
        }
    }
    if let Some(result) = sportscore::find_match(home, away, date, league, sportscore_events) {
        if espn_match.is_none() || is_terminal(result.state) {
            return Some((result, daily::SPORTSCORE_SOURCE));
        }
    }
    espn_match.map(|result| (result, daily::SCORE_SOURCE))
}

fn is_terminal(state: MatchState) -> bool {
    matches!(
        state,
        MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
    )
}

/// Relevés à historiser pour cette collecte.
///
/// On ne garde que les rencontres utiles : coup d'envoi dans les 48 prochaines
/// heures, ou rencontre déjà commencée mais dont le signal n'est pas encore
/// noté (fenêtre de grâce). Le filtrage « cote ou volume a changé » est fait
/// par le store, contre le dernier relevé de chaque sélection.
pub fn collect_snapshot_rows(
    markets: &[MarketSnapshot],
    open: &std::collections::HashSet<String>,
    now: DateTime<Utc>,
) -> Vec<SnapshotRow> {
    let mut rows = Vec::new();
    for market in markets {
        for m in &market.matches {
            let Some(kickoff) = crate::enrich::parse_kickoff(&m.date) else {
                continue;
            };
            let fixture = crate::enrich::fixture_key(&m.home, &m.away);
            let upcoming = kickoff > now
                && kickoff <= now + chrono::Duration::hours(th::SNAPSHOT_HORIZON_HOURS);
            let started_and_open = kickoff <= now
                && now - kickoff <= chrono::Duration::hours(th::SNAPSHOT_LIVE_GRACE_HOURS)
                && open.contains(&fixture);
            if !(upcoming || started_and_open) {
                continue;
            }
            rows.push(SnapshotRow {
                market_key: m.market.slug().to_string(),
                market_id: m.market_id,
                selection_id: m.selection_id,
                fixture_key: fixture,
                captured_at: now.to_rfc3339_opts(SecondsFormat::Secs, true),
                coef: m.coef_new,
                volume: m.volume,
                total_volume: m.total_volume,
                kickoff: m.date.clone(),
            });
        }
    }
    rows
}

/// Délai de base avant la prochaine collecte, selon l'activité observée.
pub fn next_delay_secs(active_window: bool, cfg: &Config) -> u64 {
    if active_window {
        cfg.active_interval_secs.max(60)
    } else {
        cfg.idle_interval_secs
            .max(cfg.active_interval_secs)
            .max(60)
    }
}

/// Vrai si la rencontre est en cours (jusqu'à 4 h après le coup d'envoi) ou
/// démarre dans les `hours` prochaines heures.
pub fn within_window(raw: &str, now: DateTime<Utc>, hours: i64) -> bool {
    let Some(start) = parse_datetime(raw) else {
        return false;
    };
    let from = now - chrono::Duration::hours(4);
    let to = now + chrono::Duration::hours(hours);
    start >= from && start <= to
}

fn parse_datetime(raw: &str) -> Option<DateTime<Utc>> {
    crate::enrich::parse_kickoff(raw)
}

/// Minutes entre une détection (`now`) et le coup d'envoi.
/// `None` quand l'une des deux dates est illisible : jamais une valeur inventée.
pub fn minutes_before_kickoff(date: &str, now: &str) -> Option<i64> {
    match (parse_datetime(date), parse_datetime(now)) {
        (Some(kickoff), Some(now)) => Some((kickoff - now).num_minutes()),
        _ => None,
    }
}

/// Jitter positif : les collectes ne tombent jamais sur un rythme exact.
fn pseudo_jitter(max_secs: u64) -> u64 {
    if max_secs == 0 {
        return 0;
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos() as u64)
        .unwrap_or(0);
    nanos % (max_secs + 1)
}

/// Utilitaire de diagnostic : sérialise un snapshot compact pour les logs.
pub fn summarize(snapshot: &Snapshot) -> Value {
    serde_json::json!({
        "computed_at": snapshot.computed_at,
        "markets": snapshot.markets.len(),
        "matches": snapshot.markets.iter().map(|m| m.matches.len()).sum::<usize>(),
        "signals": snapshot.signals.len(),
        "warnings": snapshot.warnings,
    })
}

#[allow(dead_code)]
fn _assert_types(_: &TrackedSignal) {}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::TimeZone;

    #[test]
    fn active_window_matches_upcoming_and_live_games() {
        let now = Utc.with_ymd_and_hms(2026, 11, 9, 18, 0, 0).unwrap();
        assert!(within_window("2026-11-09T20:00:00Z", now, 6));
        assert!(within_window("2026-11-09 16:00:00", now, 6), "match en cours");
        assert!(!within_window("2026-11-10T03:00:00Z", now, 6), "trop tard");
        assert!(!within_window("", now, 6));
        assert!(!within_window("pas une date", now, 6));
    }

    #[test]
    fn snapshots_only_cover_the_next_48_hours_and_open_live_games() {
        let now = Utc.with_ymd_and_hms(2026, 11, 9, 18, 0, 0).unwrap();
        let market = |date: &str| {
            let rows = vec![serde_json::json!({
                "home": "A", "away": "B", "date": date, "market_id": 1, "selection_id": 2,
                "coef_1": 1.9, "coef_x": 3.6, "coef_2": 4.2,
                "coef_1_new": 1.9, "coef_x_new": 3.6, "coef_2_new": 4.2,
                "volume_1": 3000, "volume_x": 1000, "volume_2": 1000
            })];
            let matches = crate::enrich::enrich(
                &rows,
                MarketKey::OneXTwo,
                crate::model::Source::Live,
                0,
            );
            MarketSnapshot {
                market: Some(MarketKey::OneXTwo),
                key: "1x2".into(),
                label: String::new(),
                short: String::new(),
                total_volume: 5000.0,
                matches,
                source: crate::model::Source::Live,
                updated_at: String::new(),
                error: None,
            }
        };
        let markets = vec![
            market("2026-11-09T20:00:00Z"),
            market("2026-11-12T20:00:00Z"),
            market("2026-11-09T12:00:00Z"),
        ];
        let rows = collect_snapshot_rows(&markets, &std::collections::HashSet::new(), now);
        assert_eq!(rows.len(), 1, "seule la rencontre à 2 h est historisée");

        let open = std::collections::HashSet::from(["a_vs_b".to_string()]);
        let rows = collect_snapshot_rows(&markets, &open, now);
        assert_eq!(rows.len(), 2, "la rencontre commencée mais non notée reste");
    }

    #[test]
    fn idle_cadence_is_slower_than_active() {
        let mut cfg = Config::from_env();
        cfg.active_interval_secs = 600;
        cfg.idle_interval_secs = 1800;
        assert_eq!(next_delay_secs(true, &cfg), 600);
        assert_eq!(next_delay_secs(false, &cfg), 1800);

        cfg.active_interval_secs = 0;
        cfg.idle_interval_secs = 0;
        assert_eq!(next_delay_secs(true, &cfg), 60, "plancher anti-rafale");
        assert_eq!(next_delay_secs(false, &cfg), 60);
    }

    #[test]
    fn a_terminal_sportscore_result_beats_an_unfinished_espn_event() {
        let result = |state, home_score, away_score, league_slug: &str| MatchResult {
            id: format!("{league_slug}-1"),
            name: "Perugia vs Sassari Torres".into(),
            date: "2026-11-16T19:45:00Z".into(),
            date_label: String::new(),
            league_slug: league_slug.into(),
            league_name: String::new(),
            home_team: "Perugia".into(),
            away_team: "Sassari Torres".into(),
            home_logo: String::new(),
            away_logo: String::new(),
            home_score,
            away_score,
            home_ht: None,
            away_ht: None,
            state,
            status_detail: String::new(),
            completed: state == MatchState::Finished,
            total_goals: home_score.zip(away_score).map(|(h, a)| h + a),
            btts: home_score.zip(away_score).map(|(h, a)| h > 0 && a > 0),
        };

        let unfinished_events = [result(MatchState::Scheduled, None, None, "ita.1")];
        let finished_events = [result(
            MatchState::Finished,
            Some(0),
            Some(1),
            "italian-serie-c",
        )];
        let (found, source) = find_score(
            "Perugia",
            "Sassari Torres",
            "2026-11-16T19:45:00Z",
            "Italian Serie C",
            &unfinished_events,
            &finished_events,
        )
        .expect("score SportScore");
        assert_eq!(source, daily::SPORTSCORE_SOURCE);
        assert_eq!((found.home_score, found.away_score), (Some(0), Some(1)));

        let espn_events = [result(MatchState::Finished, Some(2), Some(0), "ita.1")];
        let sportscore_events = [result(
            MatchState::Finished,
            Some(0),
            Some(1),
            "italian-serie-c",
        )];
        let (found, source) = find_score(
            "Perugia",
            "Sassari Torres",
            "2026-11-16T19:45:00Z",
            "Italian Serie C",
            &espn_events,
            &sportscore_events,
        )
        .expect("score ESPN");
        assert_eq!(source, daily::SCORE_SOURCE);
        assert_eq!((found.home_score, found.away_score), (Some(2), Some(0)));
    }

    #[test]
    fn jitter_stays_within_bounds() {
        for _ in 0..64 {
            assert!(pseudo_jitter(90) <= 90);
        }
        assert_eq!(pseudo_jitter(0), 0);
    }
}
