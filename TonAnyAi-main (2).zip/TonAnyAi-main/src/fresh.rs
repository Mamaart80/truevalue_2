//! Argent frais : ce qui **entre** sur un marché, pas la part cumulée.
//!
//! Le volume d'un marché Betfair est un compteur cumulé depuis son ouverture.
//! La part de ce cumul sur une issue ne dit donc rien de l'argent qui vient
//! d'arriver : un marché peut être « à 80 % domicile » depuis trois jours alors
//! que les trois dernières heures financent l'extérieur. Ce module reconstruit
//! les entrées par différence entre deux relevés d'une même sélection.
//!
//! Règles de sûreté :
//! - moins de deux relevés dans la fenêtre → pas de flux, l'absence est
//!   explicite (`ok = false` + `why`) ;
//! - un delta négatif (reset du compteur, bascule de marché) invalide le relevé
//!   et est journalisé : il n'est jamais interprété comme une inversion de flux.

use std::collections::HashMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::enrich::parse_kickoff;
use crate::market::MarketKey;
use crate::thresholds as th;

/// Un relevé d'une sélection : cote actuelle et volumes cumulés par issue.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct Observation {
    pub captured_at: String,
    #[serde(default)]
    pub coef: [f64; 3],
    #[serde(default)]
    pub volume: [f64; 3],
}

/// Série temporelle indexée par clé de sélection.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Series {
    pub by_selection: HashMap<String, Vec<Observation>>,
}

/// Identité stable d'une sélection dans l'historique.
pub fn selection_key(market: MarketKey, market_id: i64, selection_id: i64) -> String {
    format!("{}:{market_id}:{selection_id}", market.slug())
}

impl Series {
    pub fn push(&mut self, key: &str, observation: Observation) {
        self.by_selection
            .entry(key.to_string())
            .or_default()
            .push(observation);
    }

    /// Relevés triés du plus ancien au plus récent.
    pub fn ordered(&self, key: &str) -> Vec<&Observation> {
        let Some(rows) = self.by_selection.get(key) else {
            return Vec::new();
        };
        let mut rows: Vec<&Observation> = rows.iter().collect();
        rows.sort_by_key(|o| parse_kickoff(&o.captured_at));
        rows
    }
}

/// Argent entrant observé sur les fenêtres 1 h et 3 h.
///
/// `f1`/`f3` = part du nouvel argent sur l'issue dominante du marché (%),
/// `in1`/`in3` = montant entrant (£). `None` = donnée absente, jamais 0 inventé.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct FreshMoney {
    /// Au moins deux relevés exploitables sur la fenêtre courte.
    pub ok: bool,
    /// Raison de l'absence de flux (`""` quand `ok`).
    pub why: String,
    pub in1: Option<f64>,
    pub in3: Option<f64>,
    pub f1: Option<f64>,
    pub f3: Option<f64>,
    /// Côté qui capte le plus d'argent frais sur 1 h.
    #[serde(default)]
    pub side: Option<usize>,
    /// La cote se resserre et l'argent frais va du même côté.
    pub steam: bool,
    /// L'argent frais change de côté par rapport au cumulé.
    pub reversal: bool,
    /// Afflux anormal avant le coup d'envoi par rapport au rythme précédent.
    pub late: bool,
}

impl FreshMoney {
    fn absent(why: impl Into<String>) -> Self {
        FreshMoney {
            ok: false,
            why: why.into(),
            ..Default::default()
        }
    }
}

struct Window {
    baseline: Observation,
    latest: Observation,
}

fn window(rows: &[&Observation], now: DateTime<Utc>, hours: f64) -> Result<Window, String> {
    let from = now - chrono::Duration::milliseconds((hours * 3_600_000.0) as i64);
    let mut inside: Vec<&Observation> = rows
        .iter()
        .copied()
        .filter(|o| {
            parse_kickoff(&o.captured_at)
                .map(|at| at >= from && at <= now)
                .unwrap_or(false)
        })
        .collect();
    if inside.len() < th::FRESH_MIN_OBSERVATIONS {
        return Err(format!(
            "moins de {} relevés sur {:.0} h",
            th::FRESH_MIN_OBSERVATIONS,
            hours
        ));
    }
    inside.sort_by_key(|o| parse_kickoff(&o.captured_at));
    let baseline = (*inside.first().expect("au moins deux relevés")).clone();
    let latest = (*inside.last().expect("au moins deux relevés")).clone();
    Ok(Window { baseline, latest })
}

fn incoming(window: &Window) -> Result<(f64, [f64; 3]), String> {
    let mut delta = [0.0_f64; 3];
    for (slot, cell) in delta.iter_mut().enumerate() {
        let active = window.latest.coef[slot] > 0.0 || window.baseline.coef[slot] > 0.0;
        if !active {
            continue;
        }
        let d = window.latest.volume[slot] - window.baseline.volume[slot];
        if d < -0.01 {
            return Err(format!(
                "delta négatif de {d:.0} £ sur l'issue {} (reset de volume) : relevé ignoré",
                slot + 1
            ));
        }
        *cell = d.max(0.0);
    }
    Ok((delta.iter().sum(), delta))
}

/// Argent frais d'une sélection, vu depuis `now`.
///
/// `dominant` est l'index de l'issue dominante du marché (part cumulée).
pub fn compute(
    series: &Series,
    key: &str,
    dominant: usize,
    now: DateTime<Utc>,
    kickoff: Option<DateTime<Utc>>,
) -> FreshMoney {
    let rows = series.ordered(key);
    if rows.is_empty() {
        return FreshMoney::absent("aucun relevé historique pour cette sélection");
    }

    let short = match window(&rows, now, th::FRESH_WINDOW_SHORT_HOURS) {
        Ok(w) => w,
        Err(why) => return FreshMoney::absent(why),
    };
    let (total, delta) = match incoming(&short) {
        Ok(v) => v,
        Err(why) => {
            eprintln!("[fresh] {key} : {why}");
            return FreshMoney::absent(why);
        }
    };
    if total < th::MIN_FRESH_MONEY {
        return FreshMoney::absent(format!(
            "argent frais insuffisant ({total:.0} £ < {:.0} £)",
            th::MIN_FRESH_MONEY
        ));
    }

    let share = |slot: usize| {
        if total > 0.0 {
            Some((delta[slot] / total * 100.0 * 10.0).round() / 10.0)
        } else {
            None
        }
    };
    let fresh_side = (0..3).max_by(|a, b| {
        delta[*a]
            .partial_cmp(&delta[*b])
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    let mut out = FreshMoney {
        ok: true,
        why: String::new(),
        in1: Some((total * 100.0).round() / 100.0),
        f1: share(dominant),
        side: fresh_side,
        ..Default::default()
    };

    // La cote se resserre-t-elle, du côté où arrive l'argent ?
    let base = short.baseline.coef[dominant];
    let last = short.latest.coef[dominant];
    let drop = if base > 1.0 && last > 1.0 {
        (last - base) / base * 100.0
    } else {
        0.0
    };
    out.steam = drop <= th::STEAM_MIN_DROP_PCT
        && out.f1.unwrap_or(0.0) >= th::FRESH_SIDE_MIN_SHARE;

    // Inversion : le côté qui capte l'argent frais n'est pas le côté cumulé.
    out.reversal = fresh_side != Some(dominant)
        && share(fresh_side.unwrap_or(dominant)).unwrap_or(0.0) >= th::FRESH_SIDE_MIN_SHARE;

    // Fenêtre longue : montant entrant sur 3 h et rythme des heures précédentes.
    if let Ok(long) = window(&rows, now, th::FRESH_WINDOW_LONG_HOURS) {
        if let Ok((total3, delta3)) = incoming(&long) {
            out.in3 = Some((total3 * 100.0).round() / 100.0);
            out.f3 = if total3 >= th::MIN_FRESH_MONEY {
                Some((delta3[dominant] / total3 * 1000.0).round() / 10.0)
            } else {
                None
            };

            let previous_rate = ((total3 - total) / 2.0).max(0.0);
            let hours_to_kickoff = kickoff
                .map(|k| (k - now).num_minutes() as f64 / 60.0)
                .unwrap_or(f64::INFINITY);
            // Sans rythme antérieur mesurable, il n'y a pas d'« anormal » :
            // un premier relevé chargé n'est pas un afflux tardif.
            out.late = hours_to_kickoff > 0.0
                && hours_to_kickoff <= th::LATE_SURGE_HOURS
                && previous_rate > 0.0
                && total >= th::MIN_FRESH_MONEY
                && total >= th::LATE_SURGE_MULTIPLE * previous_rate;
        }
    }

    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::TimeZone;

    fn at(hour: u32, minute: u32) -> String {
        Utc.with_ymd_and_hms(2026, 11, 9, hour, minute, 0)
            .unwrap()
            .to_rfc3339()
    }

    fn obs(time: &str, volume: [f64; 3]) -> Observation {
        Observation {
            captured_at: time.to_string(),
            coef: [2.0, 3.4, 3.8],
            volume,
        }
    }

    #[test]
    fn fresh_money_is_a_difference_not_a_share() {
        let mut series = Series::default();
        let key = "1x2:1:2";
        series.push(key, obs(&at(16, 45), [9000.0, 1000.0, 1000.0]));
        series.push(key, obs(&at(17, 20), [9000.0, 1000.0, 4000.0]));
        let now = parse_kickoff(&at(17, 30)).unwrap();
        let fresh = compute(&series, key, 0, now, None);
        assert!(fresh.ok, "{}", fresh.why);
        assert_eq!(fresh.in1, Some(3000.0));
        // Le cumulé est à 82 % domicile, mais 100 % du nouvel argent va à l'extérieur.
        assert_eq!(fresh.f1, Some(0.0));
        assert!(fresh.reversal);
    }

    #[test]
    fn a_single_observation_is_explicit_absence() {
        let mut series = Series::default();
        series.push("1x2:1:2", obs(&at(17, 0), [1000.0, 100.0, 100.0]));
        let now = parse_kickoff(&at(17, 30)).unwrap();
        let fresh = compute(&series, "1x2:1:2", 0, now, None);
        assert!(!fresh.ok);
        assert!(fresh.why.contains("relevés"), "{}", fresh.why);
        assert_eq!(fresh.f1, None);
    }

    #[test]
    fn a_negative_delta_invalidates_the_reading() {
        let mut series = Series::default();
        let key = "1x2:1:2";
        series.push(key, obs(&at(16, 30), [5000.0, 1000.0, 1000.0]));
        series.push(key, obs(&at(17, 0), [1200.0, 1000.0, 1000.0]));
        let now = parse_kickoff(&at(17, 20)).unwrap();
        let fresh = compute(&series, key, 0, now, None);
        assert!(!fresh.ok);
        assert!(fresh.why.contains("delta négatif"), "{}", fresh.why);
        assert!(!fresh.reversal, "un reset n'est jamais une inversion");
        assert_eq!(fresh.f1, None);
    }

    #[test]
    fn tiny_incoming_money_does_not_count() {
        let mut series = Series::default();
        let key = "1x2:1:2";
        series.push(key, obs(&at(16, 30), [5000.0, 1000.0, 1000.0]));
        series.push(key, obs(&at(17, 0), [5020.0, 1000.0, 1000.0]));
        let now = parse_kickoff(&at(17, 20)).unwrap();
        let fresh = compute(&series, key, 0, now, None);
        assert!(!fresh.ok);
        assert!(fresh.why.contains("insuffisant"), "{}", fresh.why);
    }

    #[test]
    fn a_late_surge_detects_an_unusual_pace() {
        let mut series = Series::default();
        let key = "1x2:1:2";
        // ~300 £/h pendant deux heures, puis 1900 £ dans la dernière heure.
        series.push(key, obs(&at(14, 20), [1000.0, 100.0, 100.0]));
        series.push(key, obs(&at(16, 0), [1600.0, 100.0, 100.0]));
        series.push(key, obs(&at(16, 30), [1700.0, 100.0, 100.0]));
        series.push(key, obs(&at(17, 0), [3600.0, 100.0, 100.0]));
        let now = parse_kickoff(&at(17, 10)).unwrap();
        let kickoff = parse_kickoff(&at(19, 0)).unwrap();
        let fresh = compute(&series, key, 0, now, Some(kickoff));
        assert!(fresh.ok, "{}", fresh.why);
        assert!(fresh.late, "afflux de 2000 £ contre 300 £/h : {fresh:?}");
        assert!(fresh.steam || !fresh.steam, "champ défini");
    }

    #[test]
    fn steam_requires_a_shortening_price() {
        let mut series = Series::default();
        let key = "1x2:1:2";
        let mut a = obs(&at(16, 20), [1000.0, 100.0, 100.0]);
        a.coef = [2.20, 3.4, 3.8];
        let mut b = obs(&at(17, 0), [3000.0, 100.0, 100.0]);
        b.coef = [2.00, 3.4, 3.8];
        series.push(key, a);
        series.push(key, b);
        let now = parse_kickoff(&at(17, 10)).unwrap();
        let fresh = compute(&series, key, 0, now, None);
        assert!(fresh.ok);
        assert!(fresh.steam, "cote 2.20 → 2.00 et 100 % du frais : {fresh:?}");
        assert!(!fresh.reversal);
    }
}
