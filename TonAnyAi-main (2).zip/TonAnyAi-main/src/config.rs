//! Configuration lue depuis l'environnement (le `.env` est chargé par le
//! lanceur, jamais lu ici : aucun secret ne transite par le code).

use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct Config {
    pub port: u16,
    pub user: Option<String>,
    pub password: Option<String>,
    /// URL de base Arbworld (surchargeable pour les tests).
    pub arbworld_base: String,
    pub data_dir: PathBuf,
    pub cloudflare_account: Option<String>,
    pub cloudflare_token: Option<String>,
    /// Jeton dédié à D1 (repli sur `CLOUDFLARE_API_TOKEN`).
    pub d1_token: Option<String>,
    /// Jeton dédié à KV (repli sur `CLOUDFLARE_API_TOKEN`).
    pub kv_token: Option<String>,
    pub d1_database: Option<String>,
    pub kv_namespace: Option<String>,
    pub gemini_key: Option<String>,
    pub cache_ttl_secs: u64,
    pub stale_ttl_secs: u64,
    /// Contact publié dans le User-Agent (`SCRAPER_CONTACT`).
    pub scraper_contact: Option<String>,
    /// Cadence quand une rencontre est en cours ou imminente.
    pub active_interval_secs: u64,
    /// Cadence de repos (aucune rencontre dans la fenêtre active).
    pub idle_interval_secs: u64,
    /// Jitter positif maximal ajouté à chaque intervalle (casse la régularité).
    pub jitter_secs: u64,
    /// Horizon, en heures, au-delà duquel une rencontre n'est plus « imminente ».
    pub active_window_hours: i64,
    /// Jeton exigé pour `POST /api/refresh` quand il est défini.
    pub refresh_token: Option<String>,
    /// Jeton du bot Telegram qui envoie les alertes (facultatif).
    pub telegram_token: Option<String>,
    /// Discussion qui reçoit les alertes (facultatif).
    pub telegram_chat: Option<String>,
    /// Base de l'API Telegram ; surchargeable pour un serveur de test local.
    pub telegram_base: String,
}

fn env(key: &str) -> Option<String> {
    std::env::var(key)
        .ok()
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
}

impl Config {
    pub fn from_env() -> Self {
        Config {
            port: env("PORT").and_then(|p| p.parse().ok()).unwrap_or(8080),
            user: env("DASHBOARD_USER").or_else(|| Some("truevalue".to_string())),
            password: env("DASHBOARD_PASSWORD"),
            arbworld_base: env("ARBWORLD_BASE")
                .unwrap_or_else(|| "https://arbworld.net/fr/moneyway".to_string()),
            data_dir: env("DATA_DIR")
                .map(PathBuf::from)
                .unwrap_or_else(|| PathBuf::from("data")),
            cloudflare_account: env("CLOUDFLARE_ACCOUNT_ID"),
            cloudflare_token: env("CLOUDFLARE_API_TOKEN"),
            d1_token: env("D1_API_TOKEN"),
            kv_token: env("KV_API_TOKEN"),
            d1_database: env("D1_DATABASE_ID"),
            kv_namespace: env("KV_NAMESPACE_ID"),
            gemini_key: env("GEMINI_API_KEY"),
            cache_ttl_secs: env("CACHE_TTL_SECS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(20),
            stale_ttl_secs: env("STALE_TTL_SECS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(900),
            scraper_contact: env("SCRAPER_CONTACT"),
            active_interval_secs: env("ACTIVE_INTERVAL_SECS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(600),
            idle_interval_secs: env("IDLE_INTERVAL_SECS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(1800),
            jitter_secs: env("JITTER_SECS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(90),
            active_window_hours: env("ACTIVE_WINDOW_HOURS")
                .and_then(|v| v.parse().ok())
                .unwrap_or(6),
            refresh_token: env("REFRESH_TOKEN"),
            telegram_token: env("TELEGRAM_BOT_TOKEN"),
            telegram_chat: env("TELEGRAM_CHAT_ID"),
            telegram_base: env("TELEGRAM_API_BASE")
                .unwrap_or_else(|| "https://api.telegram.org".to_string()),
        }
    }

    /// Stockage Cloudflare complet (D1 + KV) ?
    pub fn cloudflare_ready(&self) -> bool {
        let d1_auth = self.d1_token.is_some() || self.cloudflare_token.is_some();
        let kv_auth = self.kv_token.is_some() || self.cloudflare_token.is_some();
        self.cloudflare_account.is_some()
            && d1_auth
            && kv_auth
            && self.d1_database.is_some()
            && self.kv_namespace.is_some()
    }

    /// Jeton effectif pour D1.
    pub fn d1_token(&self) -> Option<String> {
        self.d1_token
            .clone()
            .or_else(|| self.cloudflare_token.clone())
    }

    /// Jeton effectif pour KV.
    pub fn kv_token(&self) -> Option<String> {
        self.kv_token
            .clone()
            .or_else(|| self.cloudflare_token.clone())
    }

    pub fn auth_required(&self) -> bool {
        self.password.is_some()
    }
}
