//! Journal des rencontres suivies et bilan de la journée.
//!
//! Toute rencontre enregistrée dans les signaux y entre, **y compris les
//! recoupements neutres** : ce sont les résultats de matchs qui sont suivis, pas
//! seulement les paris. Le score vient d'ESPN, avec SportScore en secours ; une
//! rencontre dont le score n'est pas retrouvé reste sans score, elle n'est
//! jamais notée par défaut.

use chrono::Datelike;
use serde::{Deserialize, Serialize};

use crate::enrich::parse_kickoff;
use crate::model::{
    BetOutcome, Confidence, FixtureMetrics, MatchResult, MatchState, Signal, SignalKind,
    TrackedSignal,
};

/// Provenance prioritaire des scores.
pub const SCORE_SOURCE: &str = "espn";

/// Provenance de secours pour les compétitions qu'ESPN ne couvre pas.
pub const SPORTSCORE_SOURCE: &str = "sportscore";

/// Libellé du bilan quotidien quand les deux sources peuvent alimenter le journal.
pub const SCORE_SOURCE_LABEL: &str = "espn + sportscore";

/// Une rencontre suivie, neutre comprise, avec son score quand il est connu.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MatchLogRow {
    pub fixture_key: String,
    /// Coup d'envoi tel que collecté (`2026-11-12 19:45:00`).
    pub match_date: String,
    /// Journée du coup d'envoi (UTC, `AAAA-MM-JJ`) : clé du bilan quotidien.
    pub day: String,
    pub home: String,
    pub away: String,
    pub league: String,
    /// Type de signal au dernier relevé (`neutral` pour un recoupement neutre).
    pub kind: String,
    /// Vrai si la rencontre a porté au moins un signal non neutre.
    pub flagged: bool,
    pub state: MatchState,
    pub status_detail: String,
    pub home_score: Option<i64>,
    pub away_score: Option<i64>,
    /// Fournisseur du score (`espn`), vide tant qu'aucun score n'est connu.
    pub source: String,
    /// Mesures de contexte figées au dernier relevé d'avant-match. Absentes des
    /// rencontres journalisées avant l'ajout de la calibration.
    #[serde(default)]
    pub metrics: Option<FixtureMetrics>,
    pub updated_at: String,
}

impl MatchLogRow {
    /// Ligne de journal pour un signal du snapshot (neutre ou non).
    /// `None` si le coup d'envoi est illisible : on n'invente pas de journée.
    pub fn from_signal(signal: &Signal, now: &str) -> Option<Self> {
        let day = day_of(&signal.date)?;
        Some(Self {
            fixture_key: signal.fixture_key.clone(),
            match_date: signal.date.clone(),
            day,
            home: signal.home.clone(),
            away: signal.away.clone(),
            league: signal.league.clone(),
            kind: signal.kind.key().to_string(),
            flagged: signal.kind.flagged(),
            state: MatchState::Scheduled,
            status_detail: String::new(),
            home_score: None,
            away_score: None,
            source: String::new(),
            metrics: Some(signal.metrics.clone()),
            updated_at: now.to_string(),
        })
    }

    /// Ligne de journal pour un signal déjà persisté.
    ///
    /// Le snapshot courant ne suffit pas : une rencontre sort du snapshot dès
    /// qu'elle démarre (ou qu'une collecte la laisse de côté), alors qu'elle
    /// reste dans l'historique. Sans cette reprise, le bilan du jour affichait
    /// des propositions sans leurs rencontres.
    pub fn from_tracked(row: &TrackedSignal, now: &str) -> Option<Self> {
        if row.fixture_key.is_empty() || row.home.is_empty() || row.away.is_empty() {
            return None;
        }
        let day = day_of(&row.date)?;
        let kind = SignalKind::from_key(&row.kind)
            .map(|kind| kind.key().to_string())
            .unwrap_or_else(|| row.kind.clone());
        let flagged = SignalKind::from_key(&row.kind)
            .map(|kind| kind.flagged())
            .unwrap_or(!row.kind.is_empty());
        // Score déjà noté : on le recopie tel quel. Sinon la rencontre reste à
        // venir, et le prochain cycle la réinterroge.
        let graded = row.home_score.is_some() && row.away_score.is_some();
        Some(Self {
            fixture_key: row.fixture_key.clone(),
            match_date: row.date.clone(),
            day,
            home: row.home.clone(),
            away: row.away.clone(),
            league: row.league.clone(),
            kind,
            flagged,
            state: if graded {
                MatchState::Finished
            } else {
                MatchState::Scheduled
            },
            status_detail: if graded { "FT".to_string() } else { String::new() },
            home_score: row.home_score,
            away_score: row.away_score,
            source: if graded { SCORE_SOURCE.to_string() } else { String::new() },
            // L'historique des signaux ne transporte pas les mesures de
            // contexte : on n'écrase jamais celles déjà journalisées.
            metrics: None,
            updated_at: now.to_string(),
        })
    }

    /// Applique un résultat ESPN. Renvoie vrai si quelque chose a changé.
    pub fn apply(&mut self, result: &MatchResult, now: &str) -> bool {
        self.apply_from(result, now, SCORE_SOURCE)
    }

    /// Applique un résultat en conservant sa provenance (ESPN ou SportScore).
    ///
    /// Un score déjà enregistré n'est jamais effacé par un relevé plus pauvre,
    /// et un état terminal (terminé, reporté, annulé) n'est jamais rétrogradé.
    pub fn apply_from(&mut self, result: &MatchResult, now: &str, source: &str) -> bool {
        let terminal = matches!(
            self.state,
            MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
        );
        let mut changed = false;
        if !terminal && self.state != result.state {
            self.state = result.state;
            changed = true;
        }
        if !terminal && self.status_detail != result.status_detail {
            self.status_detail = result.status_detail.clone();
            changed = true;
        }
        if result.home_score.is_some() && self.home_score != result.home_score {
            self.home_score = result.home_score;
            changed = true;
        }
        if result.away_score.is_some() && self.away_score != result.away_score {
            self.away_score = result.away_score;
            changed = true;
        }
        if (result.home_score.is_some() || result.away_score.is_some()) && self.source != source {
            self.source = source.to_string();
            changed = true;
        }
        self.updated_at = now.to_string();
        changed
    }

    pub fn has_final_score(&self) -> bool {
        self.state == MatchState::Finished
            && self.home_score.is_some()
            && self.away_score.is_some()
    }
}

/// Journée (UTC) d'une date de coup d'envoi.
pub fn day_of(raw: &str) -> Option<String> {
    parse_kickoff(raw).map(|at| at.date_naive().format("%Y-%m-%d").to_string())
}

/// Clé persistée d'un état de rencontre.
pub fn state_key(state: MatchState) -> &'static str {
    match state {
        MatchState::Scheduled => "SCHEDULED",
        MatchState::InProgress => "IN_PROGRESS",
        MatchState::Finished => "FINISHED",
        MatchState::Postponed => "POSTPONED",
        MatchState::Cancelled => "CANCELLED",
    }
}

/// Relit un état persisté ; une valeur inconnue reste « à venir ».
pub fn state_from(raw: &str) -> MatchState {
    match raw {
        "IN_PROGRESS" => MatchState::InProgress,
        "FINISHED" => MatchState::Finished,
        "POSTPONED" => MatchState::Postponed,
        "CANCELLED" => MatchState::Cancelled,
        _ => MatchState::Scheduled,
    }
}

/// Chiffres de la journée.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct DailyTotals {
    /// Rencontres enregistrées dans les signaux ce jour-là.
    pub tracked: usize,
    /// Dont porteuses d'un signal non neutre.
    pub flagged: usize,
    /// Dont recoupements neutres.
    pub neutral: usize,
    /// Rencontres avec un score final.
    pub finished: usize,
    /// Rencontres sans score final (à venir, en cours ou score indisponible).
    pub awaiting: usize,
    /// Propositions suivies (hors score exact).
    pub bets: usize,
    pub won: usize,
    pub lost: usize,
    pub push: usize,
    /// Propositions pas encore notées (match non joué ou score manquant).
    pub pending_bets: usize,
    /// Profit en unités (mise 1u) sur les propositions réglées.
    pub profit: f64,
    pub roi_pct: f64,
    /// CLV moyen des propositions qui ont une cote de clôture.
    pub clv_pct: Option<f64>,
    /// Rencontres dont la compétition n'a aucune source de score : elles
    /// resteront « en attente » et l'interface doit le dire.
    #[serde(default)]
    pub uncovered: usize,
}

/// Compétition du jour qu'aucune source de score ne couvre.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct UncoveredLeague {
    pub league: String,
    pub matches: usize,
}

/// Une proposition suivie, rattachée à sa rencontre.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DailyBet {
    pub fixture_key: String,
    pub teams: String,
    pub kind: String,
    pub group: String,
    pub market: String,
    pub pick: String,
    pub odds: Option<f64>,
    pub closing_odds: Option<f64>,
    pub clv_pct: Option<f64>,
    pub outcome: BetOutcome,
    pub explanation: String,
    /// Confiance enregistrée à la détection (`None` pour les lignes
    /// antérieures à sa persistance).
    #[serde(default)]
    pub confidence: Option<Confidence>,
}

/// Performance d'un niveau de confiance sur la journée.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ConfidencePerformance {
    pub confidence: String,
    pub bets: usize,
    pub won: usize,
    pub lost: usize,
    pub push: usize,
    pub pending_bets: usize,
    /// Propositions à confiance élevée écartées parce que leur cote est absente
    /// ou inférieure au plancher jouable commun (1,30).
    #[serde(default)]
    pub below_odds_floor: usize,
    /// Profit en unités (mise 1u) sur les propositions réglées.
    pub profit: f64,
    /// `None` tant qu'aucune proposition n'est réglée : un ROI à 0 laisserait
    /// croire à une mesure alors qu'il n'y a rien à mesurer.
    pub roi_pct: Option<f64>,
    pub clv_pct: Option<f64>,
}

/// Bilan d'une journée : uniquement les rencontres de ce jour.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DailyReport {
    pub day: String,
    pub today: String,
    pub label: String,
    pub is_today: bool,
    pub score_source: &'static str,
    pub totals: DailyTotals,
    /// Performances par niveau de confiance (Élevé, Moyen, Faible,
    /// « Non renseigné » pour les lignes antérieures à sa persistance).
    #[serde(default)]
    pub by_confidence: Vec<ConfidencePerformance>,
    pub matches: Vec<MatchLogRow>,
    pub bets: Vec<DailyBet>,
    /// Compétitions du jour sans source de score, les plus fournies d'abord.
    #[serde(default)]
    pub uncovered: Vec<UncoveredLeague>,
    /// Journées disponibles, de la plus récente à la plus ancienne.
    pub days: Vec<String>,
}

/// Compétitions du jour qu'aucune source de score ne couvre.
///
/// Sert à rendre l'attente explicite : « en attente » ne doit pas cacher une
/// compétition qui n'aura jamais de score.
pub fn uncovered_leagues(
    rows: &[MatchLogRow],
    has_source: impl Fn(&str) -> bool,
) -> Vec<UncoveredLeague> {
    let mut counts: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
    for row in rows {
        if row.has_final_score() || has_source(&row.league) {
            continue;
        }
        *counts.entry(row.league.as_str()).or_default() += 1;
    }
    let mut out: Vec<UncoveredLeague> = counts
        .into_iter()
        .map(|(league, matches)| UncoveredLeague {
            league: league.to_string(),
            matches,
        })
        .collect();
    out.sort_by(|a, b| b.matches.cmp(&a.matches).then(a.league.cmp(&b.league)));
    out
}

/// Construit le bilan d'une journée à partir du journal et de l'historique.
pub fn report(
    day: &str,
    today: &str,
    rows: &[MatchLogRow],
    signals: &[TrackedSignal],
    known_days: &[String],
) -> DailyReport {
    let mut matches: Vec<MatchLogRow> = rows.iter().filter(|row| row.day == day).cloned().collect();
    matches.sort_by(|a, b| a.match_date.cmp(&b.match_date).then(a.home.cmp(&b.home)));

    let mut totals = DailyTotals {
        tracked: matches.len(),
        ..Default::default()
    };

    for row in &matches {
        if row.flagged {
            totals.flagged += 1;
        } else {
            totals.neutral += 1;
        }
        if row.has_final_score() {
            totals.finished += 1;
        } else {
            totals.awaiting += 1;
        }
    }

    let mut bets: Vec<DailyBet> = Vec::new();
    for signal in signals {
        if day_of(&signal.date).as_deref() != Some(day) {
            continue;
        }
        for proposal in &signal.proposals {
            // Le score exact n'est jamais noté : il n'entre pas dans le bilan.
            if proposal.group.key() == "score" {
                continue;
            }
            bets.push(DailyBet {
                fixture_key: signal.fixture_key.clone(),
                teams: format!("{} — {}", signal.home, signal.away),
                kind: signal.kind.clone(),
                group: proposal.group.key().to_string(),
                market: proposal.market.clone(),
                pick: proposal.pick.clone(),
                odds: proposal.entry_odds,
                closing_odds: proposal.closing_odds,
                clv_pct: proposal.clv_pct,
                outcome: proposal.outcome,
                explanation: proposal.explanation.clone(),
                confidence: signal.confidence,
            });
        }
    }
    bets.sort_by(|a, b| a.teams.cmp(&b.teams).then(a.market.cmp(&b.market)));
    let by_confidence = confidence_performance(&bets);

    let mut profit = 0.0;
    let mut clv_sum = 0.0;
    let mut clv_n = 0usize;
    for bet in &bets {
        totals.bets += 1;
        match bet.outcome {
            BetOutcome::Won => {
                totals.won += 1;
                profit += bet.odds.unwrap_or(1.0) - 1.0;
            }
            BetOutcome::Lost => {
                totals.lost += 1;
                profit -= 1.0;
            }
            BetOutcome::Push => totals.push += 1,
            BetOutcome::Pending | BetOutcome::Unknown => totals.pending_bets += 1,
        }
        if let Some(clv) = bet.clv_pct {
            clv_sum += clv;
            clv_n += 1;
        }
    }
    let settled = totals.won + totals.lost + totals.push;
    totals.profit = round2(profit);
    totals.roi_pct = if settled > 0 {
        round2(profit / settled as f64 * 100.0)
    } else {
        0.0
    };
    totals.clv_pct = if clv_n > 0 {
        Some(round2(clv_sum / clv_n as f64))
    } else {
        None
    };

    // Sélecteur : le jour courant et les journées passées, jamais les journées
    // à venir — leurs rencontres existent déjà au journal (elles sont suivies à
    // l'avance), mais il n'y a pas de bilan à en tirer.
    let mut days: Vec<String> = known_days
        .iter()
        .filter(|day| day.as_str() <= today)
        .cloned()
        .collect();
    if !days.iter().any(|d| d == today) {
        days.push(today.to_string());
    }
    days.sort_by(|a, b| b.cmp(a));
    days.dedup();

    DailyReport {
        day: day.to_string(),
        today: today.to_string(),
        label: french_day(day),
        is_today: day == today,
        score_source: SCORE_SOURCE_LABEL,
        totals,
        by_confidence,
        matches,
        bets,
        uncovered: Vec::new(),
        days,
    }
}

fn round2(value: f64) -> f64 {
    (value * 100.0).round() / 100.0
}

/// Agrège les propositions de la journée par niveau de confiance.
///
/// L'ordre est fixe (Élevé, Moyen, Faible, non renseigné) pour que l'onglet
/// Bilan affiche toujours la même lecture, même quand un niveau n'a rien produit.
fn confidence_performance(bets: &[DailyBet]) -> Vec<ConfidencePerformance> {
    const LEVELS: [Option<Confidence>; 4] = [
        Some(Confidence::Eleve),
        Some(Confidence::Moyen),
        Some(Confidence::Faible),
        None,
    ];

    LEVELS
        .into_iter()
        .map(|level| {
            let mut out = ConfidencePerformance {
                confidence: level
                    .map(|value| value.label().to_string())
                    .unwrap_or_else(|| "Non renseigné".to_string()),
                ..Default::default()
            };
            let mut clv_sum = 0.0;
            let mut clv_n = 0usize;
            for bet in bets.iter().filter(|bet| bet.confidence == level) {
                // Le plancher ne concerne que la confiance élevée : c'est le
                // filtre utilisateur déjà appliqué à l'affichage et aux alertes.
                // Une cote absente ne passe pas non plus.
                if level == Some(Confidence::Eleve)
                    && !bet
                        .odds
                        .map(|odds| odds >= crate::thresholds::CONFIDENCE_ELEVE_MIN_ODDS)
                        .unwrap_or(false)
                {
                    out.below_odds_floor += 1;
                    continue;
                }
                out.bets += 1;
                match bet.outcome {
                    BetOutcome::Won => {
                        out.won += 1;
                        out.profit += bet.odds.unwrap_or(1.0) - 1.0;
                    }
                    BetOutcome::Lost => {
                        out.lost += 1;
                        out.profit -= 1.0;
                    }
                    BetOutcome::Push => out.push += 1,
                    BetOutcome::Pending | BetOutcome::Unknown => out.pending_bets += 1,
                }
                if let Some(clv) = bet.clv_pct {
                    clv_sum += clv;
                    clv_n += 1;
                }
            }
            let settled = out.won + out.lost + out.push;
            out.profit = round2(out.profit);
            out.roi_pct = (settled > 0).then(|| round2(out.profit / settled as f64 * 100.0));
            out.clv_pct = (clv_n > 0).then(|| round2(clv_sum / clv_n as f64));
            out
        })
        .collect()
}

/// Libellé français d'une journée (`mercredi 12 novembre`), sans dépendance de
/// localisation : c'est le seul endroit où les noms sont écrits.
pub fn french_day(day: &str) -> String {
    let Ok(date) = chrono::NaiveDate::parse_from_str(day, "%Y-%m-%d") else {
        return day.to_string();
    };
    const WEEKDAYS: [&str; 7] = [
        "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche",
    ];
    const MONTHS: [&str; 12] = [
        "janvier",
        "février",
        "mars",
        "avril",
        "mai",
        "juin",
        "juillet",
        "août",
        "septembre",
        "octobre",
        "novembre",
        "décembre",
    ];
    format!(
        "{} {} {}",
        WEEKDAYS[date.weekday().num_days_from_monday() as usize],
        date.day(),
        MONTHS[date.month0() as usize]
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Play, Recommendation, Slot};
    use crate::proposals::{MarketGroup, Proposal};

    fn log_row(kind: &str, state: MatchState, score: Option<(i64, i64)>) -> MatchLogRow {
        MatchLogRow {
            fixture_key: "a_vs_b".into(),
            match_date: "2026-11-12 19:45:00".into(),
            day: "2026-11-12".into(),
            home: "A".into(),
            away: "B".into(),
            league: "Premier League".into(),
            kind: kind.into(),
            flagged: kind != "neutral",
            state,
            status_detail: String::new(),
            home_score: score.map(|s| s.0),
            away_score: score.map(|s| s.1),
            source: if score.is_some() { "espn".into() } else { String::new() },
            metrics: None,
            updated_at: "2026-11-12T20:00:00Z".into(),
        }
    }

    fn proposal(outcome: BetOutcome, entry: f64, close: f64, clv: f64) -> Proposal {
        Proposal {
            group: MarketGroup::Issue,
            market: "1X2".into(),
            pick: "Domicile".into(),
            share: 60.0,
            entry_odds: Some(entry),
            entry_novig: None,
            series_key: "1x2:1:2".into(),
            market_key: None,
            play: Play::MatchResult { side: Slot::First },
            authorized: true,
            closing_odds: Some(close),
            closing_novig: None,
            clv_pct: Some(clv),
            clv_novig_pct: None,
            outcome,
            explanation: "Score final 2-1.".into(),
        }
    }

    fn tracked(outcome: BetOutcome) -> TrackedSignal {
        TrackedSignal {
            id: "x".into(),
            first_seen: "2026-11-12T10:00:00Z".into(),
            last_seen: "2026-11-12T10:00:00Z".into(),
            date: "2026-11-12 19:45:00".into(),
            home: "A".into(),
            away: "B".into(),
            league: "Premier League".into(),
            category: "Steam argent frais".into(),
            convergence_score: 70.0,
            value: Recommendation {
                play: Play::MatchResult { side: Slot::First },
                label: "Domicile".into(),
                odds: Some(2.0),
            },
            safety: Recommendation {
                play: Play::NoBet,
                label: "aucun pari".into(),
                odds: None,
            },
            value_outcome: outcome,
            safety_outcome: BetOutcome::Unknown,
            value_explanation: String::new(),
            home_score: Some(2),
            away_score: Some(1),
            graded_at: Some("2026-11-12T22:00:00Z".into()),
            fixture_key: "a_vs_b".into(),
            kind: "steam".into(),
            confidence: Some(Confidence::Eleve),
            proposals: vec![proposal(outcome, 2.0, 1.8, 11.11)],
            closing_odds: Some(1.8),
            clv_pct: Some(11.11),
            clv_novig_pct: None,
            signal_family: "Résultat".into(),
            minutes_before_kickoff: Some(120),
            liquidity_tier: "HIGH".into(),
        }
    }

    #[test]
    fn neutral_matches_are_counted_like_the_others() {
        let rows = vec![
            log_row("neutral", MatchState::Finished, Some((1, 1))),
            log_row("steam", MatchState::Scheduled, None),
        ];
        let report = report(
            "2026-11-12",
            "2026-11-12",
            &rows,
            &[tracked(BetOutcome::Won)],
            &[],
        );
        assert_eq!(report.totals.tracked, 2);
        assert_eq!(report.totals.neutral, 1);
        assert_eq!(report.totals.flagged, 1);
        assert_eq!(report.totals.finished, 1);
        assert_eq!(report.totals.awaiting, 1);
        assert!(report.is_today);
        assert_eq!(report.label, "jeudi 12 novembre");
    }

    #[test]
    fn uncovered_leagues_lists_the_competitions_without_any_source() {
        let rows = vec![
            log_row("steam", MatchState::Finished, Some((2, 1))),
            log_row("neutral", MatchState::Scheduled, None),
        ];
        let without_source = uncovered_leagues(&rows, |_| false);
        assert_eq!(
            without_source,
            vec![UncoveredLeague {
                league: "Premier League".into(),
                matches: 1,
            }],
            "la rencontre déjà notée n'est pas comptée"
        );
        assert!(uncovered_leagues(&rows, |league| league == "Premier League").is_empty());
    }

    #[test]
    fn a_report_without_coverage_says_so() {
        let rows = vec![log_row("neutral", MatchState::Scheduled, None)];
        let mut report = report("2026-11-12", "2026-11-12", &rows, &[], &[]);
        report.uncovered = uncovered_leagues(&report.matches, |_| false);
        report.totals.uncovered = report.uncovered.iter().map(|u| u.matches).sum();
        assert_eq!(report.totals.uncovered, 1);
        assert_eq!(report.uncovered[0].league, "Premier League");
    }

    #[test]
    fn the_day_selector_only_lists_today_and_past_days() {
        let known = [
            "2026-11-14".to_string(),
            "2026-11-12".to_string(),
            "2026-11-10".to_string(),
        ];
        let report = report("2026-11-11", "2026-11-11", &[], &[], &known);
        assert_eq!(report.days, vec!["2026-11-11", "2026-11-10"]);
    }

    #[test]
    fn a_finished_state_without_score_is_not_a_result() {
        let mut row = log_row("neutral", MatchState::Finished, None);
        row.home_score = None;
        let report = report("2026-11-12", "2026-11-12", &[row], &[], &[]);
        assert_eq!(report.totals.finished, 0);
        assert_eq!(report.totals.awaiting, 1);
    }

    #[test]
    fn bets_are_scoped_to_their_own_day() {
        let report = report(
            "2026-11-13",
            "2026-11-13",
            &[],
            &[tracked(BetOutcome::Won)],
            &[],
        );
        assert_eq!(report.totals.bets, 0);
        assert!(report.bets.is_empty());
    }

    #[test]
    fn roi_and_clv_are_computed_on_settled_bets() {
        let report = report(
            "2026-11-12",
            "2026-11-13",
            &[log_row("steam", MatchState::Finished, Some((2, 1)))],
            &[tracked(BetOutcome::Won)],
            &[],
        );
        assert_eq!(report.totals.bets, 1);
        assert_eq!(report.totals.won, 1);
        assert_eq!(report.totals.profit, 1.0);
        assert_eq!(report.totals.roi_pct, 100.0);
        assert_eq!(report.totals.clv_pct, Some(11.11));
        assert!(!report.is_today);
    }

    #[test]
    fn high_confidence_bets_are_separated_from_the_rest() {
        let mut medium = tracked(BetOutcome::Lost);
        medium.id = "medium".into();
        medium.confidence = Some(Confidence::Moyen);

        let mut short = tracked(BetOutcome::Lost);
        short.id = "short".into();
        short.proposals[0].entry_odds = Some(1.29);

        let mut boundary = tracked(BetOutcome::Won);
        boundary.id = "boundary".into();
        boundary.proposals[0].entry_odds = Some(1.3);

        let mut legacy = tracked(BetOutcome::Pending);
        legacy.id = "legacy".into();
        legacy.confidence = None;
        legacy.proposals[0].outcome = BetOutcome::Pending;
        legacy.proposals[0].clv_pct = None;

        let report = report(
            "2026-11-12",
            "2026-11-12",
            &[log_row("steam", MatchState::Finished, Some((2, 1)))],
            &[tracked(BetOutcome::Won), boundary, short, medium, legacy],
            &[],
        );

        assert_eq!(report.by_confidence.len(), 4);
        let high = &report.by_confidence[0];
        assert_eq!(high.confidence, "Élevé");
        assert_eq!((high.bets, high.won, high.lost), (2, 2, 0));
        assert_eq!(high.below_odds_floor, 1, "1,29 est sous le plancher");
        assert_eq!(high.profit, 1.3, "1,00 + 0,30 : 1,30 passe");
        assert_eq!(high.roi_pct, Some(65.0));

        let medium = &report.by_confidence[1];
        assert_eq!(medium.confidence, "Moyen");
        assert_eq!((medium.bets, medium.won, medium.lost), (1, 0, 1));
        assert_eq!(medium.roi_pct, Some(-100.0));

        let unknown = report.by_confidence.last().expect("niveau non renseigné");
        assert_eq!(unknown.confidence, "Non renseigné");
        assert_eq!(unknown.bets, 1);
        assert_eq!(unknown.pending_bets, 1);
        assert_eq!(unknown.roi_pct, None, "rien de réglé, donc rien à mesurer");
    }

    #[test]
    fn pending_proposals_never_count_as_settled() {
        let report = report(
            "2026-11-12",
            "2026-11-12",
            &[log_row("steam", MatchState::InProgress, None)],
            &[tracked(BetOutcome::Pending)],
            &[],
        );
        assert_eq!(report.totals.pending_bets, 1);
        assert_eq!(report.totals.profit, 0.0);
        assert_eq!(report.totals.roi_pct, 0.0);
    }

    #[test]
    fn apply_never_clears_a_recorded_score() {
        let mut row = log_row("steam", MatchState::Finished, Some((2, 1)));
        let poorer = MatchResult {
            id: "1".into(),
            name: "A vs B".into(),
            date: "2026-11-12 19:45:00".into(),
            date_label: String::new(),
            league_slug: "eng.1".into(),
            league_name: String::new(),
            home_team: "A".into(),
            away_team: "B".into(),
            home_logo: String::new(),
            away_logo: String::new(),
            home_score: None,
            away_score: None,
            home_ht: None,
            away_ht: None,
            state: MatchState::Scheduled,
            status_detail: "NS".into(),
            completed: false,
            total_goals: None,
            btts: None,
        };
        assert!(!row.apply(&poorer, "2026-11-12T23:00:00Z"));
        assert_eq!(row.state, MatchState::Finished);
        assert_eq!((row.home_score, row.away_score), (Some(2), Some(1)));
        assert_eq!(row.source, "espn");
    }

    #[test]
    fn apply_records_a_first_score() {
        let mut row = log_row("neutral", MatchState::Scheduled, None);
        let result = MatchResult {
            id: "1".into(),
            name: "A vs B".into(),
            date: "2026-11-12 19:45:00".into(),
            date_label: String::new(),
            league_slug: "eng.1".into(),
            league_name: String::new(),
            home_team: "A".into(),
            away_team: "B".into(),
            home_logo: String::new(),
            away_logo: String::new(),
            home_score: Some(0),
            away_score: Some(0),
            home_ht: None,
            away_ht: None,
            state: MatchState::Finished,
            status_detail: "FT".into(),
            completed: true,
            total_goals: Some(0),
            btts: Some(false),
        };
        assert!(row.apply(&result, "2026-11-12T23:00:00Z"));
        assert!(row.has_final_score());
        assert_eq!(row.source, "espn");
    }

    #[test]
    fn a_persisted_signal_rejoins_the_journal_with_its_result() {
        let row = MatchLogRow::from_tracked(&tracked(BetOutcome::Won), "2026-11-12T23:00:00Z")
            .expect("ligne de journal");
        assert!(row.flagged);
        assert_eq!(row.kind, "steam");
        assert!(row.has_final_score());
        assert_eq!(row.source, "espn");
        assert_eq!(row.day, "2026-11-12");
    }

    #[test]
    fn an_ungraded_signal_stays_without_score() {
        let mut signal = tracked(BetOutcome::Pending);
        signal.home_score = None;
        signal.away_score = None;
        let row = MatchLogRow::from_tracked(&signal, "2026-11-12T23:00:00Z").expect("ligne");
        assert_eq!(row.state, MatchState::Scheduled);
        assert!(!row.has_final_score());
        assert!(row.source.is_empty());
    }

    #[test]
    fn a_signal_without_fixture_key_is_skipped() {
        let mut signal = tracked(BetOutcome::Won);
        signal.fixture_key.clear();
        assert!(MatchLogRow::from_tracked(&signal, "2026-11-12T23:00:00Z").is_none());
    }

    #[test]
    fn unbounded_dates_do_not_create_a_day() {
        assert_eq!(day_of("pas une date"), None);
        assert_eq!(day_of("2026-11-12 19:45:00"), Some("2026-11-12".into()));
    }
}
