//! Grille de scores : chaque issue est un **ensemble de scores**.
//!
//! Deux issues fortement financées sont contradictoires si l'intersection de
//! leurs ensembles est vide. C'est un test unique qui remplace les règles
//! codées en dur : Under 2.5 contre Over 3.5, victoire extérieur contre 1X,
//! Over 2.5 contre score exact 1-0, etc.
//!
//! Univers : 0 à 6 buts par équipe, plus une cellule « autre » par côté
//! (7 = « 7 buts ou plus »). Comme aucune ligne de buts suivie ne dépasse 3.5,
//! traiter « autre » comme 7 buts est exact pour toutes les comparaisons.
//!
//! La mi-temps et le MT/FM sont **hors grille** : le score à la mi-temps n'est
//! pas comparable au score final, et le MT/FM est une combinaison de deux
//! scores. Ils ne peuvent donc ni confirmer ni contredire par ce test.

use crate::market::MarketKey;


/// Buts par équipe pris en compte individuellement.
pub const SIDE_MAX: u8 = 6;
/// Cellule « 7 buts ou plus ».
pub const OTHER: u8 = 7;
/// Nombre de cellules : 8 × 8.
pub const CELLS: usize = 64;

pub type ScoreSet = [bool; CELLS];

fn idx(home: u8, away: u8) -> usize {
    home as usize * 8 + away as usize
}

fn build(mut f: impl FnMut(u8, u8) -> bool) -> ScoreSet {
    let mut set = [false; CELLS];
    for home in 0..=OTHER {
        for away in 0..=OTHER {
            set[idx(home, away)] = f(home, away);
        }
    }
    set
}

pub fn home_win() -> ScoreSet {
    build(|h, a| h > a)
}

pub fn draw() -> ScoreSet {
    build(|h, a| h == a)
}

pub fn away_win() -> ScoreSet {
    build(|h, a| a > h)
}

pub fn both_score() -> ScoreSet {
    build(|h, a| h > 0 && a > 0)
}

pub fn over(line: f64) -> ScoreSet {
    build(|h, a| (h + a) as f64 > line)
}

pub fn under(line: f64) -> ScoreSet {
    build(|h, a| ((h + a) as f64) < line)
}

fn union(a: &ScoreSet, b: &ScoreSet) -> ScoreSet {
    std::array::from_fn(|i| a[i] || b[i])
}

fn exact(label: &str) -> Option<ScoreSet> {
    let (h, a) = label.split_once('-')?;
    let home: u8 = h.trim().parse().ok()?;
    let away: u8 = a.trim().parse().ok()?;
    if home > SIDE_MAX || away > SIDE_MAX {
        return None;
    }
    let mut set = [false; CELLS];
    set[idx(home, away)] = true;
    Some(set)
}

/// Ensemble de scores couvert par l'issue `slot` d'un marché.
///
/// `None` signifie « hors grille » (mi-temps, MT/FM, libellé illisible) : ce
/// n'est pas un ensemble vide, c'est une absence de représentation.
pub fn issue_set(market: MarketKey, slot: usize, label: &str) -> Option<ScoreSet> {
    match market {
        MarketKey::OneXTwo => Some(match slot {
            0 => home_win(),
            1 => draw(),
            _ => away_win(),
        }),
        // Le DNB est le seul handicap proposé : « nul exclu », donc l'ensemble
        // d'une victoire à domicile ne contient pas les scores nuls.
        MarketKey::DrawNoBet => Some(match slot {
            0 => home_win(),
            2 => away_win(),
            _ => build(|_, _| false),
        }),
        MarketKey::DoubleChance => Some(match slot {
            0 => union(&home_win(), &draw()),
            1 => union(&draw(), &away_win()),
            _ => union(&home_win(), &away_win()),
        }),
        MarketKey::OverUnder15 => Some(if slot == 0 {
            under(1.5)
        } else {
            over(1.5)
        }),
        MarketKey::OverUnder25 => Some(if slot == 0 {
            under(2.5)
        } else {
            over(2.5)
        }),
        MarketKey::OverUnder35 => Some(if slot == 0 {
            under(3.5)
        } else {
            over(3.5)
        }),
        MarketKey::Btts => Some(if slot == 0 {
            both_score()
        } else {
            build(|h, a| !(h > 0 && a > 0))
        }),
        MarketKey::CorrectScore => exact(label),
        MarketKey::HalfTime | MarketKey::HalfTimeFullTime => None,
    }
}

/// Les deux ensembles ont-ils au moins un score en commun ?
pub fn overlap(a: &ScoreSet, b: &ScoreSet) -> bool {
    a.iter().zip(b.iter()).any(|(x, y)| *x && *y)
}

/// Contradiction : aucune histoire de score ne satisfait les deux issues.
pub fn contradict(a: &ScoreSet, b: &ScoreSet) -> bool {
    !overlap(a, b)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn set(market: MarketKey, slot: usize) -> ScoreSet {
        let label = if market == MarketKey::CorrectScore {
            "1-0"
        } else {
            ""
        };
        issue_set(market, slot, label).expect("issue représentable")
    }

    #[test]
    fn under_25_contradicts_over_35() {
        assert!(contradict(
            &set(MarketKey::OverUnder25, 0),
            &set(MarketKey::OverUnder35, 2)
        ));
    }

    #[test]
    fn under_25_does_not_contradict_over_15() {
        // Deux buts exactement : sous 2.5 et au-dessus de 1.5.
        assert!(overlap(
            &set(MarketKey::OverUnder25, 0),
            &set(MarketKey::OverUnder15, 2)
        ));
        // …mais Under 2.5 et Over 2.5 s'excluent bien.
        assert!(contradict(
            &set(MarketKey::OverUnder25, 0),
            &set(MarketKey::OverUnder25, 2)
        ));
    }

    #[test]
    fn away_win_contradicts_double_chance_1x() {
        assert!(contradict(
            &set(MarketKey::OneXTwo, 2),
            &set(MarketKey::DoubleChance, 0)
        ));
    }

    #[test]
    fn home_win_does_not_contradict_dnb_home() {
        assert!(overlap(
            &set(MarketKey::OneXTwo, 0),
            &set(MarketKey::DrawNoBet, 0)
        ));
    }

    #[test]
    fn over_25_contradicts_exact_score_1_0() {
        let score = issue_set(MarketKey::CorrectScore, 0, "1-0").expect("score lisible");
        assert!(contradict(&set(MarketKey::OverUnder25, 2), &score));
    }

    #[test]
    fn btts_no_does_not_contradict_over_25() {
        // 3-0 : plus de 2.5 buts et une équipe qui ne marque pas.
        assert!(overlap(
            &set(MarketKey::Btts, 2),
            &set(MarketKey::OverUnder25, 2)
        ));
    }

    #[test]
    fn half_time_is_out_of_grid() {
        assert!(issue_set(MarketKey::HalfTime, 0, "").is_none());
        assert!(issue_set(MarketKey::HalfTimeFullTime, 0, "1/1").is_none());
    }
}
