//! Serveur HTTP (tiny_http) : API JSON + assets embarqués.
//!
//! - authentification Basic obligatoire dès qu'un mot de passe est configuré ;
//! - lecture sans effet de bord : seule `POST /api/refresh` collecte ;
//! - aucune réponse « fallback » : si le snapshot est absent, l'API renvoie 503
//!   et le tableau de bord affiche un état vide explicite.

use std::sync::Arc;
use std::thread;

use base64::Engine;
use serde::Serialize;
use serde_json::{json, Value};
use tiny_http::{Header, Method, Request, Response, Server};

use crate::ai::Analyzer;
use crate::market::MarketKey;
use crate::pipeline::Pipeline;

const INDEX_HTML: &str = include_str!("../site/index.html");
const APP_JS: &str = include_str!("../site/app.js");
const STYLE_CSS: &str = include_str!("../site/style.css");

/// Comparaison à temps constant (jeton de refresh, comme pour Basic auth).
fn constant_time_eq(a: &str, b: &str) -> bool {
    a.len() == b.len()
        && a.bytes()
            .zip(b.bytes())
            .fold(0u8, |acc, (x, y)| acc | (x ^ y))
            == 0
}

pub struct App {
    pipeline: Arc<Pipeline>,
    analyzer: Analyzer,
}

fn header(name: &str, value: &str) -> Header {
    Header::from_bytes(name.as_bytes(), value.as_bytes()).expect("en-tête valide")
}

fn respond_json(request: Request, code: u16, value: &impl Serialize) {
    let body = serde_json::to_string(value).unwrap_or_else(|_| "{}".to_string());
    let response = Response::from_string(body)
        .with_status_code(code)
        .with_header(header("Content-Type", "application/json; charset=utf-8"))
        .with_header(header("Cache-Control", "no-store"));
    let _ = request.respond(response);
}

fn respond_text(request: Request, code: u16, content_type: &str, body: &str) {
    // `private` : ces assets sont servis derrière l'authentification Basic et
    // ne doivent pas être mis en cache par un proxy partagé.
    let response = Response::from_string(body)
        .with_status_code(code)
        .with_header(header("Content-Type", content_type))
        .with_header(header("Cache-Control", "private, max-age=300"));
    let _ = request.respond(response);
}

fn error(request: Request, code: u16, message: impl Into<String>) {
    respond_json(
        request,
        code,
        &json!({ "ok": false, "error": message.into() }),
    );
}

fn decode_component(raw: &str) -> String {
    let bytes = raw.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b'%' if i + 2 < bytes.len() => {
                let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).unwrap_or("");
                match u8::from_str_radix(hex, 16) {
                    Ok(byte) => {
                        out.push(byte);
                        i += 3;
                    }
                    Err(_) => {
                        out.push(b'%');
                        i += 1;
                    }
                }
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).to_string()
}

fn query_map(query: &str) -> std::collections::HashMap<String, String> {
    query
        .split('&')
        .filter(|p| !p.is_empty())
        .filter_map(|pair| {
            let (k, v) = pair.split_once('=').unwrap_or((pair, ""));
            Some((decode_component(k), decode_component(v)))
        })
        .collect()
}

impl App {
    pub fn new(pipeline: Arc<Pipeline>) -> Self {
        let analyzer = Analyzer::new(pipeline.cfg.gemini_key.clone());
        Self { pipeline, analyzer }
    }

    fn authorized(&self, request: &Request) -> bool {
        let Some(expected) = &self.pipeline.cfg.password else {
            return true;
        };
        let user = self
            .pipeline
            .cfg
            .user
            .clone()
            .unwrap_or_else(|| "truevalue".to_string());
        let header_value = request
            .headers()
            .iter()
            .find(|h| {
                h.field
                    .as_str()
                    .as_str()
                    .eq_ignore_ascii_case("authorization")
            })
            .map(|h| h.value.as_str().to_string());
        let Some(value) = header_value else {
            return false;
        };
        let Some(encoded) = value.strip_prefix("Basic ") else {
            return false;
        };
        let decoded = base64::engine::general_purpose::STANDARD
            .decode(encoded.trim())
            .ok()
            .and_then(|bytes| String::from_utf8(bytes).ok());
        match decoded {
            Some(creds) => {
                let expected_creds = format!("{user}:{expected}");
                // Comparaison à temps constant.
                creds.len() == expected_creds.len()
                    && creds
                        .bytes()
                        .zip(expected_creds.bytes())
                        .fold(0u8, |acc, (a, b)| acc | (a ^ b))
                        == 0
            }
            None => false,
        }
    }

    /// Jeton machine valide (cron Cloudflare) ?
    fn token_ok(&self, request: &Request) -> bool {
        let Some(token) = &self.pipeline.cfg.refresh_token else {
            return false;
        };
        request
            .headers()
            .iter()
            .find(|h| {
                h.field
                    .as_str()
                    .as_str()
                    .eq_ignore_ascii_case("x-refresh-token")
            })
            .map(|h| constant_time_eq(h.value.as_str(), token))
            .unwrap_or(false)
    }

    /// Collecte autorisée : jeton machine (cron Cloudflare) **ou** opérateur
    /// connecté au tableau de bord. Sans la seconde branche, le bouton
    /// « Actualiser » de l'interface renvoyait 403 dès qu'un jeton était posé.
    fn refresh_allowed(&self, request: &Request) -> bool {
        if self.pipeline.cfg.refresh_token.is_none() {
            return true;
        }
        self.token_ok(request)
            || (self.pipeline.cfg.auth_required() && self.authorized(request))
    }

    fn snapshot_or_error(&self, request: Request) {
        match self.pipeline.snapshot() {
            Some(snapshot) => {
                // Le bloc `v2` est ajouté au snapshot tel quel ; il est absent
                // quand l'historisation n'est pas active.
                let mut value = serde_json::to_value(&snapshot).unwrap_or_else(|_| json!({}));
                if let Some(block) = self.pipeline.v2_block(&snapshot) {
                    value["v2"] = serde_json::to_value(block).unwrap_or(Value::Null);
                }
                respond_json(request, 200, &value)
            }
            None => error(
                request,
                503,
                "Aucun snapshot. Lancez une collecte (POST /api/refresh).",
            ),
        }
    }

    /// Bloc `v2` seul (route dédiée pour la nouvelle interface).
    fn v2_or_unavailable(&self, request: Request) {
        let Some(snapshot) = self.pipeline.snapshot() else {
            return error(request, 503, "Aucun snapshot disponible.");
        };
        match self.pipeline.v2_block(&snapshot) {
            Some(block) => {
                let mut value = json!({ "ok": true });
                value["v2"] = serde_json::to_value(block).unwrap_or(Value::Null);
                respond_json(request, 200, &value)
            }
            None => respond_json(
                request,
                200,
                &json!({
                    "ok": true,
                    "v2": null,
                    "reason": "Historisation inactive : aucun relevé enregistré.",
                }),
            ),
        }
    }

    fn handle_body(&self, request: &mut Request) -> Value {
        let mut body = String::new();
        let _ = request.as_reader().read_to_string(&mut body);
        serde_json::from_str(&body).unwrap_or(Value::Null)
    }

    pub fn handle(&self, mut request: Request) {
        let method = request.method().clone();
        let full_url = request.url().to_string();
        let (path, query) = full_url.split_once('?').unwrap_or((&full_url, ""));
        let query = query_map(query);

        if request.method() == &Method::Options {
            let _ = request
                .respond(Response::empty(204).with_header(header("Allow", "GET, POST, OPTIONS")));
            return;
        }

        // Routes publiques (santé + assets + favicon).
        match (method.clone(), path) {
            (Method::Get, "/api/health") => {
                let snapshot = self.pipeline.snapshot();
                return respond_json(
                    request,
                    200,
                    &json!({
                        "ok": true,
                        "mode": self.pipeline.store.mode(),
                        "auth": self.pipeline.cfg.auth_required(),
                        "d1": self.pipeline.store.d1_usage().map(|usage| json!({
                            "day": usage.day,
                            "rows_read": usage.rows_read,
                            "rows_written": usage.rows_written,
                            "read_ratio": usage.read_ratio(),
                            "write_ratio": usage.write_ratio(),
                            "blocked": usage.blocked,
                        })),
                        "snapshot": snapshot.map(|s| json!({
                            "computed_at": s.computed_at,
                            "signals": s.signals.len(),
                            "markets": s.markets.len(),
                        })),
                        "schedule": self.pipeline.schedule_info(),
                        "telegram": self.pipeline.alerts_configured(),
                    }),
                );
            }
            (Method::Get, "/") | (Method::Get, "/index.html") => {
                if !self.authorized(&request) {
                    return unauthorized(request);
                }
                return respond_text(request, 200, "text/html; charset=utf-8", INDEX_HTML);
            }
            (Method::Get, "/app.js") => {
                if !self.authorized(&request) {
                    return unauthorized(request);
                }
                return respond_text(
                    request,
                    200,
                    "application/javascript; charset=utf-8",
                    APP_JS,
                );
            }
            (Method::Get, "/style.css") => {
                if !self.authorized(&request) {
                    return unauthorized(request);
                }
                return respond_text(request, 200, "text/css; charset=utf-8", STYLE_CSS);
            }
            (Method::Get, "/favicon.ico") => {
                let _ = request.respond(Response::empty(204));
                return;
            }
            _ => {}
        }

        // Le cron Cloudflare ne peut pas porter d'identifiants Basic : un jeton
        // machine valide suffit pour `POST /api/refresh` (la route revérifie
        // ensuite jeton **ou** opérateur). Sans cette exception, le cron
        // recevait 401 et aucune collecte automatique n'avait lieu.
        let machine_refresh = method == Method::Post
            && path == "/api/refresh"
            && self.token_ok(&request);
        if !self.authorized(&request) && !machine_refresh {
            return unauthorized(request);
        }

        match (method, path) {
            (Method::Get, "/api/snapshot") => self.snapshot_or_error(request),
            (Method::Get, "/api/v2") => self.v2_or_unavailable(request),
            (Method::Get, "/api/markets") => {
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                let markets: Vec<Value> = snapshot
                    .markets
                    .iter()
                    .map(|m| {
                        let key = m.market.unwrap_or(MarketKey::OneXTwo).def();
                        json!({
                            "key": m.key,
                            "label": m.label,
                            "short": m.short,
                            "category": key.category,
                            "help": key.help,
                            "matches": m.matches.len(),
                            "total_volume": m.total_volume,
                            "source": m.source,
                            "error": m.error,
                        })
                    })
                    .collect();
                respond_json(
                    request,
                    200,
                    &json!({
                        "ok": true,
                        "computed_at": snapshot.computed_at,
                        "markets": markets,
                        "total_volume": markets.iter().filter_map(|m| m["total_volume"].as_f64()).sum::<f64>(),
                        "warnings": snapshot.warnings,
                    }),
                )
            }
            (Method::Get, p) if p.starts_with("/api/markets/") => {
                let slug = &p["/api/markets/".len()..];
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                match snapshot.markets.iter().find(|m| m.key == slug) {
                    Some(market) => respond_json(request, 200, market),
                    None => error(request, 404, format!("Marché inconnu : {slug}")),
                }
            }
            (Method::Get, "/api/signals") => {
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                respond_json(
                    request,
                    200,
                    &json!({
                        "ok": true,
                        "computed_at": snapshot.computed_at,
                        "count": snapshot.signals.len(),
                        "signals": snapshot.signals,
                    }),
                )
            }
            (Method::Get, "/api/track-record") => {
                // Bilan recalculé à la lecture : le `track_record` du snapshot
                // date de la collecte et pouvait afficher un total différent
                // des lignes listées juste en dessous.
                let recent = self.pipeline.store.recent_cached(200);
                let stats = self.pipeline.store.signal_stats();
                let by_group: Value = crate::proposals::MarketGroup::PROPOSABLE
                    .into_iter()
                    .map(|group| {
                        let value = stats.by_group.get(group.key()).copied().unwrap_or_default();
                        (group.key().to_string(), stats_json(&value))
                    })
                    .collect::<serde_json::Map<_, _>>()
                    .into();
                let by_kind: Value = stats
                    .by_kind
                    .iter()
                    .map(|(key, value)| (key.clone(), stats_json(value)))
                    .collect::<serde_json::Map<_, _>>()
                    .into();
                // L'historique détaillé (cotes d'entrée et de clôture, CLV,
                // résultat) est déjà construit par le bloc `v2`.
                let hist = self
                    .pipeline
                    .snapshot()
                    .and_then(|snapshot| self.pipeline.v2_block(&snapshot))
                    .map(|block| block.hist)
                    .unwrap_or_default();
                respond_json(
                    request,
                    200,
                    &json!({
                        "ok": true,
                        "track_record": self.pipeline.store.track_record(),
                        "by_group": by_group,
                        "by_kind": by_kind,
                        "totals": stats_json(&stats.totals),
                        "hist": hist,
                        "recent": recent,
                    }),
                )
            }
            (Method::Get, "/api/simulation") => {
                // Lecture seule : aucune ouverture de position ici. Les entrées
                // et les règlements sont faits par la collecte.
                match self.pipeline.simulation_report() {
                    Ok(report) => respond_json(
                        request,
                        200,
                        &json!({ "ok": true, "simulation": report }),
                    ),
                    Err(err) => error(request, 502, format!("Simulation indisponible : {err}")),
                }
            }
            (Method::Get, "/api/daily") => {
                // Sans `date`, le bilan du jour (UTC). Les jours précédents sont
                // listés dans `report.days` ; aucune donnée d'un autre jour
                // n'est mélangée à la réponse.
                let day = query.get("date").map(String::as_str).filter(|d| is_day(d));
                match self.pipeline.daily_report(day) {
                    Ok(report) => respond_json(request, 200, &json!({ "ok": true, "report": report })),
                    Err(err) => error(request, 502, format!("Bilan indisponible : {err}")),
                }
            }
            (Method::Get, "/api/exchange") => {
                // Lecture seule : les prix Polymarket sont lus à la demande et
                // mis en cache, jamais recopiés dans le snapshot.
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                let rows = crate::polymarket::rows(
                    &snapshot.signals,
                    &self.pipeline.exchange,
                    crate::thresholds::EXCHANGE_MAX_FIXTURES,
                );
                let matched = rows.iter().filter(|row| row.quote.is_some()).count();
                respond_json(
                    request,
                    200,
                    &json!({
                        "ok": true,
                        "computed_at": snapshot.computed_at,
                        "count": rows.len(),
                        "matched": matched,
                        "rows": rows,
                    }),
                )
            }
            (Method::Get, "/api/backtest") => {
                // Profondeur bornée : au-delà, la réponse mélangerait des
                // périodes où les seuils n'étaient pas les mêmes.
                let days = query
                    .get("days")
                    .and_then(|raw| raw.parse::<usize>().ok())
                    .unwrap_or(crate::thresholds::BACKTEST_DEFAULT_DAYS)
                    .clamp(1, crate::thresholds::BACKTEST_MAX_DAYS);
                match self.pipeline.backtest(days) {
                    Ok(report) => {
                        respond_json(request, 200, &json!({ "ok": true, "backtest": report }))
                    }
                    Err(err) => error(request, 502, format!("Backtest indisponible : {err}")),
                }
            }
            (Method::Post, "/api/refresh") => {
                if !self.refresh_allowed(&request) {
                    return error(request, 403, "Jeton de refresh invalide.");
                }
                // Le cron (appel machine) suit la cadence adaptative ; un
                // opérateur connecté peut toujours forcer une collecte.
                if self.token_ok(&request) && !self.pipeline.is_due() {
                    return respond_json(
                        request,
                        200,
                        &json!({
                            "ok": true,
                            "deferred": true,
                            "message": "Collecte différée : aucune rencontre imminente.",
                            "schedule": self.pipeline.schedule_info(),
                        }),
                    );
                }
                match self.pipeline.refresh(false) {
                    Ok(snapshot) => respond_json(
                        request,
                        200,
                        &json!({
                            "ok": true,
                            "computed_at": snapshot.computed_at,
                            "signals": snapshot.signals.len(),
                            "warnings": snapshot.warnings,
                        }),
                    ),
                    Err(err) => error(request, 429, err),
                }
            }
            (Method::Post, "/api/ai/match") => {
                let body = self.handle_body(&mut request);
                let market = body
                    .get("market")
                    .and_then(|m| m.as_str())
                    .and_then(MarketKey::parse);
                let id = body.get("id").and_then(|i| i.as_str()).unwrap_or_default();
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                let found = snapshot
                    .markets
                    .iter()
                    .find(|m| Some(m.key.as_str()) == market.map(MarketKey::slug))
                    .and_then(|m| m.matches.iter().find(|row| row.id == id));
                match found {
                    Some(row) => {
                        let (analysis, source) = self.analyzer.analyze_match(row);
                        respond_json(
                            request,
                            200,
                            &json!({ "ok": true, "source": source, "analysis": analysis }),
                        )
                    }
                    None => error(request, 404, "Marché introuvable dans le snapshot."),
                }
            }
            (Method::Post, "/api/ai/signal") => {
                let body = self.handle_body(&mut request);
                let id = body.get("id").and_then(|i| i.as_str()).unwrap_or_default();
                let Some(snapshot) = self.pipeline.snapshot() else {
                    return error(request, 503, "Aucun snapshot disponible.");
                };
                match snapshot.signals.iter().find(|s| s.id == id) {
                    Some(signal) => {
                        let (analysis, source) = self.analyzer.analyze_signal(signal);
                        respond_json(
                            request,
                            200,
                            &json!({ "ok": true, "source": source, "analysis": analysis }),
                        )
                    }
                    None => error(request, 404, "Signal introuvable dans le snapshot."),
                }
            }
            _ => error(request, 404, "Route inconnue."),
        }
    }
}

/// Journée au format `AAAA-MM-JJ` (toute autre valeur est ignorée).
fn is_day(raw: &str) -> bool {
    raw.len() == 10 && raw.chars().all(|c| c.is_ascii_digit() || c == '-')
}

/// Statistiques prêtes pour l'API : chiffres + lisibilité de l'échantillon.
fn stats_json(value: &crate::model::SignalStats) -> Value {
    json!({
        "n": value.n,
        "hit_pct": value.hit_pct,
        "roi_pct": value.roi_pct,
        "clv_pct": value.clv_pct,
        "sample_sufficient": value.sample_sufficient(),
        "reliable": value.reliable(),
    })
}

fn unauthorized(request: Request) {
    let response = Response::from_string("Authentification requise")
        .with_status_code(401)
        .with_header(header("WWW-Authenticate", "Basic realm=\"Truevalue\""))
        .with_header(header("Content-Type", "text/plain; charset=utf-8"));
    let _ = request.respond(response);
}

/// Démarre le serveur (bloquant).
pub fn serve(pipeline: Arc<Pipeline>, threads: usize) -> Result<(), String> {
    let addr = format!("0.0.0.0:{}", pipeline.cfg.port);
    let server = Arc::new(Server::http(&addr).map_err(|e| format!("écoute {addr} : {e}"))?);
    let app = Arc::new(App::new(pipeline));

    let mut handles = Vec::new();
    for _ in 0..threads.max(2) {
        let server = server.clone();
        let app = app.clone();
        handles.push(thread::spawn(move || loop {
            match server.recv() {
                Ok(request) => app.handle(request),
                Err(_) => break,
            }
        }));
    }
    for handle in handles {
        let _ = handle.join();
    }
    Ok(())
}
