//! Résultats réels via l'API publique ESPN.
//!
//! Le rapprochement des équipes est le point fragile de l'implémentation
//! d'origine : elle supprimait le mot « real » et acceptait un score de 0,55 par
//! équipe, ce qui rapprochait le Real Madrid de l'Atlético ou deux clubs d'une
//! même ville. Ici la similarité est calculée sur des jetons normalisés et les
//! deux équipes doivent dépasser un seuil élevé, avec vérification de la date.

use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant};

use serde_json::Value;

use crate::enrich::{format_date, normalize_team, parse_kickoff};
use crate::model::{MatchResult, MatchState};
use crate::thresholds as th;

pub struct League {
    pub slug: &'static str,
    pub name: &'static str,
    pub flag: &'static str,
    pub category: &'static str,
}

pub const LEAGUES: [League; 44] = [
    League {
        slug: "uefa.champions",
        name: "Ligue des champions",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "uefa.europa",
        name: "Ligue Europa",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "uefa.nations",
        name: "Ligue des nations",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "uefa.europa.conf",
        name: "Ligue Conférence",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "eng.1",
        name: "Premier League",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "eng.2",
        name: "Championship",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "eng.3",
        name: "League One",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "eng.fa",
        name: "FA Cup",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "esp.1",
        name: "La Liga",
        flag: "🇪🇸",
        category: "SPAIN",
    },
    League {
        slug: "esp.2",
        name: "Segunda División",
        flag: "🇪🇸",
        category: "SPAIN",
    },
    League {
        slug: "esp.copa_del_rey",
        name: "Coupe du Roi",
        flag: "🇪🇸",
        category: "SPAIN",
    },
    League {
        slug: "ita.1",
        name: "Serie A",
        flag: "🇮🇹",
        category: "ITALY",
    },
    League {
        slug: "ita.2",
        name: "Serie B",
        flag: "🇮🇹",
        category: "ITALY",
    },
    League {
        slug: "ger.1",
        name: "Bundesliga",
        flag: "🇩🇪",
        category: "GERMANY",
    },
    League {
        slug: "ger.2",
        name: "2. Bundesliga",
        flag: "🇩🇪",
        category: "GERMANY",
    },
    League {
        slug: "fra.1",
        name: "Ligue 1",
        flag: "🇫🇷",
        category: "FRANCE",
    },
    League {
        slug: "fra.2",
        name: "Ligue 2",
        flag: "🇫🇷",
        category: "FRANCE",
    },
    League {
        slug: "ned.1",
        name: "Eredivisie",
        flag: "🇳🇱",
        category: "OTHER",
    },
    League {
        slug: "por.1",
        name: "Liga Portugal",
        flag: "🇵🇹",
        category: "OTHER",
    },
    League {
        slug: "tur.1",
        name: "Süper Lig",
        flag: "🇹🇷",
        category: "OTHER",
    },
    League {
        slug: "bel.1",
        name: "Pro League",
        flag: "🇧🇪",
        category: "OTHER",
    },
    League {
        slug: "fifa.friendly",
        name: "Matchs amicaux",
        flag: "🌍",
        category: "OTHER",
    },
    League {
        slug: "fifa.friendly_u21",
        name: "Amicaux internationaux U21",
        flag: "🌍",
        category: "OTHER",
    },
    League {
        slug: "uefa.wchampions",
        name: "Ligue des champions féminine",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "uefa.w.europa",
        name: "Europa League féminine",
        flag: "🇪🇺",
        category: "EUROPE",
    },
    League {
        slug: "caf.nations_qual",
        name: "Qualifications CAN",
        flag: "🌍",
        category: "AFRICA",
    },
    League {
        slug: "concacaf.nations.league",
        name: "Ligue des nations CONCACAF",
        flag: "🌎",
        category: "OTHER",
    },
    League {
        slug: "uru.1",
        name: "Liga AUF Uruguaya",
        flag: "🇺🇾",
        category: "OTHER",
    },
    League {
        slug: "uru.2",
        name: "Segunda División Uruguay",
        flag: "🇺🇾",
        category: "OTHER",
    },
    League {
        slug: "col.1",
        name: "Primera A colombienne",
        flag: "🇨🇴",
        category: "OTHER",
    },
    League {
        slug: "col.2",
        name: "Primera B colombienne",
        flag: "🇨🇴",
        category: "OTHER",
    },
    League {
        slug: "bra.1",
        name: "Brasileirão Serie A",
        flag: "🇧🇷",
        category: "OTHER",
    },
    League {
        slug: "bra.2",
        name: "Brasileirão Serie B",
        flag: "🇧🇷",
        category: "OTHER",
    },
    League {
        slug: "arg.1",
        name: "Liga Profesional argentine",
        flag: "🇦🇷",
        category: "OTHER",
    },
    League {
        slug: "arg.2",
        name: "Primera Nacional argentine",
        flag: "🇦🇷",
        category: "OTHER",
    },
    League {
        slug: "mex.1",
        name: "Liga MX",
        flag: "🇲🇽",
        category: "OTHER",
    },
    League {
        slug: "mex.2",
        name: "Liga de Expansión MX",
        flag: "🇲🇽",
        category: "OTHER",
    },
    League {
        slug: "slv.1",
        name: "Primera División salvadorienne",
        flag: "🇸🇻",
        category: "OTHER",
    },
    League {
        slug: "bol.copa",
        name: "Coupe de Bolivie",
        flag: "🇧🇴",
        category: "OTHER",
    },
    League {
        slug: "sco.2",
        name: "Scottish Championship",
        flag: "🏴",
        category: "OTHER",
    },
    League {
        slug: "eng.4",
        name: "League Two",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "eng.trophy",
        name: "EFL Trophy",
        flag: "🏴",
        category: "ENGLAND",
    },
    League {
        slug: "fra.w.1",
        name: "Première Ligue féminine",
        flag: "🇫🇷",
        category: "FRANCE",
    },
    League {
        slug: "eng.w.league_cup",
        name: "League Cup féminine",
        flag: "🏴",
        category: "ENGLAND",
    },
];

/// Slug ESPN correspondant à une compétition Arbworld, quand la couverture
/// existe. Sert à n'interroger que les compétitions réellement suivies.
/// Correspondances spécifiques (motif dans le nom Arbworld, slug ESPN),
/// testées **avant** les règles génériques : « Brazilian Serie B » contenait
/// « serie b » et partait en Serie B italienne, « Salvadoran Primera Division »
/// en Liga espagnole, « Uruguayan Segunda Division » en Segunda espagnole et
/// « CONCACAF Nations League » en Ligue des nations UEFA. Chaque couple a été
/// vérifié contre les affiches réellement collectées (scoreboard ESPN).
const COMPETITION_SLUGS: [(&str, &str); 24] = [
    ("concacaf nations league", "concacaf.nations.league"),
    // « CAF African Cup of Nations Qualifiers » : les qualifications, pas la
    // phase finale (`caf.nations`), dont les données ne sont pas vérifiées.
    ("cup of nations qualif", "caf.nations_qual"),
    ("women's champions league", "uefa.wchampions"),
    ("ladies europa", "uefa.w.europa"),
    ("ladies league cup", "eng.w.league_cup"),
    ("premiere ligue", "fra.w.1"),
    ("brazilian serie b", "bra.2"),
    ("brazilian serie a", "bra.1"),
    ("colombian primera a", "col.1"),
    ("colombian primera b", "col.2"),
    ("uruguayan primera", "uru.1"),
    ("uruguayan segunda", "uru.2"),
    ("salvadoran primera", "slv.1"),
    ("bolivian cup", "bol.copa"),
    ("efl trophy", "eng.trophy"),
    ("sky bet league 2", "eng.4"),
    ("english league two", "eng.4"),
    ("league two", "eng.4"),
    ("liga de ascenso", "mex.2"),
    ("liga mx", "mex.1"),
    ("argentinian primera division", "arg.1"),
    ("primera nacional", "arg.2"),
    ("scottish championship", "sco.2"),
    ("friendlies international u21", "fifa.friendly_u21"),
];

pub fn slug_for_competition(name: &str) -> Option<&'static str> {
    let n = name.to_lowercase();

    // 1. Correspondances spécifiques d'abord : l'ordre des règles décide.
    for (needle, slug) in COMPETITION_SLUGS {
        if n.contains(needle) {
            return Some(slug);
        }
    }

    // 2. Une compétition féminine ou de jeunes sans correspondance explicite ne
    // doit jamais hériter du championnat masculin senior.
    if n.contains("women") || n.contains("ladies") || n.contains("(w)") {
        return None;
    }
    if n.contains("u19")
        || n.contains("u20")
        || n.contains("u21")
        || n.contains("u23")
        || n.contains("youth")
    {
        return None;
    }

    // 3. Compétitions européennes et coupes.
    if n.contains("nations league") {
        return Some("uefa.nations");
    }
    if n.contains("champions league") {
        return Some("uefa.champions");
    }
    if n.contains("conference league") {
        return Some("uefa.europa.conf");
    }
    if n.contains("europa league") || n.contains("europa cup") {
        return Some("uefa.europa");
    }
    if n.contains("copa del rey") {
        return Some("esp.copa_del_rey");
    }
    if n.contains("fa cup") {
        return Some("eng.fa");
    }
    if n.contains("friendly") || n.contains("friendlies") {
        return Some("fifa.friendly");
    }
    // Championnats nationaux : sans ces correspondances, aucune compétition
    // domestique ne produit de slug, et la notation interne ESPN restait vide
    // pour la majorité des rencontres suivies.
    if n.contains("2. bundesliga") || n.contains("bundesliga 2") {
        return Some("ger.2");
    }
    if n.contains("bundesliga") {
        return Some("ger.1");
    }
    if n.contains("premier league") {
        return Some("eng.1");
    }
    if n.contains("championship") {
        return Some("eng.2");
    }
    if n.contains("league one") {
        return Some("eng.3");
    }
    if n.contains("la liga") || n.contains("laliga") || n.contains("primera division") {
        return Some("esp.1");
    }
    if n.contains("segunda") {
        return Some("esp.2");
    }
    if n.contains("serie b") {
        return Some("ita.2");
    }
    if n.contains("serie a") {
        return Some("ita.1");
    }
    if n.contains("ligue 2") {
        return Some("fra.2");
    }
    if n.contains("ligue 1") {
        return Some("fra.1");
    }
    if n.contains("eredivisie") {
        return Some("ned.1");
    }
    if n.contains("liga portugal") || n.contains("primeira liga") {
        return Some("por.1");
    }
    if n.contains("super lig") || n.contains("süper lig") || n.contains("superlig") {
        return Some("tur.1");
    }
    if n.contains("pro league") || n.contains("jupiler") {
        return Some("bel.1");
    }
    None
}

pub fn league_name(slug: &str) -> &'static str {
    LEAGUES
        .iter()
        .find(|l| l.slug == slug)
        .map(|l| l.name)
        .unwrap_or("Compétition")
}

/// Ligue utilisée quand l'appelant ne précise rien.
pub const DEFAULT_LEAGUES: [&str; 8] = [
    "uefa.champions",
    "uefa.europa",
    "eng.1",
    "esp.1",
    "ita.1",
    "ger.1",
    "fra.1",
    "eng.2",
];

/// Client scoreboard avec cache mémoire.
pub struct ResultsClient {
    ttl: Duration,
    cache: Mutex<HashMap<String, (Instant, Vec<MatchResult>)>>,
}

impl Default for ResultsClient {
    fn default() -> Self {
        Self::new(Duration::from_secs(60))
    }
}

impl ResultsClient {
    pub fn new(ttl: Duration) -> Self {
        Self {
            ttl,
            cache: Mutex::new(HashMap::new()),
        }
    }

    pub fn scoreboard(&self, slug: &str, date: Option<&str>) -> Result<Vec<MatchResult>, String> {
        let cache_key = format!("{slug}_{}", date.unwrap_or("current"));
        {
            let cache = self.cache.lock().unwrap();
            if let Some((at, events)) = cache.get(&cache_key) {
                if at.elapsed() < self.ttl {
                    return Ok(events.clone());
                }
            }
        }

        let mut url =
            format!("https://site.api.espn.com/apis/site/v2/sports/soccer/{slug}/scoreboard");
        if let Some(d) = date {
            url.push_str(&format!("?dates={d}"));
        }

        let response = ureq::get(&url)
            .set("User-Agent", "truevalue/0.1")
            .timeout(Duration::from_secs(8))
            .call()
            .map_err(|e| format!("ESPN {slug} : {e}"))?;

        let payload: Value = response
            .into_json()
            .map_err(|e| format!("ESPN {slug} JSON : {e}"))?;

        let events = payload
            .get("events")
            .and_then(|e| e.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|ev| parse_event(ev, slug))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();

        self.cache
            .lock()
            .unwrap()
            .insert(cache_key, (Instant::now(), events.clone()));
        Ok(events)
    }

    /// Récupère plusieurs ligues (séquentiellement : ESPN est déjà rapide et
    /// paralléliser sans limite a causé des 429 dans la version d'origine).
    ///
    /// Renvoie les rencontres **et** les erreurs : les avaler silencieusement
    /// laissait une position ouverte 48 h sans qu'aucun warning ne signale la
    /// panne du fournisseur de scores.
    pub fn many(&self, slugs: &[&str], date: Option<&str>) -> (Vec<MatchResult>, Vec<String>) {
        let mut out = Vec::new();
        let mut errors = Vec::new();
        for slug in slugs {
            match self.scoreboard(slug, date) {
                Ok(mut events) => out.append(&mut events),
                Err(err) => errors.push(err),
            }
        }
        (out, errors)
    }
}

pub fn parse_event(event: &Value, slug: &str) -> Option<MatchResult> {
    let comp = event
        .get("competitions")
        .and_then(|c| c.as_array())
        .and_then(|c| c.first())?;
    let competitors = comp.get("competitors").and_then(|c| c.as_array())?;
    if competitors.len() < 2 {
        return None;
    }

    let home = competitors
        .iter()
        .find(|c| c.get("homeAway").and_then(|h| h.as_str()) == Some("home"))
        .or_else(|| competitors.first())?;
    let away = competitors
        .iter()
        .find(|c| c.get("homeAway").and_then(|h| h.as_str()) == Some("away"))
        .or_else(|| competitors.get(1))?;

    let status_type = event.get("status").and_then(|s| s.get("type"));
    let state = status_type
        .and_then(|t| t.get("state"))
        .and_then(|s| s.as_str())
        .unwrap_or("pre");
    let status_name = status_type
        .and_then(|t| t.get("name"))
        .and_then(|s| s.as_str())
        .unwrap_or("");
    let completed = status_type
        .and_then(|t| t.get("completed"))
        .and_then(|c| c.as_bool())
        .unwrap_or(false)
        || state == "post";

    let match_state = if status_name.contains("POSTPONED") {
        MatchState::Postponed
    } else if status_name.contains("CANCELED") || status_name.contains("CANCELLED") {
        MatchState::Cancelled
    } else if completed {
        MatchState::Finished
    } else if state == "in" {
        MatchState::InProgress
    } else {
        MatchState::Scheduled
    };

    let score_of = |c: &Value| -> Option<i64> {
        c.get("score").and_then(|s| {
            s.as_str()
                .and_then(|x| x.parse::<i64>().ok())
                .or_else(|| s.as_i64())
        })
    };
    let half_of = |c: &Value| -> Option<i64> {
        c.get("linescores")
            .and_then(|l| l.as_array())
            .and_then(|l| l.first())
            .and_then(|p| p.get("value"))
            .and_then(|v| {
                // ESPN renvoie tantôt un nombre, tantôt une chaîne : sans les
                // deux lectures, la mi-temps manquait et le groupe `mt` était
                // noté Inconnu alors que la donnée existait.
                v.as_i64()
                    .or_else(|| v.as_f64().map(|f| f.round() as i64))
                    .or_else(|| v.as_str().and_then(|s| s.trim().parse::<i64>().ok()))
            })
    };

    // ESPN renvoie « 0 » avant le coup d'envoi : afficher 0-0 sur un match à
    // venir se lit comme un résultat. On ne lit les scores qu'une fois la
    // rencontre commencée.
    let started = matches!(match_state, MatchState::InProgress | MatchState::Finished);
    let home_score = if started { score_of(home) } else { None };
    let away_score = if started { score_of(away) } else { None };
    let (total_goals, btts) = match (home_score, away_score) {
        (Some(h), Some(a)) => (Some(h + a), Some(h > 0 && a > 0)),
        _ => (None, None),
    };

    let date = event
        .get("date")
        .and_then(|d| d.as_str())
        .unwrap_or("")
        .to_string();

    let status_detail = status_type
        .and_then(|t| t.get("detail"))
        .and_then(|d| d.as_str())
        .unwrap_or("")
        .to_string();
    let home_ht = if started { half_of(home) } else { None };
    let away_ht = if started { half_of(away) } else { None };

    Some(MatchResult {
        id: event
            .get("id")
            .and_then(|i| i.as_str())
            .unwrap_or_default()
            .to_string(),
        name: event
            .get("name")
            .and_then(|n| n.as_str())
            .unwrap_or_default()
            .to_string(),
        date_label: format_date(&date),
        date,
        league_slug: slug.to_string(),
        league_name: league_name(slug).to_string(),
        home_team: team_name(home),
        away_team: team_name(away),
        home_logo: logo(home),
        away_logo: logo(away),
        home_score,
        away_score,
        home_ht,
        away_ht,
        state: match_state,
        status_detail,
        completed: match_state == MatchState::Finished,
        total_goals,
        btts,
    })
}

fn team_name(competitor: &Value) -> String {
    competitor
        .get("team")
        .and_then(|t| {
            t.get("displayName")
                .or_else(|| t.get("shortDisplayName"))
                .or_else(|| t.get("name"))
        })
        .and_then(|n| n.as_str())
        .unwrap_or_default()
        .to_string()
}

fn logo(competitor: &Value) -> String {
    competitor
        .get("team")
        .and_then(|t| t.get("logo"))
        .and_then(|l| l.as_str())
        .unwrap_or_default()
        .to_string()
}

/// Similarité entre deux noms d'équipe (0..1).
pub fn similarity(a: &str, b: &str) -> f64 {
    let na = normalize_team(a);
    let nb = normalize_team(b);
    if na.is_empty() || nb.is_empty() {
        return 0.0;
    }
    if na == nb {
        return 1.0;
    }
    // Deux noms dont l'un contient l'autre restent distincts si la partie
    // commune est courte (« Madrid » vs « Real Madrid »).
    if na.contains(&nb) || nb.contains(&na) {
        let (short, long) = if na.len() <= nb.len() {
            (&na, &nb)
        } else {
            (&nb, &na)
        };
        if short.len() >= 5 && long.len() - short.len() <= 6 {
            return 0.92;
        }
    }
    let bg = |s: &str| -> Vec<String> {
        let chars: Vec<char> = s.chars().collect();
        (0..chars.len().saturating_sub(1))
            .map(|i| format!("{}{}", chars[i], chars[i + 1]))
            .collect()
    };
    let (ba, bb) = (bg(&na), bg(&nb));
    if ba.is_empty() || bb.is_empty() {
        return 0.0;
    }
    let hits = ba.iter().filter(|g| bb.contains(g)).count();
    (2.0 * hits as f64) / (ba.len() + bb.len()) as f64
}

/// Retrouve la rencontre ESPN correspondant à une affiche Arbworld.
pub fn find_match<'a>(
    home: &str,
    away: &str,
    date: Option<&str>,
    league_slug: Option<&str>,
    events: &'a [MatchResult],
) -> Option<&'a MatchResult> {
    let mut best: Option<(&MatchResult, f64)> = None;

    for ev in events {
        // Ordre strict : une affiche inversée noterait le domicile sur
        // l'extérieur et fausserait silencieusement tout le bilan. ESPN fournit
        // `homeAway`, donc une inversion est un défaut de données, pas un cas
        // normal.
        let home_sim = similarity(home, &ev.home_team);
        let away_sim = similarity(away, &ev.away_team);
        if home_sim < th::ESPN_MATCH_MIN_SIMILARITY
            || away_sim < th::ESPN_MATCH_MIN_SIMILARITY
        {
            continue;
        }
        // Une même affiche peut se retrouver en championnat et en coupe. Sans
        // contrôle de compétition, un résultat manquant pouvait être remplacé
        // par l'autre match.
        if let Some(slug) = league_slug {
            if ev.league_slug != slug {
                continue;
            }
        }
        let mut scored = (home_sim + away_sim) / 2.0;
        // Les dates Arbworld n'ont pas toujours de fuseau : on compare des
        // horodatages, jamais des chaînes. Une date attendue illisible ne doit
        // pas désactiver silencieusement le contrôle de date.
        if let Some(raw) = date {
            let Some(expected) = parse_kickoff(raw) else {
                continue;
            };
            let Some(at) = parse_kickoff(&ev.date) else {
                continue;
            };
            let seconds = (expected - at).num_seconds().abs();
            if seconds > th::ESPN_MATCH_MAX_HOURS * 3_600 {
                continue;
            }
            scored -= (seconds as f64 / 86_400.0).min(1.0) * 0.02;
        }
        if best.map(|(_, s)| scored > s).unwrap_or(true) {
            best = Some((ev, scored));
        }
    }

    best.filter(|(_, score)| *score >= th::ESPN_MATCH_MIN_SIMILARITY)
        .map(|(ev, _)| ev)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn maps_tracked_competitions_to_espn_slugs() {
        assert_eq!(slug_for_competition("UEFA Nations League A"), Some("uefa.nations"));
        assert_eq!(slug_for_competition("Spanish Copa del Rey"), Some("esp.copa_del_rey"));
        assert_eq!(slug_for_competition("Friendlies International"), Some("fifa.friendly"));
        assert_eq!(
            slug_for_competition("UEFA Women's Champions League"),
            Some("uefa.wchampions")
        );
        assert_eq!(
            slug_for_competition("UEFA Ladies Europa Cup"),
            Some("uefa.w.europa")
        );
        assert_eq!(slug_for_competition("EFL Trophy"), Some("eng.trophy"));
    }

    /// Compétitions vues au journal de production (11-13 nov. 2026) : leur slug
    /// a été vérifié contre les affiches réelles dans le scoreboard ESPN.
    #[test]
    fn competitions_du_journal_sont_mappees_sans_confusion() {
        let cases = [
            ("CAF African Cup of Nations Qualifiers", "caf.nations_qual"),
            ("CONCACAF Nations League B", "concacaf.nations.league"),
            ("Brazilian Serie B", "bra.2"),
            ("Colombian Primera A", "col.1"),
            ("Colombian Primera B", "col.2"),
            ("Uruguayan Segunda Division", "uru.2"),
            ("Salvadoran Primera Division", "slv.1"),
            ("Bolivian Cup", "bol.copa"),
            ("French Premiere Ligue", "fra.w.1"),
            ("English Ladies League Cup", "eng.w.league_cup"),
            ("Friendlies International U21", "fifa.friendly_u21"),
            ("UEFA Nations League D", "uefa.nations"),
        ];
        for (name, slug) in cases {
            assert_eq!(slug_for_competition(name), Some(slug), "{name}");
        }
        // Confusions corrigées : ces noms tombaient dans un championnat étranger.
        assert_ne!(slug_for_competition("Brazilian Serie B"), Some("ita.2"));
        assert_ne!(
            slug_for_competition("Salvadoran Primera Division"),
            Some("esp.1")
        );
        assert_ne!(
            slug_for_competition("Uruguayan Segunda Division"),
            Some("esp.2")
        );
        assert_ne!(
            slug_for_competition("CONCACAF Nations League B"),
            Some("uefa.nations")
        );
        // Sans source vérifiée, on ne propose rien plutôt qu'un championnat voisin.
        assert_eq!(slug_for_competition("UEFA U19 Euro Qualifiers"), None);
        assert_eq!(slug_for_competition("Friendlies International U19"), None);
        assert_eq!(slug_for_competition("Japanese J League Cup"), None);
        assert_eq!(slug_for_competition("Scottish Ladies Premier League"), None);
        assert_eq!(slug_for_competition("Other Competitions Soccer"), None);
    }

    #[test]
    fn similarity_distinguishes_city_rivals() {
        assert!(similarity("Real Madrid", "Real Madrid") > 0.95);
        assert!(similarity("Manchester United", "Man United") > 0.6);
        assert!(similarity("Real Madrid", "Atletico Madrid") < 0.62);
        assert!(similarity("Arsenal", "Chelsea") < 0.3);
    }

    #[test]
    fn every_catalog_competition_has_a_slug() {
        // Les noms rencontrés côté Arbworld pour le catalogue ESPN.
        let cases = [
            ("Premier League", "eng.1"),
            ("EFL Championship", "eng.2"),
            ("League One", "eng.3"),
            ("FA Cup", "eng.fa"),
            ("La Liga", "esp.1"),
            ("Segunda División", "esp.2"),
            ("Copa del Rey", "esp.copa_del_rey"),
            ("Serie A", "ita.1"),
            ("Serie B", "ita.2"),
            ("Bundesliga", "ger.1"),
            ("2. Bundesliga", "ger.2"),
            ("Ligue 1", "fra.1"),
            ("Ligue 2", "fra.2"),
            ("Eredivisie", "ned.1"),
            ("Liga Portugal", "por.1"),
            ("Süper Lig", "tur.1"),
            ("Pro League", "bel.1"),
            ("UEFA Champions League", "uefa.champions"),
            ("UEFA Europa League", "uefa.europa"),
            ("UEFA Conference League", "uefa.europa.conf"),
            ("UEFA Nations League A", "uefa.nations"),
            ("Friendlies International", "fifa.friendly"),
        ];
        for (name, slug) in cases {
            assert_eq!(slug_for_competition(name), Some(slug), "{name}");
        }
        // Féminines sans correspondance explicite : jamais le championnat masculin.
        assert_eq!(slug_for_competition("Premier League Women"), None);
    }

    #[test]
    fn a_swapped_fixture_is_not_matched() {
        let ev = parse_event(
            &json!({
                "id": "1", "date": "2026-11-09T20:00:00Z",
                "status": {"type": {"state": "post", "completed": true}},
                "competitions": [{"competitors": [
                    {"homeAway": "home", "score": "2", "team": {"displayName": "Chelsea"}},
                    {"homeAway": "away", "score": "1", "team": {"displayName": "Arsenal"}}
                ]}]
            }),
            "eng.1",
        )
        .unwrap();
        let events = vec![ev];
        assert!(
            find_match("Arsenal", "Chelsea", None, Some("eng.1"), &events).is_none(),
            "une affiche inversée ne doit jamais être rapprochée"
        );
    }

    #[test]
    fn a_kickoff_without_timezone_is_still_compared() {
        let mut ev = parse_event(
            &json!({
                "id": "1", "date": "2026-11-09T20:00:00Z",
                "status": {"type": {"state": "post", "completed": true}},
                "competitions": [{"competitors": [
                    {"homeAway": "home", "score": "2", "team": {"displayName": "Arsenal"}},
                    {"homeAway": "away", "score": "1", "team": {"displayName": "Chelsea"}}
                ]}]
            }),
            "eng.1",
        )
        .unwrap();
        ev.date = "2026-11-09T20:00:00Z".into();
        let events = vec![ev];
        // Date Arbworld sans fuseau, à 4 jours d'écart : hors tolérance.
        assert!(find_match("Arsenal", "Chelsea", Some("2026-11-13 20:00:00"), Some("eng.1"), &events).is_none());
        // Même jour : rapproché.
        assert!(find_match("Arsenal", "Chelsea", Some("2026-11-09 20:00:00"), Some("eng.1"), &events).is_some());
    }

    #[test]
    fn find_match_requires_the_same_competition() {
        let ev = parse_event(
            &json!({
                "id": "1", "date": "2026-11-09T20:00:00Z",
                "status": {"type": {"state": "post", "completed": true}},
                "competitions": [{"competitors": [
                    {"homeAway": "home", "score": "2", "team": {"displayName": "Arsenal"}},
                    {"homeAway": "away", "score": "1", "team": {"displayName": "Chelsea"}}
                ]}]
            }),
            "eng.1",
        )
        .unwrap();
        let events = vec![ev];
        assert!(find_match("Arsenal", "Chelsea", Some("2026-11-09T20:00:00Z"), Some("eng.1"), &events).is_some());
        assert!(find_match("Arsenal", "Chelsea", Some("2026-11-09T20:00:00Z"), Some("eng.fa"), &events).is_none());
    }

    #[test]
    fn half_time_accepts_a_string_value() {
        let ev = json!({
            "id": "1", "date": "2026-11-09T20:00:00Z",
            "status": {"type": {"state": "post", "completed": true}},
            "competitions": [{"competitors": [
                {"homeAway": "home", "score": "2", "linescores": [{"value": "1"}],
                 "team": {"displayName": "Arsenal"}},
                {"homeAway": "away", "score": "1", "linescores": [{"value": 0}],
                 "team": {"displayName": "Chelsea"}}
            ]}]
        });
        let m = parse_event(&ev, "eng.1").expect("match");
        assert_eq!(m.home_ht, Some(1));
        assert_eq!(m.away_ht, Some(0));
    }

    #[test]
    fn parses_scoreboard_event() {
        let ev = json!({
            "id": "1",
            "name": "Arsenal vs Chelsea",
            "date": "2026-11-09T20:00:00Z",
            "status": {"type": {"state": "post", "completed": true, "detail": "FT"}},
            "competitions": [{"competitors": [
                {"homeAway": "home", "score": "2", "linescores": [{"value": 1}],
                 "team": {"displayName": "Arsenal", "logo": "a.png"}},
                {"homeAway": "away", "score": "1", "linescores": [{"value": 0}],
                 "team": {"displayName": "Chelsea", "logo": "c.png"}}
            ]}]
        });
        let m = parse_event(&ev, "eng.1").expect("match");
        assert_eq!(m.home_score, Some(2));
        assert_eq!(m.away_score, Some(1));
        assert_eq!(m.home_ht, Some(1));
        assert_eq!(m.total_goals, Some(3));
        assert_eq!(m.btts, Some(true));
        assert_eq!(m.state, MatchState::Finished);
    }

    #[test]
    fn scheduled_events_have_no_score() {
        let ev = json!({
            "id": "2",
            "date": "2026-11-12T19:45:00Z",
            "status": {"type": {"state": "pre", "completed": false, "detail": "Scheduled"}},
            "competitions": [{"competitors": [
                {"homeAway": "home", "score": "0", "team": {"displayName": "Italy"}},
                {"homeAway": "away", "score": "0", "team": {"displayName": "France"}}
            ]}]
        });
        let m = parse_event(&ev, "uefa.nations").expect("match");
        assert_eq!(m.state, MatchState::Scheduled);
        assert_eq!(m.home_score, None);
        assert_eq!(m.away_score, None);
        assert_eq!(m.total_goals, None);
        assert_eq!(m.btts, None);
    }

    #[test]
    fn find_match_requires_both_teams() {
        let ev = parse_event(
            &json!({
                "id": "1", "date": "2026-11-09T20:00:00Z",
                "status": {"type": {"state": "in"}},
                "competitions": [{"competitors": [
                    {"homeAway": "home", "team": {"displayName": "Arsenal"}},
                    {"homeAway": "away", "team": {"displayName": "Chelsea"}}
                ]}]
            }),
            "eng.1",
        )
        .unwrap();
        let events = vec![ev];
        assert!(find_match("Arsenal", "Chelsea", None, Some("eng.1"), &events).is_some());
        assert!(find_match("Arsenal", "Liverpool", None, Some("eng.1"), &events).is_none());
        assert!(find_match("Aston Villa", "Chelsea", None, Some("eng.1"), &events).is_none());
    }
}
