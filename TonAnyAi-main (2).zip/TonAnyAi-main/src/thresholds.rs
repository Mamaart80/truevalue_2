//! Tous les seuils du moteur, au même endroit et documentés.
//!
//! Règle du projet : aucun seuil numérique ne vit ailleurs que dans ce fichier.
//! Les modules importent `crate::thresholds as th` et lisent les constantes par
//! leur nom, pour qu'un ajustement se discute à un seul endroit.
//!
//! Les valeurs marquées « non calibré » sont des hypothèses de travail : le
//! dépôt n'a pas encore assez d'historique noté pour les valider.

// ---------------------------------------------------------------------------
// Entrée dans le moteur
// ---------------------------------------------------------------------------

/// Volume minimal d'un marché pour entrer dans un recoupement (en £).
/// En dessous, la variation de volume n'est plus distinguable du bruit.
pub const MIN_MARKET_VOLUME: f64 = 250.0;

/// Conviction minimale (points au-dessus du neutre du marché) pour parler de
/// tendance. 10 pts = « un dixième de marché au-delà du hasard ».
pub const MIN_CONVICTION: f64 = 10.0;

/// Nombre de marchés minimum pour qu'un recoupement ait un sens.
pub const MIN_MARKETS: usize = 2;

/// Cote minimale pour qu'un prix soit négociable (1.00 = pas de cote).
pub const MIN_TRADABLE_ODDS: f64 = 1.01;

// ---------------------------------------------------------------------------
// Filtre qualité des données (chantier 4)
// ---------------------------------------------------------------------------

/// Volume plancher d'un marché jugé exploitable (palier `LOW`).
pub const QUALITY_MIN_VOLUME: f64 = 250.0;

/// Bornes de la somme des 1/cote sur un marché partition (en %).
/// En dessous de 98 %, il manque une issue ; au-dessus de 108 %, le marché est
/// soit très margé, soit mal collecté. Dans les deux cas le prix n'est pas
/// interprétable. Non calibré : fourchette large, à resserrer avec l'historique.
pub const OVERROUND_MIN_PCT: f64 = 98.0;
pub const OVERROUND_MAX_PCT: f64 = 108.0;

/// Cotes aberrantes sur l'issue dominante. 1.01 n'est pas un prix (gain
/// maximal d'un cent par unité misée) ; au-delà de 100, la ligne est
/// invraisemblable pour une issue majoritairement financée.
pub const ABERRANT_ODDS_MIN: f64 = 1.02;
pub const ABERRANT_ODDS_MAX: f64 = 100.0;

/// Âge maximal de `last_update` avant de considérer le marché comme périmé.
/// Non calibré : observé sur la fraîcheur Arbworld constatée en production.
pub const MAX_DATA_AGE_MINUTES: i64 = 120;

// ---------------------------------------------------------------------------
// Argent frais (chantier 2)
// ---------------------------------------------------------------------------

/// Fenêtres glissantes d'observation de l'argent entrant.
pub const FRESH_WINDOW_SHORT_HOURS: f64 = 1.0;
pub const FRESH_WINDOW_LONG_HOURS: f64 = 3.0;

/// Argent entrant minimal (toutes issues confondues, en £) pour qu'un flux
/// compte. Sous ce montant, la variation est un arrondi de collecte.
pub const MIN_FRESH_MONEY: f64 = 150.0;

/// Nombre minimal de relevés dans la fenêtre. Avec un seul relevé, on ne peut
/// pas calculer d'entrée d'argent : l'absence est explicite.
pub const FRESH_MIN_OBSERVATIONS: usize = 2;

/// Raccourcissement de cote minimal (%) pour qualifier un « steam » : la cote
/// doit baisser d'au moins 1 % sur la fenêtre courte.
pub const STEAM_MIN_DROP_PCT: f64 = -1.0;

/// Part minimale du nouvel argent sur un côté pour parler d'inversion de flux.
pub const FRESH_SIDE_MIN_SHARE: f64 = 55.0;

/// Fenêtre « avant le coup d'envoi » et multiple de rythme pour un afflux tardif.
/// Non calibré : 3× le rythme des deux heures précédentes est un choix de
/// prudence, à revoir avec l'historique.
pub const LATE_SURGE_HOURS: f64 = 6.0;
pub const LATE_SURGE_MULTIPLE: f64 = 3.0;

// ---------------------------------------------------------------------------
// Historisation des relevés (chantier 1)
// ---------------------------------------------------------------------------

/// Un relevé n'est enregistré que si la cote a bougé d'au moins 0.5 % ou si le
/// volume a bougé d'au moins 1 £ depuis le dernier relevé de la sélection.
pub const SNAPSHOT_MIN_ODDS_CHANGE_PCT: f64 = 0.5;
pub const SNAPSHOT_MIN_VOLUME_CHANGE: f64 = 1.0;

/// Horizon d'historisation : seules les rencontres qui démarrent dans les
/// 48 prochaines heures sont historisées…
pub const SNAPSHOT_HORIZON_HOURS: i64 = 48;

/// …plus celles déjà commencées mais non notées, dans cette limite de grâce.
pub const SNAPSHOT_LIVE_GRACE_HOURS: i64 = 6;

/// Purge automatique des relevés plus vieux que ce nombre de jours (les
/// rencontres dont le signal n'est pas noté sont conservées).
pub const SNAPSHOT_PURGE_DAYS: i64 = 14;

/// Intervalle minimal entre deux purges.
///
/// La purge tournait à chaque collecte : sans index sur `captured_at`, c'était
/// un balayage complet de `snapshots` toutes les dix minutes, soit l'essentiel
/// des 5 M de lignes lues par jour. Une purge par heure suffit très largement
/// au rythme d'insertion (~3 000 lignes/jour).
pub const SNAPSHOT_PURGE_INTERVAL_SECS: u64 = 3_600;

/// Nombre maximal de relevés supprimés par purge. Une purge bornée ne peut
/// jamais relire la table entière, même après un long arrêt.
pub const SNAPSHOT_PURGE_BATCH: i64 = 2_000;

/// Fenêtre de relevés tenue en mémoire, pour savoir ce qui a changé et nourrir
/// le moteur d'argent frais.
///
/// Le moteur ne regarde que `FRESH_WINDOW_LONG_HOURS` (3 h) : 4 h laisse une
/// heure de marge. Cette fenêtre n'est lue en base qu'une fois par démarrage ;
/// la relire à chaque collecte épuisait le quota de lignes lues de D1
/// (5 M par jour, atteint le 14/11).
pub const SNAPSHOT_RECENT_HOURS: i64 = 4;

/// Durée de validité du bilan et des statistiques gardés en mémoire. Ce n'est
/// pas un seuil de marché : cela borne la fraîcheur de chiffres qui coûtaient
/// jusqu'à 2 000 lignes lues à chaque chargement d'onglet.
pub const STATS_CACHE_TTL_SECS: u64 = 60;

/// Nombre de lignes par `INSERT` groupé : 7 × 13 = 91 paramètres, sous la
/// limite D1 de 100 paramètres liés par requête.
pub const SNAPSHOT_BATCH_ROWS: usize = 7;

/// Budget quotidien prudent sur les lignes lues (plafond gratuit : 5 M).
///
/// Au-delà, D1 refuse **toutes** les requêtes jusqu'à minuit UTC : plus de
/// notation, plus de snapshot, plus d'alerte. La marge laisse le temps de
/// terminer la journée en mode dégradé plutôt que de tout perdre.
pub const D1_READ_BUDGET: u64 = 3_500_000;

/// Budget quotidien prudent sur les lignes écrites (plafond gratuit : 100 k).
pub const D1_WRITE_BUDGET: u64 = 70_000;

/// Au-delà de cette fraction du budget, les lectures non essentielles
/// (recalcul du bilan, backfill du journal, purge) sont différées.
pub const D1_PRESSURE_RATIO: f64 = 0.8;

/// Intervalle minimal entre deux tentatives d'application du schéma (index
/// manquant après un démarrage sous quota épuisé).
pub const D1_SCHEMA_RETRY_SECS: u64 = 3_600;

// ---------------------------------------------------------------------------
// Journal des rencontres et bilan quotidien
// ---------------------------------------------------------------------------

/// Une rencontre dont le score n'est pas encore connu est réinterrogée pendant
/// ce nombre de jours après sa journée (reports et collectes manquées).
pub const RESULT_SYNC_DAYS: i64 = 3;

/// Similarité minimale entre les deux noms d'équipe pour rapprocher une
/// rencontre Arbworld d'un événement ESPN.
pub const ESPN_MATCH_MIN_SIMILARITY: f64 = 0.62;

/// Écart maximal entre le coup d'envoi attendu et l'événement ESPN. Une
/// tolérance de 3 jours permettait de régler un match avec une autre rencontre
/// des mêmes équipes ; 24 h couvre les décalages de fuseau et de programmation.
pub const ESPN_MATCH_MAX_HOURS: i64 = 24;

/// Similarité minimale pour rapprocher une rencontre Arbworld d'un événement
/// SportScore. Plus basse que celle d'ESPN car SportScore ajoute parfois des
/// précisions au nom (« Olympiakos Piraeus B » contre « Olympiacos B ») ; la
/// compétition et la date restreignent déjà fortement les candidats.
pub const SPORTSCORE_MATCH_MIN_SIMILARITY: f64 = 0.55;

/// Écart maximal entre le coup d'envoi attendu et l'événement SportScore.
pub const SPORTSCORE_MATCH_MAX_HOURS: i64 = 24;

/// Délai réseau maximal d'un appel SportScore.
pub const SPORTSCORE_TIMEOUT_SECS: u64 = 8;

/// Durée du cache SportScore par couple (jour, compétition).
pub const SPORTSCORE_CACHE_TTL_SECS: u64 = 60;

/// Profondeur du sélecteur de journées du bilan (jours précédents proposés).
pub const DAILY_LOOKBACK_DAYS: usize = 60;

/// Reprise de l'historique des signaux dans le journal (jours déjà enregistrés
/// ou récents), pour que les rencontres déjà notées apparaissent au bilan.
pub const DAILY_BACKFILL_DAYS: i64 = 7;

// ---------------------------------------------------------------------------
// Poids de marché (volume anormal sur une rencontre)
// ---------------------------------------------------------------------------

/// Volume minimal (en £) d'une rencontre, tous marchés confondus, pour que son
/// poids soit interprétable. Non calibré : sous ce montant, un multiple élevé
/// ne mesure que l'indigence du reste de la collecte.
pub const WEIGHT_MIN_VOLUME: f64 = 8_000.0;

/// Multiple de la médiane du jour au-delà duquel la rencontre pèse
/// anormalement. Non calibré : 3× la médiane est une hypothèse de travail, à
/// revoir quand l'historique permettra de comparer poids et résultats.
pub const WEIGHT_MIN_MULTIPLE: f64 = 3.0;

/// Part minimale (%) du volume de la rencontre portée par une seule famille de
/// marchés (« Résultat » ou « Buts »). En dessous, l'argent est réparti entre
/// familles et ne dit rien de l'intention.
pub const WEIGHT_MIN_FAMILY_SHARE: f64 = 65.0;

/// Nombre minimal de marchés cotés pour que la répartition par famille soit
/// lisible : deux lignes de buts ne font pas une famille dominante.
pub const WEIGHT_MIN_MARKETS: usize = 3;

/// Nombre minimal de rencontres dans une journée pour que sa médiane serve de
/// référence ; sinon la médiane porte sur toute la collecte (une journée à
/// trois rencontres n'a pas de « normale »).
pub const WEIGHT_MIN_PEERS: usize = 8;

// ---------------------------------------------------------------------------
// Match sans favori (écart de prix trop faible)
// ---------------------------------------------------------------------------

/// Écart maximal (points de probabilité implicite normalisée) entre domicile et
/// extérieur pour qu'un 1X2 soit jugé sans favori.
///
/// On mesure l'écart des probabilités **sans marge** et non l'écart des cotes
/// brutes : ce dernier dépend du niveau du nul et ne veut pas dire la même
/// chose d'une rencontre à l'autre. Non calibré : à 5 pts, avec un nul à 20 %
/// ou plus, la part dominante reste sous 45 %, donc la règle « consensus
/// favori » (60 %) ne peut pas se déclencher sur le même match.
pub const EVEN_MAX_GAP_PP: f64 = 5.0;

/// Volume minimal du 1X2 (£) pour qu'un match équilibré soit signalé. En
/// dessous, le prix est une cote d'affichage que personne ne joue : signaler
/// l'équilibre d'un marché vide n'apprend rien.
pub const EVEN_MIN_VOLUME: f64 = 3_000.0;

// ---------------------------------------------------------------------------
// Backtest des seuils (/api/backtest)
// ---------------------------------------------------------------------------

/// Profondeur par défaut du backtest, en jours journalisés.
pub const BACKTEST_DEFAULT_DAYS: usize = 14;

/// Profondeur maximale acceptée par l'API : au-delà, la réponse mélangerait des
/// périodes où les seuils n'étaient pas les mêmes.
pub const BACKTEST_MAX_DAYS: usize = 60;

// ---------------------------------------------------------------------------
// Exchange (prix Polymarket, /api/exchange)
// ---------------------------------------------------------------------------

/// Nombre maximal de rencontres interrogées par lecture : une requête amont
/// par rencontre, et l'API de recherche n'a pas de quota documenté.
pub const EXCHANGE_MAX_FIXTURES: usize = 12;

/// Horizon des rencontres interrogées (heures avant le coup d'envoi).
pub const EXCHANGE_HORIZON_HOURS: i64 = 48;

/// Tolérance entre l'heure du coup d'envoi et la fin de l'événement Polymarket.
/// Non calibré : 6 h couvre les décalages de programmation sans rapprocher deux
/// éditions d'une même affiche.
pub const EXCHANGE_MATCH_MAX_HOURS: i64 = 6;

/// Durée de validité d'une réponse Polymarket en mémoire (secondes).
pub const EXCHANGE_CACHE_TTL_SECS: u64 = 300;

/// Écart de probabilité (points) au-delà duquel la divergence entre la collecte
/// Betfair et Polymarket est signalée. Non calibré : 3 pts est une hypothèse de
/// travail, à revoir avec des prix comparés sur plusieurs semaines.
pub const EXCHANGE_NOTABLE_GAP_PP: f64 = 3.0;

/// Délai maximal d'une requête Polymarket (secondes).
pub const EXCHANGE_TIMEOUT_SECS: u64 = 8;

// ---------------------------------------------------------------------------
// Alertes Telegram (signaux à confiance élevée)
// ---------------------------------------------------------------------------

/// Nombre maximal d'alertes envoyées par cycle : une rafale de vingt signaux
/// « Élevé » ne doit pas transformer le canal en mur de messages.
pub const TELEGRAM_MAX_ALERTS_PER_RUN: usize = 3;

/// Délai maximal d'un envoi (secondes). Une API lente ne retarde pas la collecte
/// plus longtemps que ça.
pub const TELEGRAM_TIMEOUT_SECS: u64 = 8;

/// Nombre d'identifiants déjà alertés conservés. Sert à ne pas renvoyer deux
/// fois la même alerte après un redémarrage ; 400 couvre plusieurs jours de
/// signaux à confiance élevée.
pub const TELEGRAM_SEEN_MAX: usize = 400;

// ---------------------------------------------------------------------------
// Simulation de trading en points
// ---------------------------------------------------------------------------

/// Capital initial de la simulation, en points.
pub const SIM_STARTING_POINTS: f64 = 10.0;

/// Mise fixe par position, en points. Une position consomme donc une unité du
/// capital tant qu'elle est ouverte.
pub const SIM_STAKE_POINTS: f64 = 1.0;

/// Nombre maximal de positions simultanées. Le capital de 10 points limite de
/// toute façon l'exposition à 10 unités.
pub const SIM_MAX_OPEN: usize = 10;

/// Marge minimale avant le coup d'envoi, en secondes. Il n'y a plus de fenêtre
/// haute : la position s'ouvre dès le premier cycle où le signal est éligible,
/// pourvu qu'au moins une minute sépare la décision du coup d'envoi. Cette
/// marge évite d'ouvrir sur un cycle qui chevauche le départ (horloge, latence).
pub const SIM_MIN_KICKOFF_LEAD_SECS: i64 = 60;

/// Plancher de cote **unique** : alertes, simulation et performance.
/// Le seuil est inclusif : 1,30 est accepté, 1,29 est refusé.
/// Les anciens seuils divergents (1,20 pour l'alerte, 1,30 pour la simulation)
/// envoyaient des alertes qui ne pouvaient jamais ouvrir de position.
///
/// L'affichage du signal reste plus permissif (`MIN_TRADABLE_ODDS`, 1,01) :
/// une cote courte est une information de marché, pas un pari recommandé.
pub const MIN_BET_ODDS: f64 = 1.3;

/// Cote minimale d'entrée de la simulation (alias de `MIN_BET_ODDS`).
pub const SIM_MIN_ODDS: f64 = MIN_BET_ODDS;

/// Délai après le coup d'envoi au-delà duquel une position ouverte sans résultat
/// ESPN est rendue (`VOID`). Une compétition non couverte ou un match disparu
/// ne doit jamais immobiliser une place indéfiniment.
pub const SIM_RESULT_GRACE_HOURS: i64 = 48;

/// Nombre de positions réglées renvoyées dans l'historique détaillé. Les
/// statistiques et le capital, eux, portent sur tout l'historique via un agrégat
/// D1 : cette limite ne concerne que l'affichage.
pub const SIM_HISTORY_LIMIT: usize = 500;

// ---------------------------------------------------------------------------
// Propositions par groupe de marché (chantier 7)
// ---------------------------------------------------------------------------

/// Conviction minimale d'un marché pour qu'il porte une proposition :
/// 15 pts au-dessus du neutre de sa forme (33 % en 3 issues, 50 % en 2).
pub const MIN_PROPOSAL_CONVICTION: f64 = 15.0;

// ---------------------------------------------------------------------------
// Échantillon et autorisation de pari (chantier 8)
// ---------------------------------------------------------------------------

/// En dessous de 30 cas, une statistique s'affiche mais ne s'interprète pas.
pub const SAMPLE_MIN_DISPLAY: usize = 30;

/// En dessous de 200 cas, on ne parle pas de fiabilité.
pub const SAMPLE_MIN_RELIABLE: usize = 200;

// ---------------------------------------------------------------------------
// Écarts de prix et cohérence
// ---------------------------------------------------------------------------

/// Tolérance d'écart entre deux marchés sur la même probabilité (points).
pub const GAP_TOLERANCE_PP: f64 = 4.0;

/// Au-delà de cet écart, les marchés ne valorisent pas le même match : le
/// volume n'est plus interprétable.
pub const GAP_DIVERGENCE_PP: f64 = 12.0;

/// Écart minimal entre deux lignes de buts imbriquées pour signaler un prix
/// incohérent (la ligne haute ne peut pas être plus probable que la basse).
pub const NESTED_GOALS_GAP_PP: f64 = 3.0;

// ---------------------------------------------------------------------------
// Confiance (chantier 6)
// ---------------------------------------------------------------------------

/// Frontières de la confiance : < 45 = Faible, < 70 = Moyen, sinon Élevé.
/// Non calibré : il n'existe pas encore assez de signaux notés pour vérifier
/// que « Élevé » gagne plus souvent que « Faible ».
pub const CONFIDENCE_FAIBLE_MAX: f64 = 45.0;
pub const CONFIDENCE_ELEVE_MIN: f64 = 70.0;

/// Filtre d'affichage et de performance : une confiance élevée n'est retenue
/// que si la cote atteint le plancher commun (1,30 inclus). Alias de
/// `MIN_BET_ODDS` : l'alerte, elle, s'appuie directement sur la proposition
/// éligible de la simulation (`simulation::primary_proposal`).
pub const CONFIDENCE_ELEVE_MIN_ODDS: f64 = MIN_BET_ODDS;

/// Points de la composante « qualité des données » (le marché de référence
/// passe ou ne passe pas le filtre).
pub const CONF_QUALITY_POINTS: f64 = 25.0;

/// Points par palier de liquidité, dans l'ordre `Low, Medium, High, Whale`.
pub const CONF_LIQUIDITY_POINTS: [f64; 4] = [0.0, 10.0, 18.0, 25.0];

/// Points par nombre de familles de confirmation (index = nb de familles,
/// plafonné à 2).
pub const CONF_FAMILY_POINTS: [f64; 3] = [0.0, 10.0, 20.0];

/// Points si de l'argent frais confirme le côté dominant sur 1 h.
pub const CONF_FRESH_POINTS: f64 = 15.0;

/// Points si l'historique du type de signal existe et affiche un CLV positif.
pub const CONF_HISTORY_POINTS: f64 = 10.0;
