//! Transformation des lignes brutes Arbworld en marchés exploitables.
//!
//! Les corrections apportées par rapport à l'implémentation TypeScript d'origine :
//! - les marchés multi-issues (score exact, MT/FM) ne sont plus déguisés en 1/X/2 ;
//! - plus aucune cote inventée quand une ligne est vide ;
//! - le score « smart money » combine concentration, edge (part de volume moins
//!   probabilité implicite) et resserrement de cote, au lieu d'un barème fixe ;
//! - les seuils sont relatifs à la forme du marché (50 % neutre en 2 issues,
//!   33 % en 3 issues) et non au seul pourcentage brut.

use chrono::{DateTime, TimeZone, Utc};
use serde_json::Value;

use crate::market::{MarketDef, MarketKey, MarketShape};
use crate::model::{LiquidityTier, Match, ScoreOutcome, SignalType, Slot, Source};

const MONTHS_FR: [&str; 12] = [
    "janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.",
    "déc.",
];

/// Lit une date de coup d'envoi : RFC 3339 ou « AAAA-MM-JJ HH:MM:SS » en UTC.
///
/// Arbworld ne renvoie pas toujours le même format : le moteur de signaux doit
/// pouvoir décider si une rencontre a commencé quel que soit celui reçu.
pub fn parse_kickoff(raw: &str) -> Option<DateTime<Utc>> {
    let raw = raw.trim();
    if let Ok(parsed) = DateTime::parse_from_rfc3339(raw) {
        return Some(parsed.with_timezone(&Utc));
    }
    // ESPN renvoie parfois `2026-11-17T16:30Z` (sans secondes) : sans ce
    // format, `find_match` rejette l'événement et aucun signal n'est noté.
    for format in [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%dT%H:%MZ",
        "%Y-%m-%dT%H:%M:%SZ",
    ] {
        if let Ok(naive) = chrono::NaiveDateTime::parse_from_str(raw, format) {
            return Some(Utc.from_utc_datetime(&naive));
        }
    }
    None
}

/// Formate une date RFC 3339 en « 9 nov. 20:00 » (heure UTC, stable côté serveur).
pub fn format_date(raw: &str) -> String {
    match DateTime::parse_from_rfc3339(raw) {
        Ok(dt) => {
            let dt = dt.with_timezone(&Utc);
            format!(
                "{} {} {}:{:02}",
                dt.format("%-d"),
                MONTHS_FR[dt.format("%m").to_string().parse::<usize>().unwrap_or(1) - 1],
                dt.format("%H"),
                dt.format("%M")
            )
        }
        Err(_) => raw.to_string(),
    }
}

fn num(v: &Value, key: &str) -> f64 {
    v.get(key)
        .and_then(|x| {
            x.as_f64()
                .or_else(|| x.as_str().and_then(|s| s.trim().parse::<f64>().ok()))
        })
        .filter(|n| n.is_finite())
        .unwrap_or(0.0)
}

fn text(v: &Value, keys: &[&str]) -> String {
    for key in keys {
        if let Some(s) = v.get(*key).and_then(|x| x.as_str()) {
            if !s.trim().is_empty() {
                return s.trim().to_string();
            }
        }
    }
    String::new()
}

fn int_id(v: &Value, key: &str) -> i64 {
    v.get(key)
        .and_then(|x| {
            x.as_i64()
                .or_else(|| x.as_str().and_then(|s| s.parse::<i64>().ok()))
        })
        .unwrap_or(0)
}

fn round1(value: f64) -> f64 {
    (value * 10.0).round() / 10.0
}

/// Construit la liste des marchés à partir du JSON `data` d'Arbworld.
pub fn enrich(rows: &[Value], key: MarketKey, source: Source, age_seconds: u64) -> Vec<Match> {
    let def = key.def();
    rows.iter()
        .enumerate()
        .filter_map(|(idx, row)| enrich_one(row, def, idx, source, age_seconds))
        .collect()
}

fn enrich_one(
    row: &Value,
    def: MarketDef,
    idx: usize,
    source: Source,
    age_seconds: u64,
) -> Option<Match> {
    let home = text(row, &["home"]);
    let away = text(row, &["away"]);
    if home.is_empty() || away.is_empty() {
        return None;
    }

    let mut match_ = Match {
        id: format!(
            "{}_{}_{}",
            int_id(row, "market_id"),
            int_id(row, "selection_id"),
            idx
        ),
        market: def.key,
        shape: def.shape,
        date: text(row, &["date"]),
        date_label: format_date(&text(row, &["date"])),
        country: text(row, &["country"]).to_uppercase(),
        league: text(row, &["leage", "league"]),
        home,
        away,
        market_id: int_id(row, "market_id"),
        selection_id: int_id(row, "selection_id"),
        last_update: text(row, &["last_update"]),
        labels: [
            def.slot_labels.0.to_string(),
            def.slot_labels.1.unwrap_or("").to_string(),
            def.slot_labels.2.to_string(),
        ],
        coef: [0.0; 3],
        coef_new: [0.0; 3],
        volume: [0.0; 3],
        total_volume: 0.0,
        share: [0.0; 3],
        implied: [0.0; 3],
        edge: [0.0; 3],
        drop: [0.0; 3],
        dominant: Slot::First,
        dominant_index: 0,
        dominant_label: String::new(),
        dominant_share: 0.0,
        smart_money_score: 0.0,
        signal_type: SignalType::Balanced,
        signal_label: String::new(),
        liquidity_tier: LiquidityTier::Low,
        outcomes: Vec::new(),
        source,
        age_seconds,
        betfair_chart_url: String::new(),
        betfair_market_url: String::new(),
        flag_url: format!(
            "https://arbworld.net/assets/images/flags/{}.webp",
            text(row, &["country"]).to_lowercase()
        ),
    };
    if match_.league.is_empty() {
        match_.league = "Football".to_string();
    }

    if def.shape == MarketShape::Multi {
        fill_multi(row, &mut match_, def);
    } else {
        fill_structured(row, &mut match_, def);
    }

    Some(match_)
}

fn fill_multi(row: &Value, m: &mut Match, def: MarketDef) {
    let raw = row
        .get("outcomes")
        .and_then(|o| o.as_array())
        .cloned()
        .unwrap_or_default();

    let mut outcomes: Vec<ScoreOutcome> = raw
        .iter()
        .filter_map(|o| {
            let label = text(o, &["label"]);
            if label.is_empty() {
                return None;
            }
            Some(ScoreOutcome {
                label,
                coef: opt_positive(o, "coef"),
                coef_new: opt_positive(o, "coef_new"),
                volume: num(o, "volume").max(0.0),
                pct: 0.0,
            })
        })
        .collect();

    let total: f64 = outcomes.iter().map(|o| o.volume).sum();
    m.total_volume = (total * 100.0).round() / 100.0;

    for o in outcomes.iter_mut() {
        o.pct = if total > 0.0 {
            round1(o.volume / total * 100.0)
        } else {
            0.0
        };
    }
    outcomes.sort_by(|a, b| {
        b.volume
            .partial_cmp(&a.volume)
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    // Les trois premières issues servent d'aperçu ; aucune n'est inventée.
    for (i, o) in outcomes.iter().take(3).enumerate() {
        m.labels[i] = o.label.clone();
        m.coef[i] = o.coef.unwrap_or(0.0);
        m.coef_new[i] = o.coef_new.or(o.coef).unwrap_or(0.0);
        m.volume[i] = o.volume;
        m.share[i] = o.pct;
        m.implied[i] = if m.coef_new[i] > 0.0 {
            round1(100.0 / m.coef_new[i])
        } else {
            0.0
        };
        m.edge[i] = round1(m.share[i] - m.implied[i]);
        m.drop[i] = if m.coef[i] > 0.0 {
            round1((m.coef_new[i] - m.coef[i]) / m.coef[i] * 100.0)
        } else {
            0.0
        };
    }
    m.dominant = Slot::First;
    m.dominant_index = 0;
    m.dominant_label = outcomes
        .first()
        .map(|o| o.label.clone())
        .unwrap_or_default();
    m.dominant_share = outcomes.first().map(|o| o.pct).unwrap_or(0.0);
    m.liquidity_tier = LiquidityTier::from_volume(m.total_volume);
    m.smart_money_score = multi_score(m.dominant_share, m.total_volume);
    m.signal_type = if m.dominant_share >= 45.0 && m.total_volume >= 1_000.0 {
        SignalType::WhaleAccumulation
    } else {
        SignalType::Balanced
    };
    m.signal_label = if m.signal_type == SignalType::WhaleAccumulation {
        format!("Concentration sur {}", m.dominant_label)
    } else {
        SignalType::Balanced.label().to_string()
    };
    m.outcomes = outcomes.into_iter().take(12).collect();

    let market_id = if m.market_id > 0 {
        m.market_id.to_string()
    } else {
        String::new()
    };
    m.betfair_chart_url = format!(
        "https://graphs.betfair.com/1.{}/{}/0",
        market_id, m.selection_id
    );
    m.betfair_market_url =
        format!("https://www.betfair.com/exchange/plus/football/market/1.{market_id}");
    let _ = def;
}

fn fill_structured(row: &Value, m: &mut Match, def: MarketDef) {
    let two_way = def.shape == MarketShape::TwoWay;

    let coef = [num(row, "coef_1"), num(row, "coef_x"), num(row, "coef_2")];
    let coef_new_raw = [
        num(row, "coef_1_new"),
        num(row, "coef_x_new"),
        num(row, "coef_2_new"),
    ];
    let volume_raw = [
        num(row, "volume_1"),
        num(row, "volume_x"),
        num(row, "volume_2"),
    ];

    // En 2 issues, la colonne X n'existe pas : on ne la fabrique pas.
    let active = [true, !two_way, true];

    for i in 0..3 {
        if !active[i] {
            continue;
        }
        m.volume[i] = volume_raw[i].max(0.0);
        m.coef[i] = if coef[i] > 0.0 { coef[i] } else { 0.0 };
        m.coef_new[i] = if coef_new_raw[i] > 0.0 {
            coef_new_raw[i]
        } else {
            m.coef[i]
        };
    }
    if two_way {
        m.volume[1] = 0.0;
        m.coef[1] = 0.0;
        m.coef_new[1] = 0.0;
    }

    let total: f64 = m.volume.iter().sum();
    m.total_volume = (total * 100.0).round() / 100.0;

    for i in 0..3 {
        m.share[i] = if total > 0.0 && active[i] {
            round1(m.volume[i] / total * 100.0)
        } else {
            0.0
        };
        m.drop[i] = if m.coef[i] > 0.0 && m.coef_new[i] > 0.0 {
            round1((m.coef_new[i] - m.coef[i]) / m.coef[i] * 100.0)
        } else {
            0.0
        };
    }

    // Probabilités implicites normalisées (marge du bookmaker retirée).
    let inv: [f64; 3] = std::array::from_fn(|i| {
        if active[i] && m.coef_new[i] > 0.0 {
            1.0 / m.coef_new[i]
        } else {
            0.0
        }
    });
    let inv_sum: f64 = inv.iter().sum();
    for i in 0..3 {
        m.implied[i] = if inv_sum > 0.0 {
            round1(inv[i] / inv_sum * 100.0)
        } else {
            0.0
        };
        m.edge[i] = round1(m.share[i] - m.implied[i]);
    }

    // Issue dominante.
    let mut best = 0usize;
    for i in 1..3 {
        if active[i] && m.share[i] > m.share[best] {
            best = i;
        }
    }
    m.dominant_index = best;
    m.dominant = match best {
        1 => Slot::Draw,
        2 => Slot::Second,
        _ => Slot::First,
    };
    m.dominant_label = m.labels[best].clone();
    m.dominant_share = m.share[best];

    m.liquidity_tier = LiquidityTier::from_volume(m.total_volume);
    let (signal_type, score) = classify(def, m, best);
    m.signal_type = signal_type;
    m.smart_money_score = score;
    m.signal_label = signal_label(signal_type, m, best);

    let market_id = if m.market_id > 0 {
        m.market_id.to_string()
    } else {
        String::new()
    };
    m.betfair_chart_url = format!(
        "https://graphs.betfair.com/1.{}/{}/0",
        market_id, m.selection_id
    );
    m.betfair_market_url =
        format!("https://www.betfair.com/exchange/plus/football/market/1.{market_id}");
}

fn opt_positive(v: &Value, key: &str) -> Option<f64> {
    let n = num(v, key);
    if n > 0.0 {
        Some(n)
    } else {
        None
    }
}

fn multi_score(share: f64, volume: f64) -> f64 {
    let tier = LiquidityTier::from_volume(volume);
    let concentration = (share - 15.0).max(0.0) * 1.1;
    let liquidity = match tier {
        LiquidityTier::Whale => 15.0,
        LiquidityTier::High => 10.0,
        LiquidityTier::Medium => 5.0,
        LiquidityTier::Low => 0.0,
    };
    (20.0 + concentration + liquidity).clamp(10.0, liquidity_cap(tier))
}

/// Plafond de score par palier de liquidité : une concentration de 100 % sur
/// 440 £ n'est pas un signal maximal et ne doit pas arriver en tête.
fn liquidity_cap(tier: LiquidityTier) -> f64 {
    match tier {
        LiquidityTier::Whale => 100.0,
        LiquidityTier::High => 88.0,
        LiquidityTier::Medium => 70.0,
        LiquidityTier::Low => 40.0,
    }
}

/// Classe un marché structuré et calcule son score de conviction (0-100).
fn classify(def: MarketDef, m: &Match, best: usize) -> (SignalType, f64) {
    let conviction = (m.dominant_share - def.neutral_share()).max(0.0);
    let edge = m.edge[best].max(0.0);
    let drop = m.drop[best];
    let odds = m.coef_new[best];

    let mut score = 20.0 + conviction * 1.05 + edge * 0.9;
    if drop < -8.0 {
        score += (-drop - 8.0).min(15.0) * 0.9;
    }
    score += match m.liquidity_tier {
        LiquidityTier::Whale => 8.0,
        LiquidityTier::High => 4.0,
        LiquidityTier::Medium => 1.0,
        LiquidityTier::Low => 0.0,
    };
    let score = score.clamp(10.0, liquidity_cap(m.liquidity_tier));

    let signal = if m.dominant_share >= 65.0 && m.total_volume >= 5_000.0 {
        SignalType::WhaleAccumulation
    } else if drop <= -8.0 && edge >= 4.0 && m.total_volume >= 1_500.0 {
        SignalType::SharpDrop
    } else if odds >= 2.5 && conviction >= 8.0 && edge >= 6.0 {
        SignalType::UnderdogSurge
    } else if odds > 0.0 && odds <= 1.8 && m.dominant_share >= 68.0 {
        SignalType::FavoriteSteam
    } else {
        SignalType::Balanced
    };

    (signal, score)
}

fn signal_label(kind: SignalType, m: &Match, best: usize) -> String {
    let share = m.dominant_share;
    let odds = m.coef_new[best];
    let drop = m.drop[best];
    match kind {
        SignalType::WhaleAccumulation => {
            format!("{} % du volume sur {}", share.round(), m.dominant_label)
        }
        SignalType::AccumulationInfo => {
            format!("{} % du volume cumulé sur {} · information", share.round(), m.dominant_label)
        }
        SignalType::SharpDrop => format!("Cote {odds:.2} ({drop:+.1} %) sur {}", m.dominant_label),
        SignalType::UnderdogSurge => {
            format!(
                "{} % du volume à {odds:.2} sur {}",
                share.round(),
                m.dominant_label
            )
        }
        SignalType::FavoriteSteam => format!("Favori soutenu : {} %", share.round()),
        // « Flux équilibré » ne doit pas être affiché quand une issue capte
        // l'essentiel du volume : l'étiquette doit décrire ce qu'on observe.
        SignalType::Balanced => {
            if share >= 60.0 && m.liquidity_tier == LiquidityTier::Low {
                format!("Concentration {} % · marché trop mince", share.round())
            } else if share >= 60.0 {
                format!("Concentration {} % sans confirmation", share.round())
            } else {
                "Flux équilibré".to_string()
            }
        }
    }
}

/// Clé de rencontre normalisée pour recouper les marchés entre eux.
pub fn fixture_key(home: &str, away: &str) -> String {
    format!("{}_vs_{}", normalize_team(home), normalize_team(away))
}

/// Normalisation défensive : accents, casse, ponctuation, suffixes de club.
pub fn normalize_team(name: &str) -> String {
    let mut out = String::new();
    // Replier la casse **avant** la table d'accents : sinon « Étoile » devient
    // « toile » alors que « Etoile » devient « etoile », et deux affiches de la
    // même équipe produisent des fixture_key différents.
    for ch in name.to_lowercase().chars() {
        let folded = match ch {
            'à' | 'â' | 'ä' | 'á' | 'ã' | 'å' => 'a',
            'é' | 'è' | 'ê' | 'ë' => 'e',
            'í' | 'ì' | 'î' | 'ï' => 'i',
            'ó' | 'ò' | 'ô' | 'ö' | 'õ' => 'o',
            'ú' | 'ù' | 'û' | 'ü' => 'u',
            'ç' => 'c',
            'ñ' => 'n',
            'ß' => 's',
            c => c,
        };
        if folded.is_ascii_alphanumeric() {
            out.push(folded.to_ascii_lowercase());
        } else {
            out.push(' ');
        }
    }
    let cleaned: String = out
        .split_whitespace()
        .filter(|tok| {
            !matches!(
                *tok,
                "fc" | "cf" | "sc" | "ac" | "as" | "afc" | "cd" | "club" | "de" | "the"
            )
        })
        .map(|tok| match tok {
            "utd" => "united",
            "co" => "county",
            "ath" => "athletic",
            "int" => "internazionale",
            other => other,
        })
        .collect::<Vec<_>>()
        .join("");
    if cleaned.is_empty() {
        out.chars().filter(|c| c.is_ascii_alphanumeric()).collect()
    } else {
        cleaned
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn espn_dates_without_seconds_are_parsed() {
        let kickoff = parse_kickoff("2026-11-17T16:30Z").expect("date ESPN");
        assert_eq!(kickoff.format("%Y-%m-%d %H:%M:%S").to_string(), "2026-11-17 16:30:00");
        assert!(parse_kickoff("2026-11-17T16:30:00Z").is_some());
        assert!(parse_kickoff("2026-11-17 16:30:00").is_some());
    }

    #[test]
    fn uppercase_accents_are_folded_like_lowercase_ones() {
        assert_eq!(normalize_team("Étoile"), normalize_team("Etoile"));
        assert_eq!(normalize_team("À propos"), normalize_team("A propos"));
        assert_eq!(normalize_team("Île"), normalize_team("Ile"));
    }

    fn row_1x2() -> Value {
        json!({
            "date": "2026-11-09T20:00:00Z",
            "country": "eng",
            "leage": "Premier League",
            "home": "Arsenal",
            "away": "Chelsea",
            "market_id": 123,
            "selection_id": 456,
            "coef_1": 2.00, "coef_x": 3.50, "coef_2": 3.80,
            "coef_1_new": 1.70, "coef_x_new": 3.60, "coef_2_new": 4.20,
            "volume_1": 80000, "volume_x": 15000, "volume_2": 23000
        })
    }

    #[test]
    fn structured_market_math() {
        let m = &enrich(&[row_1x2()], MarketKey::OneXTwo, Source::Live, 0)[0];
        assert!((m.total_volume - 118_000.0).abs() < 0.01);
        assert_eq!(m.dominant, Slot::First);
        assert!((m.share[0] - 67.8).abs() < 0.2);
        assert!(m.implied[0] < m.share[0]);
        assert!(m.drop[0] < -10.0);
        assert!(m.smart_money_score > 50.0);
        assert_eq!(m.signal_type, SignalType::WhaleAccumulation);
    }

    #[test]
    fn two_way_has_no_draw_column() {
        let row = json!({
            "home": "A", "away": "B",
            "coef_1": 1.8, "coef_2": 2.1, "coef_1_new": 1.8, "coef_2_new": 2.1,
            "volume_1": 6000, "volume_2": 4000
        });
        let m = &enrich(&[row], MarketKey::Btts, Source::Live, 0)[0];
        assert_eq!(m.volume[1], 0.0);
        assert_eq!(m.share[1], 0.0);
        assert!((m.share[0] - 60.0).abs() < 0.01);
    }

    #[test]
    fn multi_market_sorts_and_never_invents() {
        let row = json!({
            "home": "A", "away": "B",
            "outcomes": [
                {"label": "1-0", "coef": 7.0, "coef_new": 6.0, "volume": 1200},
                {"label": "1-1", "coef": 6.5, "coef_new": 6.2, "volume": 3400},
                {"label": "2-1", "coef": 8.5, "coef_new": 8.0, "volume": 400}
            ]
        });
        let m = &enrich(&[row], MarketKey::CorrectScore, Source::Live, 0)[0];
        assert_eq!(m.dominant_label, "1-1");
        assert_eq!(m.outcomes.len(), 3);
        assert!((m.total_volume - 5000.0).abs() < 0.01);
        assert!(m.dominant_share > 60.0);
    }

    #[test]
    fn empty_multi_has_no_fake_outcomes() {
        let row = json!({"home": "A", "away": "B", "outcomes": []});
        let m = &enrich(&[row], MarketKey::CorrectScore, Source::Live, 0)[0];
        assert!(m.outcomes.is_empty());
        assert_eq!(m.coef_new[0], 0.0);
        assert_eq!(m.dominant_share, 0.0);
    }

    #[test]
    fn fixture_keys_are_stable() {
        assert_eq!(
            fixture_key("Manchester United", "Real Madrid"),
            fixture_key("manchester utd", "Real Madrid ")
        );
        assert_ne!(
            fixture_key("Real Madrid", "Barcelona"),
            fixture_key("Real Sociedad", "Barcelona")
        );
    }

    #[test]
    fn dates_are_formatted_in_french() {
        assert_eq!(format_date("2026-11-09T20:05:00Z"), "9 nov. 20:05");
    }

    #[test]
    fn low_liquidity_is_never_scored_as_a_strong_signal() {
        let row = json!({
            "home": "A", "away": "B",
            "coef_1": 2.00, "coef_x": 3.40, "coef_2": 3.60,
            "coef_1_new": 1.85, "coef_x_new": 3.50, "coef_2_new": 3.70,
            "volume_1": 440, "volume_x": 0, "volume_2": 0
        });
        let m = &enrich(&[row], MarketKey::OneXTwo, Source::Live, 0)[0];
        assert_eq!(m.liquidity_tier, LiquidityTier::Low);
        assert!(
            m.smart_money_score <= 40.0,
            "score {} malgré 440 £",
            m.smart_money_score
        );
        assert_ne!(m.signal_label, "Flux équilibré");
        assert!(
            m.signal_label.contains("trop mince"),
            "libellé inattendu : {}",
            m.signal_label
        );
    }

    #[test]
    fn balanced_flow_keeps_its_label_and_multi_score_is_capped() {
        let even = json!({
            "home": "A", "away": "B",
            "coef_1": 2.60, "coef_x": 3.20, "coef_2": 2.90,
            "coef_1_new": 2.60, "coef_x_new": 3.20, "coef_2_new": 2.90,
            "volume_1": 2000, "volume_x": 1800, "volume_2": 1900
        });
        let m = &enrich(&[even], MarketKey::OneXTwo, Source::Live, 0)[0];
        assert_eq!(m.signal_type, SignalType::Balanced);
        assert_eq!(m.signal_label, "Flux équilibré");

        let multi = json!({
            "home": "A", "away": "B",
            "outcomes": [
                {"label": "1-0", "coef": 7.0, "coef_new": 6.0, "volume": 3400},
                {"label": "1-1", "coef": 6.5, "coef_new": 6.2, "volume": 1600}
            ]
        });
        let m = &enrich(&[multi], MarketKey::CorrectScore, Source::Live, 0)[0];
        assert!(m.dominant_share > 60.0);
        assert!(
            m.smart_money_score <= 70.0,
            "score {} non plafonné pour un marché de 5 000 £",
            m.smart_money_score
        );
    }
}
