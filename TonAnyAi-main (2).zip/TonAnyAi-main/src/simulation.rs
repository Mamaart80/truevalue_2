//! Simulation de trading en points, à partir des signaux à confiance élevée.
//!
//! Règles fixes :
//! - capital de départ : 10 points ;
//! - une position par rencontre, mise fixe de 1 point ;
//! - ouverture au premier cycle où le signal est éligible, sans fenêtre haute :
//!   une rencontre vue 44 h à l'avance peut être simulée tout de suite. Seule
//!   borne : au moins une minute avant le coup d'envoi, jamais après ;
//! - si la capacité manque, le signal reste mémorisé comme candidat et est
//!   réessayé à chaque cycle, jusqu'au coup d'envoi ;
//! - uniquement les signaux `Élevé` dont la cote est au moins égale au plancher
//!   commun (`MIN_BET_ODDS`, 1,30), partagé avec les alertes ;
//! - 10 positions ouvertes au maximum, et jamais plus que le capital disponible.
//!
//! Le seul ordonnanceur est donc la capacité, pas l'heure : il n'y a plus de
//! créneau T−15 à manquer. Le prix d'entrée est celui du dernier cycle où le
//! signal était présent dans le flux (les propositions sont recalculées à
//! chaque cycle), pas une cote figée au premier cycle.
//!
//! La cote enregistrée est celle de la proposition du signal : elle sert de prix
//! d'entrée au contrat binaire. Le règlement utilise la notation typée du
//! moteur (`verify::grade_proposal`), jamais une recherche de texte. Une
//! rencontre reportée, annulée ou impossible à noter rend la mise (statut
//! `VOID`) au lieu d'inventer un gain.

use std::collections::HashSet;

use serde::{Deserialize, Serialize};

use crate::enrich::{normalize_team, parse_kickoff};
use crate::model::{BetOutcome, Confidence, MatchResult, MatchState, Play, Signal, SignalKind};
use crate::proposals::MarketGroup;
use crate::thresholds as th;

/// État d'une position simulée.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SimStatus {
    #[default]
    Open,
    Won,
    Lost,
    Push,
    /// Rencontre reportée, annulée ou non notable : la mise est rendue.
    /// Tout statut inconnu relu depuis la base est traité comme annulé.
    #[serde(other)]
    Void,
}

impl SimStatus {
    pub fn key(self) -> &'static str {
        match self {
            SimStatus::Open => "OPEN",
            SimStatus::Won => "WON",
            SimStatus::Lost => "LOST",
            SimStatus::Push => "PUSH",
            SimStatus::Void => "VOID",
        }
    }

    pub fn from_key(raw: &str) -> Self {
        match raw {
            "OPEN" => SimStatus::Open,
            "WON" => SimStatus::Won,
            "LOST" => SimStatus::Lost,
            "PUSH" => SimStatus::Push,
            "VOID" => SimStatus::Void,
            _ => SimStatus::Void,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            SimStatus::Open => "Ouverte",
            SimStatus::Won => "Gagnée",
            SimStatus::Lost => "Perdue",
            SimStatus::Push => "Remboursée",
            SimStatus::Void => "Annulée",
        }
    }
}

/// Une position simulée, persistée entre les collectes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SimPosition {
    /// Identifiant stable : `sim_` + identifiant du signal.
    pub id: String,
    pub signal_id: String,
    pub fixture_key: String,
    /// Coup d'envoi tel que collecté.
    pub match_date: String,
    /// Journée UTC (`AAAA-MM-JJ`).
    pub day: String,
    pub home: String,
    pub away: String,
    pub league: String,
    pub kind: String,
    /// Groupe de la proposition retenue (`issue`, `buts`, …).
    pub group: String,
    pub market: String,
    pub pick: String,
    /// Cote d'entrée (prix du contrat binaire).
    pub odds: f64,
    /// Mise en points (toujours 1 point).
    pub stake: f64,
    pub play: Play,
    pub opened_at: String,
    pub minutes_before_kickoff: i64,
    pub status: SimStatus,
    pub settled_at: Option<String>,
    /// Profit net en points (négatif pour une perte), `None` tant qu'ouverte.
    pub pnl: Option<f64>,
    pub home_score: Option<i64>,
    pub away_score: Option<i64>,
    pub note: String,
}

impl SimPosition {
    pub fn is_open(&self) -> bool {
        self.status == SimStatus::Open
    }
}

/// Bilan de la simulation, prêt pour `/api/simulation`.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SimulationReport {
    pub starting_points: f64,
    pub stake_points: f64,
    /// Marge minimale avant le coup d'envoi, en minutes (il n'y a plus de fenêtre haute).
    pub min_kickoff_lead_minutes: i64,
    pub min_odds: f64,
    pub max_open: usize,
    /// Capital de départ + profit réalisé (les positions ouvertes ne sont pas
    /// marquées au marché : leur mise est déjà sortie du disponible).
    pub balance_points: f64,
    /// Points encore engageables : capital − mises des positions ouvertes.
    pub available_points: f64,
    pub open_stakes: f64,
    pub realized_pnl: f64,
    pub roi_pct: Option<f64>,
    pub open_count: usize,
    pub settled: usize,
    pub won: usize,
    pub lost: usize,
    pub push: usize,
    pub void: usize,
    pub win_rate_pct: Option<f64>,
    pub positions: Vec<SimPosition>,
}

/// Minutes restantes avant le coup d'envoi, arrondies au-dessus, ou `None` si
/// l'horaire est illisible ou si la marge de sécurité n'est pas respectée.
///
/// Il n'y a volontairement **aucune borne haute** : un signal peut être ouvert
/// dès qu'il est détecté, même très longtemps avant le match. La seule borne
/// est basse (`SIM_MIN_KICKOFF_LEAD_SECS`) pour ne jamais ouvrir au coup d'envoi.
pub fn entry_lead_minutes(kickoff: &str, now: &str) -> Option<i64> {
    let kickoff = parse_kickoff(kickoff)?;
    let now = parse_kickoff(now)?;
    let seconds = (kickoff - now).num_seconds();
    (seconds >= th::SIM_MIN_KICKOFF_LEAD_SECS).then_some((seconds + 59) / 60)
}

/// Le plancher est inclusif : 1,30 est accepté, 1,29 est refusé.
pub fn odds_eligible(odds: Option<f64>) -> bool {
    odds.map(|value| value.is_finite() && value >= th::SIM_MIN_ODDS)
        .unwrap_or(false)
}

/// Capacité : plafond de 10 positions **et** capital suffisant pour la mise.
pub fn can_open(open_count: usize, available_points: f64) -> bool {
    open_count < th::SIM_MAX_OPEN && available_points >= th::SIM_STAKE_POINTS
}

/// Une compétition n'est simulable que si une source sait la retrouver :
/// ESPN d'abord, SportScore ensuite pour les compétitions qu'il couvre.
pub fn league_covered(league: &str) -> bool {
    crate::espn::slug_for_competition(league).is_some()
        || crate::sportscore::covers_competition(league)
}

/// Proposition retenue : la première du signal (ordre des groupes) dont la cote
/// dépasse le plancher. Une seule position par signal.
pub fn primary_proposal(signal: &Signal) -> Option<&crate::proposals::Proposal> {
    if signal.confidence != Confidence::Eleve || !signal.kind.flagged() {
        return None;
    }
    // `authorized` n'est volontairement pas filtré : la simulation applique la
    // règle demandée (confiance Élevé + cote ≥ 1,30), pas l'autorisation par
    // échantillon qui dépend de l'historique déjà noté.
    signal
        .proposals
        .iter()
        .find(|proposal| proposal.group != MarketGroup::Score && odds_eligible(proposal.entry_odds))
}

/// Construit la position d'un signal, sans exigence horaire.
///
/// Le signal reste éligible même s'il disparaît du flux ou si la capacité est
/// pleine : la position est mémorisée comme **candidat** et réessayée à chaque
/// cycle jusqu'au coup d'envoi. `opened_at` et `minutes_before_kickoff` sont
/// renseignés au moment de l'ouverture réelle, pas ici.
pub fn candidate(signal: &Signal) -> Option<SimPosition> {
    if signal.kind == SignalKind::Neutral || !league_covered(&signal.league) {
        return None;
    }
    let proposal = primary_proposal(signal)?;
    let odds = proposal.entry_odds?;
    let day = parse_kickoff(&signal.date)?
        .date_naive()
        .format("%Y-%m-%d")
        .to_string();
    // L'identifiant doit distinguer deux rencontres de la même affiche à des
    // dates différentes (saison suivante, coupe, match rejoué). La compétition
    // évite aussi de confondre un championnat et une coupe le même jour.
    let league = normalize_team(&signal.league);
    let id = if league.is_empty() {
        format!("sim_{}_{}", signal.id, day)
    } else {
        format!("sim_{}_{}_{}", signal.id, day, league)
    };
    Some(SimPosition {
        id,
        signal_id: signal.id.clone(),
        fixture_key: signal.fixture_key.clone(),
        match_date: signal.date.clone(),
        day,
        home: signal.home.clone(),
        away: signal.away.clone(),
        league: signal.league.clone(),
        kind: signal.kind.key().to_string(),
        group: proposal.group.key().to_string(),
        market: proposal.market.clone(),
        pick: proposal.pick.clone(),
        odds,
        stake: th::SIM_STAKE_POINTS,
        play: proposal.play.clone(),
        opened_at: String::new(),
        minutes_before_kickoff: 0,
        status: SimStatus::Open,
        settled_at: None,
        pnl: None,
        home_score: None,
        away_score: None,
        note: "Candidat en attente d'une place.".to_string(),
    })
}

/// Construit la position d'un signal si le coup d'envoi n'est pas encore donné
/// (marge de sécurité incluse). Plus de fenêtre haute : l'éligibilité suffit.
pub fn draft(signal: &Signal, now: &str) -> Option<SimPosition> {
    entry_lead_minutes(&signal.date, now)?;
    candidate(signal)
}

/// Pourquoi un signal à confiance élevée n'a pas pu ouvrir de position.
/// `None` signifie que toutes les conditions sont réunies (hors capacité).
pub fn rejection_reason(signal: &Signal, now: &str) -> Option<&'static str> {
    if signal.confidence != Confidence::Eleve {
        return Some("confiance inférieure à Élevé");
    }
    if !signal.kind.flagged() {
        return Some("signal descriptif, sans pari");
    }
    if !league_covered(&signal.league) {
        return Some("compétition sans source de score (ESPN/SportScore)");
    }
    if primary_proposal(signal).is_none() {
        return Some("cote d'entrée sous le plancher commun");
    }
    if entry_lead_minutes(&signal.date, now).is_none() {
        return Some("coup d'envoi déjà donné ou marge de sécurité dépassée");
    }
    None
}

fn realized_pnl(positions: &[SimPosition]) -> f64 {
    positions
        .iter()
        .filter(|position| !position.is_open())
        .filter_map(|position| position.pnl)
        .sum()
}

/// Ouvre les positions possibles, dans l'ordre du calendrier.
///
/// Une rencontre déjà suivie (même identifiant ou même affiche + coup d'envoi +
/// compétition) n'est jamais ouverte deux fois, y compris après un redémarrage.
pub fn plan_entries(signals: &[Signal], positions: &[SimPosition], now: &str) -> Vec<SimPosition> {
    let realized = realized_pnl(positions);
    plan_entries_with_realized(signals, positions, realized, now)
}

/// Variante utilisée par la production : le PnL réalisé vient d'un agrégat D1,
/// pas du chargement de tout l'historique. `positions` ne contient alors que
/// les positions encore ouvertes.
pub fn plan_entries_with_realized(
    signals: &[Signal],
    positions: &[SimPosition],
    realized: f64,
    now: &str,
) -> Vec<SimPosition> {
    let drafts: Vec<SimPosition> = signals.iter().filter_map(|s| draft(s, now)).collect();
    plan_drafts_with_realized(drafts, positions, realized, now)
}

/// Ouvre les positions à partir de candidats déjà construits : signaux du cycle
/// courant **et** candidats mémorisés lors des cycles précédents.
///
/// La marge avant le coup d'envoi est revérifiée ici avec l'heure du cycle :
/// un candidat mémorisé n'est jamais ouvert après le départ. L'heure retenue
/// est celle du début du cycle, pas la fin des appels réseau.
pub fn plan_drafts_with_realized(
    mut drafts: Vec<SimPosition>,
    positions: &[SimPosition],
    realized: f64,
    now: &str,
) -> Vec<SimPosition> {
    let mut taken_ids: HashSet<String> = positions.iter().map(|p| p.id.clone()).collect();
    let mut taken_fixtures: HashSet<(String, String, String)> = positions
        .iter()
        .map(|p| {
            (
                p.fixture_key.clone(),
                p.match_date.clone(),
                normalize_team(&p.league),
            )
        })
        .collect();
    let mut open_count = positions.iter().filter(|p| p.is_open()).count();
    let open_stakes: f64 = positions
        .iter()
        .filter(|p| p.is_open())
        .map(|p| p.stake)
        .sum();
    let mut available = round2(th::SIM_STARTING_POINTS + realized - open_stakes).max(0.0);

    drafts.sort_by(|a, b| {
        a.match_date
            .cmp(&b.match_date)
            .then(a.home.cmp(&b.home))
            .then(a.away.cmp(&b.away))
    });

    let mut out = Vec::new();
    for mut position in drafts {
        let Some(minutes) = entry_lead_minutes(&position.match_date, now) else {
            continue;
        };
        let fixture = (
            position.fixture_key.clone(),
            position.match_date.clone(),
            normalize_team(&position.league),
        );
        if taken_ids.contains(&position.id) || taken_fixtures.contains(&fixture) {
            continue;
        }
        if !can_open(open_count, available) {
            continue;
        }
        position.opened_at = now.to_string();
        position.minutes_before_kickoff = minutes;
        position.note = format!("Entrée à {minutes} min du coup d'envoi.");
        taken_ids.insert(position.id.clone());
        taken_fixtures.insert(fixture);
        open_count += 1;
        available = round2(available - position.stake);
        out.push(position);
    }
    out
}

/// Règle une position à partir du score réel.
///
/// Renvoie vrai si la position a changé d'état. Un match à venir ou en cours ne
/// clôture rien ; un match terminé mais non notable rend la mise (`VOID`).
pub fn settle(position: &mut SimPosition, result: &MatchResult, now: &str) -> bool {
    if !position.is_open() {
        return false;
    }
    if matches!(result.state, MatchState::Scheduled | MatchState::InProgress) {
        return false;
    }

    position.home_score = result.home_score;
    position.away_score = result.away_score;
    position.settled_at = Some(now.to_string());

    if matches!(result.state, MatchState::Postponed | MatchState::Cancelled) {
        position.status = SimStatus::Void;
        position.pnl = Some(0.0);
        position.note = "Rencontre reportée ou annulée : mise rendue.".to_string();
        return true;
    }

    let graded = crate::verify::grade_proposal(&position.group, &position.play, Some(result));
    position.note = graded.explanation.clone();
    match graded.outcome {
        BetOutcome::Won => {
            position.status = SimStatus::Won;
            position.pnl = Some(round2(position.stake * (position.odds - 1.0)));
        }
        BetOutcome::Lost => {
            position.status = SimStatus::Lost;
            position.pnl = Some(-position.stake);
        }
        BetOutcome::Push => {
            position.status = SimStatus::Push;
            position.pnl = Some(0.0);
        }
        BetOutcome::Pending => {
            // Un match terminé ne peut pas rester en attente : la position est
            // rendue plutôt que de bloquer une place indéfiniment.
            position.status = SimStatus::Void;
            position.pnl = Some(0.0);
            position.note = format!("{} Mise rendue.", graded.explanation);
        }
        BetOutcome::Unknown => {
            position.status = SimStatus::Void;
            position.pnl = Some(0.0);
            position.note = format!("{} Mise rendue.", graded.explanation);
        }
    }
    true
}

/// Annule immédiatement une position ouverte sur une compétition sans source
/// (ni ESPN ni SportScore). Sans cela, elle resterait `OPEN` jusqu'au délai de
/// grâce, et le point serait immobilisé alors qu'aucun score ne peut arriver.
pub fn void_uncovered(position: &mut SimPosition, now: &str) -> bool {
    if !position.is_open() || league_covered(&position.league) {
        return false;
    }
    position.status = SimStatus::Void;
    position.settled_at = Some(now.to_string());
    position.pnl = Some(0.0);
    position.note = "Compétition non couverte par ESPN ni SportScore : mise rendue.".to_string();
    true
}

/// Annule une position ouverte dont le résultat n'est pas connu après le délai
/// de grâce. Sans cela, une compétition non couverte ou un match disparu du
/// scoreboard immobiliserait une place et un point pour toujours.
pub fn expire(position: &mut SimPosition, now: &str) -> bool {
    if !position.is_open() {
        return false;
    }
    let Some(kickoff) = parse_kickoff(&position.match_date) else {
        return false;
    };
    let Some(now) = parse_kickoff(now) else {
        return false;
    };
    if (now - kickoff).num_hours() < th::SIM_RESULT_GRACE_HOURS {
        return false;
    }
    position.status = SimStatus::Void;
    position.settled_at = Some(now.to_rfc3339_opts(chrono::SecondsFormat::Secs, true));
    position.pnl = Some(0.0);
    position.note = format!(
        "Aucun résultat ESPN ou SportScore {} h après le coup d'envoi : mise rendue.",
        th::SIM_RESULT_GRACE_HOURS
    );
    true
}

/// Totaux de toutes les positions réglées, y compris celles qui ne sont plus
/// renvoyées dans l'historique détaillé.
#[derive(Debug, Clone, Default)]
pub struct SimTotals {
    pub realized_pnl: f64,
    pub risked: f64,
    pub won: usize,
    pub lost: usize,
    pub push: usize,
    pub void: usize,
    pub settled: usize,
}

pub fn totals(positions: &[SimPosition]) -> SimTotals {
    let mut totals = SimTotals::default();
    for position in positions.iter().filter(|position| !position.is_open()) {
        totals.realized_pnl += position.pnl.unwrap_or(0.0);
        match position.status {
            SimStatus::Won => {
                totals.won += 1;
                totals.risked += position.stake;
            }
            SimStatus::Lost => {
                totals.lost += 1;
                totals.risked += position.stake;
            }
            SimStatus::Push => {
                totals.push += 1;
                totals.risked += position.stake;
            }
            SimStatus::Void => totals.void += 1,
            SimStatus::Open => {}
        }
    }
    totals.settled = totals.won + totals.lost + totals.push + totals.void;
    totals
}

/// Bilan complet, calculé à la lecture et sans appel externe.
pub fn report(positions: Vec<SimPosition>) -> SimulationReport {
    let totals = totals(&positions);
    report_with_totals(positions, totals)
}

/// Bilan avec des totaux calculés sur tout l'historique (agrégat D1) et une
/// liste détaillée limitée. Les deux ne doivent jamais être confondus : le
/// capital et le ROI viennent de `totals`, pas des seules lignes affichées.
pub fn report_with_totals(
    mut positions: Vec<SimPosition>,
    totals: SimTotals,
) -> SimulationReport {
    positions.sort_by(|a, b| {
        b.is_open()
            .cmp(&a.is_open())
            .then(b.opened_at.cmp(&a.opened_at))
    });

    let open_count = positions.iter().filter(|p| p.is_open()).count();
    let open_stakes = positions
        .iter()
        .filter(|p| p.is_open())
        .map(|p| p.stake)
        .sum::<f64>();
    let balance = round2(th::SIM_STARTING_POINTS + totals.realized_pnl);

    SimulationReport {
        starting_points: th::SIM_STARTING_POINTS,
        stake_points: th::SIM_STAKE_POINTS,
        min_kickoff_lead_minutes: th::SIM_MIN_KICKOFF_LEAD_SECS / 60,
        min_odds: th::SIM_MIN_ODDS,
        max_open: th::SIM_MAX_OPEN,
        balance_points: balance,
        available_points: round2(balance - open_stakes).max(0.0),
        open_stakes: round2(open_stakes),
        realized_pnl: round2(totals.realized_pnl),
        roi_pct: (totals.risked > 0.0)
            .then(|| round2(totals.realized_pnl / totals.risked * 100.0)),
        open_count,
        settled: totals.settled,
        won: totals.won,
        lost: totals.lost,
        push: totals.push,
        void: totals.void,
        win_rate_pct: (totals.won + totals.lost > 0).then(|| {
            round2(totals.won as f64 / (totals.won + totals.lost) as f64 * 100.0)
        }),
        positions,
    }
}

fn round2(value: f64) -> f64 {
    (value * 100.0).round() / 100.0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Recommendation, Signal, SignalCategory, Slot, Source};
    use crate::proposals::Proposal;

    fn position(id: &str, status: SimStatus, pnl: Option<f64>) -> SimPosition {
        SimPosition {
            id: id.to_string(),
            signal_id: id.to_string(),
            fixture_key: id.to_string(),
            match_date: "2026-11-09T20:00:00Z".to_string(),
            day: "2026-11-09".to_string(),
            home: "A".to_string(),
            away: "B".to_string(),
            league: "L".to_string(),
            kind: "favorite".to_string(),
            group: "issue".to_string(),
            market: "1X2".to_string(),
            pick: "Domicile".to_string(),
            odds: 1.8,
            stake: 1.0,
            play: Play::MatchResult { side: Slot::First },
            opened_at: "2026-11-09T19:45:00Z".to_string(),
            minutes_before_kickoff: 15,
            status,
            settled_at: None,
            pnl,
            home_score: None,
            away_score: None,
            note: String::new(),
        }
    }

    fn signal(id: &str, confidence: Confidence, kind: SignalKind, odds: f64) -> Signal {
        Signal {
            id: format!("sig_{id}"),
            fixture_key: id.to_string(),
            home: id.to_string(),
            away: "B".to_string(),
            league: "Premier League".to_string(),
            country: String::new(),
            flag_url: String::new(),
            date: "2026-11-09T20:00:00Z".to_string(),
            date_label: String::new(),
            convergence_score: 80.0,
            category: SignalCategory::ConvergenceFavorite,
            category_label: String::new(),
            scenario_title: String::new(),
            analysis_summary: String::new(),
            value: Recommendation {
                play: Play::NoBet,
                label: String::new(),
                odds: None,
            },
            safety: Recommendation {
                play: Play::NoBet,
                label: String::new(),
                odds: None,
            },
            divergence_explanation: None,
            total_volume: 1_000.0,
            markets: Vec::new(),
            odds: Default::default(),
            kind,
            families: Vec::new(),
            confidence,
            fresh: Default::default(),
            quality: Default::default(),
            proposals: vec![Proposal {
                group: MarketGroup::Issue,
                market: "1X2".to_string(),
                pick: "Domicile".to_string(),
                share: 70.0,
                entry_odds: Some(odds),
                entry_novig: None,
                series_key: String::new(),
                market_key: Some(crate::market::MarketKey::OneXTwo),
                play: Play::MatchResult { side: Slot::First },
                authorized: false,
                closing_odds: None,
                closing_novig: None,
                clv_pct: None,
                clv_novig_pct: None,
                outcome: BetOutcome::Pending,
                explanation: String::new(),
            }],
            liquidity_tier: Default::default(),
            direction: String::new(),
            weight: None,
            metrics: Default::default(),
            source: Source::Snapshot,
            computed_at: String::new(),
        }
    }

    fn finished(home: i64, away: i64) -> MatchResult {
        MatchResult {
            id: "1".into(),
            name: "A vs B".into(),
            date: "2026-11-09T20:00:00Z".into(),
            date_label: String::new(),
            league_slug: "eng.1".into(),
            league_name: String::new(),
            home_team: "A".into(),
            away_team: "B".into(),
            home_logo: String::new(),
            away_logo: String::new(),
            home_score: Some(home),
            away_score: Some(away),
            home_ht: None,
            away_ht: None,
            state: MatchState::Finished,
            status_detail: "FT".into(),
            completed: true,
            total_goals: Some(home + away),
            btts: Some(home > 0 && away > 0),
        }
    }

    #[test]
    fn any_time_before_kickoff_is_allowed_without_an_upper_bound() {
        // 15 min, 10 min, 44 h : tout est ouvrable, il n'y a plus de fenêtre haute.
        assert_eq!(
            entry_lead_minutes("2026-11-09T20:00:00Z", "2026-11-09T19:45:00Z"),
            Some(15)
        );
        assert_eq!(
            entry_lead_minutes("2026-11-09T20:00:00Z", "2026-11-09T19:50:00Z"),
            Some(10)
        );
        assert_eq!(
            entry_lead_minutes("2026-11-09T20:00:00Z", "2026-11-08T00:00:00Z"),
            Some(2640)
        );
        // Seule la marge basse reste : jamais au coup d'envoi ni après.
        assert_eq!(
            entry_lead_minutes("2026-11-09T20:00:00Z", "2026-11-09T19:59:30Z"),
            None
        );
        assert_eq!(
            entry_lead_minutes("2026-11-09T20:00:00Z", "2026-11-09T20:00:00Z"),
            None
        );
    }

    #[test]
    fn open_and_unknown_statuses_are_distinguished() {
        assert_eq!(SimStatus::from_key("OPEN"), SimStatus::Open);
        assert_eq!(SimStatus::from_key("BOGUS"), SimStatus::Void);
    }

    #[test]
    fn an_uncovered_competition_is_never_opened_and_is_voided_if_already_open() {
        let mut uncovered = signal("uncovered", Confidence::Eleve, SignalKind::Favorite, 1.8);
        uncovered.league = "Japanese J League Cup".into();
        assert!(draft(&uncovered, "2026-11-09T19:50:00Z").is_none());

        let mut position = position("uncovered", SimStatus::Open, None);
        position.league = "Japanese J League Cup".into();
        assert!(void_uncovered(&mut position, "2026-11-16T23:50:00Z"));
        assert_eq!(position.status, SimStatus::Void);
        assert_eq!(position.pnl, Some(0.0));
        assert!(position.note.contains("non couverte par ESPN ni SportScore"));
        assert!(!void_uncovered(&mut position, "2026-11-16T23:50:00Z"));
    }

    #[test]
    fn sportscore_covers_the_competitions_espn_misses() {
        for league in [
            "Italian Serie C",
            "Greek Super League 2",
            "Friendlies International U20",
        ] {
            assert!(league_covered(league), "{league} doit être couverte");
        }
        assert!(!league_covered("Japanese J League Cup"));
    }

    #[test]
    fn an_unresolved_position_expires_after_the_grace_period() {
        let mut stale = position("stale", SimStatus::Open, None);
        assert!(!expire(&mut stale, "2026-11-11T19:59:00Z"));
        assert!(expire(&mut stale, "2026-11-11T20:00:00Z"));
        assert_eq!(stale.status, SimStatus::Void);
        assert_eq!(stale.pnl, Some(0.0));
        assert!(stale.note.contains("Aucun résultat ESPN ou SportScore"));
    }

    #[test]
    fn the_same_fixture_on_another_date_is_a_new_position() {
        let mut previous = position("old", SimStatus::Won, Some(0.8));
        previous.id = "sim_sig_team_2026-11-09_l".into();
        previous.signal_id = "sig_team".into();
        previous.fixture_key = "team".into();
        previous.match_date = "2026-11-09T20:00:00Z".into();

        let mut future = signal("team", Confidence::Eleve, SignalKind::Favorite, 1.8);
        future.date = "2026-11-16T20:00:00Z".into();
        let entries = plan_entries(&[future], &[previous], "2026-11-16T19:50:00Z");
        assert_eq!(entries.len(), 1);
        assert!(entries[0].id.contains("2026-11-16"));
    }

    #[test]
    fn odds_floor_is_inclusive() {
        assert!(!odds_eligible(Some(1.29)));
        assert!(odds_eligible(Some(1.3)));
        assert!(odds_eligible(Some(1.31)));
        assert!(!odds_eligible(None));
    }

    #[test]
    fn capacity_stops_at_ten_positions_and_at_the_available_capital() {
        assert!(can_open(9, 1.0));
        assert!(!can_open(10, 10.0));
        assert!(!can_open(9, 0.99));
    }

    #[test]
    fn settlement_pays_the_decimal_odds_and_never_invents_a_win() {
        let mut won = position("a", SimStatus::Open, None);
        assert!(settle(&mut won, &finished(2, 1), "2026-11-09T22:00:00Z"));
        assert_eq!(won.status, SimStatus::Won);
        assert_eq!(won.pnl, Some(0.8));

        let mut lost = position("b", SimStatus::Open, None);
        assert!(settle(&mut lost, &finished(0, 2), "2026-11-09T22:00:00Z"));
        assert_eq!(lost.status, SimStatus::Lost);
        assert_eq!(lost.pnl, Some(-1.0));

        let mut postponed = position("c", SimStatus::Open, None);
        let mut event = finished(0, 0);
        event.state = MatchState::Postponed;
        assert!(settle(&mut postponed, &event, "2026-11-09T22:00:00Z"));
        assert_eq!(postponed.status, SimStatus::Void);
        assert_eq!(postponed.pnl, Some(0.0));
    }

    #[test]
    fn only_high_confidence_tradable_signals_are_drafted() {
        let now = "2026-11-09T19:50:00Z";
        assert!(draft(
            &signal("high", Confidence::Eleve, SignalKind::Favorite, 1.31),
            now
        )
        .is_some());
        assert!(draft(
            &signal("medium", Confidence::Moyen, SignalKind::Favorite, 1.8),
            now
        )
        .is_none());
        assert!(draft(
            &signal("observation", Confidence::Eleve, SignalKind::Weight, 1.8),
            now
        )
        .is_none());
        assert!(draft(
            &signal("short", Confidence::Eleve, SignalKind::Favorite, 1.29),
            now
        )
        .is_none());
    }

    #[test]
    fn an_eligible_signal_opens_immediately_even_far_from_kickoff() {
        let kickoff = "2026-11-09T20:00:00Z";
        let mut sig = signal("early", Confidence::Eleve, SignalKind::Favorite, 1.8);
        sig.date = kickoff.into();

        // 30 min avant : ouverture immédiate, plus d'attente de T−15.
        let entries = plan_entries(&[sig.clone()], &[], "2026-11-09T19:30:00Z");
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].minutes_before_kickoff, 30);

        // 44 h avant : idem, il n'y a pas de borne haute.
        let far = plan_entries(&[sig.clone()], &[], "2026-11-08T00:00:00Z");
        assert_eq!(far.len(), 1);
        assert_eq!(far[0].minutes_before_kickoff, 2640);

        // Le candidat mémorisé suffit toujours si le signal a disparu du flux.
        let memorized = candidate(&sig).expect("candidat éligible");
        assert!(memorized.opened_at.is_empty());
        assert_eq!(
            plan_drafts_with_realized(vec![memorized], &[], 0.0, "2026-11-09T19:50:00Z").len(),
            1
        );

        // Jamais après le coup d'envoi, même avec un candidat périmé.
        assert!(plan_drafts_with_realized(
            vec![candidate(&sig).unwrap()],
            &[],
            0.0,
            "2026-11-09T20:05:00Z"
        )
        .is_empty());
    }

    #[test]
    fn rejection_reasons_name_the_blocker() {
        let kickoff = "2026-11-09T20:00:00Z";
        let now = "2026-11-09T19:50:00Z";
        let mut sig = signal("a", Confidence::Eleve, SignalKind::Favorite, 1.8);
        sig.date = kickoff.into();
        assert_eq!(rejection_reason(&sig, now), None);

        let mut short = sig.clone();
        short.proposals[0].entry_odds = Some(1.29);
        assert_eq!(
            rejection_reason(&short, now),
            Some("cote d'entrée sous le plancher commun")
        );

        let mut uncovered = sig.clone();
        uncovered.league = "Japanese J League Cup".into();
        assert_eq!(
            rejection_reason(&uncovered, now),
            Some("compétition sans source de score (ESPN/SportScore)")
        );

        // Bien avant le coup d'envoi, il n'y a plus de blocage temporel.
        assert_eq!(rejection_reason(&sig, "2026-11-09T19:00:00Z"), None);
        // Après le coup d'envoi, le blocage reste impératif.
        assert_eq!(
            rejection_reason(&sig, "2026-11-09T20:01:00Z"),
            Some("coup d'envoi déjà donné ou marge de sécurité dépassée")
        );

        let mut weak = sig.clone();
        weak.confidence = Confidence::Moyen;
        assert_eq!(
            rejection_reason(&weak, now),
            Some("confiance inférieure à Élevé")
        );
    }

    #[test]
    fn an_eleventh_position_is_never_opened() {
        let now = "2026-11-09T19:50:00Z";
        let signals: Vec<Signal> = (0..11)
            .map(|index| {
                signal(
                    &format!("team{index}"),
                    Confidence::Eleve,
                    SignalKind::Favorite,
                    1.8,
                )
            })
            .collect();
        let entries = plan_entries(&signals, &[], now);
        assert_eq!(entries.len(), 10);
        assert!(entries.iter().all(|entry| entry.is_open()));
        assert!(entries
            .iter()
            .all(|entry| entry.minutes_before_kickoff == 10));

        // La même rencontre n'ouvre pas une seconde position.
        assert!(plan_entries(&signals[..1], &entries, now).is_empty());
    }

    #[test]
    fn history_totals_are_independent_of_the_displayed_slice() {
        let totals = totals(&[
            position("win", SimStatus::Won, Some(0.8)),
            position("loss", SimStatus::Lost, Some(-1.0)),
            position("void", SimStatus::Void, Some(0.0)),
        ]);
        assert_eq!(totals.settled, 3);
        assert_eq!(totals.won, 1);
        assert_eq!(totals.lost, 1);
        assert_eq!(totals.void, 1);
        assert_eq!(round2(totals.realized_pnl), -0.2);
        assert_eq!(totals.risked, 2.0);
    }

    #[test]
    fn report_keeps_open_stakes_out_of_the_available_points() {
        let report = report(vec![
            position("open", SimStatus::Open, None),
            position("win", SimStatus::Won, Some(0.8)),
            position("loss", SimStatus::Lost, Some(-1.0)),
        ]);
        assert_eq!(report.balance_points, 9.8);
        assert_eq!(report.open_stakes, 1.0);
        assert_eq!(report.available_points, 8.8);
        assert_eq!(report.open_count, 1);
        assert_eq!(report.settled, 2);
        assert_eq!(report.roi_pct, Some(-10.0));
    }
}
