//! Moteur de signaux croisés.
//!
//! Réécriture calibrée du moteur TypeScript : les seuils sont exprimés en
//! *conviction* (part dominante moins la part neutre du marché) et en *edge*
//! (part de volume moins probabilité implicite), pas en pourcentage brut. Un
//! marché à deux issues n'est jamais « en convergence » à 52 %, et la double
//! chance n'est pas jugée sur la même échelle qu'un 1X2.
//!
//! Aucune cote ni aucun score n'est inventé : si le marché n'existe pas, il
//! n'apparaît pas dans le signal et n'est pas mentionné dans le texte.
//!
//! Garde-fous de fiabilité :
//! - aucune recommandation sans cote réellement négociable (cote > 1) ;
//! - aucune recommandation sur une rencontre dont le coup d'envoi est passé ;
//! - la rencontre de référence est choisie dans un ordre fixe, pour qu'une
//!   même collecte produise toujours le même signal.

use std::collections::{HashMap, HashSet};

use chrono::{DateTime, Utc};

use crate::enrich::{fixture_key, parse_kickoff};
use crate::fresh::{self, selection_key, FreshMoney, Series};
use crate::grid;
use crate::market::{MarketKey, MarketShape};
use crate::model::{
    Confidence, FixtureMetrics, LiquidityTier, MarketSnapshot, MarketWeight, Match, OddsAnalysis,
    OddsGap, OddsView, Play, Recommendation, Signal, SignalCategory, SignalKind, SignalMarket,
    SignalStats, Slot, Source,
};
use crate::proposals::{self, Authorizer, Proposal};
use crate::quality::{self, Quality};
use crate::thresholds as th;

/// Compatibilité interne : les constantes vivent dans `src/thresholds.rs`.
const MIN_MARKET_VOLUME: f64 = th::MIN_MARKET_VOLUME;
const MIN_CONVICTION: f64 = th::MIN_CONVICTION;
const MIN_MARKETS: usize = th::MIN_MARKETS;
const MIN_TRADABLE_ODDS: f64 = th::MIN_TRADABLE_ODDS;

/// Marchés utilisés comme référence, du plus pertinent au moins pertinent.
/// L'ordre est figé : sans lui, `HashMap::values().next()` renvoyait un marché
/// arbitraire et le signal changeait d'un processus à l'autre.
const REFERENCE_ORDER: [MarketKey; 6] = [
    MarketKey::OneXTwo,
    MarketKey::OverUnder25,
    MarketKey::Btts,
    MarketKey::OverUnder15,
    MarketKey::OverUnder35,
    MarketKey::DrawNoBet,
];

/// Calcul sans historique ni autorisation : utilisé par les tests et le mode
/// dégradé. Le flux d'argent frais est alors absent (jamais inventé).
pub fn compute(snapshots: &[MarketSnapshot], computed_at: &str) -> Vec<Signal> {
    compute_with_context(
        snapshots,
        &Series::default(),
        &Authorizer::default(),
        computed_at,
    )
}

pub fn compute_with_context(
    snapshots: &[MarketSnapshot],
    series: &Series,
    authorizer: &Authorizer,
    computed_at: &str,
) -> Vec<Signal> {
    let now = parse_kickoff(computed_at);
    let mut fixtures: HashMap<String, HashMap<MarketKey, crate::model::Match>> = HashMap::new();

    for snap in snapshots {
        let Some(key) = snap.market else { continue };
        for m in &snap.matches {
            if m.total_volume < MIN_MARKET_VOLUME
                || m.home.trim().is_empty()
                || m.away.trim().is_empty()
            {
                continue;
            }
            fixtures
                .entry(fixture_key(&m.home, &m.away))
                .or_default()
                .insert(key, m.clone());
        }
    }

    // Comparaison de volume entre rencontres : elle ne peut se faire qu'ici,
    // où toute la collecte est disponible, jamais marché par marché.
    let weights = market_weights(&fixtures);

    let mut signals: Vec<Signal> = fixtures
        .into_iter()
        .filter(|(_, markets)| markets.len() >= MIN_MARKETS)
        .filter_map(|(key, markets)| {
            evaluate(
                &key,
                &markets,
                weights.get(&key),
                series,
                authorizer,
                now,
                computed_at,
            )
        })
        .collect();

    signals.sort_by(|a, b| {
        let rank = |c: SignalCategory| match c {
            SignalCategory::DivergenceWarning => 0,
            SignalCategory::ConvergenceOver | SignalCategory::ConvergenceUnder => 1,
            SignalCategory::ConvergenceFavorite => 2,
            SignalCategory::NeutralOpportunity => 3,
        };
        rank(a.category)
            .cmp(&rank(b.category))
            .then(
                b.convergence_score
                    .partial_cmp(&a.convergence_score)
                    .unwrap_or(std::cmp::Ordering::Equal),
            )
            .then(
                b.total_volume
                    .partial_cmp(&a.total_volume)
                    .unwrap_or(std::cmp::Ordering::Equal),
            )
            // Départage stable : deux collectes identiques doivent produire
            // exactement la même liste, dans le même ordre.
            .then_with(|| a.id.cmp(&b.id))
    });
    signals
}

fn conviction(m: &crate::model::Match) -> f64 {
    (m.dominant_share - m.market.def().neutral_share()).max(0.0)
}

/// Journée d'une rencontre : les dix premiers caractères de sa date ISO.
fn day_of(date: &str) -> &str {
    date.get(..10).unwrap_or(date)
}

/// Médiane d'une série de volumes (aucune valeur inventée si la série est vide).
fn median(mut values: Vec<f64>) -> Option<f64> {
    if values.is_empty() {
        return None;
    }
    values.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let mid = values.len() / 2;
    Some(if values.len().is_multiple_of(2) {
        (values[mid - 1] + values[mid]) / 2.0
    } else {
        values[mid]
    })
}

/// Date d'une rencontre, lue dans l'ordre figé des marchés : une même collecte
/// doit toujours désigner la même journée, quel que soit l'ordre de la carte.
fn fixture_date(markets: &HashMap<MarketKey, Match>) -> Option<String> {
    REFERENCE_ORDER
        .iter()
        .find_map(|key| markets.get(key))
        .or_else(|| MarketKey::ALL.iter().find_map(|key| markets.get(key)))
        .map(|m| m.date.clone())
}

/// Poids de chaque rencontre dans la collecte, comparé à la médiane de sa
/// journée.
///
/// C'est la seule échelle qui ait un sens : un samedi de championnat et un mardi
/// de coupe n'ont pas la même activité, donc un multiple calculé sur toute la
/// collecte mesurerait surtout le calendrier. Si la journée compte trop peu de
/// rencontres (`WEIGHT_MIN_PEERS`), la médiane porte sur toute la collecte ; si
/// aucune référence n'existe, aucun poids n'est calculé — il n'y a rien à
/// comparer et rien n'est inventé.
fn market_weights(
    fixtures: &HashMap<String, HashMap<MarketKey, Match>>,
) -> HashMap<String, MarketWeight> {
    if fixtures.len() < 2 {
        return HashMap::new();
    }
    // L'ordre d'itération d'une `HashMap` n'est pas stable : on trie les clés
    // pour que deux collectes identiques produisent exactement les mêmes poids.
    let mut rows: Vec<(&str, f64, String)> = fixtures
        .iter()
        .filter_map(|(key, markets)| {
            fixture_date(markets).map(|date| {
                let volume = markets.values().map(|m| m.total_volume).sum::<f64>();
                (key.as_str(), volume, date)
            })
        })
        .collect();
    rows.sort_by(|a, b| a.0.cmp(b.0));
    let Some(collecte) = median(rows.iter().map(|row| row.1).collect()) else {
        return HashMap::new();
    };

    let mut days: HashMap<&str, Vec<f64>> = HashMap::new();
    for (_, volume, date) in &rows {
        days.entry(day_of(date)).or_default().push(*volume);
    }

    rows.iter()
        .filter_map(|(key, volume, date)| {
            let reference = match days.get(day_of(date)) {
                Some(peers) if peers.len() >= th::WEIGHT_MIN_PEERS => median(peers.clone())?,
                _ => collecte,
            };
            let markets = fixtures.get(*key)?;

            // Répartition du volume entre les deux familles suivies : c'est ce
            // qui distingue « l'argent se forme sur l'issue » de « sur les
            // buts ». Une famille n'est retenue que si elle domine.
            let mut families: HashMap<&'static str, f64> = HashMap::new();
            for (market, m) in markets {
                *families.entry(family_of(*market)).or_default() += m.total_volume;
            }
            let mut ranked: Vec<(&'static str, f64)> = families.into_iter().collect();
            ranked.sort_by(|a, b| {
                b.1.partial_cmp(&a.1)
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| a.0.cmp(b.0))
            });
            let (family, family_volume) = ranked.first().copied()?;

            let multiple = if reference > 0.0 {
                volume / reference
            } else {
                0.0
            };
            let family_share = if *volume > 0.0 {
                family_volume / volume * 100.0
            } else {
                0.0
            };
            Some((
                key.to_string(),
                MarketWeight {
                    volume: r1(*volume),
                    reference: r1(reference),
                    multiple: r1(multiple),
                    family: family.to_string(),
                    family_share: r1(family_share),
                    markets: markets.len(),
                    outlier: *volume >= th::WEIGHT_MIN_VOLUME
                        && multiple >= th::WEIGHT_MIN_MULTIPLE
                        && family_share >= th::WEIGHT_MIN_FAMILY_SHARE
                        && markets.len() >= th::WEIGHT_MIN_MARKETS,
                },
            ))
        })
        .collect()
}

/// Probabilités implicites normalisées du 1X2, lues sur les **cotes**.
///
/// La marge est déjà retirée par `enrich` (les `implied` sont normalisées),
/// donc l'écart se compare d'une rencontre à l'autre — contrairement à un écart
/// de cotes brutes, qui dépend du niveau du nul. La mesure est renvoyée **même
/// quand elle ne franchit pas le seuil « sans favori »** : c'est ce qui permet
/// de calibrer le seuil au lieu de le supposer.
fn implied_gap(markets: &HashMap<MarketKey, Match>) -> Option<[f64; 3]> {
    let m = markets.get(&MarketKey::OneXTwo)?;
    // Les trois issues doivent être réellement cotées : sur un 1X2 incomplet,
    // l'écart ne mesurerait qu'un trou de collecte.
    if m.coef_new.iter().filter(|c| **c > MIN_TRADABLE_ODDS).count() < 3 {
        return None;
    }
    Some(m.implied)
}

/// Une lecture sémantique d'un marché de totaux.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Goals {
    Over,
    Under,
}

fn goals_lean(m: &crate::model::Match) -> Option<Goals> {
    if !m.market.def().is_goals_totals() || conviction(m) < MIN_CONVICTION {
        return None;
    }
    match m.dominant {
        Slot::Second => Some(Goals::Over),
        Slot::First => Some(Goals::Under),
        Slot::Draw => None,
    }
}

fn btts_lean(m: &crate::model::Match) -> Option<bool> {
    if conviction(m) < MIN_CONVICTION {
        return None;
    }
    match m.dominant {
        Slot::First => Some(true),
        Slot::Second => Some(false),
        Slot::Draw => None,
    }
}

/// Somme de buts du score le plus joué, si le marché existe.
fn top_score(m: &crate::model::Match) -> Option<(u8, u8, f64)> {
    let top = m.outcomes.first()?;
    let (h, a) = top.label.split_once('-')?;
    let home: u8 = h.trim().parse().ok()?;
    let away: u8 = a.trim().parse().ok()?;
    Some((home, away, top.pct))
}

fn reco(play: Play, label: impl Into<String>, odds: Option<f64>) -> Recommendation {
    Recommendation {
        play,
        label: label.into(),
        odds,
    }
}

fn r1(value: f64) -> f64 {
    (value * 10.0).round() / 10.0
}

/// Probabilité brute d'une issue (1 / cote), sans normalisation.
fn raw_prob(m: &Match, slot: usize) -> Option<f64> {
    let odds = m.coef_new[slot];
    (odds > 1.0).then(|| 1.0 / odds)
}

/// Probabilités 1X2 reconstruites depuis les **cotes** de double chance.
///
/// Les trois issues DC ne forment pas une partition (un nul est couvert par 1X
/// et X2), donc normaliser 1/cote sur les trois n'a pas de sens probabiliste.
/// En revanche `1X + 12 - X2` vaut exactement `2 × P(domicile)`, ce qui donne une
/// estimation indépendante de celle du marché 1X2 : c'est la base des écarts.
fn dc_probabilities(m: &Match) -> Option<[f64; 3]> {
    let a = raw_prob(m, 0)?; // 1X
    let b = raw_prob(m, 1)?; // X2
    let c = raw_prob(m, 2)?; // 12
    let home = (a + c - b) / 2.0;
    let draw = (a + b - c) / 2.0;
    let away = (b + c - a) / 2.0;
    let sum = home + draw + away;
    if sum <= 0.0 {
        return None;
    }
    Some([
        home / sum * 100.0,
        draw / sum * 100.0,
        away / sum * 100.0,
    ])
}

/// Probabilités domicile / extérieur déduites du DNB (nul remboursé).
fn dnb_probabilities(m: &Match) -> Option<(f64, f64)> {
    let home = raw_prob(m, 0)?;
    let away = raw_prob(m, 2)?;
    let sum = home + away;
    if sum <= 0.0 {
        return None;
    }
    Some((home / sum * 100.0, away / sum * 100.0))
}

/// Marge du marché (surcote) : `100 × (Σ 1/cote − 1)`.
///
/// Un bookmaker ou un exchange cote toujours « un peu trop cher » au total.
/// Cette marge n'est pas un profit : c'est le prix de la liquidité. Au-delà de
/// 5 %, les cotes sont larges, les probabilités implicites sont biaisées (les
/// outsiders sont surévalués) et l'edge affiché doit être lu avec prudence.
/// Les marchés non partition (double chance, multi-issues) sont exclus : leur
/// somme de 1/cote n'a pas de sens.
fn overround_pct(m: &Match) -> Option<f64> {
    if m.shape == MarketShape::Multi || m.market == MarketKey::DoubleChance {
        return None;
    }
    let inv: f64 = m
        .coef_new
        .iter()
        .filter(|c| **c > 1.0)
        .map(|c| 1.0 / c)
        .sum();
    (inv > 0.0).then(|| r1((inv - 1.0) * 100.0))
}

fn odds_view(m: &Match, slot: usize) -> OddsView {
    let odds = m.coef_new[slot];
    OddsView {
        label: m.labels[slot].clone(),
        market: m.market.slug().to_string(),
        odds: (odds > 1.0).then_some(odds),
        implied: r1(m.implied[slot]),
        share: r1(m.share[slot]),
        edge_pp: r1(m.share[slot] - m.implied[slot]),
    }
}

/// Retrouve le marché et l'issue qui portent un pari donné.
fn play_quote<'a>(markets: &'a HashMap<MarketKey, Match>, play: &Play) -> Option<(&'a Match, usize)> {
    let (key, slot) = match play {
        Play::TotalGoals { line, over } => {
            let key = if (*line - 1.5).abs() < 0.01 {
                MarketKey::OverUnder15
            } else if (*line - 2.5).abs() < 0.01 {
                MarketKey::OverUnder25
            } else if (*line - 3.5).abs() < 0.01 {
                MarketKey::OverUnder35
            } else {
                return None;
            };
            (key, if *over { 2 } else { 0 })
        }
        Play::Btts { yes } => (MarketKey::Btts, if *yes { 0 } else { 2 }),
        Play::MatchResult { side } => (MarketKey::OneXTwo, side.index()),
        Play::DrawNoBet { side } => (MarketKey::DrawNoBet, side.index()),
        Play::DoubleChance { .. } | Play::ExactScore { .. } | Play::NoBet => return None,
    };
    markets.get(&key).map(|m| (m, slot))
}

/// Écarts de prix entre marchés + score de cohérence (0-100).
fn price_gaps(markets: &HashMap<MarketKey, Match>) -> (Vec<OddsGap>, Option<f64>) {
    let mut gaps = Vec::new();
    let mut penalty = 0.0_f64;
    // Nombre de comparaisons réellement effectuées : sans aucune comparaison,
    // la cohérence est absente (`None`), jamais 100 par défaut.
    let mut comparisons = 0usize;
    let one = markets.get(&MarketKey::OneXTwo);

    if let (Some(one), Some(dc)) = (one, markets.get(&MarketKey::DoubleChance)) {
        if let Some(dc_p) = dc_probabilities(dc) {
            comparisons += 3;
            for (i, label) in ["1 (Domicile)", "X (Nul)", "2 (Extérieur)"].iter().enumerate() {
                let gap = dc_p[i] - one.implied[i];
                if gap.abs() >= th::GAP_TOLERANCE_PP {
                    penalty += (gap.abs() - 4.0).min(14.0) * 1.1;
                    gaps.push(OddsGap {
                        label: format!("1X2 ↔ double chance · {label}"),
                        left: r1(one.implied[i]),
                        right: r1(dc_p[i]),
                        gap_pp: r1(gap),
                        note: format!(
                            "Le 1X2 price {label} à {:.1} % alors que les cotes de double chance impliquent {:.1} % ({gap:+.1} pts)",
                            one.implied[i], dc_p[i]
                        ),
                    });
                }
            }
        }
    }

    if let (Some(one), Some(dnb)) = (one, markets.get(&MarketKey::DrawNoBet)) {
        if let Some((home, _away)) = dnb_probabilities(dnb) {
            let total = one.implied[0] + one.implied[2];
            if total > 0.0 {
                comparisons += 1;
                let expected = one.implied[0] / total * 100.0;
                let gap = home - expected;
                if gap.abs() >= th::GAP_TOLERANCE_PP {
                    penalty += (gap.abs() - 4.0).min(14.0) * 1.1;
                    gaps.push(OddsGap {
                        label: "1X2 ↔ DNB · domicile".to_string(),
                        left: r1(expected),
                        right: r1(home),
                        gap_pp: r1(gap),
                        note: format!(
                            "Le DNB implique {home:.1} % pour le domicile contre {expected:.1} % déduits du 1X2 ({gap:+.1} pts)"
                        ),
                    });
                }
            }
        }
    }

    let over = |key: MarketKey| markets.get(&key).map(|m| m.implied[2]);
    for (low, high, label) in [
        (MarketKey::OverUnder15, MarketKey::OverUnder25, "+1.5 ↔ +2.5 buts"),
        (MarketKey::OverUnder25, MarketKey::OverUnder35, "+2.5 ↔ +3.5 buts"),
    ] {
        if let (Some(p_low), Some(p_high)) = (over(low), over(high)) {
            comparisons += 1;
            let gap = p_high - p_low;
            if gap > th::NESTED_GOALS_GAP_PP {
                penalty += (gap - 3.0).min(14.0) * 1.1;
                gaps.push(OddsGap {
                    label: label.to_string(),
                    left: r1(p_low),
                    right: r1(p_high),
                    gap_pp: r1(gap),
                    note: format!(
                        "La ligne haute est plus probable ({p_high:.1} %) que la ligne basse ({p_low:.1} %) : les cotes de buts s'imbriquent mal"
                    ),
                });
            }
        }
    }

    if let (Some(btts), Some(o15)) = (
        markets.get(&MarketKey::Btts),
        over(MarketKey::OverUnder15),
    ) {
        comparisons += 1;
        let gap = btts.implied[0] - o15;
        if gap > 4.0 {
            penalty += (gap - 4.0).min(14.0) * 1.1;
            gaps.push(OddsGap {
                label: "BTTS Oui ↔ +1.5 buts".to_string(),
                left: r1(o15),
                right: r1(btts.implied[0]),
                gap_pp: r1(gap),
                note: format!(
                    "BTTS Oui ({:.1} %) ne peut pas être plus probable que +1.5 buts ({o15:.1} %)",
                    btts.implied[0]
                ),
            });
        }
    }

    let coherence = (comparisons > 0).then(|| r1((100.0 - penalty).clamp(0.0, 100.0)));
    (gaps, coherence)
}

/// Marché de référence : premier marché coté dans l'ordre figé.
fn reference_market(
    markets: &HashMap<MarketKey, crate::model::Match>,
) -> Option<&crate::model::Match> {
    REFERENCE_ORDER
        .iter()
        .find_map(|key| markets.get(key))
        .or_else(|| MarketKey::ALL.iter().find_map(|key| markets.get(key)))
}

/// Cote réellement négociable pour un pari donné.
fn tradable_quote<'a>(
    markets: &'a HashMap<MarketKey, crate::model::Match>,
    play: &Play,
) -> Option<(&'a crate::model::Match, usize)> {
    play_quote(markets, play).filter(|(m, slot)| m.coef_new[*slot] > MIN_TRADABLE_ODDS)
}

/// Le coup d'envoi est-il déjà donné à l'heure du calcul ?
pub(crate) fn has_started(date: &str, computed_at: &str) -> bool {
    match (parse_kickoff(date), parse_kickoff(computed_at)) {
        (Some(kickoff), Some(now)) => now >= kickoff,
        _ => false,
    }
}

fn evaluate(
    key: &str,
    all: &HashMap<MarketKey, Match>,
    weight: Option<&MarketWeight>,
    series: &Series,
    authorizer: &Authorizer,
    now: Option<DateTime<Utc>>,
    computed_at: &str,
) -> Option<Signal> {
    // --- Filtre qualité : rejeté = visible mais inopérant -------------------
    let quality_map: HashMap<MarketKey, Quality> = all
        .iter()
        .map(|(k, m)| (*k, quality::assess(m, now)))
        .collect();
    let fresh_map: HashMap<MarketKey, FreshMoney> = all
        .iter()
        .map(|(k, m)| (*k, fresh_of(series, *k, m, now)))
        .collect();
    let usable: HashMap<MarketKey, Match> = all
        .iter()
        .filter(|(k, _)| quality_map[*k].ok)
        .map(|(k, m)| (*k, m.clone()))
        .collect();
    let usable_keys: HashSet<MarketKey> = usable.keys().copied().collect();
    // La référence est choisie parmi les marchés exploitables ; si aucun ne
    // passe le filtre, on garde une référence pour afficher le rejet.
    let reference = reference_market(&usable).or_else(|| reference_market(all))?;
    let markets = &usable;

    let ou25 = markets.get(&MarketKey::OverUnder25);
    let ou15 = markets.get(&MarketKey::OverUnder15);
    let ou35 = markets.get(&MarketKey::OverUnder35);
    let btts = markets.get(&MarketKey::Btts);
    let score = markets.get(&MarketKey::CorrectScore);
    let one_x_two = markets.get(&MarketKey::OneXTwo);
    let dnb = markets.get(&MarketKey::DrawNoBet);
    let dc = markets.get(&MarketKey::DoubleChance);

    let btts_lean = btts
        .and_then(|m| btts_lean(m))
        .map(|yes| (yes, btts.unwrap()));
    let top = score.and_then(top_score);

    let total_volume: f64 = all.values().map(|m| m.total_volume).sum();
    let stale = all.values().any(|m| !m.source.is_live());

    // --- Contradiction par grille de scores (remplace les règles en dur) ----
    let divergence = grid_divergence(&usable, &fresh_map);
    let divergence_detected = divergence.is_some();

    let mut signal_markets: Vec<SignalMarket> = all
        .iter()
        .map(|(k, m)| SignalMarket {
            market: *k,
            market_label: k.def().short.to_string(),
            dominant_label: m.dominant_label.clone(),
            dominant_share: m.dominant_share,
            odds: if m.coef_new[m.dominant.index()] > 0.0 {
                Some(m.coef_new[m.dominant.index()])
            } else {
                None
            },
            volume: m.total_volume,
            // Une concentration du cumulé sans argent frais n'est plus un
            // signal de flux : elle est dégradée en simple information.
            signal_label: if m.signal_type == crate::model::SignalType::WhaleAccumulation
                && !fresh_map[k].ok
            {
                format!(
                    "{} % du volume cumulé sur {} · information (pas d'argent frais)",
                    m.dominant_share.round(),
                    m.dominant_label
                )
            } else {
                m.signal_label.clone()
            },
            conviction: (conviction(m) * 10.0).round() / 10.0,
            quality: quality_map[k].clone(),
            fresh: fresh_map[k].clone(),
        })
        .collect();
    signal_markets.sort_by(|a, b| {
        b.conviction
            .partial_cmp(&a.conviction)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.market.slug().cmp(b.market.slug()))
    });

    let bullets = signal_markets
        .iter()
        .take(4)
        .map(|m| {
            format!(
                "{} : {} ({:.0} % du volume, {:.0} k£)",
                m.market_label,
                m.dominant_label,
                m.dominant_share,
                m.volume / 1000.0
            )
        })
        .collect::<Vec<_>>()
        .join(" · ");

    let (mut category, mut title, mut summary, mut value, _legacy_safety, mut score_marker, mut extra) =
        if let Some((text, strength)) = divergence {
            (
                SignalCategory::DivergenceWarning,
                "Contradiction entre marchés".to_string(),
                format!(
                    "Deux compartiments financent des scénarios incompatibles : {text}. \
                 Les flux se neutralisent, il n'y a pas d'edge exploitable."
                ),
                reco(Play::NoBet, "Aucun pari : contradiction", None),
                reco(Play::NoBet, "S'abstenir", None),
                (100.0 - (strength - 110.0).max(0.0) * 0.15).clamp(10.0, 45.0),
                Some(text),
            )
        } else if let Some(m) = ou25 {
            let line = 2.5;
            match goals_lean(m) {
                Some(Goals::Over) if m.dominant_share >= 60.0 => {
                    let corroborated_by_btts = matches!(btts_lean, Some((true, _)));
                    let corroborated_by_score = top
                        .map(|(h, a, pct)| h + a >= 3 && pct >= 18.0)
                        .unwrap_or(false);
                    let corroborated_by_ou35 = ou35
                        .and_then(goals_lean)
                        .map(|g| g == Goals::Over)
                        .unwrap_or(false);

                    if corroborated_by_btts || corroborated_by_score || corroborated_by_ou35 {
                        let mut parts = vec![format!(
                            "Plus de 2.5 buts financé à {:.0} %",
                            m.dominant_share
                        )];
                        if let (true, Some(b)) = (corroborated_by_btts, btts) {
                            parts.push(format!("BTTS Oui à {:.0} %", b.dominant_share));
                        }
                        if let Some((h, a, pct)) = top {
                            if h + a >= 3 {
                                parts.push(format!("score exact {h}-{a} à {pct:.0} %"));
                            }
                        }
                        if corroborated_by_ou35 {
                            if let Some(o) = ou35 {
                                parts.push(format!("+3.5 buts à {:.0} %", o.dominant_share));
                            }
                        }
                        let mut score = 55.0 + conviction(m) * 0.9;
                        if corroborated_by_btts {
                            score += 8.0;
                        }
                        if corroborated_by_ou35 {
                            score += 6.0;
                        }
                        (
                            SignalCategory::ConvergenceOver,
                            "Scénario prolifique confirmé".to_string(),
                            format!(
                                "Les marchés de buts pointent dans la même direction : {}. \
                             Recoupement de {} marchés pour {:.0} k£ échangés.",
                                parts.join(", "),
                                markets.len(),
                                total_volume / 1000.0
                            ),
                            reco(
                                Play::TotalGoals { line, over: true },
                                "Plus de 2.5 buts",
                                Some(m.coef_new[2]),
                            ),
                            reco(
                                Play::TotalGoals {
                                    line: 1.5,
                                    over: true,
                                },
                                "Plus de 1.5 buts (sécurité)",
                                ou15.map(|o| o.coef_new[2]),
                            ),
                            score.clamp(55.0, 97.0),
                            None,
                        )
                    } else {
                        neutral(
                            &bullets,
                            markets.len(),
                            total_volume,
                            &signal_markets,
                            one_x_two,
                            m,
                        )
                    }
                }
                Some(Goals::Under) if m.dominant_share >= 60.0 => {
                    let corroborated_by_btts = matches!(btts_lean, Some((false, _)));
                    let corroborated_by_score = top
                        .map(|(h, a, pct)| h + a <= 2 && pct >= 18.0)
                        .unwrap_or(false);
                    let corroborated_by_ou15 = ou15
                        .and_then(goals_lean)
                        .map(|g| g == Goals::Under)
                        .unwrap_or(false);

                    if corroborated_by_btts || corroborated_by_score || corroborated_by_ou15 {
                        let mut parts = vec![format!(
                            "Moins de 2.5 buts financé à {:.0} %",
                            m.dominant_share
                        )];
                        if let (true, Some(b)) = (corroborated_by_btts, btts) {
                            parts.push(format!("BTTS Non à {:.0} %", b.dominant_share));
                        }
                        if let Some((h, a, pct)) = top {
                            if h + a <= 2 {
                                parts.push(format!("score exact {h}-{a} à {pct:.0} %"));
                            }
                        }
                        let mut score = 55.0 + conviction(m) * 0.9;
                        if corroborated_by_btts {
                            score += 8.0;
                        }
                        if corroborated_by_ou15 {
                            score += 5.0;
                        }
                        (
                            SignalCategory::ConvergenceUnder,
                            "Scénario fermé confirmé".to_string(),
                            format!(
                                "Les marchés de buts convergent vers un match verrouillé : {}. \
                             Recoupement de {} marchés pour {:.0} k£ échangés.",
                                parts.join(", "),
                                markets.len(),
                                total_volume / 1000.0
                            ),
                            reco(
                                Play::TotalGoals { line, over: false },
                                "Moins de 2.5 buts",
                                Some(m.coef_new[0]),
                            ),
                            reco(
                                Play::TotalGoals {
                                    line: 3.5,
                                    over: false,
                                },
                                "Moins de 3.5 buts (sécurité)",
                                ou35.map(|o| o.coef_new[0]),
                            ),
                            score.clamp(55.0, 97.0),
                            None,
                        )
                    } else {
                        neutral(
                            &bullets,
                            markets.len(),
                            total_volume,
                            &signal_markets,
                            one_x_two,
                            m,
                        )
                    }
                }
                _ => neutral(
                    &bullets,
                    markets.len(),
                    total_volume,
                    &signal_markets,
                    one_x_two,
                    m,
                ),
            }
        } else if let Some(m1) = one_x_two {
            let side = m1.dominant;
            let same_side = |m: &crate::model::Match| m.dominant == side;
            let dnb_confirms = dnb
                .map(|d| {
                    same_side(d)
                        && d.market.def().shape == MarketShape::TwoWay
                        && conviction(d) >= 10.0
                })
                .unwrap_or(false);
            // Correction : « 12 » (domicile ou extérieur) ne confirme pas une
            // victoire à domicile, et « X2 » ne confirme pas une victoire à
            // l'extérieur. Seule l'issue qui contient le côté visé compte.
            let dc_confirms = dc
                .map(|d| match side {
                    Slot::First => d.dominant == Slot::First,
                    Slot::Second => d.dominant == Slot::Draw,
                    Slot::Draw => false,
                })
                .unwrap_or(false);

            if m1.dominant_share >= 60.0 && (dnb_confirms || dc_confirms) {
                let odds = m1.coef_new[side.index()];
                (
                    SignalCategory::ConvergenceFavorite,
                    format!("Consensus sur {}", m1.dominant_label),
                    format!(
                    "Le 1X2 place {:.0} % du volume sur {} et les marchés dérivés confirment la \
                     même hiérarchie ({} marchés recoupés).",
                    m1.dominant_share,
                    m1.dominant_label,
                    markets.len()
                ),
                    reco(
                        Play::MatchResult { side },
                        format!("Victoire {}", m1.dominant_label),
                        Some(odds),
                    ),
                    reco(
                        Play::DrawNoBet { side },
                        "DNB (remboursé si nul)",
                        dnb.map(|d| d.coef_new[side.index()]),
                    ),
                    55.0 + conviction(m1) * 0.8 + if dnb_confirms { 6.0 } else { 3.0 },
                    None,
                )
            } else {
                neutral(
                    &bullets,
                    markets.len(),
                    total_volume,
                    &signal_markets,
                    one_x_two,
                    m1,
                )
            }
        } else {
            neutral(
                &bullets,
                markets.len(),
                total_volume,
                &signal_markets,
                one_x_two,
                reference,
            )
        };

    // --- Garde-fous : aucun pari qui ne pourrait pas être pris -------------
    // Une rencontre commencée n'a plus de cotes d'avant-match : on garde
    // l'observation des flux, mais la recommandation est retirée.
    if value.play != Play::NoBet && has_started(&reference.date, computed_at) {
        let kickoff = if reference.date_label.is_empty() {
            reference.date.clone()
        } else {
            reference.date_label.clone()
        };
        category = SignalCategory::NeutralOpportunity;
        title = "Coup d'envoi déjà donné".to_string();
        summary = format!(
            "{summary} Coup d'envoi à {kickoff} : la rencontre est commencée, les cotes d'avant-match \
             ne sont plus négociables et aucun pari n'est proposé."
        );
        value = reco(Play::NoBet, "Aucun pari : rencontre commencée", None);
        score_marker = score_marker.min(40.0);
        extra = Some(format!("Coup d'envoi : {kickoff}"));
    }

    // Un marché sans cote (volume présent, prix absent) ne peut pas porter un
    // pari : la recommandation est remplacée par une abstention explicite.
    if value.play != Play::NoBet && tradable_quote(markets, &value.play).is_none() {
        let detail = match play_quote(markets, &value.play) {
            Some((m, slot)) => format!(
                "le marché {} n'a pas de cote pour {}",
                m.market.def().short,
                m.labels[slot]
            ),
            None => "le marché correspondant n'est pas collecté".to_string(),
        };
        category = SignalCategory::NeutralOpportunity;
        title = "Marché non coté".to_string();
        summary = format!(
            "{summary} {detail} : aucun pari n'est proposé sur un prix inexistant."
        );
        value = reco(Play::NoBet, "Aucun pari : marché non coté", None);
        score_marker = score_marker.min(45.0);
        extra = Some(detail);
    }

    // --- Intégration des cotes au signal ---------------------------------
    let (gap_list, coherence) = price_gaps(markets);

    // Chantier 3 : l'écart « part − implicite » ne décide plus d'un pari et ne
    // classe plus un signal. On garde une phrase de contexte ; le choix d'un
    // pari repose sur le mouvement de cote, l'argent frais et la confirmation
    // par une autre famille de marchés.
    if value.play != Play::NoBet {
        if let Some((m, slot)) = play_quote(markets, &value.play) {
            if matches!(
                category,
                SignalCategory::ConvergenceOver
                    | SignalCategory::ConvergenceUnder
                    | SignalCategory::ConvergenceFavorite
            ) {
                summary = format!(
                    "{summary} Prix : cote {:.2}, implicite {:.1} %, flux {:.0} %.",
                    m.coef_new[slot], m.implied[slot], m.share[slot]
                );
            }
        }
    }

    // Une incohérence de prix franche entre deux marchés est une divergence au
    // même titre qu'un conflit de volumes.
    let strong_gap = gap_list
        .iter()
        .filter(|g| g.gap_pp.abs() >= th::GAP_DIVERGENCE_PP)
        .max_by(|a, b| {
            a.gap_pp
                .abs()
                .partial_cmp(&b.gap_pp.abs())
                .unwrap_or(std::cmp::Ordering::Equal)
        })
        .cloned();
    if let Some(gap) = strong_gap {
        if matches!(
            category,
            SignalCategory::ConvergenceOver
                | SignalCategory::ConvergenceUnder
                | SignalCategory::ConvergenceFavorite
        ) {
            category = SignalCategory::DivergenceWarning;
            title = "Prix incohérents entre marchés".to_string();
            summary = format!(
                "Les cotes ne se recoupent pas : {}. Les marchés ne s'accordent pas sur la même 
                 probabilité, donc le signal de volume n'est pas exploitable en l'état.",
                gap.note
            );
            score_marker = score_marker.min(40.0);
            extra = Some(gap.note.clone());
        }
    }

    // --- Lecture courante : argent frais, familles, confiance ----------------
    let leading = markets
        .values()
        .max_by(|a, b| {
            conviction(a)
                .partial_cmp(&conviction(b))
                .unwrap_or(std::cmp::Ordering::Equal)
                // `HashMap` itère dans un ordre non garanti : sans départage,
                // une égalité changeait `kind` et 15 points de confiance d'un
                // processus à l'autre.
                .then_with(|| a.market.slug().cmp(b.market.slug()))
        })
        .unwrap_or(reference);
    let leading_fresh = fresh_map
        .get(&leading.market)
        .cloned()
        .unwrap_or_default();
    let mut kind = determine_kind(divergence_detected, category, &leading_fresh);
    let families = confirming_families(markets);
    let mut confidence = confidence_of(
        &quality_map[&reference.market],
        reference.liquidity_tier,
        families.len(),
        &leading_fresh,
        authorizer.by_kind.get(kind.key()),
    );

    // --- Poids de marché : où se forme le prix ------------------------------
    // Une rencontre peut capter beaucoup plus de volume que les autres de sa
    // journée, et le concentrer sur une seule famille (résultat ou buts). C'est
    // une information de localisation : elle dit où le marché se forme, jamais
    // dans quel sens parier. Elle ne remplace donc pas une convergence, elle la
    // complète ; seule, elle devient un signal descriptif sans proposition.
    if let Some(w) = weight.filter(|w| w.outlier) {
        summary = format!(
            "{summary} Poids de marché : {:.0} k£ échangés sur la rencontre, soit {:.1}× la médiane \
             de la journée ({:.0} k£), dont {:.0} % sur la famille {}.",
            w.volume / 1000.0,
            w.multiple,
            w.reference / 1000.0,
            w.family_share,
            w.family
        );
        if kind == SignalKind::Neutral {
            kind = SignalKind::Weight;
            title = "Rencontre sous forte activité".to_string();
            summary = format!(
                "La rencontre capte {:.1}× le volume médian de la journée ({:.0} k£ contre {:.0} k£), \
                 concentré à {:.0} % sur la famille {} : c'est là que le marché se forme. En revanche, \
                 aucun côté n'est financé plus que le prix ne l'implique, donc aucun pari n'est proposé.",
                w.multiple,
                w.volume / 1000.0,
                w.reference / 1000.0,
                w.family_share,
                w.family
            );
            // Un poids élevé n'est pas une conviction directionnelle : la
            // jauge reste basse et la confiance ne peut pas être « Élevé ».
            score_marker = score_marker.min(45.0);
        }
        confidence = match confidence {
            Confidence::Eleve => Confidence::Moyen,
            other => other,
        };
    }

    // --- Match sans favori : le marché ne sépare pas les deux équipes -------
    // C'est une qualification de la rencontre, pas une direction : un prix juste
    // ne se joue pas. Comme `Weight`, elle plafonne la confiance à `Moyen`
    // (cf. `docs/INTERPRETATION.md`) : sans favorite, il n'y a pas de signal
    // directionnel à confiance élevée. Elle complète aussi le résumé pour que
    // le lecteur sache à quoi il a affaire.
    let implied = implied_gap(markets);
    let gap_pp = implied.map(|p| (p[0] - p[2]).abs());
    let one_x_two_volume = one_x_two.map(|m| m.total_volume).unwrap_or(0.0);
    if let (Some(p), Some(gap)) = (implied, gap_pp) {
        if gap <= th::EVEN_MAX_GAP_PP && one_x_two_volume >= th::EVEN_MIN_VOLUME {
            summary = format!(
                "{summary} Match sans favori : le 1X2 price {:.1} % pour le domicile et {:.1} % \
                 pour l'extérieur, soit {gap:.1} pts d'écart — le marché ne tranche pas.",
                p[0], p[2]
            );
            if kind == SignalKind::Neutral {
                kind = SignalKind::Even;
                title = "Match sans favori".to_string();
                summary = format!(
                    "Match sans favori : le 1X2 donne {:.1} % au domicile et {:.1} % à \
                     l'extérieur, soit {gap:.1} pts d'écart — le marché ne sépare pas les deux \
                     équipes. Un match équilibré n'est pas un pari (le prix est réputé juste) et il \
                     disqualifie toute lecture « favori » : c'est une rencontre à passer, pas à jouer.",
                    p[0], p[2]
                );
                score_marker = score_marker.min(40.0);
            }
            confidence = match confidence {
                Confidence::Eleve => Confidence::Moyen,
                other => other,
            };
        }
    }

    // Les marchés rejetés restent visibles : la raison est écrite dans le
    // résumé, jamais masquée.
    let rejected: Vec<String> = all
        .iter()
        .filter(|(k, _)| !quality_map[*k].ok)
        .map(|(k, m)| format!("{} : {}", m.market.def().short, quality_map[k].why()))
        .collect();
    if !rejected.is_empty() {
        summary = format!("{summary} Données écartées — {}.", rejected.join(" · "));
    }

    // Une rencontre commencée n'a plus de cotes d'avant-match : l'observation
    // reste, la proposition disparaît.
    // Direction du match : seule une lecture 1X2 (ou DNB) a un sens ici, pas
    // la dominante d'un marché de buts.
    let direction = all
        .get(&MarketKey::OneXTwo)
        .or_else(|| all.get(&MarketKey::DrawNoBet))
        .map(|m| match m.dominant {
            Slot::First => "domicile",
            Slot::Draw => "nul",
            Slot::Second => "extérieur",
        })
        .unwrap_or_default()
        .to_string();

    let locked = has_started(&reference.date, computed_at);
    let mut proposals: Vec<Proposal> = if locked {
        Vec::new()
    } else {
        proposals::build(markets, &usable_keys, kind, authorizer)
    };
    // Les observations ne proposent rien : ni le volume (il ne choisit pas un
    // côté) ni l'équilibre d'un match (un prix juste ne se joue pas).
    if matches!(kind, SignalKind::Weight | SignalKind::Even) {
        proposals.clear();
    }
    // Une seule proposition par groupe de marché : l'ancien pari « sécurité »
    // n'existe plus.
    value = match proposals.first() {
        Some(p) if kind.tradable() => reco(p.play.clone(), p.pick.clone(), p.entry_odds),
        _ => reco(Play::NoBet, "Aucun pari recommandé", None),
    };
    let safety: Recommendation = reco(Play::NoBet, "S'abstenir", None);

    let value_view = proposals.first().and_then(|p| {
        p.market_key.and_then(|key| {
            markets
                .get(&key)
                .map(|m| odds_view(m, m.dominant_index))
        })
    });
    let ev_pct = value_view.as_ref().and_then(|view| {
        view.odds
            .map(|odds| r1((view.share / 100.0 * odds - 1.0) * 100.0))
    });
    // --- Mesures de contexte pour la calibration (/api/backtest) -------------
    // Conservées même sous les seuils : c'est la seule façon de vérifier plus
    // tard qu'un seuil discrimine, plutôt que de le supposer.
    let price = |value: f64| (value > MIN_TRADABLE_ODDS).then_some(value);
    let metrics = FixtureMetrics {
        volume: r1(total_volume),
        reference: weight.map(|w| w.reference).unwrap_or_default(),
        multiple: weight.map(|w| w.multiple).unwrap_or_default(),
        family: weight.map(|w| w.family.clone()).unwrap_or_default(),
        family_share: weight.map(|w| w.family_share).unwrap_or_default(),
        markets: all.len(),
        p_home: implied.map(|p| r1(p[0])),
        p_draw: implied.map(|p| r1(p[1])),
        p_away: implied.map(|p| r1(p[2])),
        gap_pp: gap_pp.map(r1),
        overround_pct: overround_pct(reference),
        over_25_implied: ou25.map(|m| r1(m.implied[2])),
        home_odds: one_x_two.and_then(|m| price(m.coef_new[0])),
        draw_odds: one_x_two.and_then(|m| price(m.coef_new[1])),
        away_odds: one_x_two.and_then(|m| price(m.coef_new[2])),
        over_25_odds: ou25.and_then(|m| price(m.coef_new[2])),
        under_25_odds: ou25.and_then(|m| price(m.coef_new[0])),
    };

    let odds_block = OddsAnalysis {
        safety: None,
        value: value_view,
        favorite: Some(odds_view(reference, reference.dominant_index)),
        gaps: gap_list,
        coherence,
        overround_pct: overround_pct(reference),
        ev_pct,
    };

    Some(Signal {
        // Identifiant stable par rencontre : une catégorie qui bascule
        // (neutre → convergence) ne doit pas créer un second suivi, sinon le
        // bilan compte deux fois la même rencontre.
        id: format!("sig_{key}"),
        fixture_key: key.to_string(),
        home: reference.home.clone(),
        away: reference.away.clone(),
        league: reference.league.clone(),
        country: reference.country.clone(),
        flag_url: reference.flag_url.clone(),
        date: reference.date.clone(),
        date_label: reference.date_label.clone(),
        convergence_score: (score_marker * 10.0).round() / 10.0,
        category,
        category_label: category.label().to_string(),
        scenario_title: title,
        analysis_summary: summary,
        value,
        safety,
        divergence_explanation: extra,
        total_volume: (total_volume * 100.0).round() / 100.0,
        markets: signal_markets,
        odds: odds_block,
        kind,
        families,
        confidence,
        fresh: leading_fresh,
        quality: quality_map[&reference.market].clone(),
        proposals,
        liquidity_tier: reference.liquidity_tier,
        direction,
        weight: weight.cloned(),
        metrics,
        source: if stale { Source::Stale } else { Source::Live },
        computed_at: computed_at.to_string(),
    })
}

/// Marché exploitable qui porte la lecture (plus forte conviction).
fn fresh_of(
    series: &Series,
    key: MarketKey,
    m: &Match,
    now: Option<DateTime<Utc>>,
) -> FreshMoney {
    let Some(now) = now else {
        return FreshMoney {
            ok: false,
            why: "horodatage de collecte illisible".to_string(),
            ..Default::default()
        };
    };
    fresh::compute(
        series,
        &selection_key(key, m.market_id, m.selection_id),
        m.dominant_index,
        now,
        parse_kickoff(&m.date),
    )
}

/// Famille de confirmation d'un marché.
///
/// « Résultat » : 1X2, DNB, double chance, mi-temps.
/// « Buts » : lignes de buts, BTTS, score exact, MT/FM.
pub fn family_of(key: MarketKey) -> &'static str {
    match key {
        MarketKey::OneXTwo
        | MarketKey::DrawNoBet
        | MarketKey::DoubleChance
        | MarketKey::HalfTime => "Résultat",
        MarketKey::OverUnder15
        | MarketKey::OverUnder25
        | MarketKey::OverUnder35
        | MarketKey::Btts
        | MarketKey::CorrectScore
        | MarketKey::HalfTimeFullTime => "Buts",
    }
}

/// Familles réellement porteuses (marché exploitable et financé). Plusieurs
/// marchés d'une même famille comptent pour une seule confirmation.
fn confirming_families(markets: &HashMap<MarketKey, Match>) -> Vec<String> {
    let mut resultat = false;
    let mut buts = false;
    for (key, m) in markets {
        if conviction(m) < MIN_CONVICTION {
            continue;
        }
        if family_of(*key) == "Résultat" {
            resultat = true;
        } else {
            buts = true;
        }
    }
    let mut out = Vec::new();
    if resultat {
        out.push("Résultat".to_string());
    }
    if buts {
        out.push("Buts".to_string());
    }
    out
}

/// Type de signal courant, dérivé de la contradiction, de l'argent frais puis
/// de la classification historique.
fn determine_kind(
    divergence: bool,
    category: SignalCategory,
    fresh: &FreshMoney,
) -> SignalKind {
    if divergence || category == SignalCategory::DivergenceWarning {
        return SignalKind::Divergence;
    }
    if fresh.reversal {
        return SignalKind::Reversal;
    }
    if fresh.late {
        return SignalKind::Late;
    }
    if fresh.steam {
        return SignalKind::Steam;
    }
    match category {
        SignalCategory::ConvergenceOver => SignalKind::Over,
        SignalCategory::ConvergenceUnder => SignalKind::Under,
        SignalCategory::ConvergenceFavorite => SignalKind::Favorite,
        _ => SignalKind::Neutral,
    }
}

/// Confiance calculée : qualité, liquidité, familles, argent frais, historique.
/// Aucune valeur constante : elle baisse si un ingrédient manque.
fn confidence_of(
    quality: &Quality,
    tier: LiquidityTier,
    families: usize,
    fresh: &FreshMoney,
    history: Option<&SignalStats>,
) -> Confidence {
    let liquidity = match tier {
        LiquidityTier::Low => th::CONF_LIQUIDITY_POINTS[0],
        LiquidityTier::Medium => th::CONF_LIQUIDITY_POINTS[1],
        LiquidityTier::High => th::CONF_LIQUIDITY_POINTS[2],
        LiquidityTier::Whale => th::CONF_LIQUIDITY_POINTS[3],
    };
    let family_points = th::CONF_FAMILY_POINTS[families.min(2)];
    let fresh_points = if fresh.ok && fresh.f1.unwrap_or(0.0) >= th::FRESH_SIDE_MIN_SHARE {
        th::CONF_FRESH_POINTS
    } else {
        0.0
    };
    let history_points = match history {
        Some(stats) if stats.n > 0 && stats.clv_pct > 0.0 => th::CONF_HISTORY_POINTS,
        _ => 0.0,
    };
    let score = if quality.ok {
        th::CONF_QUALITY_POINTS
    } else {
        0.0
    } + liquidity
        + family_points
        + fresh_points
        + history_points;

    let confidence = Confidence::from_score(score);
    // Un signal fort exige deux familles de confirmation différentes.
    if families < 2 && confidence == Confidence::Eleve {
        return Confidence::Moyen;
    }
    confidence
}

/// Contradiction par grille de scores : deux issues financées dont les
/// ensembles de scores ne se croisent jamais.
///
/// Une issue est « financée » au sens du moteur : conviction >= MIN_CONVICTION,
/// marché exploitable (le filtre qualité est appliqué en amont). La mi-temps et
/// le MT/FM sont hors grille et ne participent pas au test.
fn grid_divergence(
    markets: &HashMap<MarketKey, Match>,
    fresh: &HashMap<MarketKey, FreshMoney>,
) -> Option<(String, f64)> {
    let mut issues: Vec<(MarketKey, grid::ScoreSet, f64, String)> = Vec::new();
    for (key, m) in markets {
        if conviction(m) < MIN_CONVICTION {
            continue;
        }
        let label = if *key == MarketKey::CorrectScore {
            m.dominant_label.as_str()
        } else {
            ""
        };
        if let Some(set) = grid::issue_set(*key, m.dominant_index, label) {
            issues.push((
                *key,
                set,
                m.dominant_share,
                m.dominant_label.clone(),
            ));
        }
    }
    issues.sort_by(|a, b| a.0.slug().cmp(b.0.slug()));

    let mut best: Option<(String, f64)> = None;
    for i in 0..issues.len() {
        for j in (i + 1)..issues.len() {
            let (key_a, set_a, share_a, label_a) = &issues[i];
            let (key_b, set_b, share_b, label_b) = &issues[j];
            if key_a == key_b || !grid::contradict(set_a, set_b) {
                continue;
            }
            let strength = share_a + share_b;
            if best.as_ref().map(|(_, s)| strength <= *s).unwrap_or(false) {
                continue;
            }
            let fresh_note = |key: &MarketKey| {
                fresh
                    .get(key)
                    .filter(|f| f.ok)
                    .map(|f| format!(", argent frais {:.0} % sur 1 h", f.f1.unwrap_or(0.0)))
                    .unwrap_or_default()
            };
            let text = format!(
                "{} financé à {:.0} % ({}{}) contre {} financé à {:.0} % ({}{}) : aucun score ne satisfait les deux",
                key_a.def().short,
                share_a,
                label_a,
                fresh_note(key_a),
                key_b.def().short,
                share_b,
                label_b,
                fresh_note(key_b)
            );
            best = Some((text, strength));
        }
    }
    best
}

fn neutral(
    bullets: &str,
    market_count: usize,
    total_volume: f64,
    signal_markets: &[SignalMarket],
    one_x_two: Option<&crate::model::Match>,
    _reference: &crate::model::Match,
) -> (
    SignalCategory,
    String,
    String,
    Recommendation,
    Recommendation,
    f64,
    Option<String>,
) {
    let _ = one_x_two;
    let best = signal_markets.first().map(|m| m.conviction).unwrap_or(0.0);
    (
        SignalCategory::NeutralOpportunity,
        "Recoupement sans anomalie".to_string(),
        format!(
            "{} marché(s) recoupé(s) pour {:.0} k£. Aucune contradiction ni convergence forte : \
             {}.",
            market_count,
            total_volume / 1000.0,
            bullets
        ),
        reco(Play::NoBet, "Aucun pari recommandé", None),
        reco(Play::NoBet, "Surveiller l'évolution des cotes", None),
        (40.0 + best * 0.5).clamp(20.0, 65.0),
        None,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enrich::enrich;
    use crate::market::MarketKey;
    use crate::model::{MarketSnapshot, Source};
    use crate::proposals::MarketGroup;
    use serde_json::json;

    fn snap(key: MarketKey, rows: Vec<serde_json::Value>) -> MarketSnapshot {
        let matches = enrich(&rows, key, Source::Live, 0);
        MarketSnapshot {
            market: Some(key),
            key: key.slug().to_string(),
            label: key.def().label.to_string(),
            short: key.def().short.to_string(),
            total_volume: matches.iter().map(|m| m.total_volume).sum(),
            matches,
            source: Source::Live,
            updated_at: "2026-11-09T20:00:00Z".to_string(),
            error: None,
        }
    }

    // Coup d'envoi à 22:00 : les tests calculent leurs signaux avant, sinon le
    // garde-fou « rencontre commencée » retirerait les recommandations.
    fn base(home: &str, away: &str) -> serde_json::Value {
        json!({"home": home, "away": away, "league": "Test", "country": "eng",
               "date": "2026-11-09T22:00:00Z", "market_id": 1, "selection_id": 2})
    }

    fn with(mut base: serde_json::Value, kv: serde_json::Value) -> serde_json::Value {
        if let (Some(obj), Some(extra)) = (base.as_object_mut(), kv.as_object()) {
            for (k, v) in extra {
                obj.insert(k.clone(), v.clone());
            }
        }
        base
    }

    #[test]
    fn over_convergence_requires_corroboration() {
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(signals.len(), 1);
        assert_eq!(signals[0].category, SignalCategory::ConvergenceOver);
        assert_eq!(
            signals[0].value.play,
            Play::TotalGoals {
                line: 2.5,
                over: true
            }
        );
    }

    #[test]
    fn a_coin_flip_is_not_a_signal() {
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                   "volume_1": 5200, "volume_2": 4800}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                   "volume_1": 5100, "volume_2": 4900}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(signals[0].category, SignalCategory::NeutralOpportunity);
        assert_eq!(signals[0].value.play, Play::NoBet);
    }

    #[test]
    fn fixtures_need_two_markets() {
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let signals = compute(
            &[snap(MarketKey::OverUnder25, vec![ou])],
            "2026-11-09T20:00:00Z",
        );
        assert!(signals.is_empty());
    }

    #[test]
    fn divergence_suppresses_any_recommendation() {
        let one = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 3.2, "coef_x": 3.4, "coef_2": 2.1,
                   "coef_1_new": 3.8, "coef_x_new": 3.7, "coef_2_new": 2.05,
                   "volume_1": 2000, "volume_x": 2000, "volume_2": 12000}),
        );
        let dc = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.4, "coef_x": 1.5, "coef_2": 1.9,
                   "coef_1_new": 1.35, "coef_x_new": 1.55, "coef_2_new": 1.95,
                   "volume_1": 14000, "volume_x": 3000, "volume_2": 3000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::DoubleChance, vec![dc]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(signals[0].category, SignalCategory::DivergenceWarning);
        assert_eq!(signals[0].value.play, Play::NoBet);
    }

    #[test]
    fn ids_are_stable_across_volume_changes() {
        let mk = |v2: u64| {
            with(
                base("Arsenal", "Chelsea"),
                json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                       "volume_1": 3000, "volume_2": v2}),
            )
        };
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let a = compute(
            &[
                snap(MarketKey::OverUnder25, vec![mk(9000)]),
                snap(MarketKey::Btts, vec![btts.clone()]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let b = compute(
            &[
                snap(MarketKey::OverUnder25, vec![mk(9500)]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T21:00:00Z",
        );
        assert_eq!(a[0].id, b[0].id);
    }

    #[test]
    fn id_is_stable_when_category_changes() {
        let neutral_rows = || {
            (
                with(
                    base("Arsenal", "Chelsea"),
                    json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                           "volume_1": 5200, "volume_2": 4800}),
                ),
                with(
                    base("Arsenal", "Chelsea"),
                    json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                           "volume_1": 5100, "volume_2": 4900}),
                ),
            )
        };
        let (ou, btts) = neutral_rows();
        let neutral = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let over = compute(
            &[
                snap(
                    MarketKey::OverUnder25,
                    vec![with(
                        base("Arsenal", "Chelsea"),
                        json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                               "volume_1": 3000, "volume_2": 9000}),
                    )],
                ),
                snap(
                    MarketKey::Btts,
                    vec![with(
                        base("Arsenal", "Chelsea"),
                        json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                               "volume_1": 8000, "volume_2": 2000}),
                    )],
                ),
            ],
            "2026-11-09T21:00:00Z",
        );
        assert_ne!(neutral[0].category, over[0].category);
        assert_eq!(neutral[0].id, over[0].id);
        assert_eq!(neutral[0].id, "sig_arsenal_vs_chelsea");
    }

    #[test]
    fn a_started_fixture_has_no_recommendation() {
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        // Une heure après le coup d'envoi : les cotes d'avant-match sont mortes.
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T23:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.category, SignalCategory::NeutralOpportunity);
        assert_eq!(s.value.play, Play::NoBet);
        assert_eq!(s.safety.play, Play::NoBet);
        assert!(s.analysis_summary.contains("commencée"), "{}", s.analysis_summary);
        assert!(s.convergence_score <= 40.0);
    }

    #[test]
    fn a_market_without_a_price_is_never_recommended() {
        // 75 % du volume sur « plus de 2.5 » mais aucune cote renseignée pour
        // cette issue : le moteur ne doit pas proposer un pari sans prix.
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 5.0, "coef_1_new": 5.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.value.play, Play::NoBet);
        assert_eq!(s.category, SignalCategory::NeutralOpportunity);
        assert!(s.analysis_summary.contains("cote"), "{}", s.analysis_summary);
        assert!(s.odds.value.is_none());
        assert!(s.odds.ev_pct.is_none());
    }

    #[test]
    fn a_safety_bet_is_dropped_when_its_market_is_missing() {
        // Convergence « plus de 2.5 » confirmée par BTTS, mais pas de marché
        // +/-1.5 : la couverture suggérée n'existe pas et ne doit pas rester.
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.category, SignalCategory::ConvergenceOver);
        assert_eq!(s.value.play, Play::TotalGoals { line: 2.5, over: true });
        // Une seule proposition par groupe : plus de pari « sécurité ».
        assert_eq!(s.safety.play, Play::NoBet);
        assert_eq!(s.safety.label, "S'abstenir");
        assert!(s.odds.safety.is_none());
        assert!(s.proposals.iter().all(|p| p.group != MarketGroup::Score));
    }

    #[test]
    fn families_count_once_and_a_strong_signal_needs_two() {
        let one = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_x": 3.6, "coef_2": 4.2,
                   "coef_1_new": 1.8, "coef_x_new": 3.7, "coef_2_new": 4.4,
                   "volume_1": 8000, "volume_x": 1200, "volume_2": 1500}),
        );
        let dnb = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.4, "coef_2": 3.0, "coef_1_new": 1.38, "coef_2_new": 3.1,
                   "volume_1": 6000, "volume_2": 1200}),
        );
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let two = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::DrawNoBet, vec![dnb]),
                snap(MarketKey::OverUnder25, vec![ou]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(
            two[0].families,
            vec!["Résultat".to_string(), "Buts".to_string()]
        );

        // Deux marchés de buts ne comptent que pour une seule famille.
        let ou_only = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 2.0, "coef_1_new": 1.9, "coef_2_new": 2.0,
                   "volume_1": 3000, "volume_2": 9000}),
        );
        let ou15 = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 2.4, "coef_2": 1.55, "coef_1_new": 2.38, "coef_2_new": 1.57,
                   "volume_1": 3900, "volume_2": 5100}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let one_family = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou_only]),
                snap(MarketKey::OverUnder15, vec![ou15]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(one_family[0].families, vec!["Buts".to_string()]);
        assert_ne!(
            one_family[0].confidence,
            crate::model::Confidence::Eleve,
            "une seule famille ne peut pas produire une confiance élevée"
        );
    }

    #[test]
    fn reference_market_is_chosen_deterministically() {
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.7, "coef_2": 2.2, "coef_1_new": 1.6, "coef_2_new": 2.3,
                   "volume_1": 8000, "volume_2": 2000}),
        );
        let ht = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 3.1, "coef_x": 2.1, "coef_2": 4.0,
                   "coef_1_new": 3.0, "coef_x_new": 2.0, "coef_2_new": 4.1,
                   "volume_1": 3000, "volume_x": 5000, "volume_2": 2000}),
        );
        // Ni 1X2 ni +/-2.5 : la référence doit rester BTTS quel que soit
        // l'ordre des marchés fournis.
        let a = compute(
            &[
                snap(MarketKey::Btts, vec![btts.clone()]),
                snap(MarketKey::HalfTime, vec![ht.clone()]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let b = compute(
            &[
                snap(MarketKey::HalfTime, vec![ht]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        assert_eq!(a[0].odds.favorite.as_ref().unwrap().market, "btts");
        assert_eq!(a[0].id, b[0].id);
        assert_eq!(a[0].scenario_title, b[0].scenario_title);
        assert_eq!(
            a[0].markets.iter().map(|m| m.market.slug()).collect::<Vec<_>>(),
            b[0].markets.iter().map(|m| m.market.slug()).collect::<Vec<_>>()
        );
    }

    #[test]
    fn signal_carries_price_edge_and_expectation() {
        let one = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_x": 3.6, "coef_2": 4.2,
                   "coef_1_new": 1.8, "coef_x_new": 3.7, "coef_2_new": 4.4,
                   "volume_1": 8000, "volume_x": 1200, "volume_2": 1500}),
        );
        let dnb = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.4, "coef_2": 3.0, "coef_1_new": 1.38, "coef_2_new": 3.1,
                   "volume_1": 6000, "volume_2": 1200}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::DrawNoBet, vec![dnb]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.category, SignalCategory::ConvergenceFavorite);
        let favorite = s.odds.favorite.as_ref().expect("cote du favori");
        assert!(favorite.odds.unwrap() > 1.0);
        assert!(favorite.edge_pp > 0.0, "flux supérieur à l'implicite");
        assert!(s.odds.value.is_some(), "le pari value doit être coté");
        assert!(s.odds.ev_pct.is_some());
        assert!(s.odds.coherence.unwrap() <= 100.0);
        let margin = s.odds.overround_pct.expect("marge du 1X2");
        assert!((3.5..6.0).contains(&margin), "marge inattendue : {margin}");
    }

    #[test]
    fn a_short_price_no_longer_blocks_the_signal() {
        // Chantier 3 : une cote courte ne sert plus de garde-fou. Le flux reste
        // un signal ; l'ancien edge (part − implicite) est déprécié et ne
        // décide plus de rien.
        let ou = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 6.0, "coef_2": 1.24, "coef_1_new": 6.0, "coef_2_new": 1.20,
                   "volume_1": 3500, "volume_2": 6500}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.5, "coef_2": 2.6, "coef_1_new": 1.45, "coef_2_new": 2.7,
                   "volume_1": 8000, "volume_2": 1500}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder25, vec![ou]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.category, SignalCategory::ConvergenceOver);
        assert_eq!(s.kind, crate::model::SignalKind::Over);
        assert_eq!(s.value.play, Play::TotalGoals { line: 2.5, over: true });
        // Le champ déprécié reste présent pour la rétrocompatibilité…
        assert!(s.odds.ev_pct.is_some());
        // …mais l'edge négatif n'invalide plus la proposition.
        assert!(s.proposals.iter().any(|p| p.pick == "Plus de 2.5"));
    }

    #[test]
    fn a_whale_concentration_without_fresh_money_is_only_information() {
        let one = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.75, "coef_x": 4.0, "coef_2": 5.5,
                   "coef_1_new": 1.70, "coef_x_new": 4.0, "coef_2_new": 5.5,
                   "volume_1": 9000, "volume_x": 1500, "volume_2": 1500}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.8, "coef_2": 2.0, "coef_1_new": 1.8, "coef_2_new": 2.0,
                   "volume_1": 6000, "volume_2": 4000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let whale = signals[0]
            .markets
            .iter()
            .find(|m| m.market == MarketKey::OneXTwo)
            .expect("marché 1X2");
        assert!(
            whale.signal_label.contains("information"),
            "sans argent frais, une concentration est une information : {}",
            whale.signal_label
        );
    }

    #[test]
    fn incoherent_goal_prices_are_detected() {
        // « +2.5 » plus probable que « +1.5 » : imbrication impossible.
        let ou15 = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 2.4, "coef_2": 1.6, "coef_1_new": 1.55, "coef_2_new": 2.5,
                   "volume_1": 4000, "volume_2": 4000}),
        );
        let ou25 = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 2.1, "coef_2": 1.8, "coef_1_new": 2.2, "coef_2_new": 1.70,
                   "volume_1": 4000, "volume_2": 4000}),
        );
        let btts = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.9, "coef_2": 1.95, "coef_1_new": 1.9, "coef_2_new": 1.95,
                   "volume_1": 4000, "volume_2": 4000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OverUnder15, vec![ou15]),
                snap(MarketKey::OverUnder25, vec![ou25]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert!(!s.odds.gaps.is_empty(), "aucun écart détecté");
        assert!(s.odds.coherence.unwrap() < 100.0);
    }

    #[test]
    fn double_chance_prices_rebuild_one_x_two_probabilities() {
        let one = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 2.2, "coef_x": 3.4, "coef_2": 3.2,
                   "coef_1_new": 2.2, "coef_x_new": 3.4, "coef_2_new": 3.2,
                   "volume_1": 5000, "volume_x": 3000, "volume_2": 4000}),
        );
        // 1X = 1.55, X2 = 2.1, 12 = 1.6 → domicile implicite ≈ 38 %, extérieur ≈ 33 %.
        let dc = with(
            base("Arsenal", "Chelsea"),
            json!({"coef_1": 1.55, "coef_x": 2.1, "coef_2": 1.6,
                   "coef_1_new": 1.55, "coef_x_new": 2.1, "coef_2_new": 1.6,
                   "volume_1": 5000, "volume_x": 3000, "volume_2": 4000}),
        );
        let markets = HashMap::from([
            (MarketKey::OneXTwo, enrich(&[one], MarketKey::OneXTwo, Source::Live, 0).remove(0)),
            (
                MarketKey::DoubleChance,
                enrich(&[dc], MarketKey::DoubleChance, Source::Live, 0).remove(0),
            ),
        ]);
        let rebuilt = dc_probabilities(&markets[&MarketKey::DoubleChance]).expect("cotes DC");
        assert!(rebuilt[0] > rebuilt[1] && rebuilt[0] > rebuilt[2]);
        assert!((rebuilt.iter().sum::<f64>() - 100.0).abs() < 0.01);
        let (gaps, coherence) = price_gaps(&markets);
        assert!(coherence.unwrap() <= 100.0);
        // Les deux marchés décrivent le même match : l'écart doit rester modéré.
        assert!(gaps.iter().all(|g| g.gap_pp.abs() < 25.0));
    }

    fn one_x_two(home: &str, away: &str, coefs: [f64; 3], volumes: [f64; 3]) -> serde_json::Value {
        with(
            base(home, away),
            json!({
                "coef_1": coefs[0], "coef_x": coefs[1], "coef_2": coefs[2],
                "coef_1_new": coefs[0], "coef_x_new": coefs[1], "coef_2_new": coefs[2],
                "volume_1": volumes[0], "volume_x": volumes[1], "volume_2": volumes[2]
            }),
        )
    }

    fn btts_row(home: &str, away: &str, volume: f64) -> serde_json::Value {
        with(
            base(home, away),
            json!({"coef_1": 1.95, "coef_2": 1.95, "coef_1_new": 1.95, "coef_2_new": 1.95,
                   "volume_1": volume, "volume_2": volume}),
        )
    }

    #[test]
    fn an_even_match_is_an_observation_not_a_bet() {
        // 2.45 / 3.30 / 2.75 → implicites normalisées 38.0 / 28.2 / 33.8 :
        // 4.1 pts d'écart entre les deux équipes, donc aucun favori.
        let one = one_x_two("Lens", "Nantes", [2.45, 3.30, 2.75], [1500.0, 1500.0, 1000.0]);
        let btts = btts_row("Lens", "Nantes", 2000.0);
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_eq!(s.kind, SignalKind::Even);
        assert!(s.analysis_summary.contains("Match sans favori"));
        assert_eq!(s.value.play, Play::NoBet, "un match équilibré ne se joue pas");
        assert!(s.proposals.is_empty(), "aucune proposition sur une observation");
        assert_ne!(s.confidence, Confidence::Eleve);
        assert!(!SignalKind::Even.flagged(), "rien à noter sans pari");
    }

    #[test]
    fn a_clear_favourite_is_not_an_even_match() {
        let one = one_x_two("Bayern", "Bochum", [1.40, 4.50, 7.00], [6000.0, 1000.0, 1000.0]);
        let btts = btts_row("Bayern", "Bochum", 500.0);
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, vec![one]),
                snap(MarketKey::Btts, vec![btts]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let s = &signals[0];
        assert_ne!(s.kind, SignalKind::Even);
        assert!(!s.analysis_summary.contains("Match sans favori"));
    }

    #[test]
    fn a_heavy_fixture_is_measured_against_its_day() {
        let mut one_rows = Vec::new();
        let mut btts_rows = Vec::new();
        for i in 0..8 {
            let home = format!("Petit{i}");
            let away = format!("Club{i}");
            one_rows.push(one_x_two(&home, &away, [2.0, 3.4, 3.6], [700.0, 400.0, 400.0]));
            btts_rows.push(btts_row(&home, &away, 300.0));
        }
        // La rencontre lourde : 16 k£ contre 2.1 k£ pour les autres, dont
        // 81 % sur la famille Résultat — un volume réparti, pas une direction.
        one_rows.push(one_x_two("Gros", "Match", [2.0, 3.4, 3.6], [4000.0, 3000.0, 3000.0]));
        btts_rows.push(btts_row("Gros", "Match", 1500.0));
        let dnb = with(
            base("Gros", "Match"),
            json!({"coef_1": 1.6, "coef_2": 2.6, "coef_1_new": 1.6, "coef_2_new": 2.6,
                   "volume_1": 2000, "volume_2": 1000}),
        );
        let signals = compute(
            &[
                snap(MarketKey::OneXTwo, one_rows),
                snap(MarketKey::Btts, btts_rows),
                snap(MarketKey::DrawNoBet, vec![dnb]),
            ],
            "2026-11-09T20:00:00Z",
        );
        let heavy = signals
            .iter()
            .find(|s| s.home == "Gros")
            .expect("la rencontre lourde doit produire un signal");
        let w = heavy.weight.as_ref().expect("poids calculé");
        assert!(
            (w.reference - 2100.0).abs() < 1.0,
            "médiane de la journée attendue à 2 100 £, obtenue {}",
            w.reference
        );
        assert!(w.multiple > 7.0, "multiple {}", w.multiple);
        assert!(w.outlier, "seuils franchis");
        assert_eq!(w.family, "Résultat");
        assert!((w.family_share - 81.2).abs() < 0.5);
        assert_eq!(w.markets, 3);
        assert_eq!(heavy.kind, SignalKind::Weight);
        assert_eq!(heavy.value.play, Play::NoBet);
        assert!(heavy.proposals.is_empty());
        assert!(!SignalKind::Weight.flagged(), "un poids ne se note pas");
    }

    #[test]
    fn weight_needs_a_reference_to_compare_against() {
        assert_eq!(median(vec![]), None);
        assert_eq!(median(vec![3.0, 1.0, 2.0]), Some(2.0));
        assert_eq!(median(vec![4.0, 1.0, 3.0, 2.0]), Some(2.5));
        assert_eq!(day_of("2026-11-09 22:00:00"), "2026-11-09");
        // Une seule rencontre : aucune médiane de journée, donc aucun poids.
        let one = enrich(
            &[one_x_two("Seul", "Match", [2.0, 3.4, 3.6], [500.0, 500.0, 500.0])],
            MarketKey::OneXTwo,
            Source::Live,
            0,
        )
        .remove(0);
        let fixtures = HashMap::from([(
            "seul".to_string(),
            HashMap::from([(MarketKey::OneXTwo, one)]),
        )]);
        assert!(market_weights(&fixtures).is_empty());
    }

    #[test]
    fn observation_kinds_are_never_tracked() {
        for kind in [SignalKind::Weight, SignalKind::Even] {
            assert!(!kind.tradable());
            assert!(!kind.flagged());
            assert_eq!(SignalKind::from_key(kind.key()), Some(kind));
        }
        assert_eq!(SignalKind::Even.key(), "even");
        assert_eq!(SignalKind::Even.label(), "Match sans favori");
    }
}
