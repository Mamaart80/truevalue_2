//! Analyse assistée : une synthèse heuristique déterministe, éventuellement
//! enrichie par Gemini quand une clé est fournie.
//!
//! La version d'origine appelait un modèle inexistant (`gemini-3.8-flash`) et
//! retombait silencieusement sur l'heuristique : ici le modèle est configurable
//! et la source de la réponse est toujours renvoyée au client.

use std::time::Duration;

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::model::{Match, Signal};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchAnalysis {
    pub headline: String,
    pub market_dynamic: String,
    pub sharp_vs_public: String,
    pub implied_vs_real: String,
    pub verdict: String,
    pub risk_level: String,
    pub key_advice: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SignalAnalysis {
    pub headline: String,
    pub synthesis: String,
    pub recommended_play: String,
    pub safety_net: String,
    pub sharp_vs_public: String,
    pub conclusion: String,
}

pub struct Analyzer {
    key: Option<String>,
    model: String,
}

impl Analyzer {
    pub fn new(key: Option<String>) -> Self {
        Self {
            key,
            model: std::env::var("GEMINI_MODEL").unwrap_or_else(|_| "gemini-2.5-flash".to_string()),
        }
    }

    pub fn analyze_match(&self, m: &Match) -> (MatchAnalysis, &'static str) {
        let heuristic = heuristic_match(m);
        match self.gemini(&match_prompt(m)) {
            Some(value) => match serde_json::from_value::<MatchAnalysis>(value) {
                Ok(parsed) => (parsed, "gemini"),
                Err(_) => (heuristic, "heuristique"),
            },
            None => (heuristic, "heuristique"),
        }
    }

    pub fn analyze_signal(&self, s: &Signal) -> (SignalAnalysis, &'static str) {
        let heuristic = heuristic_signal(s);
        match self.gemini(&signal_prompt(s)) {
            Some(value) => match serde_json::from_value::<SignalAnalysis>(value) {
                Ok(parsed) => (parsed, "gemini"),
                Err(_) => (heuristic, "heuristique"),
            },
            None => (heuristic, "heuristique"),
        }
    }

    fn gemini(&self, prompt: &str) -> Option<Value> {
        let key = self.key.as_ref()?;
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            self.model, key
        );
        let body = json!({
            "contents": [{ "parts": [{ "text": prompt }] }],
            "generationConfig": { "responseMimeType": "application/json", "temperature": 0.4 }
        });
        let response = ureq::post(&url)
            .timeout(Duration::from_secs(20))
            .send_json(body)
            .ok()?;
        let payload: Value = response.into_json().ok()?;
        let text = payload
            .get("candidates")?
            .get(0)?
            .get("content")?
            .get("parts")?
            .get(0)?
            .get("text")?
            .as_str()?;
        let cleaned = text
            .trim()
            .trim_start_matches("```json")
            .trim_start_matches("```")
            .trim_end_matches("```")
            .trim();
        serde_json::from_str(cleaned).ok()
    }
}

fn heuristic_match(m: &Match) -> MatchAnalysis {
    let dominant = &m.dominant_label;
    let share = m.dominant_share;
    let odds = m.coef_new[m.dominant.index()];
    let edge = m.edge[m.dominant.index()];
    let verdict = if m.smart_money_score >= 70.0 {
        "Signal fort : flux institutionnel probable"
    } else if m.smart_money_score >= 50.0 {
        "Signal modéré : à confirmer par un autre marché"
    } else {
        "Flux standard : pas d'edge identifiable"
    };
    MatchAnalysis {
        headline: format!(
            "{dominant} capte {share:.0} % du volume ({})",
            m.market.def().short
        ),
        market_dynamic: format!(
            "{:.0} k£ échangés sur {}, dont {share:.0} % sur {dominant}. Cote actuelle {odds:.2}.",
            m.total_volume / 1000.0,
            m.market.def().label
        ),
        sharp_vs_public: if edge >= 8.0 {
            format!(
                "Le volume dépasse la probabilité implicite de {edge:+.1} points : l'argent arrive plus vite que la cote ne bouge."
            )
        } else if edge <= -8.0 {
            format!(
                "Le volume est {edge:+.1} points sous la probabilité implicite : le marché price déjà le scénario."
            )
        } else {
            "Volume et cote restent cohérents : pas de divergence exploitable.".to_string()
        },
        implied_vs_real: format!(
            "Probabilité implicite {:.1} % contre {share:.1} % du volume réel.",
            m.implied[m.dominant.index()]
        ),
        verdict: verdict.to_string(),
        risk_level: match m.liquidity_tier {
            crate::model::LiquidityTier::Whale => "Faible (marché très liquide)",
            crate::model::LiquidityTier::High => "Modéré",
            crate::model::LiquidityTier::Medium => "Modéré à élevé",
            crate::model::LiquidityTier::Low => "Élevé (marché peu liquide)",
        }
        .to_string(),
        key_advice: if m.drop[m.dominant.index()] <= -8.0 {
            "La cote se resserre : vérifier qu'elle tient jusqu'au coup d'envoi avant de suivre."
                .to_string()
        } else {
            "Attendre une confirmation sur un marché dérivé (DNB, double chance) avant d'agir."
                .to_string()
        },
    }
}

fn heuristic_signal(s: &Signal) -> SignalAnalysis {
    let markets = s
        .markets
        .iter()
        .map(|m| format!("{} {}", m.market_label, m.dominant_share.round()))
        .collect::<Vec<_>>()
        .join(" · ");
    let price_line = match s.odds.favorite.as_ref() {
        Some(f) => format!(
            "{} : cote {} · implicite {:.1} % · flux {:.1} % ({:+.1} pts)",
            f.label,
            f.odds
                .map(|o| format!("{o:.2}"))
                .unwrap_or_else(|| "n/d".into()),
            f.implied,
            f.share,
            f.edge_pp
        ),
        None => "aucune cote exploitable".to_string(),
    };
    let ev_line = s
        .odds
        .ev_pct
        .map(|ev| {
            format!(" Espérance indicative {ev:+.1} % (part de volume tenue pour probabilité).")
        })
        .unwrap_or_default();
    SignalAnalysis {
        headline: format!(
            "{} ({:.0} % de convergence)",
            s.scenario_title, s.convergence_score
        ),
        synthesis: s.analysis_summary.clone(),
        recommended_play: s.value.label.clone(),
        safety_net: s.safety.label.clone(),
        sharp_vs_public: format!("Marchés recoupés : {markets}. {price_line}."),
        conclusion: match s.category {
            crate::model::SignalCategory::DivergenceWarning => {
                "Contradiction réelle : ne pas exposer de capital.".to_string()
            }
            crate::model::SignalCategory::NeutralOpportunity => {
                "Pas de conviction suffisante : observer.".to_string()
            }
            _ => format!(
                "Scénario cohérent sur {} marchés ; suivre la cote {}.{ev_line}",
                s.markets.len(),
                s.value
                    .odds
                    .map(|o| format!("{o:.2}"))
                    .unwrap_or_else(|| "n/d".into())
            ),
        },
    }
}

fn match_prompt(m: &Match) -> String {
    format!(
        "Tu es analyste quantitatif Betfair. Analyse uniquement ces données, sans rien inventer.\n\
         Marché : {} ({})\nMatch : {} vs {} ({}, {})\n\
         Volume total : {:.0} £\n\
         Issues : {} — part {:.1} %, cote {:.2}, implicite {:.1} %, edge {:+.1} pts, variation cote {:+.1} %.\n\
         Réponds en JSON avec exactement : headline, market_dynamic, sharp_vs_public, implied_vs_real, verdict, risk_level, key_advice.",
        m.market.def().label,
        m.market.slug(),
        m.home,
        m.away,
        m.league,
        m.country,
        m.total_volume,
        m.dominant_label,
        m.dominant_share,
        m.coef_new[m.dominant.index()],
        m.implied[m.dominant.index()],
        m.edge[m.dominant.index()],
        m.drop[m.dominant.index()]
    )
}

fn signal_prompt(s: &Signal) -> String {
    let markets = s
        .markets
        .iter()
        .map(|m| {
            format!(
                "- {} : {} ({:.1} % du volume, {:.0} £, cote dominante {})",
                m.market_label,
                m.dominant_label,
                m.dominant_share,
                m.volume,
                m.odds.map(|o| format!("{o:.2}")).unwrap_or_else(|| "n/d".into())
            )
        })
        .collect::<Vec<_>>()
        .join("\n");
    let prices = match s.odds.favorite.as_ref() {
        Some(f) => format!(
            "Prix de l'issue dominante : cote {} (implicite {:.1} %, flux {:.1} %, edge {:+.1} pts), cohérence inter-marchés {}.\nÉcarts de prix : {}",
            f.odds.map(|o| format!("{o:.2}")).unwrap_or_else(|| "n/d".into()),
            f.implied,
            f.share,
            f.edge_pp,
            s.odds
                .coherence
                .map(|c| format!("{c:.0}/100"))
                .unwrap_or_else(|| "n/d".into()),
            if s.odds.gaps.is_empty() {
                "aucun".to_string()
            } else {
                s.odds
                    .gaps
                    .iter()
                    .map(|g| format!("{} ({:+.1} pts)", g.label, g.gap_pp))
                    .collect::<Vec<_>>()
                    .join(", ")
            }
        ),
        None => String::new(),
    };
    format!(
        "Tu es analyste quantitatif Betfair. Base-toi UNIQUEMENT sur les marchés listés.\n\
         Match : {} vs {} ({}, {})\nCatégorie : {}\nScore de convergence : {:.0}\n\
         Marchés réellement détectés :\n{}\n{}\n\
         Scénario calculé : {}\nSynthèse : {}\nPari value : {}\nPari sécurité : {}\n\
         Réponds en JSON avec exactement : headline, synthesis, recommended_play, safety_net, sharp_vs_public, conclusion.",
        s.home,
        s.away,
        s.league,
        s.country,
        s.category.label(),
        s.convergence_score,
        markets,
        prices,
        s.scenario_title,
        s.analysis_summary,
        s.value.label,
        s.safety.label
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::enrich::enrich;
    use crate::market::MarketKey;
    use crate::model::Source;
    use serde_json::json;

    #[test]
    fn heuristic_match_never_invents_markets() {
        let rows = vec![json!({
            "home": "A", "away": "B", "coef_1": 2.0, "coef_x": 3.4, "coef_2": 3.6,
            "coef_1_new": 1.8, "coef_x_new": 3.5, "coef_2_new": 3.9,
            "volume_1": 9000, "volume_x": 1000, "volume_2": 2000
        })];
        let m = &enrich(&rows, MarketKey::OneXTwo, Source::Live, 0)[0];
        let (analysis, source) = Analyzer::new(None).analyze_match(m);
        assert_eq!(source, "heuristique");
        assert!(analysis.headline.contains("67") || analysis.headline.contains("75"));
        assert!(!analysis.market_dynamic.contains("BTTS"));
    }
}
