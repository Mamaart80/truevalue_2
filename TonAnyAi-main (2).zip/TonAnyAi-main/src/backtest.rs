//! Backtest des seuils à partir du journal des rencontres (`match_log`).
//!
//! Le moteur ne parie pas encore : ce module mesure donc ce qui **se serait**
//! passé si l'on avait suivi chaque rencontre, y compris celles qui ne portaient
//! aucun signal. Trois questions de calibration, un tableau chacune :
//!
//! - par multiple de volume : une rencontre qui capte 3× la médiane de sa
//!   journée produit-elle plus de buts que les autres ?
//! - par écart de prix : un 1X2 « sans favori » est-il réellement un pile ou
//!   face, et le nul y est-il sous-payé ?
//! - par cote du favori : la probabilité implicite de nos marchés est-elle
//!   calibrée (réalisé contre implicite) ?
//!
//! Aucune donnée n'est inventée : une rencontre sans mesure n'entre dans aucun
//! tableau, une rencontre sans score final n'entre dans aucun taux, et un taux
//! sans cas vaut `null` — jamais `0`.

use serde::{Deserialize, Serialize};

use crate::daily::MatchLogRow;
use crate::model::FixtureMetrics;

/// Bornes des tranches de multiple de volume (rapport à la médiane du jour).
const MULTIPLE_EDGES: [f64; 3] = [1.5, 3.0, 5.0];
const MULTIPLE_LABELS: [&str; 4] = ["< 1,5×", "1,5–3×", "3–5×", "5× et +"];

/// Bornes des tranches d'écart entre les deux équipes (points d'implicite).
const GAP_EDGES: [f64; 3] = [2.0, 5.0, 10.0];
const GAP_LABELS: [&str; 4] = ["0–2 pts", "2–5 pts", "5–10 pts", "10 pts et +"];

/// Bornes des tranches de cote du favori (le plus court des trois 1X2).
const FAVORITE_EDGES: [f64; 3] = [1.5, 2.0, 3.0];
const FAVORITE_LABELS: [&str; 4] = ["< 1,50", "1,50–2,00", "2,00–3,00", "3,00 et +"];

/// Une tranche de poids de marché, comparée au réalisé.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct MultipleBucket {
    pub label: String,
    /// Rencontres de la tranche avec un score final.
    pub n: usize,
    /// Buts marqués en moyenne.
    pub avg_goals: Option<f64>,
    /// Part des rencontres à 3 buts ou plus (réalisé).
    pub over_25_pct: Option<f64>,
    /// Prix moyen du marché pour « plus de 2.5 buts » au moment de la mesure.
    pub over_25_implied_pct: Option<f64>,
    /// ROI d'une mise de 1 unité sur « plus de 2.5 » à la cote enregistrée.
    pub over_25_roi_pct: Option<f64>,
    /// Part des rencontres où les deux équipes marquent.
    pub btts_pct: Option<f64>,
}

/// Une tranche d'écart de prix entre les deux équipes.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct GapBucket {
    pub label: String,
    pub n: usize,
    pub home_pct: Option<f64>,
    pub draw_pct: Option<f64>,
    pub away_pct: Option<f64>,
    pub implied_home_pct: Option<f64>,
    pub implied_draw_pct: Option<f64>,
    pub implied_away_pct: Option<f64>,
    /// ROI d'une mise de 1 unité sur le nul à la cote enregistrée.
    pub draw_roi_pct: Option<f64>,
}

/// Une tranche de cote du favori : le marché est-il calibré ?
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct FavoriteBucket {
    pub label: String,
    pub n: usize,
    /// Part des fois où le favori du marché a gagné.
    pub hit_pct: Option<f64>,
    /// Probabilité implicite moyenne de ce favori.
    pub implied_pct: Option<f64>,
    pub roi_pct: Option<f64>,
    /// Nombre de cas réellement misés (cote disponible), sur lesquels le ROI
    /// est calculé.
    pub roi_cases: usize,
}

/// Résultat complet du backtest.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct BacktestReport {
    /// Profondeur demandée, en jours.
    pub days: usize,
    /// Rencontres journalisées sur la période.
    pub fixtures: usize,
    /// Rencontres dont le score final est connu.
    pub settled: usize,
    /// Rencontres portant des mesures de contexte (les plus anciennes n'en ont
    /// pas : la colonne n'existait pas encore).
    pub measured: usize,
    /// Rencontres exploitables : mesures **et** score final.
    pub compared: usize,
    pub by_multiple: Vec<MultipleBucket>,
    pub by_gap: Vec<GapBucket>,
    pub by_favorite_odds: Vec<FavoriteBucket>,
}

#[derive(Clone, Default)]
struct MultipleAcc {
    n: usize,
    goals: i64,
    over: usize,
    btts: usize,
    implied: f64,
    implied_n: usize,
    roi: f64,
    roi_n: usize,
}

#[derive(Clone, Default)]
struct GapAcc {
    n: usize,
    home: usize,
    draw: usize,
    away: usize,
    implied_home: f64,
    implied_draw: f64,
    implied_away: f64,
    implied_n: usize,
    draw_roi: f64,
    draw_roi_n: usize,
}

#[derive(Clone, Default)]
struct FavoriteAcc {
    n: usize,
    hit: usize,
    implied: f64,
    implied_n: usize,
    roi: f64,
    roi_n: usize,
}

fn bucket_index(value: f64, edges: &[f64]) -> usize {
    edges.iter().filter(|edge| value >= **edge).count()
}

fn round1(value: f64) -> f64 {
    (value * 10.0).round() / 10.0
}

fn ratio(part: usize, whole: usize) -> Option<f64> {
    (whole > 0).then(|| round1(part as f64 / whole as f64 * 100.0))
}

fn mean(sum: f64, count: usize) -> Option<f64> {
    (count > 0).then(|| round1(sum / count as f64))
}

fn average_return(sum: f64, count: usize) -> Option<f64> {
    (count > 0).then(|| round1(sum / count as f64 * 100.0))
}

/// Favori du marché : l'issue à la cote la plus courte, avec sa cote.
fn favorite(metrics: &FixtureMetrics) -> Option<(usize, f64)> {
    [
        (0usize, metrics.home_odds),
        (1, metrics.draw_odds),
        (2, metrics.away_odds),
    ]
    .into_iter()
    .filter_map(|(side, odds)| odds.map(|odds| (side, odds)))
    .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal))
}

/// Construit le backtest à partir des rencontres journalisées.
pub fn report(rows: &[MatchLogRow], days: usize) -> BacktestReport {
    let mut multiples = vec![MultipleAcc::default(); MULTIPLE_LABELS.len()];
    let mut gaps = vec![GapAcc::default(); GAP_LABELS.len()];
    let mut favorites = vec![FavoriteAcc::default(); FAVORITE_LABELS.len()];
    let mut settled = 0usize;
    let mut measured = 0usize;
    let mut compared = 0usize;

    for row in rows {
        let score = match (row.has_final_score(), row.home_score, row.away_score) {
            (true, Some(home), Some(away)) => Some((home, away)),
            _ => None,
        };
        if score.is_some() {
            settled += 1;
        }
        let Some(metrics) = row.metrics.as_ref() else {
            continue;
        };
        measured += 1;

        let Some((home, away)) = score else { continue };
        compared += 1;
        let goals = home + away;
        let over = goals >= 3;
        let btts = home > 0 && away > 0;

        // --- Poids de marché contre prolificité ------------------------------
        // Sans référence médiane, le multiple ne mesure rien : la rencontre
        // n'entre pas dans le tableau (elle n'est pas comptée comme « 0× »).
        if metrics.reference > 0.0 && metrics.multiple > 0.0 {
            let acc = &mut multiples[bucket_index(metrics.multiple, &MULTIPLE_EDGES)];
            acc.n += 1;
            acc.goals += goals;
            if over {
                acc.over += 1;
            }
            if btts {
                acc.btts += 1;
            }
            if let Some(implied) = metrics.over_25_implied {
                acc.implied += implied;
                acc.implied_n += 1;
            }
            if let Some(odds) = metrics.over_25_odds {
                acc.roi += if over { odds - 1.0 } else { -1.0 };
                acc.roi_n += 1;
            }
        }

        // --- Écart de prix entre les deux équipes ----------------------------
        if let Some(gap) = metrics.gap_pp {
            let acc = &mut gaps[bucket_index(gap, &GAP_EDGES)];
            acc.n += 1;
            if home > away {
                acc.home += 1;
            } else if home == away {
                acc.draw += 1;
            } else {
                acc.away += 1;
            }
            if let (Some(home_p), Some(draw_p), Some(away_p)) =
                (metrics.p_home, metrics.p_draw, metrics.p_away)
            {
                acc.implied_home += home_p;
                acc.implied_draw += draw_p;
                acc.implied_away += away_p;
                acc.implied_n += 1;
            }
            if let Some(odds) = metrics.draw_odds {
                acc.draw_roi += if home == away { odds - 1.0 } else { -1.0 };
                acc.draw_roi_n += 1;
            }
        }

        // --- Favori du marché -----------------------------------------------
        if let Some((side, odds)) = favorite(metrics) {
            let acc = &mut favorites[bucket_index(odds, &FAVORITE_EDGES)];
            acc.n += 1;
            let hit = match side {
                0 => home > away,
                1 => home == away,
                _ => away > home,
            };
            if hit {
                acc.hit += 1;
            }
            if let Some(implied) = [metrics.p_home, metrics.p_draw, metrics.p_away][side] {
                acc.implied += implied;
                acc.implied_n += 1;
            }
            acc.roi += if hit { odds - 1.0 } else { -1.0 };
            acc.roi_n += 1;
        }
    }

    let by_multiple = multiples
        .into_iter()
        .zip(MULTIPLE_LABELS)
        .map(|(acc, label)| MultipleBucket {
            label: label.to_string(),
            n: acc.n,
            avg_goals: (acc.n > 0).then(|| round1(acc.goals as f64 / acc.n as f64)),
            over_25_pct: ratio(acc.over, acc.n),
            over_25_implied_pct: mean(acc.implied, acc.implied_n),
            over_25_roi_pct: average_return(acc.roi, acc.roi_n),
            btts_pct: ratio(acc.btts, acc.n),
        })
        .collect();

    let by_gap = gaps
        .into_iter()
        .zip(GAP_LABELS)
        .map(|(acc, label)| GapBucket {
            label: label.to_string(),
            n: acc.n,
            home_pct: ratio(acc.home, acc.n),
            draw_pct: ratio(acc.draw, acc.n),
            away_pct: ratio(acc.away, acc.n),
            implied_home_pct: mean(acc.implied_home, acc.implied_n),
            implied_draw_pct: mean(acc.implied_draw, acc.implied_n),
            implied_away_pct: mean(acc.implied_away, acc.implied_n),
            draw_roi_pct: average_return(acc.draw_roi, acc.draw_roi_n),
        })
        .collect();

    let by_favorite_odds = favorites
        .into_iter()
        .zip(FAVORITE_LABELS)
        .map(|(acc, label)| FavoriteBucket {
            label: label.to_string(),
            n: acc.n,
            hit_pct: ratio(acc.hit, acc.n),
            implied_pct: mean(acc.implied, acc.implied_n),
            roi_pct: average_return(acc.roi, acc.roi_n),
            roi_cases: acc.roi_n,
        })
        .collect();

    BacktestReport {
        days,
        fixtures: rows.len(),
        settled,
        measured,
        compared,
        by_multiple,
        by_gap,
        by_favorite_odds,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{FixtureMetrics, MatchState};

    fn row(multiple: f64, gap: Option<f64>, score: Option<(i64, i64)>) -> MatchLogRow {
        let metrics = FixtureMetrics {
            volume: 10_000.0,
            reference: 2_500.0,
            multiple,
            family: "Buts".into(),
            family_share: 70.0,
            markets: 3,
            p_home: gap.map(|_| 38.0),
            p_draw: gap.map(|_| 28.0),
            p_away: gap.map(|_| 34.0),
            gap_pp: gap,
            overround_pct: Some(1.2),
            over_25_implied: Some(52.0),
            home_odds: Some(2.45),
            draw_odds: Some(3.30),
            away_odds: Some(2.75),
            over_25_odds: Some(1.90),
            under_25_odds: Some(1.95),
        };
        MatchLogRow {
            fixture_key: "a_vs_b".into(),
            match_date: "2026-11-12 19:45:00".into(),
            day: "2026-11-12".into(),
            home: "A".into(),
            away: "B".into(),
            league: "Test".into(),
            kind: "neutral".into(),
            flagged: false,
            state: if score.is_some() {
                MatchState::Finished
            } else {
                MatchState::Scheduled
            },
            status_detail: String::new(),
            home_score: score.map(|s| s.0),
            away_score: score.map(|s| s.1),
            source: if score.is_some() {
                "espn".into()
            } else {
                String::new()
            },
            metrics: Some(metrics),
            updated_at: "2026-11-12T20:00:00Z".into(),
        }
    }

    fn unmeasured() -> MatchLogRow {
        let mut row = row(1.0, None, Some((2, 2)));
        row.metrics = None;
        row
    }

    #[test]
    fn buckets_compare_realised_to_implied() {
        let rows = vec![
            row(0.8, Some(1.0), Some((0, 0))),
            row(3.2, Some(3.5), Some((2, 1))),
            row(6.0, None, Some((1, 1))),
            row(2.0, None, None),
            unmeasured(),
        ];
        let report = report(&rows, 14);
        assert_eq!(report.fixtures, 5);
        assert_eq!(report.settled, 4);
        assert_eq!(report.measured, 4);
        assert_eq!(report.compared, 3);

        // Tranche basse : une seule rencontre notée, 0-0.
        let low = &report.by_multiple[0];
        assert_eq!(low.label, "< 1,5×");
        assert_eq!(low.n, 1);
        assert_eq!(low.avg_goals, Some(0.0));
        assert_eq!(low.over_25_pct, Some(0.0));
        assert_eq!(low.over_25_implied_pct, Some(52.0));
        assert_eq!(low.over_25_roi_pct, Some(-100.0));

        // 1,5–3× : une rencontre sans score, donc hors taux.
        assert_eq!(report.by_multiple[1].n, 0);
        assert_eq!(report.by_multiple[1].over_25_pct, None);

        // 3–5× : 2-1, donc plus de 2.5 buts réalisé, gagné à 1.90.
        let heavy = &report.by_multiple[2];
        assert_eq!(heavy.n, 1);
        assert_eq!(heavy.over_25_pct, Some(100.0));
        assert_eq!(heavy.over_25_roi_pct, Some(90.0));
        assert_eq!(heavy.btts_pct, Some(100.0));

        // 5× et + : 1-1, deux buts.
        assert_eq!(report.by_multiple[3].n, 1);
        assert_eq!(report.by_multiple[3].avg_goals, Some(2.0));

        // Écart : le nul à 1 pt d'écart est payé 3.30.
        let tight = &report.by_gap[0];
        assert_eq!(tight.n, 1);
        assert_eq!(tight.draw_pct, Some(100.0));
        assert_eq!(tight.implied_draw_pct, Some(28.0));
        assert_eq!(tight.draw_roi_pct, Some(230.0));
        assert_eq!(report.by_gap[1].home_pct, Some(100.0));
        assert_eq!(report.by_gap[3].n, 0);

        // Favori à 2.45 : deux échecs, une réussite.
        let favorite = &report.by_favorite_odds[2];
        assert_eq!(favorite.n, 3);
        assert_eq!(favorite.hit_pct, Some(33.3));
        assert_eq!(favorite.implied_pct, Some(38.0));
        assert_eq!(favorite.roi_pct, Some(-18.3));
        assert_eq!(favorite.roi_cases, 3);
    }

    #[test]
    fn an_empty_period_reports_no_rate() {
        let report = report(&[], 7);
        assert_eq!(report.days, 7);
        assert_eq!(report.fixtures, 0);
        assert!(report.by_multiple.iter().all(|b| b.n == 0));
        assert!(report.by_multiple.iter().all(|b| b.over_25_pct.is_none()));
        assert!(report.by_gap.iter().all(|b| b.draw_roi_pct.is_none()));
    }
}
