//! Collecte des flux Arbworld : extraction du JSON embarqué, cache,
//! « stale-while-revalidate », requêtes conditionnelles et back-off.
//!
//! Politique de politesse, volontairement explicite :
//! - User-Agent identifiable (`truevalue/<version> (+contact)`) et configurable
//!   par `SCRAPER_CONTACT` : on ne se fait pas passer pour un navigateur ;
//! - une seule requête à la fois par marché (single-flight) et cache frais ;
//! - sur refus (403/429/503) ou panne réseau : back-off exponentiel qui respecte
//!   `Retry-After`, plafonné à une heure, pendant lequel **aucune** requête n'est
//!   émise (les données périmées connues sont servies en `Stale`) ;
//! - `If-None-Match` / `If-Modified-Since` quand le site fournit des validateurs
//!   (Arbworld renvoie aujourd'hui `no-store` : la branche 304 reste inutilisée
//!   mais correcte si cela change).
//!
//! Contrairement à la version TypeScript, la provenance est explicite (`Source`) :
//! une donnée périmée est servie avec son âge et jamais présentée comme live.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use serde_json::Value;

use crate::market::MarketKey;
use crate::model::Source;

/// User-Agent identifiable. `contact` vient de `SCRAPER_CONTACT` (URL ou email).
pub fn user_agent(contact: Option<&str>) -> String {
    let base = format!("truevalue/{}", env!("CARGO_PKG_VERSION"));
    match contact.map(str::trim).filter(|c| !c.is_empty()) {
        Some(contact) => format!("{base} (+{contact})"),
        None => format!("{base} (contact: SCRAPER_CONTACT non defini)"),
    }
}

/// Réponse HTTP normalisée (le transport est injectable pour les tests).
#[derive(Debug, Clone, Default)]
pub struct HttpReply {
    pub status: u16,
    pub body: String,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    /// `Retry-After` en secondes (les dates HTTP ne sont pas interprétées).
    pub retry_after: Option<u64>,
}

/// Transport HTTP : `(url, if_none_match, if_modified_since, user_agent)`.
pub type Transport =
    Arc<dyn Fn(&str, Option<&str>, Option<&str>, &str) -> Result<HttpReply, String> + Send + Sync>;

/// Politique de collecte d'un `Scraper`.
#[derive(Debug, Clone)]
pub struct ScraperPolicy {
    pub ttl: Duration,
    pub stale_ttl: Duration,
    pub user_agent: String,
    /// Première attente après un refus, doublée à chaque échec consécutif.
    pub backoff_base: Duration,
    /// Plafond du back-off.
    pub backoff_max: Duration,
}

impl Default for ScraperPolicy {
    fn default() -> Self {
        Self {
            ttl: Duration::from_secs(20),
            stale_ttl: Duration::from_secs(900),
            user_agent: user_agent(None),
            backoff_base: Duration::from_secs(60),
            backoff_max: Duration::from_secs(3600),
        }
    }
}

/// Résultat d'une collecte, avec sa provenance.
#[derive(Debug, Clone)]
pub struct Fetched {
    pub rows: Vec<Value>,
    pub source: Source,
    pub age_seconds: u64,
    pub data_updated_at: Option<String>,
    pub error: Option<String>,
}

#[derive(Debug, Clone)]
struct Entry {
    rows: Vec<Value>,
    fetched_at: Instant,
    data_updated_at: Option<String>,
    etag: Option<String>,
    last_modified: Option<String>,
}

/// État de back-off partagé par tous les marchés (un refus est global au site).
#[derive(Default)]
struct Backoff {
    failures: u32,
    until: Option<Instant>,
    reason: Option<String>,
}

/// Cache mémoire par marché + politique de politesse.
pub struct Scraper {
    policy: ScraperPolicy,
    entries: Mutex<HashMap<MarketKey, Entry>>,
    locks: Mutex<HashMap<MarketKey, Arc<Mutex<()>>>>,
    base_url: String,
    transport: Transport,
    backoff: Mutex<Backoff>,
}

impl Scraper {
    pub fn new(
        base_url: impl Into<String>,
        ttl: Duration,
        stale_ttl: Duration,
        user_agent: impl Into<String>,
    ) -> Self {
        Self::with_policy(
            base_url,
            ScraperPolicy {
                ttl,
                stale_ttl,
                user_agent: user_agent.into(),
                ..ScraperPolicy::default()
            },
        )
    }

    pub fn with_policy(base_url: impl Into<String>, policy: ScraperPolicy) -> Self {
        Self {
            policy,
            entries: Mutex::new(HashMap::new()),
            locks: Mutex::new(HashMap::new()),
            base_url: base_url.into(),
            transport: Arc::new(http_transport),
            backoff: Mutex::new(Backoff::default()),
        }
    }

    /// Remplace le transport (tests hors ligne).
    pub fn with_transport(mut self, transport: Transport) -> Self {
        self.transport = transport;
        self
    }

    pub fn url_for(&self, key: MarketKey) -> String {
        format!(
            "{}/football/{}",
            self.base_url.trim_end_matches('/'),
            key.slug()
        )
    }

    /// Secondes de suspension restantes (aucune requête émise pendant ce temps).
    /// Arrondi au supérieur : annoncer « 44 s » pour 44,9 s restantes induirait
    /// en erreur, et un reliquat nul doit signifier « plus de blocage ».
    pub fn backoff_remaining_secs(&self) -> Option<u64> {
        self.backoff.lock().unwrap().until.and_then(|until| {
            until
                .checked_duration_since(Instant::now())
                .map(|d| d.as_secs() + u64::from(d.subsec_nanos() > 0))
                .filter(|secs| *secs > 0)
        })
    }

    fn backoff_reason(&self) -> Option<String> {
        self.backoff.lock().unwrap().reason.clone()
    }

    /// Enregistre un refus et renvoie l'attente appliquée (secondes).
    fn register_failure(&self, retry_after: Option<u64>, reason: String) -> u64 {
        let mut backoff = self.backoff.lock().unwrap();
        backoff.failures = backoff.failures.saturating_add(1);
        let factor = 1u64 << backoff.failures.saturating_sub(1).min(6);
        let exponential = self.policy.backoff_base.as_secs().saturating_mul(factor);
        let wait = retry_after
            .unwrap_or(0)
            .max(exponential)
            .min(self.policy.backoff_max.as_secs());
        backoff.until = Some(Instant::now() + Duration::from_secs(wait));
        backoff.reason = Some(reason);
        wait
    }

    fn clear_backoff(&self) {
        let mut backoff = self.backoff.lock().unwrap();
        backoff.failures = 0;
        backoff.until = None;
        backoff.reason = None;
    }

    fn lock_for(&self, key: MarketKey) -> Arc<Mutex<()>> {
        let mut locks = self.locks.lock().unwrap();
        locks.entry(key).or_default().clone()
    }

    fn cached(&self, key: MarketKey) -> Option<(Vec<Value>, u64, Option<String>)> {
        let entries = self.entries.lock().unwrap();
        entries.get(&key).map(|e| {
            (
                e.rows.clone(),
                e.fetched_at.elapsed().as_secs(),
                e.data_updated_at.clone(),
            )
        })
    }

    fn validators(&self, key: MarketKey) -> (Option<String>, Option<String>) {
        let entries = self.entries.lock().unwrap();
        match entries.get(&key) {
            Some(entry) => (entry.etag.clone(), entry.last_modified.clone()),
            None => (None, None),
        }
    }

    fn store_entry(
        &self,
        key: MarketKey,
        rows: Vec<Value>,
        updated: Option<String>,
        etag: Option<String>,
        last_modified: Option<String>,
    ) {
        let mut entries = self.entries.lock().unwrap();
        entries.insert(
            key,
            Entry {
                rows,
                fetched_at: Instant::now(),
                data_updated_at: updated,
                etag,
                last_modified,
            },
        );
    }

    /// 304 : les données sont inchangées, on remet le cache à l'heure.
    fn touch(
        &self,
        key: MarketKey,
        etag: Option<String>,
        last_modified: Option<String>,
    ) -> Option<Entry> {
        let mut entries = self.entries.lock().unwrap();
        let entry = entries.get_mut(&key)?;
        entry.fetched_at = Instant::now();
        if etag.is_some() {
            entry.etag = etag;
        }
        if last_modified.is_some() {
            entry.last_modified = last_modified;
        }
        Some(entry.clone())
    }

    /// Récupère un marché. `force` ignore le cache frais mais **pas** le back-off.
    pub fn fetch(&self, key: MarketKey, force: bool) -> Fetched {
        if !force {
            if let Some(fetched) = self.fresh(key) {
                return fetched;
            }
        }

        // Une seule requête à la fois par marché (single-flight).
        let lock = self.lock_for(key);
        let _guard = lock.lock().unwrap();

        if !force {
            if let Some(fetched) = self.fresh(key) {
                return fetched;
            }
        }

        if let Some(wait) = self.backoff_remaining_secs() {
            let reason = self
                .backoff_reason()
                .map(|r| format!(" (dernier refus : {r})"))
                .unwrap_or_default();
            return self.degraded(key, format!("collecte suspendue {wait} s{reason}"));
        }

        let (etag, last_modified) = self.validators(key);
        let url = self.url_for(key);
        let reply = (self.transport)(
            &url,
            etag.as_deref(),
            last_modified.as_deref(),
            &self.policy.user_agent,
        );

        match reply {
            Ok(reply) if reply.status == 304 => {
                self.clear_backoff();
                match self.touch(key, reply.etag, reply.last_modified) {
                    Some(entry) => Fetched {
                        rows: entry.rows,
                        source: Source::Cache,
                        age_seconds: 0,
                        data_updated_at: entry.data_updated_at,
                        error: None,
                    },
                    None => self.degraded(key, "réponse 304 sans copie locale".to_string()),
                }
            }
            Ok(reply) if (200..300).contains(&reply.status) => {
                self.clear_backoff();
                match Self::parse_payload(&reply.body, key) {
                    Ok((rows, updated)) if !rows.is_empty() => {
                        self.store_entry(
                            key,
                            rows.clone(),
                            updated.clone(),
                            reply.etag,
                            reply.last_modified,
                        );
                        Fetched {
                            rows,
                            source: Source::Live,
                            age_seconds: 0,
                            data_updated_at: updated,
                            error: None,
                        }
                    }
                    Ok(_) => self.degraded(key, "réponse vide".to_string()),
                    Err(err) => self.degraded(key, err),
                }
            }
            Ok(reply) => {
                let wait = self.register_failure(reply.retry_after, format!("HTTP {}", reply.status));
                self.degraded(
                    key,
                    format!("HTTP {} — prochaine tentative dans {wait} s", reply.status),
                )
            }
            Err(err) => {
                let wait = self.register_failure(None, err.clone());
                self.degraded(key, format!("{err} — prochaine tentative dans {wait} s"))
            }
        }
    }

    fn fresh(&self, key: MarketKey) -> Option<Fetched> {
        let (rows, age, updated) = self.cached(key)?;
        if Duration::from_secs(age) < self.policy.ttl {
            return Some(Fetched {
                rows,
                source: Source::Cache,
                age_seconds: age,
                data_updated_at: updated,
                error: None,
            });
        }
        None
    }

    /// Échec de collecte : sert le cache périmé s'il est encore acceptable.
    fn degraded(&self, key: MarketKey, error: String) -> Fetched {
        if let Some((rows, age, updated)) = self.cached(key) {
            if Duration::from_secs(age) < self.policy.stale_ttl {
                return Fetched {
                    rows,
                    source: Source::Stale,
                    age_seconds: age,
                    data_updated_at: updated,
                    error: Some(error),
                };
            }
        }
        Fetched {
            rows: Vec::new(),
            // Aucune donnée exploitable : ne jamais présenter un échec comme
            // du live, sinon le pipeline le recopie dans le snapshot.
            source: Source::Stale,
            age_seconds: 0,
            data_updated_at: None,
            error: Some(error),
        }
    }

    fn parse_payload(body: &str, key: MarketKey) -> Result<(Vec<Value>, Option<String>), String> {
        let payload = extract_payload(body)
            .ok_or_else(|| format!("JSON embarqué introuvable pour {}", key.slug()))?;
        let rows = payload
            .get("data")
            .and_then(|d| d.as_array())
            .cloned()
            .unwrap_or_default();
        let updated = payload
            .get("data_updated_at")
            .and_then(|v| v.as_str())
            .map(str::to_string);
        Ok((rows, updated))
    }
}

/// Transport par défaut (ureq), avec validateurs conditionnels.
pub fn http_transport(
    url: &str,
    etag: Option<&str>,
    last_modified: Option<&str>,
    user_agent: &str,
) -> Result<HttpReply, String> {
    let mut request = ureq::get(url)
        .set("User-Agent", user_agent)
        .set("Accept", "text/html,application/xhtml+xml")
        .set("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8")
        .timeout(Duration::from_secs(9));
    if let Some(value) = etag {
        request = request.set("If-None-Match", value);
    }
    if let Some(value) = last_modified {
        request = request.set("If-Modified-Since", value);
    }

    let retry_after = |header: Option<&str>| {
        header
            .and_then(|v| v.trim().parse::<u64>().ok())
            .map(|secs| secs.min(3600))
    };

    match request.call() {
        Ok(response) => {
            let status = response.status();
            let etag = response.header("etag").map(str::to_string);
            let last_modified = response.header("last-modified").map(str::to_string);
            let body = if status == 304 {
                String::new()
            } else {
                response
                    .into_string()
                    .map_err(|e| format!("lecture HTML : {e}"))?
            };
            Ok(HttpReply {
                status,
                body,
                etag,
                last_modified,
                retry_after: None,
            })
        }
        Err(ureq::Error::Status(status, response)) => {
            let wait = retry_after(response.header("retry-after"));
            Ok(HttpReply {
                status,
                body: response.into_string().unwrap_or_default(),
                etag: None,
                last_modified: None,
                retry_after: wait,
            })
        }
        Err(err) => Err(format!("réseau : {err}")),
    }
}

/// Extrait le premier objet JSON `{"success": true ...}` embarqué dans un `<script>`.
///
/// Un simple regex ne suffit pas : les volumes et libellés peuvent contenir des
/// accolades ou des guillemets échappés. On scanne donc en respectant les chaînes.
pub fn extract_payload(html: &str) -> Option<Value> {
    let start = html.find("\"success\"")?;
    // Remonter à l'accolade ouvrante de l'objet.
    let obj_start = html[..start].rfind('{')?;

    let bytes = html.as_bytes();
    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;

    for i in obj_start..bytes.len() {
        let c = bytes[i] as char;
        if in_string {
            if escaped {
                escaped = false;
            } else if c == '\\' {
                escaped = true;
            } else if c == '"' {
                in_string = false;
            }
            continue;
        }
        match c {
            '"' => in_string = true,
            '{' => depth += 1,
            '}' => {
                depth -= 1;
                if depth == 0 {
                    let slice = &html[obj_start..=i];
                    return serde_json::from_str::<Value>(slice).ok();
                }
            }
            _ => {}
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn payload_body() -> String {
        r#"<html><body><script>{"success": true, "data_updated_at": "2026-11-09T20:00:00Z",
        "data": [{"home": "A", "away": "B", "volume_1": 10}]}</script></body></html>"#
            .to_string()
    }

    fn policy() -> ScraperPolicy {
        ScraperPolicy {
            ttl: Duration::from_secs(0),
            stale_ttl: Duration::from_secs(900),
            user_agent: user_agent(Some("https://example.test/contact")),
            backoff_base: Duration::from_secs(30),
            backoff_max: Duration::from_secs(600),
        }
    }

    #[test]
    fn extracts_embedded_json() {
        let html = r#"<html><body>
            <script type="application/json">{"success": true, "data_updated_at": "2026-11-09T20:00:00Z",
            "data": [{"home": "A {B}", "away": "C \"D\"", "volume_1": 10}]}</script>
        </body></html>"#;
        let payload = extract_payload(html).expect("payload");
        assert_eq!(payload["success"], Value::Bool(true));
        assert_eq!(payload["data"][0]["away"], Value::String("C \"D\"".into()));
    }

    #[test]
    fn returns_none_without_payload() {
        assert!(extract_payload("<html><body>nope</body></html>").is_none());
    }

    #[test]
    fn cache_ttl_is_respected() {
        // Aucun réseau ici : le cache vide sur un TTL nul doit échouer proprement.
        let scraper = Scraper::new(
            "https://invalid.local",
            Duration::from_secs(0),
            Duration::from_secs(0),
            "test",
        );
        assert!(scraper.cached(MarketKey::OneXTwo).is_none());
    }

    #[test]
    fn user_agent_is_identifiable() {
        assert_eq!(
            user_agent(Some("https://example.test")),
            format!("truevalue/{} (+https://example.test)", env!("CARGO_PKG_VERSION"))
        );
        let anonymous = user_agent(None);
        assert!(anonymous.starts_with("truevalue/"));
        assert!(anonymous.contains("SCRAPER_CONTACT"));
        // Jamais d'usurpation de navigateur.
        assert!(!anonymous.contains("Mozilla"));
    }

    #[test]
    fn rate_limit_suspends_without_hammering() {
        let calls = Arc::new(AtomicUsize::new(0));
        let counter = calls.clone();
        let scraper = Scraper::with_policy("https://example.test", policy()).with_transport(Arc::new(
            move |_url, _etag, _lm, _ua| {
                counter.fetch_add(1, Ordering::SeqCst);
                Ok(HttpReply {
                    status: 429,
                    retry_after: Some(45),
                    ..HttpReply::default()
                })
            },
        ));

        let first = scraper.fetch(MarketKey::OneXTwo, false);
        assert!(first.error.is_some(), "un refus doit remonter une erreur");
        assert!(first.rows.is_empty());
        let wait = scraper.backoff_remaining_secs().expect("back-off actif");
        assert!((45..=46).contains(&wait), "Retry-After respecté : {wait}");

        // Deuxième tentative : aucune requête supplémentaire tant que le délai court.
        let second = scraper.fetch(MarketKey::OneXTwo, true);
        assert_eq!(calls.load(Ordering::SeqCst), 1, "le site est martelé");
        assert!(second.error.unwrap_or_default().contains("suspendue"));
    }

    #[test]
    fn not_modified_reuses_cache_and_sends_validator() {
        let seen = Arc::new(Mutex::new(Vec::new()));
        let captured = seen.clone();
        let calls = Arc::new(AtomicUsize::new(0));
        let counter = calls.clone();

        let scraper = Scraper::with_policy("https://example.test", policy()).with_transport(Arc::new(
            move |_url, etag, _lm, _ua| {
                captured.lock().unwrap().push(etag.map(str::to_string));
                let n = counter.fetch_add(1, Ordering::SeqCst);
                if n == 0 {
                    Ok(HttpReply {
                        status: 200,
                        body: payload_body(),
                        etag: Some("W/\"v1\"".to_string()),
                        ..HttpReply::default()
                    })
                } else {
                    Ok(HttpReply {
                        status: 304,
                        etag: Some("W/\"v2\"".to_string()),
                        ..HttpReply::default()
                    })
                }
            },
        ));

        let first = scraper.fetch(MarketKey::OneXTwo, false);
        assert_eq!(first.source, Source::Live);
        assert_eq!(first.rows.len(), 1);

        let second = scraper.fetch(MarketKey::OneXTwo, false);
        assert_eq!(second.source, Source::Cache);
        assert_eq!(second.rows.len(), 1, "les lignes du cache sont réutilisées");
        assert!(second.error.is_none());
        assert_eq!(
            seen.lock().unwrap()[1],
            Some("W/\"v1\"".to_string()),
            "If-None-Match doit être envoyé"
        );
    }

    #[test]
    fn success_clears_backoff() {
        let calls = Arc::new(AtomicUsize::new(0));
        let counter = calls.clone();
        let mut zero = policy();
        zero.backoff_base = Duration::from_secs(0);
        zero.backoff_max = Duration::from_secs(0);

        let scraper = Scraper::with_policy("https://example.test", zero).with_transport(Arc::new(
            move |_url, _etag, _lm, _ua| {
                if counter.fetch_add(1, Ordering::SeqCst) == 0 {
                    Ok(HttpReply {
                        status: 503,
                        ..HttpReply::default()
                    })
                } else {
                    Ok(HttpReply {
                        status: 200,
                        body: payload_body(),
                        ..HttpReply::default()
                    })
                }
            },
        ));

        let _ = scraper.fetch(MarketKey::OneXTwo, false);
        let recovered = scraper.fetch(MarketKey::OneXTwo, false);
        assert_eq!(recovered.source, Source::Live);
        assert!(scraper.backoff_remaining_secs().is_none());
    }
}
