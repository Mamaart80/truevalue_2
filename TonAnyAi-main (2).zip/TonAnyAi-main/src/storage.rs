//! Persistance : Cloudflare D1 pour l'historique des signaux et KV pour le
//! snapshot lu par le tableau de bord. Repli sur des fichiers JSON en local,
//! pour pouvoir développer et tester sans identifiants Cloudflare.

use std::collections::HashMap;
use std::path::PathBuf;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::cloudflare::Cloudflare;
use crate::config::Config;
use crate::daily::MatchLogRow;
use crate::enrich::parse_kickoff;
use crate::model::{
    BetOutcome, CategoryStats, Confidence, MatchState, Recommendation, Signal, Snapshot,
    TrackRecord, TrackedSignal,
};
use crate::simulation::{SimPosition, SimStatus, SimTotals};

pub const SNAPSHOT_KEY: &str = "truevalue/snapshot.json";

/// Signaux déjà envoyés sur Telegram : une petite liste d'identifiants, pour ne
/// pas répéter une alerte au cycle suivant ni après un redémarrage.
pub const ALERTS_KEY: &str = "truevalue/alerts.json";

const SCHEMA: [&str; 4] = [
    "CREATE TABLE IF NOT EXISTS signals (
        id TEXT PRIMARY KEY,
        first_seen TEXT NOT NULL,
        last_seen TEXT NOT NULL,
        match_date TEXT NOT NULL DEFAULT '',
        home TEXT NOT NULL,
        away TEXT NOT NULL,
        league TEXT NOT NULL DEFAULT '',
        category TEXT NOT NULL,
        convergence_score REAL NOT NULL DEFAULT 0,
        value_play TEXT NOT NULL,
        value_label TEXT NOT NULL,
        value_odds REAL,
        safety_play TEXT NOT NULL,
        safety_label TEXT NOT NULL,
        safety_odds REAL,
        value_outcome TEXT NOT NULL DEFAULT 'PENDING',
        safety_outcome TEXT NOT NULL DEFAULT 'PENDING',
        value_explanation TEXT NOT NULL DEFAULT '',
        home_score INTEGER,
        away_score INTEGER,
        confidence TEXT NOT NULL DEFAULT '',
        graded_at TEXT
    )",
    "CREATE INDEX IF NOT EXISTS signals_date_idx ON signals(match_date)",
    "CREATE INDEX IF NOT EXISTS signals_outcome_idx ON signals(value_outcome)",
    "CREATE INDEX IF NOT EXISTS signals_category_idx ON signals(category)",
];

/// Table des relevés : une ligne par sélection et par collecte où quelque
/// chose a bougé. C'est la matière première de l'argent frais et du CLV.
const SNAPSHOTS_SCHEMA: [&str; 4] = [
    "CREATE TABLE IF NOT EXISTS snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        market_key TEXT NOT NULL,
        market_id INTEGER NOT NULL,
        selection_id INTEGER NOT NULL,
        fixture_key TEXT NOT NULL,
        captured_at TEXT NOT NULL,
        coef_new_1 REAL NOT NULL DEFAULT 0,
        coef_new_x REAL NOT NULL DEFAULT 0,
        coef_new_2 REAL NOT NULL DEFAULT 0,
        volume_1 REAL NOT NULL DEFAULT 0,
        volume_x REAL NOT NULL DEFAULT 0,
        volume_2 REAL NOT NULL DEFAULT 0,
        total_volume REAL NOT NULL DEFAULT 0,
        kickoff TEXT NOT NULL DEFAULT ''
    )",
    "CREATE INDEX IF NOT EXISTS snapshots_fixture_idx ON snapshots(fixture_key, captured_at)",
    "CREATE INDEX IF NOT EXISTS snapshots_selection_idx
        ON snapshots(market_key, market_id, selection_id, captured_at)",
    // Sans cet index, la purge (`WHERE captured_at < ?`) et le chargement de la
    // fenêtre récente balayaient **toute** la table à chaque collecte : c'était
    // la cause du dépassement des 5 M de lignes lues par jour.
    "CREATE INDEX IF NOT EXISTS snapshots_captured_idx ON snapshots(captured_at)",
];

/// Journal des rencontres suivies : une ligne par affiche et par coup d'envoi,
/// **recoupements neutres compris**. Le score n'est écrit que lorsqu'il est
/// réellement connu (`source = 'espn'`), sinon il reste absent.
const MATCH_LOG_SCHEMA: [&str; 2] = [
    "CREATE TABLE IF NOT EXISTS match_log (
        fixture_key TEXT NOT NULL,
        match_date TEXT NOT NULL,
        day TEXT NOT NULL DEFAULT '',
        home TEXT NOT NULL DEFAULT '',
        away TEXT NOT NULL DEFAULT '',
        league TEXT NOT NULL DEFAULT '',
        kind TEXT NOT NULL DEFAULT '',
        flagged INTEGER NOT NULL DEFAULT 0,
        state TEXT NOT NULL DEFAULT 'SCHEDULED',
        status_detail TEXT NOT NULL DEFAULT '',
        home_score INTEGER,
        away_score INTEGER,
        source TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT '',
        PRIMARY KEY (fixture_key, match_date)
    )",
    "CREATE INDEX IF NOT EXISTS match_log_day_idx ON match_log(day)",
];

/// Positions de la simulation de trading. Une ligne par rencontre ouverte ;
/// le statut et le profit évoluent au fil des collectes.
const SIM_SCHEMA: [&str; 3] = [
    "CREATE TABLE IF NOT EXISTS sim_positions (
        id TEXT PRIMARY KEY,
        signal_id TEXT NOT NULL,
        fixture_key TEXT NOT NULL DEFAULT '',
        match_date TEXT NOT NULL DEFAULT '',
        day TEXT NOT NULL DEFAULT '',
        home TEXT NOT NULL DEFAULT '',
        away TEXT NOT NULL DEFAULT '',
        league TEXT NOT NULL DEFAULT '',
        kind TEXT NOT NULL DEFAULT '',
        grp TEXT NOT NULL DEFAULT '',
        market TEXT NOT NULL DEFAULT '',
        pick TEXT NOT NULL DEFAULT '',
        entry_odds REAL NOT NULL,
        stake REAL NOT NULL DEFAULT 1,
        play TEXT NOT NULL DEFAULT '{}',
        opened_at TEXT NOT NULL,
        minutes_before_kickoff INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'OPEN',
        settled_at TEXT,
        pnl REAL,
        home_score INTEGER,
        away_score INTEGER,
        note TEXT NOT NULL DEFAULT ''
    )",
    "CREATE INDEX IF NOT EXISTS sim_positions_status_idx ON sim_positions(status)",
    "CREATE UNIQUE INDEX IF NOT EXISTS sim_positions_fixture_idx
        ON sim_positions(fixture_key, match_date, league)",
];

/// Candidats de simulation en attente d'une place. Le signal peut disparaître
/// du flux ou arriver quand les 10 positions sont déjà prises : sa position
/// éligible est conservée ici et réessayée à chaque cycle. `payload` est une
/// `SimPosition` sérialisée (les champs `opened_at`/`minutes` sont posés à
/// l'ouverture réelle).
const SIM_CANDIDATES_SCHEMA: [&str; 2] = [
    "CREATE TABLE IF NOT EXISTS sim_candidates (
        id TEXT PRIMARY KEY,
        payload TEXT NOT NULL,
        match_date TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT ''
    )",
    "CREATE INDEX IF NOT EXISTS sim_candidates_date_idx ON sim_candidates(match_date)",
];

/// Marqueur des migrations déjà appliquées : évite de rejouer 13 `ALTER TABLE`
/// à chaque démarrage (erreurs « duplicate column » comprise).
const META_SCHEMA: [&str; 1] = [
    "CREATE TABLE IF NOT EXISTS schema_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )",
];

/// Migrations idempotentes : D1 refuse `ADD COLUMN` sur une colonne déjà
/// présente, donc `ensure_schema` ignore ce cas précis et rien d'autre.
const MIGRATIONS: [&str; 13] = [
    "ALTER TABLE signals ADD COLUMN fixture_key TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE signals ADD COLUMN signal_kind TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE signals ADD COLUMN proposals TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE signals ADD COLUMN closing_odds REAL",
    "ALTER TABLE signals ADD COLUMN clv_pct REAL",
    "ALTER TABLE signals ADD COLUMN clv_novig_pct REAL",
    "ALTER TABLE signals ADD COLUMN signal_family TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE signals ADD COLUMN minutes_before_kickoff INTEGER",
    "ALTER TABLE signals ADD COLUMN liquidity_tier TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE signals ADD COLUMN confidence TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE match_log ADD COLUMN metrics TEXT NOT NULL DEFAULT ''",
    "CREATE INDEX IF NOT EXISTS signals_fixture_idx ON signals(fixture_key)",
    "CREATE INDEX IF NOT EXISTS signals_kind_idx ON signals(signal_kind)",
];

/// Un relevé de sélection, tel qu'historisé et relu par le moteur.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SnapshotRow {
    pub market_key: String,
    pub market_id: i64,
    pub selection_id: i64,
    pub fixture_key: String,
    pub captured_at: String,
    #[serde(default)]
    pub coef: [f64; 3],
    #[serde(default)]
    pub volume: [f64; 3],
    #[serde(default)]
    pub total_volume: f64,
    #[serde(default)]
    pub kickoff: String,
}

impl SnapshotRow {
    pub fn selection_key(&self) -> String {
        format!(
            "{}:{}:{}",
            self.market_key, self.market_id, self.selection_id
        )
    }

    pub fn observation(&self) -> crate::fresh::Observation {
        crate::fresh::Observation {
            captured_at: self.captured_at.clone(),
            coef: self.coef,
            volume: self.volume,
        }
    }
}

/// Fenêtre de relevés tenue en mémoire.
///
/// Chaque collecte relisait les six heures de relevés deux fois : une fois
/// pour le moteur d'argent frais, une fois pour savoir ce qui avait bougé.
/// C'est cette relecture répétée qui a épuisé le quota de lignes lues de D1
/// (5 M par jour) le 14 novembre. La base n'est plus lue qu'une fois par
/// démarrage.
#[derive(Default)]
struct RecentSnapshots {
    loaded: bool,
    series: crate::fresh::Series,
    /// Erreur de lecture D1 remontée au pipeline : sans elle, une panne de
    /// l'historique se traduisait par un argent frais calculé sur rien, en
    /// silence, puis par la réinsertion de tous les relevés comme neufs.
    error: Option<String>,
}

/// Historique et statistiques, relus au plus une fois par
/// `STATS_CACHE_TTL_SECS`.
struct StatsCache {
    at: std::time::Instant,
    rows: Vec<TrackedSignal>,
    bundle: crate::track::StatsBundle,
}

pub struct Store {
    /// Client D1 + identifiant de base.
    d1: Option<(Cloudflare, String)>,
    /// Client KV + identifiant de namespace.
    kv: Option<(Cloudflare, String)>,
    local_dir: PathBuf,
    /// Fenêtre glissante des relevés, voir `RecentSnapshots`.
    recent: std::sync::Mutex<RecentSnapshots>,
    /// Bilan et statistiques, voir `StatsCache`.
    stats: std::sync::Mutex<Option<StatsCache>>,
    /// Dernière purge des relevés (au plus une par heure, voir
    /// `SNAPSHOT_PURGE_INTERVAL_SECS`).
    purge_at: std::sync::Mutex<Option<std::time::Instant>>,
    /// Vrai quand le schéma et les index sont en place (voir `schema_ready`).
    schema_ready: std::sync::atomic::AtomicBool,
    /// Dernier essai d'application du schéma après un échec (index) :
    /// un essai par heure au plus, pour ne pas ralentir chaque collecte.
    schema_retry_at: std::sync::Mutex<Option<std::time::Instant>>,
}

fn s(v: &Value, key: &str) -> String {
    v.get(key)
        .and_then(|x| x.as_str())
        .unwrap_or_default()
        .to_string()
}

fn i(v: &Value, key: &str) -> Option<i64> {
    v.get(key).and_then(|x| x.as_i64())
}

fn f(v: &Value, key: &str) -> Option<f64> {
    v.get(key).and_then(|x| x.as_f64())
}

fn parse_play(raw: &str, label: String, odds: Option<f64>) -> Recommendation {
    let play = serde_json::from_str(raw).unwrap_or(crate::model::Play::NoBet);
    Recommendation { play, label, odds }
}

fn outcome(raw: &str) -> BetOutcome {
    match raw {
        "WON" => BetOutcome::Won,
        "LOST" => BetOutcome::Lost,
        "PUSH" => BetOutcome::Push,
        "PENDING" => BetOutcome::Pending,
        _ => BetOutcome::Unknown,
    }
}

fn outcome_str(o: BetOutcome) -> &'static str {
    match o {
        BetOutcome::Won => "WON",
        BetOutcome::Lost => "LOST",
        BetOutcome::Push => "PUSH",
        BetOutcome::Pending => "PENDING",
        BetOutcome::Unknown => "UNKNOWN",
    }
}

impl Store {
    pub fn new(cfg: &Config) -> Self {
        let account = cfg.cloudflare_account.clone();

        let d1 = match (account.clone(), cfg.d1_token(), cfg.d1_database.clone()) {
            (Some(account), Some(token), Some(db)) => Some((Cloudflare::new(account, token), db)),
            _ => None,
        };
        let kv = match (account, cfg.kv_token(), cfg.kv_namespace.clone()) {
            (Some(account), Some(token), Some(ns)) => Some((Cloudflare::new(account, token), ns)),
            _ => None,
        };

        Self {
            d1,
            kv,
            local_dir: cfg.data_dir.clone(),
            recent: std::sync::Mutex::new(RecentSnapshots::default()),
            stats: std::sync::Mutex::new(None),
            purge_at: std::sync::Mutex::new(None),
            schema_ready: std::sync::atomic::AtomicBool::new(false),
            schema_retry_at: std::sync::Mutex::new(None),
        }
    }

    pub fn mode(&self) -> &'static str {
        match (self.d1.is_some(), self.kv.is_some()) {
            (true, true) => "cloudflare (D1 + KV)",
            (false, false) => "fichiers locaux",
            _ => "cloudflare partiel (repli local pour le reste)",
        }
    }

    pub fn cloudflare(&self) -> Option<&Cloudflare> {
        self.d1.as_ref().map(|(client, _)| client)
    }

    /// Consommation D1 du jour (lignes lues/écrites, quota épuisé ou non).
    pub fn d1_usage(&self) -> Option<crate::cloudflare::Usage> {
        self.d1.as_ref().map(|(client, _)| client.usage())
    }

    /// Reste-t-il assez de budget pour une lecture non essentielle ?
    ///
    /// Les lectures indispensables (signaux, notation, alertes) ne passent
    /// jamais par ce filtre : seule l'historisation facultative est différée.
    pub fn d1_budget_ok(&self) -> bool {
        self.d1
            .as_ref()
            .map(|(client, _)| client.has_budget())
            .unwrap_or(true)
    }

    fn purge_due(&self) -> bool {
        match *self.purge_at.lock().unwrap() {
            Some(at) => at.elapsed().as_secs() >= crate::thresholds::SNAPSHOT_PURGE_INTERVAL_SECS,
            None => true,
        }
    }

    fn mark_purged(&self) {
        *self.purge_at.lock().unwrap() = Some(std::time::Instant::now());
    }

    /// Applique une instruction de schéma et indique si elle a abouti. Seule la
    /// création d'index est tolérante : un index manquant coûte des lectures,
    /// pas la justesse, et un `CREATE INDEX` sur une grosse table peut dépasser
    /// le délai D1. Le délai est donc allongé, et l'échec est retenté plus tard.
    fn run_schema(cf: &Cloudflare, db: &str, stmt: &str) -> Result<bool, String> {
        match cf.d1_query_with_timeout(db, stmt, Vec::new(), std::time::Duration::from_secs(60)) {
            Ok(_) => Ok(true),
            Err(err) if stmt.trim_start().starts_with("CREATE INDEX") => {
                eprintln!("[d1] index non créé (nouvel essai différé) : {err}");
                Ok(false)
            }
            Err(err) => Err(err),
        }
    }

    pub fn ensure_schema(&self) -> Result<(), String> {
        match &self.d1 {
            Some((cf, db)) => {
                let mut complete = true;
                for stmt in SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                for stmt in SNAPSHOTS_SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                for stmt in MATCH_LOG_SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                for stmt in SIM_SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                for stmt in SIM_CANDIDATES_SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                for stmt in META_SCHEMA {
                    complete &= Self::run_schema(cf, db, stmt)?;
                }
                let applied = cf
                    .d1_query(
                        db,
                        "SELECT value FROM schema_meta WHERE key = 'migrations_v1'",
                        Vec::new(),
                    )?
                    .first()
                    .and_then(|row| row.get("value"))
                    .and_then(Value::as_str)
                    .map(str::to_string);
                if applied.as_deref() != Some("1") {
                    for stmt in MIGRATIONS {
                        if let Err(err) = cf.d1_query(db, stmt, Vec::new()) {
                            // `ADD COLUMN` échoue si la colonne existe déjà :
                            // c'est le seul cas toléré, tout autre erreur remonte.
                            let duplicate = err.contains("duplicate column")
                                || err.contains("already exists");
                            if !duplicate {
                                return Err(err);
                            }
                        }
                    }
                    cf.d1_query(
                        db,
                        "INSERT INTO schema_meta (key, value) VALUES ('migrations_v1', '1')
                         ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                        Vec::new(),
                    )?;
                }
                self.schema_ready
                    .store(complete, std::sync::atomic::Ordering::Relaxed);
                Ok(())
            }
            None => {
                std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
                self.schema_ready
                    .store(true, std::sync::atomic::Ordering::Relaxed);
                Ok(())
            }
        }
    }

    /// Le schéma (et ses index) a-t-il été appliqué avec succès ?
    ///
    /// Faux après un démarrage sous quota épuisé : la collecte retente alors
    /// l'initialisation, sans quoi l'index sur `captured_at` — la correction du
    /// quota — n'existerait qu'au redémarrage suivant.
    pub fn schema_ready(&self) -> bool {
        self.schema_ready.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// Faut-il retenter l'initialisation du schéma ? (au plus une fois par
    /// heure ; l'appel réserve la tentative)
    pub fn schema_retry_due(&self) -> bool {
        let mut last = self.schema_retry_at.lock().unwrap();
        let due = match *last {
            Some(at) => at.elapsed().as_secs() >= crate::thresholds::D1_SCHEMA_RETRY_SECS,
            None => true,
        };
        if due {
            *last = Some(std::time::Instant::now());
        }
        due
    }

    /// L'historisation est-elle active ? (le bloc `v2` n'est exposé que dans
    /// ce cas, sinon l'interface affiche « indisponible »).
    pub fn history_active(&self) -> bool {
        match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(db, "SELECT 1 AS present FROM snapshots LIMIT 1", Vec::new())
                .map(|rows| !rows.is_empty())
                .unwrap_or(false),
            None => !self.read_local_snapshots().is_empty(),
        }
    }

    /// Relevés de la fenêtre récente, du plus ancien au plus récent.
    ///
    /// Une seule requête, au premier accès après le démarrage : ensuite la
    /// mémoire prend le relais via `remember`.
    fn load_recent_window(&self, since: &str) -> Result<crate::fresh::Series, String> {
        let rows: Vec<SnapshotRow> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT * FROM snapshots WHERE captured_at >= ? ORDER BY captured_at ASC",
                    vec![json!(since)],
                )?
                .iter()
                .map(row_to_snapshot)
                .collect(),
            None => self.read_local_snapshots(),
        };
        let mut series = crate::fresh::Series::default();
        for row in rows
            .into_iter()
            .filter(|row| row.captured_at.as_str() >= since)
        {
            series.push(&row.selection_key(), row.observation());
        }
        Ok(series)
    }

    /// Erreur de lecture de l'historique survenue depuis le dernier cycle.
    pub fn take_recent_error(&self) -> Option<String> {
        self.recent.lock().unwrap().error.take()
    }

    /// Retire de la fenêtre ce qui a dépassé `SNAPSHOT_RECENT_HOURS`.
    fn prune_window(series: &mut crate::fresh::Series, since: &str) {
        series.by_selection.retain(|_, readings| {
            readings.retain(|reading| reading.captured_at.as_str() >= since);
            !readings.is_empty()
        });
    }

    /// Série récente pour le moteur d'argent frais, sans relecture de la base.
    pub fn fresh_series(&self, now: DateTime<Utc>) -> crate::fresh::Series {
        let since = (now - chrono::Duration::hours(crate::thresholds::SNAPSHOT_RECENT_HOURS))
            .to_rfc3339();
        let mut cache = self.recent.lock().unwrap();
        if !cache.loaded {
            match self.load_recent_window(&since) {
                Ok(series) => cache.series = series,
                Err(err) => cache.error = Some(format!("lecture de l'historique : {err}")),
            }
            cache.loaded = true;
        }
        Self::prune_window(&mut cache.series, &since);
        cache.series.clone()
    }

    /// Ajoute la collecte courante à la fenêtre, après son écriture.
    ///
    /// Rien n'est ajouté si une écriture a échoué (`?` sort avant cet appel) :
    /// la mémoire ne doit jamais croire enregistré ce qui ne l'est pas.
    fn remember(&self, rows: &[&SnapshotRow], now: DateTime<Utc>) {
        let mut cache = self.recent.lock().unwrap();
        // Fenêtre jamais chargée : `fresh_series` la lira en base, relevés du
        // cycle compris.
        if !cache.loaded {
            return;
        }
        let since = (now - chrono::Duration::hours(crate::thresholds::SNAPSHOT_RECENT_HOURS))
            .to_rfc3339();
        for row in rows {
            cache.series.push(&row.selection_key(), row.observation());
        }
        Self::prune_window(&mut cache.series, &since);
    }

    /// Enregistre les relevés qui ont changé, en lots, puis purge les anciens.
    ///
    /// Renvoie le nombre de lignes réellement insérées. Une cote qui bouge de
    /// moins de 0.5 % et un volume qui bouge de moins de 1 £ sont considérés
    /// comme inchangés : sans cela, chaque collecte créerait 10 000 doublons.
    pub fn record_snapshots(
        &self,
        rows: &[SnapshotRow],
        now: DateTime<Utc>,
    ) -> Result<usize, String> {
        if rows.is_empty() {
            return Ok(0);
        }
        let since = (now - chrono::Duration::hours(crate::thresholds::SNAPSHOT_RECENT_HOURS))
            .to_rfc3339();
        // La comparaison se fait sur la fenêtre en mémoire, pas sur la base :
        // relire six heures de relevés à chaque collecte épuisait le quota.
        let changed: Vec<&SnapshotRow> = {
            let mut cache = self.recent.lock().unwrap();
            if !cache.loaded {
                match self.load_recent_window(&since) {
                    Ok(series) => cache.series = series,
                    Err(err) => cache.error = Some(format!("lecture de l'historique : {err}")),
                }
                cache.loaded = true;
            }
            Self::prune_window(&mut cache.series, &since);
            rows.iter()
                .filter(|row| {
                    let newest = cache
                        .series
                        .by_selection
                        .get(&row.selection_key())
                        .and_then(|readings| {
                            readings
                                .iter()
                                .max_by(|a, b| a.captured_at.cmp(&b.captured_at))
                        });
                    match newest {
                        Some(previous) => Self::has_changed(previous, row),
                        None => true,
                    }
                })
                .collect()
        };

        let inserted = match &self.d1 {
            Some((cf, db)) => {
                for chunk in changed.chunks(crate::thresholds::SNAPSHOT_BATCH_ROWS) {
                    let mut sql = String::from(
                        "INSERT INTO snapshots (market_key, market_id, selection_id, fixture_key,
                            captured_at, coef_new_1, coef_new_x, coef_new_2, volume_1, volume_x,
                            volume_2, total_volume, kickoff) VALUES ",
                    );
                    let mut params = Vec::with_capacity(chunk.len() * 13);
                    for (i, row) in chunk.iter().enumerate() {
                        if i > 0 {
                            sql.push(',');
                        }
                        sql.push_str("(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                        params.extend([
                            json!(row.market_key),
                            json!(row.market_id),
                            json!(row.selection_id),
                            json!(row.fixture_key),
                            json!(row.captured_at),
                            json!(row.coef[0]),
                            json!(row.coef[1]),
                            json!(row.coef[2]),
                            json!(row.volume[0]),
                            json!(row.volume[1]),
                            json!(row.volume[2]),
                            json!(row.total_volume),
                            json!(row.kickoff),
                        ]);
                    }
                    cf.d1_query(db, &sql, params)?;
                }
                let cutoff = (now - chrono::Duration::days(crate::thresholds::SNAPSHOT_PURGE_DAYS))
                    .to_rfc3339();
                // Purge **bornée et espacée**. Sans index sur `captured_at`,
                // un `DELETE` non borné balayait toute la table à chaque
                // collecte ; même indexé, le refaire toutes les dix minutes
                // pour quelques lignes est inutile. Les relevés des rencontres
                // dont le signal n'est pas encore noté sont conservés.
                if self.purge_due() && self.d1_budget_ok() {
                    let purge = cf.d1_query(
                        db,
                        "DELETE FROM snapshots WHERE id IN (
                            SELECT s.id FROM snapshots s
                            WHERE s.captured_at < ?
                              AND NOT EXISTS (
                                SELECT 1 FROM signals g
                                WHERE g.fixture_key = s.fixture_key
                                  AND g.value_outcome IN ('PENDING', 'UNKNOWN')
                              )
                            LIMIT ?
                         )",
                        vec![
                            json!(cutoff),
                            json!(crate::thresholds::SNAPSHOT_PURGE_BATCH),
                        ],
                    );
                    match purge {
                        Ok(_) => self.mark_purged(),
                        Err(err) => {
                            // `take_recent_error` vide le champ à la fin du
                            // cycle : on conserve la première erreur.
                            let mut cache = self.recent.lock().unwrap();
                            if cache.error.is_none() {
                                cache.error = Some(format!("purge des relevés : {err}"));
                            }
                        }
                    }
                }
                changed.len()
            }
            None => {
                let mut existing = self.read_local_snapshots();
                existing.extend(changed.iter().map(|row| (*row).clone()));
                let cutoff = now - chrono::Duration::days(crate::thresholds::SNAPSHOT_PURGE_DAYS);
                let open: std::collections::HashSet<String> = self
                    .read_local_signals()
                    .into_iter()
                    .filter(|row| {
                        matches!(row.value_outcome, BetOutcome::Pending | BetOutcome::Unknown)
                    })
                    .map(|row| row.fixture_key)
                    .collect();
                existing.retain(|row| {
                    let recent = crate::enrich::parse_kickoff(&row.captured_at)
                        .map(|at| at >= cutoff)
                        .unwrap_or(false);
                    recent || open.contains(&row.fixture_key)
                });
                self.write_local_snapshots(&existing)?;
                changed.len()
            }
        };
        // Seuls les relevés réellement écrits entrent dans la fenêtre : y
        // ajouter les lignes inchangées doublait les observations et faussait
        // le seuil minimal d'argent frais.
        self.remember(&changed, now);
        Ok(inserted)
    }

    fn has_changed(previous: &crate::fresh::Observation, row: &SnapshotRow) -> bool {
        let odds_moved = previous.coef.iter().zip(row.coef.iter()).any(|(a, b)| {
            let base = a.abs().max(1.0);
            (b - a).abs() / base * 100.0 >= crate::thresholds::SNAPSHOT_MIN_ODDS_CHANGE_PCT
        });
        let volume_moved = previous
            .volume
            .iter()
            .zip(row.volume.iter())
            .any(|(a, b)| (b - a).abs() >= crate::thresholds::SNAPSHOT_MIN_VOLUME_CHANGE);
        odds_moved || volume_moved
    }

    /// Série temporelle d'une sélection, du plus ancien au plus récent.
    pub fn selection_series(&self, key: &str) -> Result<Vec<SnapshotRow>, String> {
        let mut rows: Vec<SnapshotRow> = match &self.d1 {
            Some((cf, db)) => {
                let parts: Vec<&str> = key.splitn(3, ':').collect();
                if parts.len() != 3 {
                    return Ok(Vec::new());
                }
                let market_id = parts[1].parse::<i64>().unwrap_or(0);
                let selection_id = parts[2].parse::<i64>().unwrap_or(0);
                cf.d1_query(
                    db,
                    "SELECT * FROM snapshots WHERE market_key = ? AND market_id = ?
                     AND selection_id = ? ORDER BY captured_at ASC",
                    vec![json!(parts[0]), json!(market_id), json!(selection_id)],
                )?
                .iter()
                .map(row_to_snapshot)
                .collect()
            }
            None => self
                .read_local_snapshots()
                .into_iter()
                .filter(|row| row.selection_key() == key)
                .collect(),
        };
        rows.sort_by(|a, b| a.captured_at.cmp(&b.captured_at));
        Ok(rows)
    }

    /// Tous les relevés d'une rencontre, du plus ancien au plus récent.
    pub fn fixture_series(&self, fixture_key: &str) -> Result<Vec<SnapshotRow>, String> {
        let mut rows: Vec<SnapshotRow> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT * FROM snapshots WHERE fixture_key = ? ORDER BY captured_at ASC",
                    vec![json!(fixture_key)],
                )?
                .iter()
                .map(row_to_snapshot)
                .collect(),
            None => self
                .read_local_snapshots()
                .into_iter()
                .filter(|row| row.fixture_key == fixture_key)
                .collect(),
        };
        rows.sort_by(|a, b| a.captured_at.cmp(&b.captured_at));
        Ok(rows)
    }

    /// Dernier relevé de chaque sélection avant une heure donnée (la clôture).
    pub fn last_before(
        &self,
        fixture_key: &str,
        before: &str,
    ) -> Result<Vec<SnapshotRow>, String> {
        // `captured_at` est stocké en RFC 3339 UTC alors que `before` vient de
        // la date Arbworld, qui peut être au format « AAAA-MM-JJ HH:MM:SS ».
        // Comparer les chaînes excluait alors tous les relevés ('T' > ' ') et
        // le CLV restait vide en production. On compare des horodatages, avec
        // repli sur la comparaison textuelle quand une date est illisible.
        let limit = crate::enrich::parse_kickoff(before);
        // Le seuil est poussé dans la requête : sans lui, noter un signal
        // relisait **tous** les relevés de la rencontre sur 14 jours.
        let iso = limit
            .as_ref()
            .map(|at| at.to_rfc3339_opts(chrono::SecondsFormat::Secs, true));
        let mut rows: Vec<SnapshotRow> = match &self.d1 {
            Some((cf, db)) => match iso {
                Some(cutoff) => cf.d1_query(
                    db,
                    "SELECT * FROM snapshots WHERE fixture_key = ? AND captured_at <= ?
                     ORDER BY captured_at DESC",
                    vec![json!(fixture_key), json!(cutoff)],
                )?,
                None => cf.d1_query(
                    db,
                    "SELECT * FROM snapshots WHERE fixture_key = ? ORDER BY captured_at DESC",
                    vec![json!(fixture_key)],
                )?,
            }
            .iter()
            .map(row_to_snapshot)
            .collect(),
            None => self
                .read_local_snapshots()
                .into_iter()
                .filter(|row| row.fixture_key == fixture_key)
                .collect(),
        };
        rows.retain(|row| match (crate::enrich::parse_kickoff(&row.captured_at), limit) {
            (Some(at), Some(limit)) => at <= limit,
            _ => row.captured_at.as_str() <= before,
        });
        rows.sort_by(|a, b| b.captured_at.cmp(&a.captured_at));
        let mut seen = std::collections::HashSet::new();
        Ok(rows
            .into_iter()
            .filter(|row| seen.insert(row.selection_key()))
            .collect())
    }

    fn read_local_snapshots(&self) -> Vec<SnapshotRow> {
        std::fs::read_to_string(self.local_path("snapshots.json"))
            .ok()
            .and_then(|raw| serde_json::from_str(&raw).ok())
            .unwrap_or_default()
    }

    fn write_local_snapshots(&self, rows: &[SnapshotRow]) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let raw = serde_json::to_string(rows).map_err(|e| e.to_string())?;
        self.write_atomic("snapshots.json", &raw)
    }

    fn local_path(&self, name: &str) -> PathBuf {
        self.local_dir.join(name)
    }

    /// Écriture atomique en mode local : une interruption pendant l'écriture
    /// ne doit jamais laisser un fichier tronqué (donc un historique perdu).
    fn write_atomic(&self, name: &str, raw: &str) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let target = self.local_path(name);
        let tmp = target.with_extension(format!("{}.tmp", std::process::id()));
        std::fs::write(&tmp, raw).map_err(|e| e.to_string())?;
        std::fs::rename(&tmp, &target).map_err(|e| e.to_string())
    }

    pub fn load_snapshot(&self) -> Option<Snapshot> {
        let raw = match &self.kv {
            Some((cf, kv)) => cf.kv_get(kv, SNAPSHOT_KEY).ok().flatten(),
            None => std::fs::read_to_string(self.local_path("snapshot.json")).ok(),
        }?;
        serde_json::from_str(&raw).ok()
    }

    pub fn save_snapshot(&self, snapshot: &Snapshot) -> Result<(), String> {
        let raw = serde_json::to_string(snapshot).map_err(|e| e.to_string())?;
        match &self.kv {
            Some((cf, kv)) => cf.kv_put(kv, SNAPSHOT_KEY, &raw),
            None => {
                std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
                self.write_atomic("snapshot.json", &raw)
            }
        }
    }

    /// Identifiants de signaux déjà alertés. Une clé KV, ou un petit fichier
    /// en local : rien à voir avec l'historique D1.
    pub fn load_alerted(&self) -> Vec<String> {
        let raw = match &self.kv {
            Some((cf, kv)) => cf.kv_get(kv, ALERTS_KEY).ok().flatten(),
            None => std::fs::read_to_string(self.local_path("alerts.json")).ok(),
        };
        raw.and_then(|text| serde_json::from_str(&text).ok())
            .unwrap_or_default()
    }

    pub fn save_alerted(&self, ids: &[String]) -> Result<(), String> {
        let raw = serde_json::to_string(ids).map_err(|e| e.to_string())?;
        match &self.kv {
            Some((cf, kv)) => cf.kv_put(kv, ALERTS_KEY, &raw),
            None => {
                std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
                self.write_atomic("alerts.json", &raw)
            }
        }
    }

    /// Enregistre les signaux **flagués** du cycle (jamais les neutres).
    ///
    /// La ligne est figée à sa première détection : `first_seen`, cote d'entrée
    /// et propositions ne bougent plus, sinon le ROI et le CLV changeraient
    /// d'un cycle à l'autre. Seul `last_seen` est rafraîchi.
    pub fn upsert_signals(&self, signals: &[Signal], now: &str) -> Result<(), String> {
        let flagged: Vec<&Signal> = signals
            .iter()
            .filter(|sig| sig.kind.flagged())
            .collect();
        match &self.d1 {
            Some((cf, db)) => {
                for sig in flagged {
                    // Coup d'envoi passé : la ligne reste telle qu'elle a été
                    // enregistrée (pari pris ou abstention).
                    if crate::signals::has_started(&sig.date, now) {
                        continue;
                    }
                    let value_play = serde_json::to_string(&sig.value.play).unwrap_or_default();
                    let safety_play = serde_json::to_string(&sig.safety.play).unwrap_or_default();
                    let proposals = serde_json::to_string(&sig.proposals).unwrap_or_default();
                    cf.d1_query(
                        db,
                        "INSERT INTO signals (id, first_seen, last_seen, match_date, home, away, league,
                            category, convergence_score, value_play, value_label, value_odds,
                            safety_play, safety_label, safety_odds, fixture_key, signal_kind,
                            proposals, signal_family, minutes_before_kickoff, liquidity_tier, confidence)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                         ON CONFLICT(id) DO UPDATE SET
                            last_seen = excluded.last_seen,
                            confidence = CASE WHEN signals.confidence = ''
                                              THEN excluded.confidence
                                              ELSE signals.confidence END",
                        vec![
                            json!(sig.id),
                            json!(now),
                            json!(now),
                            json!(sig.date),
                            json!(sig.home),
                            json!(sig.away),
                            json!(sig.league),
                            json!(sig.category.label()),
                            json!(sig.convergence_score),
                            json!(value_play),
                            json!(sig.value.label),
                            json!(sig.value.odds),
                            json!(safety_play),
                            json!(sig.safety.label),
                            json!(sig.safety.odds),
                            json!(sig.fixture_key),
                            json!(sig.kind.key()),
                            json!(proposals),
                            json!(sig.families.first().cloned().unwrap_or_default()),
                            json!(crate::pipeline::minutes_before_kickoff(&sig.date, now)),
                            json!(sig.liquidity_tier.key()),
                            json!(sig.confidence.label()),
                        ],
                    )?;
                }
                Ok(())
            }
            _ => {
                let mut existing = self.read_local_signals();
                for sig in flagged {
                    if crate::signals::has_started(&sig.date, now) {
                        continue;
                    }
                    if let Some(row) = existing.iter_mut().find(|r| r.id == sig.id) {
                        // Cote d'entrée, catégorie et propositions sont figées
                        // à la première détection. La confiance manquante d'une
                        // ligne antérieure à sa persistance est complétée.
                        row.last_seen = now.to_string();
                        if row.confidence.is_none() {
                            row.confidence = Some(sig.confidence);
                        }
                    } else {
                        existing.push(TrackedSignal {
                            id: sig.id.clone(),
                            first_seen: now.to_string(),
                            last_seen: now.to_string(),
                            date: sig.date.clone(),
                            home: sig.home.clone(),
                            away: sig.away.clone(),
                            league: sig.league.clone(),
                            category: sig.category.label().to_string(),
                            convergence_score: sig.convergence_score,
                            value: sig.value.clone(),
                            safety: sig.safety.clone(),
                            value_outcome: BetOutcome::Pending,
                            safety_outcome: BetOutcome::Pending,
                            value_explanation: String::new(),
                            home_score: None,
                            away_score: None,
                            graded_at: None,
                            fixture_key: sig.fixture_key.clone(),
                            kind: sig.kind.key().to_string(),
                            confidence: Some(sig.confidence),
                            proposals: sig.proposals.clone(),
                            closing_odds: None,
                            clv_pct: None,
                            clv_novig_pct: None,
                            signal_family: sig.families.first().cloned().unwrap_or_default(),
                            minutes_before_kickoff: crate::pipeline::minutes_before_kickoff(
                                &sig.date,
                                now,
                            ),
                            liquidity_tier: sig.liquidity_tier.key().to_string(),
                        });
                    }
                }
                self.write_local_signals(&existing)
            }
        }
    }

    /// Signaux encore ouverts, les **plus récents d'abord**.
    ///
    /// L'ancien tri ascendant laissait les signaux vieux et irrécupérables
    /// occuper tout le quota (300) : les rencontres de la veille n'étaient
    /// jamais notées. Les anciens restent tentables quand il reste de la place.
    pub fn pending_signals(&self, limit: usize) -> Result<Vec<TrackedSignal>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT * FROM signals WHERE value_outcome IN ('PENDING', 'UNKNOWN')
                     ORDER BY match_date DESC LIMIT ?",
                    vec![json!(limit as i64)],
                )?;
                Ok(collapse_duplicates(
                    rows.iter().map(row_to_tracked).collect(),
                ))
            }
            _ => {
                let mut rows = self.read_local_signals();
                rows.retain(|r| {
                    matches!(r.value_outcome, BetOutcome::Pending | BetOutcome::Unknown)
                });
                let mut rows = collapse_duplicates(rows);
                rows.sort_by(|a, b| b.date.cmp(&a.date));
                rows.truncate(limit);
                Ok(rows)
            }
        }
    }

    pub fn save_grade(&self, row: &TrackedSignal) -> Result<(), String> {
        match &self.d1 {
            Some((cf, db)) => {
                cf.d1_query(
                    db,
                    "UPDATE signals SET value_outcome = ?, safety_outcome = ?, value_explanation = ?,
                        home_score = ?, away_score = ?, graded_at = ?, proposals = ?,
                        closing_odds = ?, clv_pct = ?, clv_novig_pct = ? WHERE id = ?",
                    vec![
                        json!(outcome_str(row.value_outcome)),
                        json!(outcome_str(row.safety_outcome)),
                        json!(row.value_explanation),
                        json!(row.home_score),
                        json!(row.away_score),
                        json!(row.graded_at),
                        json!(serde_json::to_string(&row.proposals).unwrap_or_default()),
                        json!(row.closing_odds),
                        json!(row.clv_pct),
                        json!(row.clv_novig_pct),
                        json!(row.id),
                    ],
                )?;
                Ok(())
            }
            _ => {
                let mut rows = self.read_local_signals();
                if let Some(existing) = rows.iter_mut().find(|r| r.id == row.id) {
                    *existing = row.clone();
                } else {
                    rows.push(row.clone());
                }
                self.write_local_signals(&rows)
            }
        }
    }

    pub fn recent_signals(&self, limit: usize) -> Result<Vec<TrackedSignal>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT * FROM signals ORDER BY match_date DESC, first_seen DESC LIMIT ?",
                    vec![json!(limit as i64)],
                )?;
                Ok(collapse_duplicates(
                    rows.iter().map(row_to_tracked).collect(),
                ))
            }
            _ => {
                let mut rows = self.read_local_signals();
                rows.sort_by(|a, b| b.date.cmp(&a.date));
                rows.truncate(limit);
                Ok(collapse_duplicates(rows))
            }
        }
    }

    /// Historique et statistiques dérivées (lecture unique par cache).
    ///
    /// Chaque chargement d'onglet relisait jusqu'à 2 000 lignes pour afficher
    /// les mêmes chiffres ; le cache borne cette lecture à une par
    /// `STATS_CACHE_TTL_SECS`, et `invalidate_stats` le vide après écriture.
    fn stats_cache(&self) -> std::sync::MutexGuard<'_, Option<StatsCache>> {
        let mut guard = self.stats.lock().unwrap();
        let fresh = guard
            .as_ref()
            .map(|cache| cache.at.elapsed().as_secs() < crate::thresholds::STATS_CACHE_TTL_SECS)
            .unwrap_or(false);
        if !fresh {
            let rows = self.recent_signals(2_000).unwrap_or_default();
            let bundle = crate::track::stats(&rows);
            *guard = Some(StatsCache {
                at: std::time::Instant::now(),
                rows,
                bundle,
            });
        }
        guard
    }

    /// Oublie le cache : la prochaine lecture relira l'historique.
    pub fn invalidate_stats(&self) {
        self.stats.lock().unwrap().take();
    }

    /// Alimente le cache avec un historique déjà lu par l'appelant.
    ///
    /// La collecte relisait 2 000 signaux pour le journal des rencontres puis
    /// une seconde fois pour le bilan : une seule lecture suffit, et le cache
    /// évite la troisième.
    pub fn prime_stats(&self, rows: Vec<TrackedSignal>) {
        let bundle = crate::track::stats(&rows);
        *self.stats.lock().unwrap() = Some(StatsCache {
            at: std::time::Instant::now(),
            rows,
            bundle,
        });
    }

    /// Les `limit` signaux les plus récents, servis depuis le cache
    /// statistiques quand il est chaud.
    ///
    /// L'interface et le bloc `v2` relisaient 200 à 400 lignes à chaque appel
    /// alors que la même liste était déjà en mémoire.
    pub fn recent_cached(&self, limit: usize) -> Vec<TrackedSignal> {
        let cached = self.stats_cache();
        match cached.as_ref() {
            Some(cache) => cache.rows.iter().take(limit).cloned().collect(),
            None => Vec::new(),
        }
    }

    pub fn track_record(&self) -> TrackRecord {        let rows = self
            .stats_cache()
            .as_ref()
            .map(|cache| cache.rows.clone())
            .unwrap_or_default();
        compute_track_record(&rows)
    }

    /// Statistiques par groupe de marché et par type de signal (chantier 8).
    pub fn signal_stats(&self) -> crate::track::StatsBundle {
        self.stats_cache()
            .as_ref()
            .map(|cache| cache.bundle.clone())
            .unwrap_or_default()
    }

    /// Enregistre les rencontres du cycle **sans écraser** un score déjà connu
    /// ni rétrograder un état terminal (mêmes règles que l'`UPSERT` D1).
    pub fn upsert_match_log(&self, rows: &[MatchLogRow]) -> Result<(), String> {
        if rows.is_empty() {
            return Ok(());
        }
        match &self.d1 {
            Some((cf, db)) => {
                // Une seule lecture pour ne réécrire que ce qui change. Sans
                // ce filtre, chaque collecte réécrivait ~400 lignes identiques
                // (une par rencontre des 7 derniers jours) : c'était le plus
                // gros poste d'écriture D1, tout près des 100 k par jour.
                let since = rows
                    .iter()
                    .map(|r| r.day.as_str())
                    .min()
                    .unwrap_or_default()
                    .to_string();
                let existing = if since.len() == 10 {
                    self.match_log_since(&since, 5_000).unwrap_or_default()
                } else {
                    Vec::new()
                };
                for row in rows {
                    let current = existing.iter().find(|e| {
                        e.fixture_key == row.fixture_key && e.match_date == row.match_date
                    });
                    if current.map(|c| !merge_changes(c, row)).unwrap_or(false) {
                        continue;
                    }
                    cf.d1_query(
                        db,
                        "INSERT INTO match_log (fixture_key, match_date, day, home, away, league,
                            kind, flagged, state, status_detail, home_score, away_score, source, updated_at,
                            metrics)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                         ON CONFLICT(fixture_key, match_date) DO UPDATE SET
                            day = excluded.day,
                            home = excluded.home,
                            away = excluded.away,
                            league = CASE WHEN excluded.league != '' THEN excluded.league
                                          ELSE match_log.league END,
                            kind = CASE WHEN excluded.flagged = 1 AND excluded.kind != ''
                                        THEN excluded.kind ELSE match_log.kind END,
                            flagged = MAX(match_log.flagged, excluded.flagged),
                            state = CASE WHEN match_log.state IN ('FINISHED', 'POSTPONED', 'CANCELLED')
                                         THEN match_log.state ELSE excluded.state END,
                            status_detail = CASE WHEN match_log.state IN ('FINISHED', 'POSTPONED', 'CANCELLED')
                                                 THEN match_log.status_detail ELSE excluded.status_detail END,
                            home_score = COALESCE(match_log.home_score, excluded.home_score),
                            away_score = COALESCE(match_log.away_score, excluded.away_score),
                            source = CASE WHEN match_log.source != '' THEN match_log.source
                                          ELSE excluded.source END,
                            metrics = CASE WHEN excluded.metrics != '' THEN excluded.metrics
                                           ELSE match_log.metrics END,
                            updated_at = excluded.updated_at",
                        vec![
                            json!(row.fixture_key),
                            json!(row.match_date),
                            json!(row.day),
                            json!(row.home),
                            json!(row.away),
                            json!(row.league),
                            json!(row.kind),
                            json!(if row.flagged { 1i64 } else { 0i64 }),
                            json!(crate::daily::state_key(row.state)),
                            json!(row.status_detail),
                            json!(row.home_score),
                            json!(row.away_score),
                            json!(row.source),
                            json!(row.updated_at),
                            json!(metrics_json(row)),
                        ],
                    )?;
                }
                Ok(())
            }
            None => {
                let mut existing = self.read_local_match_log();
                for row in rows {
                    merge_match_log(&mut existing, row);
                }
                self.write_local_match_log(&existing)
            }
        }
    }

    /// Écrit un score ou un état nouvellement connu. Aucune insertion : la
    /// rencontre doit déjà figurer au journal.
    pub fn update_match_results(&self, rows: &[MatchLogRow]) -> Result<(), String> {
        if rows.is_empty() {
            return Ok(());
        }
        match &self.d1 {
            Some((cf, db)) => {
                for row in rows {
                    cf.d1_query(
                        db,
                        "UPDATE match_log SET state = ?, status_detail = ?, home_score = ?,
                            away_score = ?, source = ?, updated_at = ?
                         WHERE fixture_key = ? AND match_date = ?",
                        vec![
                            json!(crate::daily::state_key(row.state)),
                            json!(row.status_detail),
                            json!(row.home_score),
                            json!(row.away_score),
                            json!(row.source),
                            json!(row.updated_at),
                            json!(row.fixture_key),
                            json!(row.match_date),
                        ],
                    )?;
                }
                Ok(())
            }
            None => {
                let mut existing = self.read_local_match_log();
                for row in rows {
                    if let Some(current) = existing
                        .iter_mut()
                        .find(|r| r.fixture_key == row.fixture_key && r.match_date == row.match_date)
                    {
                        current.state = row.state;
                        current.status_detail = row.status_detail.clone();
                        current.home_score = row.home_score;
                        current.away_score = row.away_score;
                        current.source = row.source.clone();
                        current.updated_at = row.updated_at.clone();
                    }
                }
                self.write_local_match_log(&existing)
            }
        }
    }

    /// Rencontres enregistrées pour une journée (UTC), par heure de coup d'envoi.
    pub fn match_log_day(&self, day: &str) -> Result<Vec<MatchLogRow>, String> {
        let mut rows: Vec<MatchLogRow> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT * FROM match_log WHERE day = ? ORDER BY match_date ASC",
                    vec![json!(day)],
                )?
                .iter()
                .map(row_to_match_log)
                .collect(),
            None => self
                .read_local_match_log()
                .into_iter()
                .filter(|row| row.day == day)
                .collect(),
        };
        rows.sort_by(|a, b| a.match_date.cmp(&b.match_date));
        Ok(rows)
    }

    /// Journées présentes au journal, de la plus récente à la plus ancienne.
    pub fn match_log_days(&self, limit: usize) -> Result<Vec<String>, String> {
        let mut days: Vec<String> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT DISTINCT day FROM match_log WHERE day != ''
                     ORDER BY day DESC LIMIT ?",
                    vec![json!(limit as i64)],
                )?
                .iter()
                .map(|row| s(row, "day"))
                .collect(),
            None => self
                .read_local_match_log()
                .into_iter()
                .map(|row| row.day)
                .filter(|day| !day.is_empty())
                .collect(),
        };
        days.sort_by(|a, b| b.cmp(a));
        days.dedup();
        days.truncate(limit);
        Ok(days)
    }

    /// Rencontres dont le score final n'est pas encore connu, depuis `since_day`.
    pub fn open_match_log(&self, since_day: &str) -> Result<Vec<MatchLogRow>, String> {
        let terminal = |state: MatchState| {
            matches!(
                state,
                MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
            )
        };
        let mut rows: Vec<MatchLogRow> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT * FROM match_log WHERE day >= ?
                     AND state NOT IN ('FINISHED', 'POSTPONED', 'CANCELLED')
                     ORDER BY match_date ASC",
                    vec![json!(since_day)],
                )?
                .iter()
                .map(row_to_match_log)
                .collect(),
            None => self
                .read_local_match_log()
                .into_iter()
                .filter(|row| row.day.as_str() >= since_day && !terminal(row.state))
                .collect(),
        };
        rows.sort_by(|a, b| a.match_date.cmp(&b.match_date));
        Ok(rows)
    }

    /// Rencontres journalisées depuis `since_day`, quel que soit leur état.
    ///
    /// Sert au backtest : on y compare **toutes** les rencontres suivies, pas
    /// seulement celles qui portaient un pari.
    pub fn match_log_since(
        &self,
        since_day: &str,
        limit: usize,
    ) -> Result<Vec<MatchLogRow>, String> {
        let mut rows: Vec<MatchLogRow> = match &self.d1 {
            Some((cf, db)) => cf
                .d1_query(
                    db,
                    "SELECT * FROM match_log WHERE day >= ? ORDER BY day ASC LIMIT ?",
                    vec![json!(since_day), json!(limit as i64)],
                )?
                .iter()
                .map(row_to_match_log)
                .collect(),
            None => self
                .read_local_match_log()
                .into_iter()
                .filter(|row| row.day.as_str() >= since_day)
                .collect(),
        };
        rows.sort_by(|a, b| a.day.cmp(&b.day).then_with(|| a.match_date.cmp(&b.match_date)));
        rows.truncate(limit);
        Ok(rows)
    }

    /// Positions de la simulation, les plus récentes d'abord.
    pub fn load_sim_positions(&self, limit: usize) -> Result<Vec<SimPosition>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT * FROM sim_positions ORDER BY opened_at DESC LIMIT ?",
                    vec![json!(limit as i64)],
                )?;
                Ok(rows.iter().map(row_to_sim_position).collect())
            }
            None => {
                let mut rows = self.read_local_sim_positions();
                rows.sort_by(|a, b| b.opened_at.cmp(&a.opened_at));
                rows.truncate(limit);
                Ok(rows)
            }
        }
    }

    /// Positions encore ouvertes, sans plafond d'historique. Le nombre est
    /// borné par la règle des 10 positions, pas par une limite de requête.
    pub fn load_open_sim_positions(&self) -> Result<Vec<SimPosition>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT * FROM sim_positions WHERE status = 'OPEN' ORDER BY opened_at ASC",
                    Vec::new(),
                )?;
                Ok(rows.iter().map(row_to_sim_position).collect())
            }
            None => {
                let mut rows: Vec<SimPosition> = self
                    .read_local_sim_positions()
                    .into_iter()
                    .filter(|position| position.is_open())
                    .collect();
                rows.sort_by(|a, b| a.opened_at.cmp(&b.opened_at));
                Ok(rows)
            }
        }
    }

    /// Candidats de simulation en attente d'une place.
    pub fn load_sim_candidates(&self) -> Result<Vec<SimPosition>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT payload FROM sim_candidates ORDER BY match_date ASC",
                    Vec::new(),
                )?;
                Ok(rows
                    .iter()
                    .filter_map(|row| {
                        row.get("payload")
                            .and_then(Value::as_str)
                            .and_then(|raw| serde_json::from_str(raw).ok())
                    })
                    .collect())
            }
            None => Ok(self.read_local_sim_candidates()),
        }
    }

    /// Enregistre les candidats éligibles, sans réécrire ceux qui sont
    /// identiques, et purge ceux dont le coup d'envoi est passé depuis plus
    /// d'une heure. Le signal peut ainsi disparaître du flux ou attendre une
    /// place sans perdre sa chance d'ouverture avant le coup d'envoi.
    pub fn save_sim_candidates(&self, candidates: &[SimPosition], now: &str) -> Result<(), String> {
        let cutoff = (Utc::now() - chrono::Duration::hours(1))
            .format("%Y-%m-%d %H:%M:%S")
            .to_string();
        match &self.d1 {
            Some((cf, db)) => {
                for candidate in candidates {
                    let payload = serde_json::to_string(candidate).map_err(|e| e.to_string())?;
                    // Colonne normalisée : la comparaison textuelle de la purge
                    // ne doit pas dépendre du format reçu (`T` ou espace).
                    let kickoff = normalized_kickoff(&candidate.match_date);
                    cf.d1_query(
                        db,
                        "INSERT INTO sim_candidates (id, payload, match_date, created_at)
                         VALUES (?, ?, ?, ?)
                         ON CONFLICT(id) DO UPDATE SET
                            payload = excluded.payload,
                            match_date = excluded.match_date
                         WHERE sim_candidates.payload != excluded.payload",
                        vec![
                            json!(candidate.id),
                            json!(payload),
                            json!(kickoff),
                            json!(now),
                        ],
                    )?;
                }
                cf.d1_query(
                    db,
                    "DELETE FROM sim_candidates WHERE match_date < ?",
                    vec![json!(cutoff)],
                )?;
                Ok(())
            }
            None => {
                let mut by_id: HashMap<String, SimPosition> = self
                    .read_local_sim_candidates()
                    .into_iter()
                    .map(|candidate| (candidate.id.clone(), candidate))
                    .collect();
                for candidate in candidates {
                    by_id.insert(candidate.id.clone(), candidate.clone());
                }
                let kept: Vec<SimPosition> = by_id
                    .into_values()
                    .filter(|candidate| {
                        normalized_kickoff(&candidate.match_date).as_str() >= cutoff.as_str()
                    })
                    .collect();
                self.write_local_sim_candidates(&kept)
            }
        }
    }

    /// Retire les candidats devenus des positions : sans cela, un match reporté
    /// avant son coup d'envoi reste réouvrable puis re-rendu `VOID` à chaque
    /// cycle, gonflant le bilan et consommant une place.
    pub fn delete_sim_candidates(&self, ids: &[String]) -> Result<(), String> {
        if ids.is_empty() {
            return Ok(());
        }
        match &self.d1 {
            Some((cf, db)) => {
                for id in ids {
                    cf.d1_query(
                        db,
                        "DELETE FROM sim_candidates WHERE id = ?",
                        vec![json!(id)],
                    )?;
                }
                Ok(())
            }
            None => {
                let kept: Vec<SimPosition> = self
                    .read_local_sim_candidates()
                    .into_iter()
                    .filter(|candidate| !ids.contains(&candidate.id))
                    .collect();
                self.write_local_sim_candidates(&kept)
            }
        }
    }

    /// Historique détaillé limité pour l'affichage. Les totaux, eux, sont
    /// calculés par `sim_totals` sur toutes les lignes.
    pub fn load_sim_history(&self, limit: usize) -> Result<Vec<SimPosition>, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT * FROM sim_positions WHERE status != 'OPEN'
                     ORDER BY opened_at DESC LIMIT ?",
                    vec![json!(limit as i64)],
                )?;
                Ok(rows.iter().map(row_to_sim_position).collect())
            }
            None => {
                let mut rows: Vec<SimPosition> = self
                    .read_local_sim_positions()
                    .into_iter()
                    .filter(|position| !position.is_open())
                    .collect();
                rows.sort_by(|a, b| b.opened_at.cmp(&a.opened_at));
                rows.truncate(limit);
                Ok(rows)
            }
        }
    }

    /// Agrégat de tout l'historique réglé. Un statut inconnu est compté comme
    /// annulé, jamais comme une position ouverte.
    pub fn sim_totals(&self) -> Result<SimTotals, String> {
        match &self.d1 {
            Some((cf, db)) => {
                let rows = cf.d1_query(
                    db,
                    "SELECT CASE WHEN status IN ('WON', 'LOST', 'PUSH') THEN status
                                  ELSE 'VOID' END AS status,
                            COUNT(*) AS n,
                            COALESCE(SUM(pnl), 0) AS pnl,
                            COALESCE(SUM(CASE WHEN status IN ('WON', 'LOST', 'PUSH')
                                              THEN stake ELSE 0 END), 0) AS risked
                     FROM sim_positions
                     WHERE status != 'OPEN'
                     GROUP BY 1",
                    Vec::new(),
                )?;
                let mut totals = SimTotals::default();
                for row in &rows {
                    let n = i(row, "n").unwrap_or(0) as usize;
                    match s(row, "status").as_str() {
                        "WON" => totals.won = n,
                        "LOST" => totals.lost = n,
                        "PUSH" => totals.push = n,
                        _ => totals.void = n,
                    }
                    totals.realized_pnl += f(row, "pnl").unwrap_or(0.0);
                    totals.risked += f(row, "risked").unwrap_or(0.0);
                }
                totals.settled = totals.won + totals.lost + totals.push + totals.void;
                Ok(totals)
            }
            None => {
                let closed: Vec<SimPosition> = self
                    .read_local_sim_positions()
                    .into_iter()
                    .filter(|position| !position.is_open())
                    .collect();
                Ok(crate::simulation::totals(&closed))
            }
        }
    }

    /// Crée ou met à jour des positions. L'identifiant est stable, donc une
    /// nouvelle collecte ne duplique jamais une entrée.
    pub fn save_sim_positions(&self, positions: &[SimPosition]) -> Result<(), String> {
        if positions.is_empty() {
            return Ok(());
        }
        match &self.d1 {
            Some((cf, db)) => {
                for position in positions {
                    cf.d1_query(
                        db,
                        "INSERT INTO sim_positions (id, signal_id, fixture_key, match_date, day,
                            home, away, league, kind, grp, market, pick, entry_odds, stake, play,
                            opened_at, minutes_before_kickoff, status, settled_at, pnl,
                            home_score, away_score, note)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                         ON CONFLICT(id) DO UPDATE SET
                            status = excluded.status,
                            settled_at = excluded.settled_at,
                            pnl = excluded.pnl,
                            home_score = excluded.home_score,
                            away_score = excluded.away_score,
                            note = excluded.note",
                        vec![
                            json!(position.id),
                            json!(position.signal_id),
                            json!(position.fixture_key),
                            json!(position.match_date),
                            json!(position.day),
                            json!(position.home),
                            json!(position.away),
                            json!(position.league),
                            json!(position.kind),
                            json!(position.group),
                            json!(position.market),
                            json!(position.pick),
                            json!(position.odds),
                            json!(position.stake),
                            json!(serde_json::to_string(&position.play).unwrap_or_default()),
                            json!(position.opened_at),
                            json!(position.minutes_before_kickoff),
                            json!(position.status.key()),
                            json!(position.settled_at),
                            json!(position.pnl),
                            json!(position.home_score),
                            json!(position.away_score),
                            json!(position.note),
                        ],
                    )?;
                }
                Ok(())
            }
            None => {
                let mut existing = self.read_local_sim_positions();
                for position in positions {
                    if let Some(current) = existing.iter_mut().find(|row| row.id == position.id) {
                        *current = position.clone();
                    } else {
                        existing.push(position.clone());
                    }
                }
                self.write_local_sim_positions(&existing)
            }
        }
    }

    fn read_local_match_log(&self) -> Vec<MatchLogRow> {
        std::fs::read_to_string(self.local_path("match_log.json"))
            .ok()
            .and_then(|raw| serde_json::from_str(&raw).ok())
            .unwrap_or_default()
    }

    fn write_local_match_log(&self, rows: &[MatchLogRow]) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let raw = serde_json::to_string(rows).map_err(|e| e.to_string())?;
        self.write_atomic("match_log.json", &raw)
    }

    fn read_local_sim_positions(&self) -> Vec<SimPosition> {
        std::fs::read_to_string(self.local_path("simulation.json"))
            .ok()
            .and_then(|raw| serde_json::from_str(&raw).ok())
            .unwrap_or_default()
    }

    fn write_local_sim_positions(&self, rows: &[SimPosition]) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let raw = serde_json::to_string_pretty(rows).map_err(|e| e.to_string())?;
        self.write_atomic("simulation.json", &raw)
    }

    fn read_local_sim_candidates(&self) -> Vec<SimPosition> {
        std::fs::read_to_string(self.local_path("sim_candidates.json"))
            .ok()
            .and_then(|raw| serde_json::from_str(&raw).ok())
            .unwrap_or_default()
    }

    fn write_local_sim_candidates(&self, rows: &[SimPosition]) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let raw = serde_json::to_string_pretty(rows).map_err(|e| e.to_string())?;
        self.write_atomic("sim_candidates.json", &raw)
    }

    fn read_local_signals(&self) -> Vec<TrackedSignal> {
        std::fs::read_to_string(self.local_path("signals.json"))
            .ok()
            .and_then(|raw| serde_json::from_str(&raw).ok())
            .unwrap_or_default()
    }

    fn write_local_signals(&self, rows: &[TrackedSignal]) -> Result<(), String> {
        std::fs::create_dir_all(&self.local_dir).map_err(|e| e.to_string())?;
        let raw = serde_json::to_string_pretty(rows).map_err(|e| e.to_string())?;
        self.write_atomic("signals.json", &raw)
    }
}

fn row_to_snapshot(row: &Value) -> SnapshotRow {
    SnapshotRow {
        market_key: s(row, "market_key"),
        market_id: i(row, "market_id").unwrap_or(0),
        selection_id: i(row, "selection_id").unwrap_or(0),
        fixture_key: s(row, "fixture_key"),
        captured_at: s(row, "captured_at"),
        coef: [
            f(row, "coef_new_1").unwrap_or(0.0),
            f(row, "coef_new_x").unwrap_or(0.0),
            f(row, "coef_new_2").unwrap_or(0.0),
        ],
        volume: [
            f(row, "volume_1").unwrap_or(0.0),
            f(row, "volume_x").unwrap_or(0.0),
            f(row, "volume_2").unwrap_or(0.0),
        ],
        total_volume: f(row, "total_volume").unwrap_or(0.0),
        kickoff: s(row, "kickoff"),
    }
}

/// Date de coup d'envoi canonique pour la purge des candidats : les relevés
/// peuvent arriver en RFC 3339 (`T…Z`) ou au format espace, la comparaison
/// textuelle doit porter sur une representation unique.
fn normalized_kickoff(raw: &str) -> String {
    parse_kickoff(raw)
        .map(|date| date.format("%Y-%m-%d %H:%M:%S").to_string())
        .unwrap_or_else(|| raw.to_string())
}

fn row_to_sim_position(row: &Value) -> SimPosition {
    SimPosition {
        id: s(row, "id"),
        signal_id: s(row, "signal_id"),
        fixture_key: s(row, "fixture_key"),
        match_date: s(row, "match_date"),
        day: s(row, "day"),
        home: s(row, "home"),
        away: s(row, "away"),
        league: s(row, "league"),
        kind: s(row, "kind"),
        group: s(row, "grp"),
        market: s(row, "market"),
        pick: s(row, "pick"),
        odds: f(row, "entry_odds").unwrap_or(0.0),
        stake: f(row, "stake").unwrap_or(crate::thresholds::SIM_STAKE_POINTS),
        play: serde_json::from_str(&s(row, "play")).unwrap_or(crate::model::Play::NoBet),
        opened_at: s(row, "opened_at"),
        minutes_before_kickoff: i(row, "minutes_before_kickoff").unwrap_or(0),
        status: SimStatus::from_key(&s(row, "status")),
        settled_at: row
            .get("settled_at")
            .and_then(|value| value.as_str())
            .map(str::to_string),
        pnl: f(row, "pnl"),
        home_score: i(row, "home_score"),
        away_score: i(row, "away_score"),
        note: s(row, "note"),
    }
}

fn row_to_match_log(row: &Value) -> MatchLogRow {
    MatchLogRow {
        fixture_key: s(row, "fixture_key"),
        match_date: s(row, "match_date"),
        day: s(row, "day"),
        home: s(row, "home"),
        away: s(row, "away"),
        league: s(row, "league"),
        kind: s(row, "kind"),
        flagged: i(row, "flagged").unwrap_or(0) != 0,
        state: crate::daily::state_from(&s(row, "state")),
        status_detail: s(row, "status_detail"),
        home_score: i(row, "home_score"),
        away_score: i(row, "away_score"),
        source: s(row, "source"),
        metrics: serde_json::from_str(&s(row, "metrics")).ok(),
        updated_at: s(row, "updated_at"),
    }
}

/// Mesures de contexte sérialisées pour la colonne `metrics` (vide si absentes).
fn metrics_json(row: &MatchLogRow) -> String {
    row.metrics
        .as_ref()
        .and_then(|metrics| serde_json::to_string(metrics).ok())
        .unwrap_or_default()
}

/// Fusion locale d'une ligne de journal : un score connu n'est jamais effacé et
/// un état terminal n'est jamais rétrogradé.
fn merge_match_log(existing: &mut Vec<MatchLogRow>, row: &MatchLogRow) {
    let Some(current) = existing
        .iter_mut()
        .find(|r| r.fixture_key == row.fixture_key && r.match_date == row.match_date)
    else {
        existing.push(row.clone());
        return;
    };
    let terminal = matches!(
        current.state,
        MatchState::Finished | MatchState::Postponed | MatchState::Cancelled
    );
    if !terminal {
        current.state = row.state;
        current.status_detail = row.status_detail.clone();
    }
    if current.home_score.is_none() {
        current.home_score = row.home_score;
    }
    if current.away_score.is_none() {
        current.away_score = row.away_score;
    }
    if row.metrics.is_some() {
        current.metrics = row.metrics.clone();
    }
    if current.source.is_empty() {
        current.source = row.source.clone();
    }
    if row.flagged && !row.kind.is_empty() {
        current.kind = row.kind.clone();
    }
    current.flagged |= row.flagged;
    if !row.league.is_empty() {
        current.league = row.league.clone();
    }
    current.day = row.day.clone();
    current.updated_at = row.updated_at.clone();
}

/// Le merge modifierait-il vraiment la ligne existante ?
///
/// `updated_at` est volontairement ignoré : c'est un horodatage de dernière
/// **modification** réelle, pas de dernière collecte.
fn merge_changes(current: &MatchLogRow, row: &MatchLogRow) -> bool {
    let mut merged = vec![current.clone()];
    merge_match_log(&mut merged, row);
    let merged = &merged[0];
    merged.day != current.day
        || merged.home != current.home
        || merged.away != current.away
        || merged.league != current.league
        || merged.kind != current.kind
        || merged.flagged != current.flagged
        || merged.state != current.state
        || merged.status_detail != current.status_detail
        || merged.home_score != current.home_score
        || merged.away_score != current.away_score
        || merged.source != current.source
        || metrics_json(merged) != metrics_json(current)
}

fn row_to_tracked(row: &Value) -> TrackedSignal {    TrackedSignal {
        id: s(row, "id"),
        first_seen: s(row, "first_seen"),
        last_seen: s(row, "last_seen"),
        date: s(row, "match_date"),
        home: s(row, "home"),
        away: s(row, "away"),
        league: s(row, "league"),
        category: s(row, "category"),
        convergence_score: f(row, "convergence_score").unwrap_or(0.0),
        value: parse_play(
            &s(row, "value_play"),
            s(row, "value_label"),
            f(row, "value_odds"),
        ),
        safety: parse_play(
            &s(row, "safety_play"),
            s(row, "safety_label"),
            f(row, "safety_odds"),
        ),
        value_outcome: outcome(&s(row, "value_outcome")),
        safety_outcome: outcome(&s(row, "safety_outcome")),
        value_explanation: s(row, "value_explanation"),
        home_score: i(row, "home_score"),
        away_score: i(row, "away_score"),
        graded_at: row
            .get("graded_at")
            .and_then(|g| g.as_str())
            .map(str::to_string),
        fixture_key: s(row, "fixture_key"),
        kind: s(row, "signal_kind"),
        confidence: Confidence::from_label(&s(row, "confidence")),
        proposals: row
            .get("proposals")
            .and_then(|p| p.as_str())
            .and_then(|raw| serde_json::from_str(raw).ok())
            .unwrap_or_default(),
        closing_odds: f(row, "closing_odds"),
        clv_pct: f(row, "clv_pct"),
        clv_novig_pct: f(row, "clv_novig_pct"),
        signal_family: s(row, "signal_family"),
        minutes_before_kickoff: i(row, "minutes_before_kickoff"),
        liquidity_tier: s(row, "liquidity_tier"),
    }
}

/// Une seule ligne par affiche et par journée.
///
/// L'identifiant portait auparavant la catégorie du signal : quand le moteur
/// basculait de « neutre » à « convergence », la même rencontre créait une
/// seconde ligne et le bilan comptait deux fois le même pari. On conserve la
/// ligne notée si elle existe, sinon la plus récente.
fn collapse_duplicates(rows: Vec<TrackedSignal>) -> Vec<TrackedSignal> {
    use std::collections::HashMap;

    type Fixture = (String, String, String);
    let key = |row: &TrackedSignal| -> Fixture {
        (row.home.to_lowercase(), row.away.to_lowercase(), row.date.clone())
    };

    let mut graded: HashMap<Fixture, usize> = HashMap::new();
    let mut latest: HashMap<Fixture, usize> = HashMap::new();
    for (index, row) in rows.iter().enumerate() {
        if matches!(
            row.value_outcome,
            BetOutcome::Won | BetOutcome::Lost | BetOutcome::Push
        ) {
            graded.entry(key(row)).or_insert(index);
        }
        latest.insert(key(row), index);
    }

    rows.into_iter()
        .enumerate()
        .filter(|(index, row)| match graded.get(&key(row)) {
            Some(kept) => kept == index,
            None => latest.get(&key(row)) == Some(index),
        })
        .map(|(_, row)| row)
        .collect()
}

/// Bilan agrégé, ROI calculé sur une mise de 1 unité par pari.
pub fn compute_track_record(rows: &[TrackedSignal]) -> TrackRecord {
    let mut rec = TrackRecord {
        signals: rows.len(),
        ..Default::default()
    };
    let mut value_profit = 0.0;
    let mut safety_profit = 0.0;
    let mut per_category: std::collections::HashMap<String, (usize, usize, f64)> =
        std::collections::HashMap::new();

    for row in rows {
        let settled_value = matches!(
            row.value_outcome,
            BetOutcome::Won | BetOutcome::Lost | BetOutcome::Push
        );
        if settled_value {
            rec.settled_value += 1;
            match row.value_outcome {
                BetOutcome::Won => {
                    rec.value_won += 1;
                    value_profit += row.value.odds.unwrap_or(1.0) - 1.0;
                }
                BetOutcome::Lost => {
                    rec.value_lost += 1;
                    value_profit -= 1.0;
                }
                BetOutcome::Push => {
                    rec.value_push += 1;
                }
                _ => {}
            }
            let entry = per_category
                .entry(row.category.clone())
                .or_insert((0, 0, 0.0));
            entry.0 += 1;
            if row.value_outcome == BetOutcome::Won {
                entry.1 += 1;
                entry.2 += row.value.odds.unwrap_or(1.0) - 1.0;
            } else if row.value_outcome == BetOutcome::Lost {
                entry.2 -= 1.0;
            }
        }

        match row.safety_outcome {
            BetOutcome::Won => {
                rec.safety_won += 1;
                safety_profit += row.safety.odds.unwrap_or(1.0) - 1.0;
            }
            BetOutcome::Lost => {
                rec.safety_lost += 1;
                safety_profit -= 1.0;
            }
            _ => {}
        }
    }

    let decided = rec.value_won + rec.value_lost;
    rec.value_win_rate = if decided > 0 {
        rec.value_won as f64 / decided as f64 * 100.0
    } else {
        0.0
    };
    let safety_decided = rec.safety_won + rec.safety_lost;
    rec.safety_win_rate = if safety_decided > 0 {
        rec.safety_won as f64 / safety_decided as f64 * 100.0
    } else {
        0.0
    };
    if rec.settled_value > 0 {
        rec.value_roi = value_profit / rec.settled_value as f64 * 100.0;
    }
    if safety_decided > 0 {
        rec.safety_roi = safety_profit / safety_decided as f64 * 100.0;
    }

    rec.by_category = per_category
        .into_iter()
        .map(|(category, (settled, won, profit))| CategoryStats {
            category,
            settled,
            won,
            win_rate: if settled > 0 {
                won as f64 / settled as f64 * 100.0
            } else {
                0.0
            },
            roi: if settled > 0 {
                profit / settled as f64 * 100.0
            } else {
                0.0
            },
        })
        .collect();
    rec.by_category.sort_by(|a, b| b.settled.cmp(&a.settled));
    rec
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Play, Slot};
    use std::path::Path;

    fn row(outcome: BetOutcome, odds: f64, category: &str) -> TrackedSignal {
        TrackedSignal {
            id: "x".into(),
            first_seen: "2026-11-09T10:00:00Z".into(),
            last_seen: "2026-11-09T11:00:00Z".into(),
            date: "2026-11-09T20:00:00Z".into(),
            home: "A".into(),
            away: "B".into(),
            league: "L".into(),
            category: category.into(),
            convergence_score: 80.0,
            value: Recommendation {
                play: Play::TotalGoals {
                    line: 2.5,
                    over: true,
                },
                label: "Plus de 2.5 buts".into(),
                odds: Some(odds),
            },
            safety: Recommendation {
                play: Play::TotalGoals {
                    line: 1.5,
                    over: true,
                },
                label: "Plus de 1.5 buts".into(),
                odds: Some(1.3),
            },
            value_outcome: outcome,
            safety_outcome: BetOutcome::Won,
            value_explanation: String::new(),
            home_score: Some(2),
            away_score: Some(1),
            graded_at: None,
            fixture_key: "a_vs_b".into(),
            kind: "over".into(),
            confidence: Some(crate::model::Confidence::Moyen),
            proposals: Vec::new(),
            closing_odds: None,
            clv_pct: None,
            clv_novig_pct: None,
            signal_family: "Buts".into(),
            minutes_before_kickoff: Some(60),
            liquidity_tier: "HIGH".into(),
        }
    }

    #[test]
    fn roi_uses_real_odds() {
        let rows = vec![
            row(BetOutcome::Won, 2.0, "Convergence +buts"),
            row(BetOutcome::Lost, 2.0, "Convergence +buts"),
            row(BetOutcome::Push, 2.0, "Convergence +buts"),
        ];
        let rec = compute_track_record(&rows);
        assert_eq!(rec.settled_value, 3);
        assert_eq!(rec.value_won, 1);
        // (+1.0 - 1.0 + 0.0) / 3 * 100
        assert!((rec.value_roi - 0.0).abs() < 0.001);
        assert!((rec.value_win_rate - 50.0).abs() < 0.001);
    }

    #[test]
    fn duplicate_fixtures_are_counted_once() {
        let mut neutral = row(BetOutcome::Pending, 1.95, "Recoupement neutre");
        neutral.id = "sig_a_vs_b_neutral".into();
        let mut under = row(BetOutcome::Pending, 1.8, "Convergence -buts");
        under.id = "sig_a_vs_b_under".into();
        under.last_seen = "2026-11-09T12:00:00Z".into();

        let collapsed = collapse_duplicates(vec![neutral, under]);
        assert_eq!(collapsed.len(), 1, "une seule ligne par affiche");
        assert_eq!(collapsed[0].id, "sig_a_vs_b_under", "la plus récente gagne");
        assert_eq!(compute_track_record(&collapsed).signals, 1);
    }

    #[test]
    fn graded_row_wins_over_a_newer_pending_one() {
        let graded = row(BetOutcome::Won, 1.8, "Convergence -buts");
        let mut pending = row(BetOutcome::Pending, 1.7, "Recoupement neutre");
        pending.last_seen = "2026-11-09T23:00:00Z".into();

        let collapsed = collapse_duplicates(vec![graded, pending]);
        assert_eq!(collapsed.len(), 1);
        assert_eq!(collapsed[0].value_outcome, BetOutcome::Won);
    }

    fn log_row() -> MatchLogRow {
        MatchLogRow {
            fixture_key: "a_vs_b".into(),
            match_date: "2026-11-18 20:00:00".into(),
            day: "2026-11-18".into(),
            home: "A".into(),
            away: "B".into(),
            league: "L".into(),
            kind: "steam".into(),
            flagged: true,
            state: MatchState::Scheduled,
            status_detail: String::new(),
            home_score: None,
            away_score: None,
            source: String::new(),
            metrics: None,
            updated_at: "2026-11-18T10:00:00Z".into(),
        }
    }

    #[test]
    fn an_identical_match_log_row_is_not_rewritten() {
        let current = log_row();
        // Seul `updated_at` change d'un cycle à l'autre : ce n'est pas une
        // modification, et la réécrire épuisait le quota d'écriture D1.
        let mut incoming = log_row();
        incoming.updated_at = "2026-11-18T11:00:00Z".into();
        assert!(!merge_changes(&current, &incoming));
    }

    #[test]
    fn a_new_score_or_state_is_written() {
        let current = log_row();
        let mut scored = log_row();
        scored.home_score = Some(2);
        scored.state = MatchState::Finished;
        assert!(merge_changes(&current, &scored));
    }

    #[test]
    fn a_terminal_match_is_not_downgraded() {
        let mut current = log_row();
        current.state = MatchState::Finished;
        current.home_score = Some(2);
        current.away_score = Some(1);
        // Le flux renvoie l'état d'avant-match : rien ne doit changer.
        assert!(!merge_changes(&current, &log_row()));
    }

    #[test]
    fn purge_is_throttled_to_once_an_hour() {
        let store = test_store("purge-throttle");
        assert!(store.purge_due(), "la première purge est autorisée");
        store.mark_purged();
        assert!(
            !store.purge_due(),
            "une purge par collecte balayait la table entière"
        );
    }

    fn test_store(name: &str) -> Store {
        let dir = std::env::temp_dir().join(format!(
            "truevalue-store-{name}-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        test_store_at(&dir)
    }

    /// Magasin sans Cloudflare, sur un dossier donné (deux instances qui
    /// partagent les mêmes fichiers simulent un redémarrage).
    fn test_store_at(dir: &Path) -> Store {
        let mut cfg = crate::config::Config::from_env();
        cfg.data_dir = dir.to_path_buf();
        cfg.cloudflare_account = None;
        cfg.d1_database = None;
        cfg.kv_namespace = None;
        Store::new(&cfg)
    }

    fn signal_at(
        date: &str,
        odds: f64,
        play: Play,
        score: f64,
        category: crate::model::SignalCategory,
    ) -> Signal {
        Signal {
            id: "sig_a_vs_b".into(),
            fixture_key: "a_vs_b".into(),
            home: "A".into(),
            away: "B".into(),
            league: "Test".into(),
            country: "ENG".into(),
            flag_url: String::new(),
            date: date.into(),
            date_label: String::new(),
            convergence_score: score,
            category,
            category_label: category.label().to_string(),
            scenario_title: String::new(),
            analysis_summary: String::new(),
            value: Recommendation {
                play,
                label: "Pari".into(),
                odds: Some(odds),
            },
            safety: Recommendation {
                play: Play::NoBet,
                label: "Rien".into(),
                odds: None,
            },
            divergence_explanation: None,
            total_volume: 1_000.0,
            markets: Vec::new(),
            odds: crate::model::OddsAnalysis::default(),
            kind: crate::model::SignalKind::Over,
            families: vec!["Buts".into()],
            confidence: crate::model::Confidence::Moyen,
            fresh: crate::fresh::FreshMoney::default(),
            quality: crate::quality::Quality::ok(),
            proposals: Vec::new(),
            liquidity_tier: crate::model::LiquidityTier::High,
            direction: "domicile".into(),
            weight: None,
            metrics: Default::default(),
            source: crate::model::Source::Live,
            computed_at: "2026-11-09T19:00:00Z".into(),
        }
    }

    #[test]
    fn a_signal_is_frozen_at_its_first_detection() {
        let store = test_store("freeze");
        let bet = Play::TotalGoals {
            line: 2.5,
            over: true,
        };
        store
            .upsert_signals(
                &[signal_at(
                    "2026-11-09T20:00:00Z",
                    1.80,
                    bet.clone(),
                    82.0,
                    crate::model::SignalCategory::ConvergenceOver,
                )],
                "2026-11-09T19:50:00Z",
            )
            .expect("enregistrement initial");

        // Collecte suivante : la cote a bougé, mais la cote d'entrée du ROI
        // reste celle de la première détection.
        store
            .upsert_signals(
                &[signal_at(
                    "2026-11-09T20:00:00Z",
                    1.60,
                    Play::NoBet,
                    40.0,
                    crate::model::SignalCategory::NeutralOpportunity,
                )],
                "2026-11-09T19:55:00Z",
            )
            .expect("collecte suivante");
        let revised = store.read_local_signals();
        assert_eq!(revised[0].value.play, bet);
        assert_eq!(revised[0].value.odds, Some(1.80));
        assert_eq!(revised[0].last_seen, "2026-11-09T19:55:00Z");

        // Coup d'envoi passé : plus aucune révision, même avec un autre prix.
        store
            .upsert_signals(
                &[signal_at(
                    "2026-11-09T20:00:00Z",
                    1.50,
                    Play::NoBet,
                    30.0,
                    crate::model::SignalCategory::NeutralOpportunity,
                )],
                "2026-11-09T20:05:00Z",
            )
            .expect("collecte en cours de match");

        let frozen = store.read_local_signals();
        assert_eq!(frozen.len(), 1);
        assert_eq!(frozen[0].value.play, bet);
        assert_eq!(frozen[0].value.odds, Some(1.80));
        assert_eq!(frozen[0].convergence_score, 82.0);
        assert_eq!(frozen[0].minutes_before_kickoff, Some(10));
        assert_eq!(
            frozen[0].confidence,
            Some(crate::model::Confidence::Moyen),
            "la confiance de la première détection est conservée"
        );
    }

    fn sim_position(
        id: &str,
        status: SimStatus,
        pnl: Option<f64>,
        opened_at: &str,
    ) -> SimPosition {
        SimPosition {
            id: id.into(),
            signal_id: format!("sig_{id}"),
            fixture_key: "a_vs_b".into(),
            match_date: "2026-11-09T20:00:00Z".into(),
            day: "2026-11-09".into(),
            home: "A".into(),
            away: "B".into(),
            league: "L".into(),
            kind: "favorite".into(),
            group: "issue".into(),
            market: "1X2".into(),
            pick: "Domicile".into(),
            odds: 1.8,
            stake: 1.0,
            play: Play::MatchResult { side: Slot::First },
            opened_at: opened_at.into(),
            minutes_before_kickoff: 15,
            status,
            settled_at: None,
            pnl,
            home_score: None,
            away_score: None,
            note: String::new(),
        }
    }

    #[test]
    fn simulation_aggregates_survive_the_history_slice() {
        let store = test_store("simulation-aggregates");
        store
            .save_sim_positions(&[
                sim_position("open", SimStatus::Open, None, "2026-11-09T19:45:00Z"),
                sim_position("won", SimStatus::Won, Some(0.8), "2026-11-09T19:40:00Z"),
                sim_position("lost", SimStatus::Lost, Some(-1.0), "2026-11-09T19:35:00Z"),
            ])
            .expect("positions");

        assert_eq!(store.load_open_sim_positions().unwrap().len(), 1);
        assert_eq!(store.load_sim_history(1).unwrap().len(), 1);
        let totals = store.sim_totals().unwrap();
        assert_eq!(totals.settled, 2);
        assert_eq!(totals.won, 1);
        assert_eq!(totals.lost, 1);
        assert_eq!(totals.risked, 2.0);
        assert!((totals.realized_pnl + 0.2).abs() < 1e-9);
    }

    #[test]
    fn sim_candidates_survive_a_restart_and_do_not_duplicate() {
        let dir = std::env::temp_dir().join(format!("truevalue-candidates-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let first = test_store_at(&dir);
        let mut early = sim_position("early", SimStatus::Open, None, "");
        early.match_date = "2026-11-18T20:00:00Z".into();
        early.opened_at = String::new();
        early.minutes_before_kickoff = 0;

        first
            .save_sim_candidates(&[early.clone()], "2026-11-17T19:30:00Z")
            .expect("candidat");
        let restarted = test_store_at(&dir);
        let loaded = restarted.load_sim_candidates().unwrap();
        assert_eq!(loaded.len(), 1);
        assert_eq!(loaded[0].id, "early");
        assert!(loaded[0].opened_at.is_empty());

        restarted
            .save_sim_candidates(&[early.clone()], "2026-11-17T19:40:00Z")
            .expect("candidat réécrit");
        assert_eq!(first.load_sim_candidates().unwrap().len(), 1);

        // Une fois la position ouverte, le candidat doit disparaître : sinon
        // un match reporté est réouvert puis re-voidé à chaque cycle.
        restarted
            .delete_sim_candidates(&[early.id])
            .expect("candidat ouvert supprimé");
        assert!(first.load_sim_candidates().unwrap().is_empty());
    }

    #[test]
    fn pending_rows_do_not_count() {
        let rows = vec![row(BetOutcome::Pending, 2.0, "Neutre")];
        let rec = compute_track_record(&rows);
        assert_eq!(rec.settled_value, 0);
        assert_eq!(rec.value_win_rate, 0.0);
    }

    fn snapshot_row(at: &str, fixture: &str, volume_1: f64) -> SnapshotRow {
        SnapshotRow {
            market_key: "1x2".into(),
            market_id: 91,
            selection_id: 92,
            fixture_key: fixture.into(),
            captured_at: at.into(),
            coef: [1.90, 3.60, 4.20],
            volume: [volume_1, 2500.0, 2000.0],
            total_volume: volume_1 + 4500.0,
            kickoff: "2026-11-09T20:00:00Z".into(),
        }
    }

    #[test]
    fn snapshots_are_recorded_only_when_something_changed() {
        let store = test_store("snapshots-change");
        let now = Utc::now();
        let at = now.to_rfc3339();
        let mut reading = snapshot_row(&at, "a_vs_b", 9000.0);

        assert_eq!(store.record_snapshots(&[reading.clone()], now).unwrap(), 1);
        // Même cote, même volume : rien à historiser.
        assert_eq!(store.record_snapshots(&[reading.clone()], now).unwrap(), 0);
        // Le volume bouge : nouveau relevé.
        reading.volume[0] += 500.0;
        assert_eq!(store.record_snapshots(&[reading.clone()], now).unwrap(), 1);

        let series = store.selection_series(&reading.selection_key()).unwrap();
        assert_eq!(series.len(), 2, "un relevé par changement");
        assert!(store.history_active());
    }

    #[test]
    fn closing_is_the_last_reading_before_kickoff() {
        let store = test_store("closing");
        let now = Utc::now();
        store
            .record_snapshots(
                &[
                    snapshot_row("2026-11-09T19:00:00Z", "a_vs_b", 1000.0),
                    snapshot_row("2026-11-09T19:50:00Z", "a_vs_b", 3000.0),
                    snapshot_row("2026-11-09T20:10:00Z", "a_vs_b", 9000.0),
                ],
                now,
            )
            .expect("relevés");
        let closing = store
            .last_before("a_vs_b", "2026-11-09T20:00:00Z")
            .expect("clôture");
        assert_eq!(closing.len(), 1, "un dernier relevé par sélection");
        assert_eq!(closing[0].volume[0], 3000.0);
    }

    #[test]
    fn closing_works_with_a_kickoff_date_without_timezone() {
        let store = test_store("closing-no-tz");
        let now = Utc::now();
        store
            .record_snapshots(
                &[
                    snapshot_row("2026-11-09T19:00:00Z", "a_vs_b", 1000.0),
                    snapshot_row("2026-11-09T19:50:00Z", "a_vs_b", 3000.0),
                    snapshot_row("2026-11-09T20:10:00Z", "a_vs_b", 9000.0),
                ],
                now,
            )
            .expect("relevés");
        let closing = store
            .last_before("a_vs_b", "2026-11-09 20:00:00")
            .expect("clôture");
        assert_eq!(closing.len(), 1, "un dernier relevé par sélection");
        assert_eq!(
            closing[0].volume[0], 3000.0,
            "le relevé d'après le coup d'envoi doit être exclu"
        );
    }

    #[test]
    fn old_snapshots_are_purged_except_open_signals() {
        let store = test_store("purge");
        let now = Utc::now();
        let old = (now - chrono::Duration::days(20)).to_rfc3339();
        // Une rencontre dont le signal reste ouvert (coup d'envoi à venir).
        store
            .upsert_signals(
                &[signal_at(
                    "2026-11-09T20:00:00Z",
                    1.80,
                    Play::TotalGoals {
                        line: 2.5,
                        over: true,
                    },
                    80.0,
                    crate::model::SignalCategory::ConvergenceOver,
                )],
                "2026-11-09T19:00:00Z",
            )
            .expect("signal ouvert");
        store
            .record_snapshots(
                &[
                    snapshot_row(&old, "a_vs_b", 1000.0),
                    snapshot_row(&old, "other_vs_team", 1000.0),
                ],
                now,
            )
            .expect("relevés");

        let kept = store.fixture_series("a_vs_b").unwrap();
        assert!(kept.len() <= 1, "relevé ancien réinséré puis conservé");
        assert!(
            store.fixture_series("other_vs_team").unwrap().is_empty(),
            "les relevés anciens d'une rencontre non suivie sont purgés"
        );
    }

    #[test]
    fn neutral_signals_are_never_persisted() {
        let store = test_store("flagged");
        let mut signal = signal_at(
            "2026-11-09T20:00:00Z",
            1.80,
            Play::NoBet,
            40.0,
            crate::model::SignalCategory::NeutralOpportunity,
        );
        signal.kind = crate::model::SignalKind::Neutral;
        store
            .upsert_signals(&[signal], "2026-11-09T19:00:00Z")
            .expect("upsert");
        assert!(store.read_local_signals().is_empty());
    }

    #[test]
    fn a_restarted_store_still_knows_the_last_reading() {
        let dir = std::env::temp_dir().join(format!(
            "truevalue-store-restart-{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        let now = Utc::now();
        let reading = snapshot_row(&now.to_rfc3339(), "a_vs_b", 9000.0);

        let first = test_store_at(&dir);
        assert_eq!(
            first
                .record_snapshots(std::slice::from_ref(&reading), now)
                .unwrap(),
            1
        );

        // Redémarrage : la fenêtre est relue depuis les fichiers, et le relevé
        // inchangé n'est pas réinséré.
        let restarted = test_store_at(&dir);
        assert_eq!(restarted.record_snapshots(&[reading], now).unwrap(), 0);
    }

    #[test]
    fn the_fresh_series_keeps_the_window_and_the_latest_reading() {
        let store = test_store("fresh-window");
        let now = Utc::now();
        let window = crate::thresholds::SNAPSHOT_RECENT_HOURS;
        let stale = (now - chrono::Duration::hours(window + 2)).to_rfc3339();
        let current = (now - chrono::Duration::hours(1)).to_rfc3339();
        store
            .record_snapshots(
                &[
                    snapshot_row(&stale, "a_vs_b", 1000.0),
                    snapshot_row(&current, "a_vs_b", 5000.0),
                ],
                now,
            )
            .expect("relevés");

        let series = store.fresh_series(now);
        let readings = series
            .by_selection
            .get("1x2:91:92")
            .expect("sélection suivie");
        assert_eq!(readings.len(), 1, "le relevé hors fenêtre est écarté");
        assert_eq!(readings[0].volume[0], 5000.0);
    }
}
