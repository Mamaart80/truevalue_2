//! Définition des marchés football suivis sur Arbworld / Betfair.
//!
//! Chaque marché porte le sens de ses issues : c'est ce qui permet ensuite de
//! raisonner sur des *slots* (`Slot::First`, `Slot::Draw`, `Slot::Second`) au lieu
//! de deviner la signification d'un libellé français par recherche de sous-chaîne.

use serde::{Deserialize, Serialize};

/// Nombre d'issues structurelles d'un marché.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MarketShape {
    /// Trois issues : 1, X, 2 (ou 1X, X2, 12 pour la double chance).
    ThreeWay,
    /// Deux issues.
    TwoWay,
    /// Distribution : score exact, MT/FT.
    Multi,
}

/// Marché suivi.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum MarketKey {
    #[serde(rename = "1x2")]
    OneXTwo,
    #[serde(rename = "over-under-2-5")]
    OverUnder25,
    #[serde(rename = "btts")]
    Btts,
    #[serde(rename = "double-chance")]
    DoubleChance,
    #[serde(rename = "dnb")]
    DrawNoBet,
    #[serde(rename = "over-under-1-5")]
    OverUnder15,
    #[serde(rename = "over-under-3-5")]
    OverUnder35,
    #[serde(rename = "half-time")]
    HalfTime,
    #[serde(rename = "correct-score")]
    CorrectScore,
    #[serde(rename = "ht-ft")]
    HalfTimeFullTime,
}

impl MarketKey {
    pub const ALL: [MarketKey; 10] = [
        MarketKey::OneXTwo,
        MarketKey::OverUnder25,
        MarketKey::Btts,
        MarketKey::DoubleChance,
        MarketKey::DrawNoBet,
        MarketKey::OverUnder15,
        MarketKey::OverUnder35,
        MarketKey::HalfTime,
        MarketKey::CorrectScore,
        MarketKey::HalfTimeFullTime,
    ];

    pub fn slug(self) -> &'static str {
        match self {
            MarketKey::OneXTwo => "1x2",
            MarketKey::OverUnder25 => "over-under-2-5",
            MarketKey::Btts => "btts",
            MarketKey::DoubleChance => "double-chance",
            MarketKey::DrawNoBet => "dnb",
            MarketKey::OverUnder15 => "over-under-1-5",
            MarketKey::OverUnder35 => "over-under-3-5",
            MarketKey::HalfTime => "half-time",
            MarketKey::CorrectScore => "correct-score",
            MarketKey::HalfTimeFullTime => "ht-ft",
        }
    }

    pub fn parse(slug: &str) -> Option<MarketKey> {
        MarketKey::ALL.into_iter().find(|m| m.slug() == slug)
    }

    pub fn def(self) -> MarketDef {
        use MarketKey::*;
        match self {
            OneXTwo => MarketDef {
                key: self,
                label: "Résultat du match (1X2)",
                short: "1X2",
                category: "core",
                shape: MarketShape::ThreeWay,
                arbworld: "MATCH_ODDS",
                slot_labels: ("1 (Domicile)", Some("X (Nul)"), "2 (Extérieur)"),
                help: "Volume sur victoire domicile, nul ou victoire extérieur.",
            },
            OverUnder25 => MarketDef {
                key: self,
                label: "Plus / Moins 2.5 buts",
                short: "+/- 2.5",
                category: "goals",
                shape: MarketShape::TwoWay,
                arbworld: "OVER_UNDER_25",
                slot_labels: ("Moins 2.5 (Under)", None, "Plus 2.5 (Over)"),
                help: "Moins de 2.5 buts (0 à 2) contre plus de 2.5 buts (3 et +).",
            },
            Btts => MarketDef {
                key: self,
                label: "Les 2 équipes marquent",
                short: "BTTS",
                category: "goals",
                shape: MarketShape::TwoWay,
                arbworld: "BOTH_TEAMS_TO_SCORE",
                slot_labels: ("Oui", None, "Non"),
                help: "Les deux équipes marquent-elles au moins un but ?",
            },
            DoubleChance => MarketDef {
                key: self,
                label: "Double chance",
                short: "Double chance",
                category: "core",
                shape: MarketShape::ThreeWay,
                arbworld: "DOUBLE_CHANCE",
                slot_labels: (
                    "1X (Dom ou nul)",
                    Some("X2 (Nul ou extérieur)"),
                    "12 (Dom ou extérieur)",
                ),
                help: "Deux issues couvertes en un seul pari.",
            },
            DrawNoBet => MarketDef {
                key: self,
                label: "Remboursé si nul (DNB)",
                short: "DNB",
                category: "core",
                shape: MarketShape::TwoWay,
                arbworld: "DRAW_NO_BET",
                slot_labels: ("1 (DNB domicile)", None, "2 (DNB extérieur)"),
                help: "Mise remboursée en cas de match nul.",
            },
            OverUnder15 => MarketDef {
                key: self,
                label: "Plus / Moins 1.5 buts",
                short: "+/- 1.5",
                category: "goals",
                shape: MarketShape::TwoWay,
                arbworld: "OVER_UNDER_15",
                slot_labels: ("Moins 1.5 (Under)", None, "Plus 1.5 (Over)"),
                help: "Moins de 1.5 buts (0 ou 1) contre plus de 1.5 buts (2 et +).",
            },
            OverUnder35 => MarketDef {
                key: self,
                label: "Plus / Moins 3.5 buts",
                short: "+/- 3.5",
                category: "goals",
                shape: MarketShape::TwoWay,
                arbworld: "OVER_UNDER_35",
                slot_labels: ("Moins 3.5 (Under)", None, "Plus 3.5 (Over)"),
                help: "Moins de 3.5 buts (0 à 3) contre plus de 3.5 buts (4 et +).",
            },
            HalfTime => MarketDef {
                key: self,
                label: "Mi-temps (1X2 MT)",
                short: "Mi-temps",
                category: "combo",
                shape: MarketShape::ThreeWay,
                arbworld: "HALF_TIME",
                slot_labels: ("1 (MT domicile)", Some("X (MT nul)"), "2 (MT extérieur)"),
                help: "Résultat à la fin de la première mi-temps.",
            },
            CorrectScore => MarketDef {
                key: self,
                label: "Score exact",
                short: "Score exact",
                category: "scores",
                shape: MarketShape::Multi,
                arbworld: "CORRECT_SCORE",
                slot_labels: ("Top score 1", Some("Top score 2"), "Top score 3"),
                help: "Répartition des volumes sur les scores exacts.",
            },
            HalfTimeFullTime => MarketDef {
                key: self,
                label: "Mi-temps / fin de match",
                short: "MT / FM",
                category: "combo",
                shape: MarketShape::Multi,
                arbworld: "HALF_TIME_FULL_TIME",
                slot_labels: ("1/1", Some("X/1"), "X/X"),
                help: "Combinaison du score à la mi-temps et au coup de sifflet final.",
            },
        }
    }
}

/// Métadonnées d'un marché.
#[derive(Debug, Clone, Copy, Serialize)]
pub struct MarketDef {
    pub key: MarketKey,
    pub label: &'static str,
    pub short: &'static str,
    pub category: &'static str,
    pub shape: MarketShape,
    /// Nom du marché chez Arbworld.
    pub arbworld: &'static str,
    /// Libellés des issues (1, X, 2).
    pub slot_labels: (&'static str, Option<&'static str>, &'static str),
    pub help: &'static str,
}

impl MarketDef {
    /// Part de volume neutre : ce qu'on attend si l'argent est réparti au hasard.
    pub fn neutral_share(&self) -> f64 {
        match self.shape {
            MarketShape::ThreeWay => 100.0 / 3.0,
            MarketShape::TwoWay => 50.0,
            MarketShape::Multi => 15.0,
        }
    }

    pub fn is_goals_totals(&self) -> bool {
        matches!(
            self.key,
            MarketKey::OverUnder15 | MarketKey::OverUnder25 | MarketKey::OverUnder35
        )
    }

}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slugs_roundtrip() {
        for key in MarketKey::ALL {
            assert_eq!(MarketKey::parse(key.slug()), Some(key));
        }
    }

    #[test]
    fn neutral_shares() {
        assert!((MarketKey::OneXTwo.def().neutral_share() - 33.33).abs() < 0.1);
        assert_eq!(MarketKey::Btts.def().neutral_share(), 50.0);
    }
}
