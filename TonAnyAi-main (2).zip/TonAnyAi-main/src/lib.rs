//! Truevalue — flux Betfair (Arbworld), signaux croisés et suivi de performance.
//!
//! Bibliothèque sans état global : la configuration et le stockage sont injectés,
//! ce qui rend la logique testable hors ligne.

pub mod ai;
pub mod backtest;
pub mod cloudflare;
pub mod config;
pub mod daily;
pub mod enrich;
pub mod espn;
pub mod fresh;
pub mod grid;
pub mod market;
pub mod model;
pub mod pipeline;
pub mod polymarket;
pub mod proposals;
pub mod quality;
pub mod scrape;
pub mod signals;
pub mod simulation;
pub mod sportscore;
pub mod storage;
pub mod telegram;
pub mod thresholds;
pub mod track;
pub mod v2;
pub mod verify;
pub mod web;
