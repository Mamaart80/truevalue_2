//! Alertes Telegram pour les signaux à confiance élevée.
//!
//! L'application fonctionne sans Telegram : quand `TELEGRAM_BOT_TOKEN` ou
//! `TELEGRAM_CHAT_ID` manque, aucune alerte n'est préparée et la collecte suit
//! son cours. Un envoi qui échoue devient un avertissement de collecte, jamais
//! une collecte perdue.

use std::collections::HashSet;
use std::time::Duration;

use serde_json::json;

use crate::model::{Confidence, Signal};
use crate::thresholds as th;

/// Client minimal de l'API Bot Telegram (un `POST` par message).
pub struct Bot {
    token: String,
    chat: String,
    base: String,
    timeout: Duration,
}

impl Bot {
    /// `None` tant que le jeton ou la discussion manquent : un bot à moitié
    /// configuré n'essaie pas d'envoyer.
    pub fn new(token: Option<String>, chat: Option<String>, base: String) -> Option<Self> {
        Some(Self {
            token: token?,
            chat: chat?,
            base,
            timeout: Duration::from_secs(th::TELEGRAM_TIMEOUT_SECS),
        })
    }

    fn redact(&self, text: &str) -> String {
        text.replace(&self.token, "[REDACTED]")
    }

    pub fn send(&self, text: &str) -> Result<(), String> {
        let url = format!(
            "{}/bot{}/sendMessage",
            self.base.trim_end_matches('/'),
            self.token
        );
        let response = ureq::post(&url).timeout(self.timeout).send_json(json!({
            "chat_id": self.chat,
            "text": text,
            // Un message d'alerte ne doit pas déplier un aperçu de lien.
            "disable_web_page_preview": true,
        }));
        match response {
            Ok(_) => Ok(()),
            Err(ureq::Error::Status(code, response)) => {
                let body = response.into_string().unwrap_or_default();
                let body: String = body.chars().take(160).collect();
                // Le jeton fait partie de l'URL : ne jamais le laisser fuir
                // dans un warning du snapshot (donc dans l'UI).
                Err(format!("HTTP {code} {}", self.redact(&body)).trim_end().to_string())
            }
            Err(ureq::Error::Transport(err)) => Err(self.redact(&err.to_string())),
        }
    }
}

/// Signaux à alerter : confiance élevée, pari, cote d'entrée au plancher commun
/// (1,30), jamais deux fois le même, dans la limite du cycle.
///
/// La couverture par une source de score N'est PAS exigée ici : l'utilisateur
/// veut recevoir l'alerte même quand la simulation ne peut pas ouvrir ni régler
/// la position (compétition non couverte par ESPN/SportScore). L'alerte et la
/// simulation ne partagent que le plancher de cote, pas l'éligibilité complète.
pub fn to_send<'a>(
    signals: &'a [Signal],
    already: &HashSet<String>,
    limit: usize,
) -> Vec<&'a Signal> {
    let mut out: Vec<&Signal> = Vec::new();
    for signal in signals {
        if out.len() >= limit {
            break;
        }
        if signal.confidence != Confidence::Eleve || !signal.kind.flagged() {
            continue;
        }
        // Seul le plancher de cote est partagé avec la simulation : la cote
        // retenue est celle de la proposition éligible (premier groupe hors
        // score, ≥ 1,30 inclus). `league_covered` n'est volontairement pas
        // testé : une alerte doit partir même si aucun score ne pourra régler
        // la simulation.
        if crate::simulation::primary_proposal(signal).is_none() {
            continue;
        }
        if already.contains(&signal.id) {
            continue;
        }
        out.push(signal);
    }
    out
}

/// Message court et lisible sur un téléphone : ce qui est signalé, où, quand,
/// et pourquoi. La cote affichée est **celle de la proposition éligible**, la
/// même que celle utilisée pour déclencher l'alerte — pas `value.odds`, qui
/// peut venir d'un marché sous le plancher et donner l'illusion d'un seuil
/// non appliqué.
pub fn message(signal: &Signal) -> String {
    let when = if signal.date_label.trim().is_empty() {
        signal.date.clone()
    } else {
        signal.date_label.clone()
    };
    let mut lines = vec![
        format!("Alerte Truevalue · confiance {}", signal.confidence.label()),
        format!("{} — {}", signal.home, signal.away),
        format!("{} · {} (UTC)", signal.league, when),
        format!(
            "{} · convergence {} %",
            signal.kind.label(),
            signal.convergence_score.round() as i64
        ),
    ];

    if let Some(proposal) = crate::simulation::primary_proposal(signal) {
        if let Some(odds) = proposal.entry_odds {
            lines.push(format!("Pari : {} @ {:.2}", proposal.pick, odds));
        }
    }

    let markets: Vec<String> = signal
        .markets
        .iter()
        .take(2)
        .map(|market| {
            format!(
                "{} {} %",
                market.market_label,
                market.dominant_share.round() as i64
            )
        })
        .collect();
    if !markets.is_empty() {
        lines.push(format!("Marchés : {}", markets.join(" · ")));
    }

    lines.join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{
        BetOutcome, Play, Recommendation, SignalCategory, SignalKind, Slot, Source,
    };
    use crate::proposals::{MarketGroup, Proposal};

    /// Signal complet avec une proposition éligible : l'alerte et la simulation
    /// partagent désormais le même test d'éligibilité.
    fn signal(id: &str, kind: SignalKind, confidence: Confidence) -> Signal {
        let odds = th::MIN_BET_ODDS + 0.2;
        Signal {
            id: id.to_string(),
            fixture_key: "a_vs_b".to_string(),
            home: "A".to_string(),
            away: "B".to_string(),
            league: "Premier League".to_string(),
            country: "ENG".to_string(),
            flag_url: String::new(),
            date: "2026-11-15T20:00:00Z".to_string(),
            date_label: "dim. 15 nov. · 20:00".to_string(),
            convergence_score: 78.0,
            category: SignalCategory::ConvergenceOver,
            category_label: "Convergence +buts".to_string(),
            scenario_title: String::new(),
            analysis_summary: String::new(),
            value: Recommendation {
                play: Play::NoBet,
                label: "Pari".to_string(),
                odds: None,
            },
            safety: Recommendation {
                play: Play::NoBet,
                label: "Rien".to_string(),
                odds: None,
            },
            divergence_explanation: None,
            total_volume: 1_000.0,
            markets: Vec::new(),
            odds: crate::model::OddsAnalysis::default(),
            kind,
            families: vec!["Buts".to_string()],
            confidence,
            fresh: crate::fresh::FreshMoney::default(),
            quality: crate::quality::Quality::ok(),
            proposals: vec![Proposal {
                group: MarketGroup::Issue,
                market: "1X2".to_string(),
                pick: "Domicile".to_string(),
                share: 70.0,
                entry_odds: Some(odds),
                entry_novig: None,
                series_key: String::new(),
                market_key: None,
                play: Play::MatchResult { side: Slot::First },
                authorized: false,
                closing_odds: None,
                closing_novig: None,
                clv_pct: None,
                clv_novig_pct: None,
                outcome: BetOutcome::Pending,
                explanation: String::new(),
            }],
            liquidity_tier: crate::model::LiquidityTier::High,
            direction: "domicile".to_string(),
            weight: None,
            metrics: Default::default(),
            source: Source::Live,
            computed_at: "2026-11-15T19:00:00Z".to_string(),
        }
    }

    #[test]
    fn only_high_confidence_signals_that_carry_a_bet_are_alerted() {
        let mut high_bet = signal("high_bet", SignalKind::Over, Confidence::Eleve);
        high_bet.value.odds = Some(1.5);
        let signals = vec![
            high_bet,
            signal("high_neutral", SignalKind::Neutral, Confidence::Eleve),
            signal("high_weight", SignalKind::Weight, Confidence::Eleve),
            signal("medium_bet", SignalKind::Over, Confidence::Moyen),
        ];
        let picked: Vec<&str> = to_send(&signals, &HashSet::new(), 10)
            .iter()
            .map(|s| s.id.as_str())
            .collect();
        assert_eq!(picked, vec!["high_bet"]);
    }

    #[test]
    fn the_odds_floor_is_inclusive_and_shared_with_the_simulation() {
        let mut at_floor = signal("at_floor", SignalKind::Over, Confidence::Eleve);
        at_floor.proposals[0].entry_odds = Some(th::MIN_BET_ODDS);
        let mut below = signal("below", SignalKind::Over, Confidence::Eleve);
        below.proposals[0].entry_odds = Some(th::MIN_BET_ODDS - 0.01);

        let signals = [at_floor, below];
        let picked: Vec<&str> = to_send(&signals, &HashSet::new(), 10)
            .iter()
            .map(|s| s.id.as_str())
            .collect();
        assert_eq!(picked, vec!["at_floor"]);
        assert_eq!(th::MIN_BET_ODDS, th::SIM_MIN_ODDS);
        assert_eq!(th::MIN_BET_ODDS, th::CONFIDENCE_ELEVE_MIN_ODDS);
    }

    #[test]
    fn an_uncovered_competition_is_still_alerted() {
        let mut uncovered = signal("uncovered", SignalKind::Over, Confidence::Eleve);
        uncovered.league = "Japanese J League Cup".to_string();
        assert!(!crate::simulation::league_covered(&uncovered.league));
        assert_eq!(to_send(&[uncovered], &HashSet::new(), 10).len(), 1);
    }

    #[test]
    fn an_alert_already_sent_is_not_sent_again() {
        let signals = vec![signal("high_bet", SignalKind::Over, Confidence::Eleve)];
        let mut already = HashSet::new();
        already.insert("high_bet".to_string());
        assert!(to_send(&signals, &already, 10).is_empty());
    }

    #[test]
    fn a_burst_is_capped_per_cycle() {
        let signals: Vec<Signal> = (0..5)
            .map(|i| {
                let mut s = signal(&format!("sig_{i}"), SignalKind::Over, Confidence::Eleve);
                s.value.odds = Some(1.5);
                s
            })
            .collect();
        assert_eq!(to_send(&signals, &HashSet::new(), 3).len(), 3);
    }

    #[test]
    fn the_message_shows_the_eligible_proposal_odds_not_value_odds() {
        let mut s = signal("high_bet", SignalKind::Over, Confidence::Eleve);
        // Le libellé « value » porte une cote sous le plancher, mais la
        // deuxième proposition est éligible : c'est elle qui doit apparaître.
        s.value.label = "Domicile".into();
        s.value.odds = Some(1.15);
        s.proposals[0].entry_odds = Some(1.15);
        s.proposals.push(s.proposals[0].clone());
        s.proposals[1].group = crate::proposals::MarketGroup::Btts;
        s.proposals[1].pick = "Non".into();
        s.proposals[1].entry_odds = Some(1.76);

        let text = message(&s);
        assert!(text.contains("A — B"));
        assert!(text.contains("confiance Élevé"));
        assert!(text.contains("Premier League"));
        assert!(text.contains("Pari : Non @ 1.76"), "{text}");
        assert!(!text.contains("1.15"), "{text}");
    }

    #[test]
    fn send_posts_the_message_to_the_bot_api() {
        use std::io::{Read, Write};
        use std::net::TcpListener;

        // Faux serveur Telegram sur la boucle locale : le test ne sort pas de
        // la machine et exerce le vrai chemin HTTP (URL, en-têtes, corps).
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let server = std::thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            stream
                .set_read_timeout(Some(Duration::from_secs(2)))
                .unwrap();
            let mut request = Vec::new();
            let mut buf = [0u8; 1024];
            loop {
                match stream.read(&mut buf) {
                    Ok(0) => break,
                    Ok(n) => {
                        request.extend_from_slice(&buf[..n]);
                        if String::from_utf8_lossy(&request).contains("Alerte test") {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
            stream
                .write_all(
                    b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 11\r\nConnection: close\r\n\r\n{\"ok\":true}",
                )
                .unwrap();
            String::from_utf8_lossy(&request).to_string()
        });

        let bot = Bot::new(
            Some("123:abc".to_string()),
            Some("42".to_string()),
            format!("http://{addr}"),
        )
        .unwrap();
        bot.send("Alerte test").unwrap();

        let request = server.join().unwrap();
        assert!(request.starts_with("POST /bot123:abc/sendMessage"), "{request}");
        assert!(request.contains("\"chat_id\":\"42\""), "{request}");
        assert!(request.contains("Alerte test"));
    }

    #[test]
    fn an_incomplete_bot_sends_nothing() {
        let base = "http://127.0.0.1:1".to_string();
        assert!(Bot::new(None, Some("42".to_string()), base.clone()).is_none());
        assert!(Bot::new(Some("token".to_string()), None, base).is_none());
    }
}
