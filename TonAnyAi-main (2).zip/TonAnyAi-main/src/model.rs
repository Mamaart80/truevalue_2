//! Modèle de données exposé par l'API et consommé par le tableau de bord.

use serde::{Deserialize, Serialize};

use crate::fresh::FreshMoney;
use crate::market::{MarketKey, MarketShape};
use crate::proposals::Proposal;
use crate::quality::Quality;

/// Issue structurelle d'un marché : 1, X, 2.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Slot {
    First,
    Draw,
    Second,
}

impl Slot {
    pub fn index(self) -> usize {
        match self {
            Slot::First => 0,
            Slot::Draw => 1,
            Slot::Second => 2,
        }
    }
}

/// Provenance d'une donnée : c'est explicite pour qu'aucune donnée de secours
/// ne puisse être présentée comme un flux live.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Source {
    /// Récupéré à l'instant depuis Arbworld.
    Live,
    /// Servi depuis le cache mémoire (encore dans la fenêtre de fraîcheur).
    Cache,
    /// Cache périmé conservé faute de mieux ; `age_seconds` le documente.
    Stale,
    /// Snapshot persisté (KV/D1), pas d'appel amont.
    Snapshot,
}

impl Source {
    pub fn is_live(self) -> bool {
        matches!(self, Source::Live)
    }
}

/// Score exact parmi les issues d'un marché multi.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScoreOutcome {
    pub label: String,
    pub coef: Option<f64>,
    pub coef_new: Option<f64>,
    pub volume: f64,
    pub pct: f64,
}

/// Une ligne de marché enrichie pour une rencontre.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Match {
    pub id: String,
    pub market: MarketKey,
    pub shape: MarketShape,
    pub date: String,
    pub date_label: String,
    pub country: String,
    pub league: String,
    pub home: String,
    pub away: String,
    pub market_id: i64,
    pub selection_id: i64,
    pub last_update: String,

    pub labels: [String; 3],

    pub coef: [f64; 3],
    pub coef_new: [f64; 3],
    pub volume: [f64; 3],
    pub total_volume: f64,
    pub share: [f64; 3],
    /// Probabilité implicite normalisée (%).
    pub implied: [f64; 3],
    /// `share - implied` en points de pourcentage : l'edge du flux.
    pub edge: [f64; 3],
    /// Variation de cote en % (négatif = cote qui se resserre).
    pub drop: [f64; 3],

    pub dominant: Slot,
    /// Index de l'issue dominante dans les tableaux `share` / `coef_new`.
    pub dominant_index: usize,
    pub dominant_label: String,
    pub dominant_share: f64,
    pub smart_money_score: f64,
    pub signal_type: SignalType,
    pub signal_label: String,
    pub liquidity_tier: LiquidityTier,

    pub outcomes: Vec<ScoreOutcome>,
    pub source: Source,
    pub age_seconds: u64,

    pub betfair_chart_url: String,
    pub betfair_market_url: String,
    pub flag_url: String,
}

/// Typologie de signal de flux sur un marché isolé.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SignalType {
    WhaleAccumulation,
    /// Concentration du volume cumulé **sans** argent frais pour la confirmer :
    /// c'est une information, pas un signal de flux.
    AccumulationInfo,
    SharpDrop,
    UnderdogSurge,
    FavoriteSteam,
    Balanced,
}

impl SignalType {
    pub fn label(self) -> &'static str {
        match self {
            SignalType::WhaleAccumulation => "Concentration forte",
            SignalType::AccumulationInfo => "Concentration · information",
            SignalType::SharpDrop => "Cote qui se resserre",
            SignalType::UnderdogSurge => "Argent sur l'outsider",
            SignalType::FavoriteSteam => "Pression favori",
            SignalType::Balanced => "Flux équilibré",
        }
    }
}

/// Niveau de liquidité d'un marché.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum LiquidityTier {
    Whale,
    High,
    Medium,
    #[default]
    Low,
}

impl LiquidityTier {
    /// Clé stable pour la persistance et l'affichage (« WHALE », « HIGH »…).
    pub fn key(self) -> &'static str {
        match self {
            LiquidityTier::Whale => "WHALE",
            LiquidityTier::High => "HIGH",
            LiquidityTier::Medium => "MEDIUM",
            LiquidityTier::Low => "LOW",
        }
    }

    pub fn from_volume(volume: f64) -> Self {
        if volume >= 30_000.0 {
            LiquidityTier::Whale
        } else if volume >= 7_000.0 {
            LiquidityTier::High
        } else if volume >= 1_200.0 {
            LiquidityTier::Medium
        } else {
            LiquidityTier::Low
        }
    }
}

/// Un pari concret, typé : la notation ne dépend plus d'une recherche de texte.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Play {
    /// Plus / moins de `line` buts, sur le temps réglementaire.
    TotalGoals { line: f64, over: bool },
    /// Les deux équipes marquent (oui / non).
    Btts { yes: bool },
    /// Résultat 1X2.
    MatchResult { side: Slot },
    /// Double chance sur deux issues.
    DoubleChance { home: bool, away: bool },
    /// Remboursé si nul.
    DrawNoBet { side: Slot },
    /// Score exact.
    ExactScore { home: u8, away: u8 },
    /// Aucun pari recommandé (divergence) : jamais compté comme gagné.
    #[default]
    NoBet,
}

/// Pari proposé par le moteur, avec son libellé lisible et sa cote.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Recommendation {
    pub play: Play,
    pub label: String,
    pub odds: Option<f64>,
}

/// Typologie exposée à la nouvelle interface (clé `kind` du bloc `v2`).
///
/// `category` reste la classification historique (libellé français) ; `kind`
/// est la lecture courante : mouvement de cote + argent frais + confirmation
/// par une autre famille de marchés.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum SignalKind {
    /// Rien à proposer : observation, pas de proposition.
    #[default]
    Neutral,
    /// Cote qui raccourcit et argent frais du même côté.
    Steam,
    /// L'argent frais change de côté par rapport au cumulé.
    Reversal,
    /// Afflux anormal avant le coup d'envoi.
    Late,
    /// Deux issues financées incompatibles au sens de la grille de scores.
    Divergence,
    /// Convergence vers un match fermé.
    Under,
    /// Convergence vers un match prolifique.
    Over,
    /// Consensus sur un favori, confirmé par un marché dérivé.
    Favorite,
    /// Poids de marché : la rencontre capte un volume très supérieur à la
    /// médiane de sa journée, concentré sur une seule famille de marchés.
    /// Information de localisation, jamais un pari (cf. `tradable`).
    Weight,
    /// Match sans favori : le 1X2 ne sépare pas les deux équipes (écart des
    /// probabilités implicites sous le seuil). Qualification de la rencontre,
    /// jamais un pari : un prix juste ne se joue pas.
    Even,
}

impl SignalKind {
    pub fn key(self) -> &'static str {
        match self {
            SignalKind::Neutral => "neutral",
            SignalKind::Steam => "steam",
            SignalKind::Reversal => "reversal",
            SignalKind::Late => "late",
            SignalKind::Divergence => "divergence",
            SignalKind::Under => "under",
            SignalKind::Over => "over",
            SignalKind::Favorite => "favorite",
            SignalKind::Weight => "weight",
            SignalKind::Even => "even",
        }
    }

    /// Libellé français (interface, historique).
    pub fn label(self) -> &'static str {
        match self {
            SignalKind::Neutral => "Recoupement neutre",
            SignalKind::Steam => "Steam argent frais",
            SignalKind::Reversal => "Inversion du flux",
            SignalKind::Late => "Afflux tardif",
            SignalKind::Divergence => "Alerte divergence",
            SignalKind::Under => "Convergence -buts",
            SignalKind::Over => "Convergence +buts",
            SignalKind::Favorite => "Consensus favori",
            SignalKind::Weight => "Poids de marché",
            SignalKind::Even => "Match sans favori",
        }
    }

    /// Un signal neutre, contradictoire ou purement descriptif (poids de
    /// marché, match sans favori) ne porte jamais de proposition.
    pub fn tradable(self) -> bool {
        !matches!(
            self,
            SignalKind::Neutral
                | SignalKind::Divergence
                | SignalKind::Weight
                | SignalKind::Even
        )
    }

    /// « Match flagué » : tout sauf neutre. Seuls ces matchs sont persistés,
    /// notés et exposés en résultats.
    ///
    /// Les observations pures (poids de marché, match sans favori) en sont
    /// exclues : elles ne portent aucun pari, donc il n'y a rien à noter. Elles
    /// restent visibles dans le snapshot courant.
    pub fn flagged(self) -> bool {
        !matches!(
            self,
            SignalKind::Neutral | SignalKind::Weight | SignalKind::Even
        )
    }

    /// Relit la clé persistée (`late`, `steam`, …).
    pub fn from_key(key: &str) -> Option<SignalKind> {
        [
            SignalKind::Neutral,
            SignalKind::Steam,
            SignalKind::Reversal,
            SignalKind::Late,
            SignalKind::Divergence,
            SignalKind::Under,
            SignalKind::Over,
            SignalKind::Favorite,
            SignalKind::Weight,
            SignalKind::Even,
        ]
        .into_iter()
        .find(|kind| kind.key() == key)
    }
}

/// Confiance d'un signal, calculée (jamais constante).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum Confidence {
    #[default]
    #[serde(rename = "Faible")]
    Faible,
    #[serde(rename = "Moyen")]
    Moyen,
    #[serde(rename = "Élevé")]
    Eleve,
}

impl Confidence {
    /// Libellé exposé à l'interface (`Faible|Moyen|Élevé`).
    pub fn label(self) -> &'static str {
        match self {
            Confidence::Faible => "Faible",
            Confidence::Moyen => "Moyen",
            Confidence::Eleve => "Élevé",
        }
    }

    pub fn from_score(score: f64) -> Self {
        if score >= crate::thresholds::CONFIDENCE_ELEVE_MIN {
            Confidence::Eleve
        } else if score >= crate::thresholds::CONFIDENCE_FAIBLE_MAX {
            Confidence::Moyen
        } else {
            Confidence::Faible
        }
    }

    /// Relit un libellé persisté. Une valeur vide ou inconnue vaut `None` :
    /// c'est le cas des lignes antérieures à l'enregistrement de la confiance.
    pub fn from_label(raw: &str) -> Option<Self> {
        match raw.trim() {
            "Faible" => Some(Confidence::Faible),
            "Moyen" => Some(Confidence::Moyen),
            "Élevé" => Some(Confidence::Eleve),
            _ => None,
        }
    }
}

/// Statistiques d'un groupe de marché ou d'un type de signal.
#[derive(Debug, Clone, Copy, Default, PartialEq, Serialize, Deserialize)]
pub struct SignalStats {
    /// Nombre de cas réglés (gagnés + perdus + remboursés).
    pub n: usize,
    pub hit_pct: f64,
    pub roi_pct: f64,
    pub clv_pct: f64,
}

impl SignalStats {
    /// 30 cas : le chiffre s'affiche.
    pub fn sample_sufficient(&self) -> bool {
        self.n >= crate::thresholds::SAMPLE_MIN_DISPLAY
    }

    /// 200 cas : on peut parler de fiabilité.
    pub fn reliable(&self) -> bool {
        self.n >= crate::thresholds::SAMPLE_MIN_RELIABLE
    }
}

/// Catégorie d'un signal croisé (classification historique, conservée pour la
/// rétrocompatibilité du snapshot et du tableau de bord existant).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SignalCategory {
    ConvergenceOver,
    ConvergenceUnder,
    ConvergenceFavorite,
    DivergenceWarning,
    NeutralOpportunity,
}

impl SignalCategory {
    pub fn label(self) -> &'static str {
        match self {
            SignalCategory::ConvergenceOver => "Convergence +buts",
            SignalCategory::ConvergenceUnder => "Convergence -buts",
            SignalCategory::ConvergenceFavorite => "Consensus favori",
            SignalCategory::DivergenceWarning => "Alerte divergence",
            SignalCategory::NeutralOpportunity => "Recoupement neutre",
        }
    }
}

/// Lecture « cote » d'une issue : prix, probabilité implicite et edge.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OddsView {
    pub label: String,
    /// Slug du marché (`1x2`, `over-under-2-5`, …).
    pub market: String,
    pub odds: Option<f64>,
    /// Probabilité implicite normalisée du marché (%).
    pub implied: f64,
    /// Part de volume observée (%).
    pub share: f64,
    /// `share - implied` en points de pourcentage.
    pub edge_pp: f64,
}

/// Écart de prix entre deux marchés sur la même probabilité.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OddsGap {
    pub label: String,
    /// Probabilité implicite du premier marché (%).
    pub left: f64,
    /// Probabilité implicite du second marché (%).
    pub right: f64,
    /// `right - left` en points de pourcentage.
    pub gap_pp: f64,
    pub note: String,
}

/// Bloc de prix attaché à un signal (vide si aucune cote n'est disponible).
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct OddsAnalysis {
    pub value: Option<OddsView>,
    pub safety: Option<OddsView>,
    /// Issue dominante du marché de référence.
    pub favorite: Option<OddsView>,
    pub gaps: Vec<OddsGap>,
    /// 0-100 : alignement des prix entre marchés (100 = cohérent).
    pub coherence: Option<f64>,
    /// Marge du marché de référence (surcote, %) : `100 × (Σ 1/cote − 1)`.
    /// Au-delà de ~5 %, les cotes sont larges et les probabilités implicites
    /// doivent être lues avec prudence (biais favori-outsider).
    #[serde(default)]
    pub overround_pct: Option<f64>,
    /// Espérance (%) si la part de volume est traitée comme probabilité.
    pub ev_pct: Option<f64>,
}

/// Un marché participant à un signal croisé.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SignalMarket {
    pub market: MarketKey,
    pub market_label: String,
    pub dominant_label: String,
    pub dominant_share: f64,
    pub odds: Option<f64>,
    pub volume: f64,
    pub signal_label: String,
    /// Conviction : part dominante moins la part neutre du marché.
    pub conviction: f64,
    /// Filtre qualité : un marché rejeté reste visible mais ne déclenche ni ne
    /// confirme rien.
    #[serde(default)]
    pub quality: Quality,
    /// Argent frais observé sur ce marché (absent si l'historisation est vide).
    #[serde(default)]
    pub fresh: FreshMoney,
}

/// Poids d'une rencontre dans la collecte du jour.
///
/// Le volume est comparé à la **médiane des rencontres de la même journée**
/// (médiane de toute la collecte si la journée compte trop peu de rencontres),
/// et réparti entre les deux familles de marchés suivies. Aucune valeur n'est
/// extrapolée : si la référence manque, le poids n'est pas calculé.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MarketWeight {
    /// Volume total de la rencontre, tous marchés confondus (£).
    pub volume: f64,
    /// Médiane de référence (£).
    pub reference: f64,
    /// `volume / reference`.
    pub multiple: f64,
    /// Famille la plus financée : « Résultat » ou « Buts ».
    pub family: String,
    /// Part du volume de la rencontre portée par cette famille (%).
    pub family_share: f64,
    /// Nombre de marchés cotés sur la rencontre.
    pub markets: usize,
    /// Vrai si les seuils de poids sont tous franchis.
    pub outlier: bool,
}

/// Mesures de contexte d'une rencontre, conservées pour la calibration.
///
/// Elles sont enregistrées **même quand aucun seuil n'est franchi** : sans les
/// valeurs situées sous le seuil, il est impossible de dire si le seuil
/// discrimine quoi que ce soit. Toutes viennent de la collecte du moment ; une
/// mesure absente reste `None`, jamais zéro.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct FixtureMetrics {
    /// Volume total de la rencontre, tous marchés confondus (£).
    pub volume: f64,
    /// Médiane de référence (£), 0 si aucune référence n'existait.
    pub reference: f64,
    /// `volume / reference`.
    pub multiple: f64,
    /// Famille la plus financée (« Résultat » ou « Buts »).
    pub family: String,
    /// Part de cette famille (%).
    pub family_share: f64,
    /// Nombre de marchés cotés.
    pub markets: usize,
    /// Probabilités implicites normalisées du 1X2 (%).
    pub p_home: Option<f64>,
    pub p_draw: Option<f64>,
    pub p_away: Option<f64>,
    /// Écart domicile / extérieur en points d'implicite.
    pub gap_pp: Option<f64>,
    /// Marge du marché de référence (%).
    pub overround_pct: Option<f64>,
    /// Probabilité implicite de « plus de 2.5 buts » (%), pour comparer le prix
    /// au réalisé dans le backtest.
    pub over_25_implied: Option<f64>,
    /// Cotes 1X2 au moment de la mesure.
    pub home_odds: Option<f64>,
    pub draw_odds: Option<f64>,
    pub away_odds: Option<f64>,
    /// Cotes de la ligne 2.5 buts, pour un ROI hypothétique.
    pub over_25_odds: Option<f64>,
    pub under_25_odds: Option<f64>,
}

/// Signal croisé sur une rencontre, recoupant plusieurs marchés réels.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Signal {
    pub id: String,
    pub fixture_key: String,
    pub home: String,
    pub away: String,
    pub league: String,
    pub country: String,
    pub flag_url: String,
    pub date: String,
    pub date_label: String,
    pub convergence_score: f64,
    pub category: SignalCategory,
    pub category_label: String,
    pub scenario_title: String,
    pub analysis_summary: String,
    pub value: Recommendation,
    pub safety: Recommendation,
    pub divergence_explanation: Option<String>,
    pub total_volume: f64,
    pub markets: Vec<SignalMarket>,
    /// Prix, écarts inter-marchés et cohérence (absent des anciens snapshots).
    /// Les champs `edge` et `ev_pct` y sont **dépréciés** : ils ne servent plus
    /// à décider ni à classer (chantier 3), seulement à relire l'historique.
    #[serde(default)]
    pub odds: OddsAnalysis,
    /// Typologie courante (`steam|reversal|late|divergence|under|over|favorite|neutral`).
    #[serde(default)]
    pub kind: SignalKind,
    /// Familles de confirmation présentes : « Résultat » et/ou « Buts ».
    #[serde(default)]
    pub families: Vec<String>,
    /// Confiance calculée (qualité, liquidité, familles, argent frais, historique).
    #[serde(default)]
    pub confidence: Confidence,
    /// Argent frais du marché de référence (1 h / 3 h).
    #[serde(default)]
    pub fresh: FreshMoney,
    /// Qualité agrégée des marchés du signal.
    #[serde(default)]
    pub quality: Quality,
    /// Propositions par groupe de marché, calculées côté moteur (une seule
    /// logique, pas de recalcul côté interface).
    #[serde(default)]
    pub proposals: Vec<Proposal>,
    /// Palier de liquidité du marché de référence à la détection.
    #[serde(default)]
    pub liquidity_tier: LiquidityTier,
    /// Direction du match selon le 1X2 (ou le DNB à défaut) :
    /// `domicile|extérieur|nul`. Vide si aucun marché de résultat n'existe.
    #[serde(default)]
    pub direction: String,
    /// Poids de la rencontre dans la collecte du jour (absent des anciens
    /// snapshots, et si aucune référence médiane n'est disponible).
    #[serde(default)]
    pub weight: Option<MarketWeight>,
    /// Mesures de contexte de la rencontre, pour la calibration (`/api/backtest`).
    #[serde(default)]
    pub metrics: FixtureMetrics,
    pub source: Source,
    /// Horodatage du snapshot qui a produit ce signal (RFC 3339).
    pub computed_at: String,
}

/// État d'une rencontre côté ESPN.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum MatchState {
    Scheduled,
    InProgress,
    Finished,
    Postponed,
    Cancelled,
}

/// Rencontre telle que renvoyée par l'API de scores ESPN.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchResult {
    pub id: String,
    pub name: String,
    pub date: String,
    pub date_label: String,
    pub league_slug: String,
    pub league_name: String,
    pub home_team: String,
    pub away_team: String,
    pub home_logo: String,
    pub away_logo: String,
    pub home_score: Option<i64>,
    pub away_score: Option<i64>,
    /// Score à la mi-temps (si disponible).
    pub home_ht: Option<i64>,
    pub away_ht: Option<i64>,
    pub state: MatchState,
    pub status_detail: String,
    pub completed: bool,
    pub total_goals: Option<i64>,
    pub btts: Option<bool>,
}

/// Résultat de la notation d'un pari.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum BetOutcome {
    Won,
    Lost,
    Push,
    #[default]
    Pending,
    Unknown,
}

/// Notation d'un pari contre un résultat réel.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GradedPlay {
    pub play: Play,
    pub label: String,
    pub odds: Option<f64>,
    pub outcome: BetOutcome,
    pub explanation: String,
}

/// Suivi persisté d'un signal dans le temps.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrackedSignal {
    pub id: String,
    pub first_seen: String,
    pub last_seen: String,
    pub date: String,
    pub home: String,
    pub away: String,
    pub league: String,
    pub category: String,
    pub convergence_score: f64,
    pub value: Recommendation,
    pub safety: Recommendation,
    pub value_outcome: BetOutcome,
    pub safety_outcome: BetOutcome,
    pub value_explanation: String,
    pub home_score: Option<i64>,
    pub away_score: Option<i64>,
    pub graded_at: Option<String>,
    // --- Ajouts v2 (tous rétrocompatibles : `#[serde(default)]`) -----------
    /// Clé de rencontre normalisée (`fixture_key`).
    #[serde(default)]
    pub fixture_key: String,
    /// Clé anglaise du type de signal (`late`, `steam`, …).
    #[serde(default)]
    pub kind: String,
    /// Confiance calculée à la première détection. `None` pour les lignes
    /// antérieures à sa persistance : elles ne sont pas classées « Faible ».
    #[serde(default)]
    pub confidence: Option<Confidence>,
    /// Propositions notées, une par groupe de marché.
    #[serde(default)]
    pub proposals: Vec<Proposal>,
    /// Cote de clôture (dernier relevé avant le coup d'envoi).
    #[serde(default)]
    pub closing_odds: Option<f64>,
    /// CLV de la proposition principale : cote d'entrée / clôture − 1.
    #[serde(default)]
    pub clv_pct: Option<f64>,
    /// CLV sans marge (probabilités implicites normalisées).
    #[serde(default)]
    pub clv_novig_pct: Option<f64>,
    /// Famille principale du signal (« Résultat » ou « Buts »).
    #[serde(default)]
    pub signal_family: String,
    /// Minutes entre la première détection et le coup d'envoi.
    #[serde(default)]
    pub minutes_before_kickoff: Option<i64>,
    /// Palier de liquidité du marché de référence à la détection.
    #[serde(default)]
    pub liquidity_tier: String,
}

/// Bilan agrégé du suivi.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct TrackRecord {
    pub signals: usize,
    pub settled_value: usize,
    pub value_won: usize,
    pub value_lost: usize,
    pub value_push: usize,
    pub value_win_rate: f64,
    /// Retour sur investissement en unités (mise 1u, cote réelle).
    pub value_roi: f64,
    pub safety_won: usize,
    pub safety_lost: usize,
    pub safety_win_rate: f64,
    pub safety_roi: f64,
    pub by_category: Vec<CategoryStats>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CategoryStats {
    pub category: String,
    pub settled: usize,
    pub won: usize,
    pub win_rate: f64,
    pub roi: f64,
}

/// Snapshot complet : c'est l'unique chose que lit le tableau de bord.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Snapshot {
    pub computed_at: String,
    pub age_seconds: u64,
    pub markets: Vec<MarketSnapshot>,
    pub signals: Vec<Signal>,
    pub track_record: TrackRecord,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct MarketSnapshot {
    pub market: Option<MarketKey>,
    pub key: String,
    pub label: String,
    pub short: String,
    pub matches: Vec<Match>,
    pub total_volume: f64,
    pub source: Source,
    pub updated_at: String,
    pub error: Option<String>,
}

impl Default for Source {
    fn default() -> Self {
        Source::Snapshot
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn confidence_boundaries_are_inclusive_at_the_lower_edge() {
        assert_eq!(Confidence::from_score(44.9), Confidence::Faible);
        assert_eq!(Confidence::from_score(45.0), Confidence::Moyen);
        assert_eq!(Confidence::from_score(69.9), Confidence::Moyen);
        assert_eq!(Confidence::from_score(70.0), Confidence::Eleve);
    }
}
