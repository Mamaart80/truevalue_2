//! Statistiques de suivi **par proposition**, par groupe de marché et par type
//! de signal.
//!
//! Le ROI est calculé sur la cote d'entrée de chaque proposition (cote à la
//! première détection), jamais sur une cote révisée. Le CLV compare cette cote
//! de clôture (dernier relevé avant le coup d'envoi).
//!
//! Règles de comptage :
//! - un remboursé (DNB sur un nul) compte dans `n`, avec un ROI de 0 ;
//! - un statut `Inconnu` (score à la mi-temps absent, rencontre non retrouvée)
//!   est exclu de toutes les statistiques, jamais compté comme gagné ;
//! - le groupe `score` n'est jamais noté.

use std::collections::HashMap;

use crate::model::{BetOutcome, SignalStats, TrackedSignal};
use crate::proposals::{Authorizer, MarketGroup, Proposal};

/// Statistiques agrégées prêtes pour l'API et l'autorisation de pari.
#[derive(Debug, Clone, Default)]
pub struct StatsBundle {
    pub by_group: HashMap<String, SignalStats>,
    pub by_kind: HashMap<String, SignalStats>,
    pub totals: SignalStats,
}

impl StatsBundle {
    /// Injecte l'historique dans le moteur : `authorized` exige un échantillon
    /// suffisant et un CLV moyen positif sur le groupe **et** sur le type.
    pub fn authorizer(&self) -> Authorizer {
        Authorizer {
            by_group: self.by_group.clone(),
            by_kind: self.by_kind.clone(),
        }
    }
}

#[derive(Default)]
struct Acc {
    won: usize,
    lost: usize,
    push: usize,
    profit: f64,
    clv_sum: f64,
    clv_n: usize,
}

impl Acc {
    fn add(&mut self, proposal: &Proposal) {
        match proposal.outcome {
            BetOutcome::Won => {
                self.won += 1;
                self.profit += proposal.entry_odds.unwrap_or(1.0) - 1.0;
            }
            BetOutcome::Lost => {
                self.lost += 1;
                self.profit -= 1.0;
            }
            BetOutcome::Push => self.push += 1,
            BetOutcome::Pending | BetOutcome::Unknown => return,
        }
        if let Some(clv) = proposal.clv_pct {
            self.clv_sum += clv;
            self.clv_n += 1;
        }
    }

    fn finish(&self) -> SignalStats {
        let settled = self.won + self.lost + self.push;
        let decided = self.won + self.lost;
        if settled == 0 {
            return SignalStats::default();
        }
        SignalStats {
            n: settled,
            hit_pct: if decided > 0 {
                round1(self.won as f64 / decided as f64 * 100.0)
            } else {
                0.0
            },
            roi_pct: round1(self.profit / settled as f64 * 100.0),
            clv_pct: if self.clv_n > 0 {
                round1(self.clv_sum / self.clv_n as f64)
            } else {
                0.0
            },
        }
    }
}

fn round1(value: f64) -> f64 {
    (value * 10.0).round() / 10.0
}

/// Calcule les statistiques par groupe et par type à partir des lignes notées.
pub fn stats(rows: &[TrackedSignal]) -> StatsBundle {
    let mut groups: HashMap<String, Acc> = HashMap::new();
    let mut kinds: HashMap<String, Acc> = HashMap::new();
    let mut totals = Acc::default();

    for row in rows {
        for proposal in &row.proposals {
            if proposal.group == MarketGroup::Score {
                continue;
            }
            let group = groups.entry(proposal.group.key().to_string()).or_default();
            group.add(proposal);
            totals.add(proposal);
            if !row.kind.is_empty() {
                kinds.entry(row.kind.clone()).or_default().add(proposal);
            }
        }
    }

    StatsBundle {
        by_group: groups
            .into_iter()
            .map(|(key, acc)| (key, acc.finish()))
            .filter(|(_, value)| value.n > 0)
            .collect(),
        by_kind: kinds
            .into_iter()
            .map(|(key, acc)| (key, acc.finish()))
            .filter(|(_, value)| value.n > 0)
            .collect(),
        totals: totals.finish(),
    }
}

/// Libellé français d'un résultat, pour l'historique et les résultats.
pub fn outcome_label(outcome: BetOutcome) -> &'static str {
    match outcome {
        BetOutcome::Won => "Gagné",
        BetOutcome::Lost => "Perdu",
        BetOutcome::Push => "Remboursé",
        BetOutcome::Pending => "En attente",
        BetOutcome::Unknown => "Inconnu",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Play;

    fn proposal(group: MarketGroup, odds: f64, outcome: BetOutcome, clv: Option<f64>) -> Proposal {
        Proposal {
            group,
            market: "x".into(),
            pick: "p".into(),
            share: 60.0,
            entry_odds: Some(odds),
            entry_novig: None,
            series_key: String::new(),
            market_key: None,
            play: Play::TotalGoals {
                line: 2.5,
                over: true,
            },
            authorized: false,
            closing_odds: None,
            closing_novig: None,
            clv_pct: clv,
            clv_novig_pct: None,
            outcome,
            explanation: String::new(),
        }
    }

    fn row(kind: &str, proposals: Vec<Proposal>) -> TrackedSignal {
        TrackedSignal {
            id: "sig".into(),
            first_seen: String::new(),
            last_seen: String::new(),
            date: String::new(),
            home: "A".into(),
            away: "B".into(),
            league: "L".into(),
            category: String::new(),
            convergence_score: 0.0,
            value: crate::model::Recommendation {
                play: Play::NoBet,
                label: String::new(),
                odds: None,
            },
            safety: crate::model::Recommendation {
                play: Play::NoBet,
                label: String::new(),
                odds: None,
            },
            value_outcome: BetOutcome::Pending,
            safety_outcome: BetOutcome::Pending,
            value_explanation: String::new(),
            home_score: None,
            away_score: None,
            graded_at: None,
            fixture_key: "a_vs_b".into(),
            kind: kind.into(),
            confidence: None,
            proposals,
            closing_odds: None,
            clv_pct: None,
            clv_novig_pct: None,
            signal_family: "Buts".into(),
            minutes_before_kickoff: None,
            liquidity_tier: String::new(),
        }
    }

    #[test]
    fn push_counts_with_zero_profit() {
        let rows = vec![row(
            "over",
            vec![
                proposal(MarketGroup::Hcp, 1.9, BetOutcome::Push, Some(0.0)),
                proposal(MarketGroup::Buts, 2.0, BetOutcome::Won, Some(2.0)),
                proposal(MarketGroup::Buts, 2.0, BetOutcome::Lost, Some(-2.0)),
            ],
        )];
        let stats = stats(&rows);
        let buts = stats.by_group["buts"];
        assert_eq!(buts.n, 2);
        assert_eq!(buts.hit_pct, 50.0);
        assert_eq!(buts.roi_pct, 0.0);
        let hcp = stats.by_group["hcp"];
        assert_eq!(hcp.n, 1);
        assert_eq!(hcp.roi_pct, 0.0);
        assert_eq!(stats.totals.n, 3);
    }

    #[test]
    fn unknown_and_pending_are_excluded() {
        let rows = vec![row(
            "late",
            vec![
                proposal(MarketGroup::Mt, 1.9, BetOutcome::Unknown, None),
                proposal(MarketGroup::Issue, 1.5, BetOutcome::Pending, None),
            ],
        )];
        let stats = stats(&rows);
        assert_eq!(stats.totals.n, 0);
        assert!(stats.by_group.is_empty());
    }

    #[test]
    fn score_never_counts() {
        let rows = vec![row(
            "over",
            vec![proposal(MarketGroup::Score, 8.0, BetOutcome::Won, None)],
        )];
        assert_eq!(stats(&rows).totals.n, 0);
    }

    #[test]
    fn roi_uses_entry_odds() {
        let rows = vec![row(
            "steam",
            vec![proposal(MarketGroup::Issue, 2.5, BetOutcome::Won, Some(4.0))],
        )];
        let stats = stats(&rows);
        assert_eq!(stats.by_kind["steam"].roi_pct, 150.0);
        assert_eq!(stats.by_kind["steam"].clv_pct, 4.0);
    }
}
