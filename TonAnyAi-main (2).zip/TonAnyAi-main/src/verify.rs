//! Notation des paris contre un résultat réel.
//!
//! Correction majeure : la version d'origine renvoyait `WON` par défaut dès que
//! le match était terminé (y compris pour un pari jamais identifié), gonflant le
//! taux de réussite. Ici tout est typé : un `NoBet` n'est jamais gagné, un match
//! non terminé reste `PENDING`, et un DNB sur un nul est `PUSH`.

use crate::model::{BetOutcome, MatchResult, MatchState, Play, Slot};

pub struct Graded {
    pub outcome: BetOutcome,
    pub explanation: String,
}

pub fn grade(play: &Play, result: Option<&MatchResult>) -> Graded {
    let Some(result) = result else {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Rencontre non retrouvée dans les scores ESPN.".to_string(),
        };
    };

    match result.state {
        MatchState::Postponed | MatchState::Cancelled => {
            return Graded {
                outcome: BetOutcome::Unknown,
                explanation: "Rencontre reportée ou annulée.".to_string(),
            }
        }
        MatchState::Scheduled | MatchState::InProgress => {
            return Graded {
                outcome: BetOutcome::Pending,
                explanation: match result.state {
                    MatchState::Scheduled => format!("Coup d'envoi à {}", result.date_label),
                    _ => format!(
                        "En cours ({}), score {} - {}.",
                        result.status_detail,
                        result.home_score.unwrap_or(0),
                        result.away_score.unwrap_or(0)
                    ),
                },
            }
        }
        MatchState::Finished => {}
    }

    // À partir d'ici le match est terminé.
    if matches!(play, Play::NoBet) {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Aucun pari recommandé : rien à noter.".to_string(),
        };
    }

    let (Some(home), Some(away)) = (result.home_score, result.away_score) else {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Score final indisponible.".to_string(),
        };
    };
    let goals = home + away;
    let score = format!("{home}-{away}");

    let outcome = |won: bool, why: String| Graded {
        outcome: if won {
            BetOutcome::Won
        } else {
            BetOutcome::Lost
        },
        explanation: why,
    };

    match play {
        Play::TotalGoals { line, over } => {
            let won = if *over {
                goals as f64 > *line
            } else {
                (goals as f64) < *line
            };
            outcome(
                won,
                format!(
                    "{} {} buts (score {score}).",
                    if *over { "Plus de" } else { "Moins de" },
                    line
                ),
            )
        }
        Play::Btts { yes } => {
            let both = home > 0 && away > 0;
            outcome(
                both == *yes,
                format!(
                    "{} : score {score}.",
                    if both {
                        "Les deux équipes ont marqué"
                    } else {
                        "Une équipe n'a pas marqué"
                    }
                ),
            )
        }
        Play::MatchResult { side } => {
            let won = match side {
                Slot::First => home > away,
                Slot::Draw => home == away,
                Slot::Second => away > home,
            };
            outcome(won, format!("Score final {score}."))
        }
        Play::DoubleChance { home: h, away: a } => {
            let won = (*h && home >= away) || (*a && away >= home);
            outcome(won, format!("Score final {score}."))
        }
        Play::DrawNoBet { side } => {
            if home == away {
                Graded {
                    outcome: BetOutcome::Push,
                    explanation: format!("Match nul {score} : mise remboursée."),
                }
            } else {
                let won = match side {
                    Slot::First => home > away,
                    Slot::Second => away > home,
                    Slot::Draw => false,
                };
                outcome(won, format!("Score final {score}."))
            }
        }
        Play::ExactScore { home: h, away: a } => outcome(
            home == *h as i64 && away == *a as i64,
            format!("Score exact attendu {h}-{a}, final {score}."),
        ),
        Play::NoBet => unreachable!("traité plus haut"),
    }
}

/// Notation d'une proposition selon son **groupe de marché**.
///
/// - `issue`, `buts`, `btts`, `hcp` : notation sur le score final ;
/// - `hcp` (DNB) : un nul est remboursé (`PUSH`), ni gagné ni perdu ;
/// - `mt` : nécessite le score à la mi-temps ; sans lui, `UNKNOWN` et la
///   proposition est exclue des statistiques — jamais gagnée par défaut ;
/// - `score` : jamais noté (`UNKNOWN`), le score exact n'est pas un pari suivi.
pub fn grade_proposal(
    group: &str,
    play: &Play,
    result: Option<&MatchResult>,
) -> Graded {
    if group == "score" {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Score exact : jamais noté.".to_string(),
        };
    }
    if group != "mt" {
        return grade(play, result);
    }

    let Some(result) = result else {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Rencontre non retrouvée dans les scores ESPN.".to_string(),
        };
    };
    match result.state {
        MatchState::Postponed | MatchState::Cancelled => {
            return Graded {
                outcome: BetOutcome::Unknown,
                explanation: "Rencontre reportée ou annulée.".to_string(),
            }
        }
        MatchState::Scheduled | MatchState::InProgress => {
            return Graded {
                outcome: BetOutcome::Pending,
                explanation: "Mi-temps pas encore jouée.".to_string(),
            }
        }
        MatchState::Finished => {}
    }
    let (Some(home_ht), Some(away_ht)) = (result.home_ht, result.away_ht) else {
        return Graded {
            outcome: BetOutcome::Unknown,
            explanation: "Score à la mi-temps indisponible : proposition non notée."
                .to_string(),
        };
    };
    let mut half_time = result.clone();
    half_time.home_score = Some(home_ht);
    half_time.away_score = Some(away_ht);
    let mut graded = grade(play, Some(&half_time));
    graded.explanation = format!(
        "Mi-temps {home_ht}-{away_ht} : {} ",
        graded.explanation
    );
    graded
}

#[cfg(test)]
mod tests {
    use super::*;

    fn finished(home: i64, away: i64) -> MatchResult {
        MatchResult {
            id: "1".into(),
            name: "A vs B".into(),
            date: "2026-11-09T20:00:00Z".into(),
            date_label: "9 nov. 20:00".into(),
            league_slug: "eng.1".into(),
            league_name: "Premier League".into(),
            home_team: "A".into(),
            away_team: "B".into(),
            home_logo: String::new(),
            away_logo: String::new(),
            home_score: Some(home),
            away_score: Some(away),
            home_ht: None,
            away_ht: None,
            state: MatchState::Finished,
            status_detail: "FT".into(),
            completed: true,
            total_goals: Some(home + away),
            btts: Some(home > 0 && away > 0),
        }
    }

    #[test]
    fn total_goals_are_exact() {
        assert_eq!(
            grade(
                &Play::TotalGoals {
                    line: 2.5,
                    over: true
                },
                Some(&finished(2, 1))
            )
            .outcome,
            BetOutcome::Won
        );
        assert_eq!(
            grade(
                &Play::TotalGoals {
                    line: 2.5,
                    over: true
                },
                Some(&finished(1, 1))
            )
            .outcome,
            BetOutcome::Lost
        );
        assert_eq!(
            grade(
                &Play::TotalGoals {
                    line: 2.5,
                    over: false
                },
                Some(&finished(1, 1))
            )
            .outcome,
            BetOutcome::Won
        );
    }

    #[test]
    fn draw_no_bet_pushes_on_draw() {
        assert_eq!(
            grade(
                &Play::DrawNoBet { side: Slot::First },
                Some(&finished(1, 1))
            )
            .outcome,
            BetOutcome::Push
        );
        assert_eq!(
            grade(
                &Play::DrawNoBet { side: Slot::First },
                Some(&finished(2, 1))
            )
            .outcome,
            BetOutcome::Won
        );
    }

    #[test]
    fn no_bet_is_never_won() {
        let g = grade(&Play::NoBet, Some(&finished(3, 0)));
        assert_eq!(g.outcome, BetOutcome::Unknown);
    }

    #[test]
    fn missing_result_is_unknown_not_won() {
        assert_eq!(grade(&Play::NoBet, None).outcome, BetOutcome::Unknown);
        assert_eq!(
            grade(&Play::MatchResult { side: Slot::First }, None).outcome,
            BetOutcome::Unknown
        );
    }

    #[test]
    fn half_time_without_a_score_is_unknown_never_won() {
        // 2-1 au final, mais pas de score à la mi-temps : on ne devine pas.
        let mut result = finished(2, 1);
        result.home_ht = None;
        result.away_ht = None;
        let graded = grade_proposal("mt", &Play::MatchResult { side: Slot::First }, Some(&result));
        assert_eq!(graded.outcome, BetOutcome::Unknown);
        assert!(graded.explanation.contains("mi-temps"), "{}", graded.explanation);
    }

    #[test]
    fn half_time_is_graded_on_the_half_time_score() {
        let mut result = finished(2, 1);
        result.home_ht = Some(0);
        result.away_ht = Some(1);
        assert_eq!(
            grade_proposal("mt", &Play::MatchResult { side: Slot::First }, Some(&result)).outcome,
            BetOutcome::Lost,
            "le domicile menait-il à la mi-temps ? non"
        );
        assert_eq!(
            grade_proposal("mt", &Play::MatchResult { side: Slot::Second }, Some(&result)).outcome,
            BetOutcome::Won
        );
    }

    #[test]
    fn exact_score_is_never_graded() {
        let play = Play::ExactScore { home: 1, away: 0 };
        let graded = grade_proposal("score", &play, Some(&finished(1, 0)));
        assert_eq!(
            graded.outcome,
            BetOutcome::Unknown,
            "le score exact ne doit jamais être noté"
        );
    }

    #[test]
    fn double_chance_covers_two_outcomes() {
        let play = Play::DoubleChance {
            home: true,
            away: false,
        };
        assert_eq!(grade(&play, Some(&finished(1, 1))).outcome, BetOutcome::Won);
        assert_eq!(grade(&play, Some(&finished(2, 0))).outcome, BetOutcome::Won);
        assert_eq!(
            grade(&play, Some(&finished(0, 1))).outcome,
            BetOutcome::Lost
        );
    }
}
