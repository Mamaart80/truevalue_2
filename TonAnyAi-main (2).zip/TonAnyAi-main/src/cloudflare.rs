//! Client minimal de l'API REST Cloudflare (D1 + KV), sans SDK.

use std::sync::Mutex;
use std::time::Duration;

use serde_json::{json, Value};

const API: &str = "https://api.cloudflare.com/client/v4";

/// Lignes lues et écrites depuis le début de la journée UTC.
///
/// D1 facture **par ligne parcourue**, pas par requête : un `SELECT` sans
/// index peut coûter des centaines de milliers de lignes. Ce compteur rend la
/// consommation visible (`/api/health`) et permet de couper les lectures
/// facultatives avant d'atteindre le plafond gratuit.
#[derive(Debug, Clone, Default)]
pub struct Usage {
    pub day: String,
    pub rows_read: u64,
    pub rows_written: u64,
    /// D1 a refusé une requête pour dépassement de quota : inutile de
    /// réessayer avant minuit UTC, chaque tentative échoue de la même façon.
    pub blocked: bool,
}

impl Usage {
    /// Part du budget de lecture consommée (0..1).
    pub fn read_ratio(&self) -> f64 {
        self.rows_read as f64 / crate::thresholds::D1_READ_BUDGET as f64
    }

    pub fn write_ratio(&self) -> f64 {
        self.rows_written as f64 / crate::thresholds::D1_WRITE_BUDGET as f64
    }
}

#[derive(Debug)]
pub struct Cloudflare {
    pub account: String,
    token: String,
    usage: Mutex<Usage>,
}

impl Cloudflare {
    pub fn new(account: impl Into<String>, token: impl Into<String>) -> Self {
        Self {
            account: account.into(),
            token: token.into(),
            usage: Mutex::new(Usage::default()),
        }
    }

    /// Consommation du jour (remise à zéro au changement de date UTC).
    pub fn usage(&self) -> Usage {
        let mut usage = self.usage.lock().unwrap();
        Self::roll_day(&mut usage);
        usage.clone()
    }

    /// Assez de budget pour une lecture non essentielle ?
    pub fn has_budget(&self) -> bool {
        let usage = self.usage();
        !usage.blocked
            && usage.read_ratio() < crate::thresholds::D1_PRESSURE_RATIO
            && usage.write_ratio() < crate::thresholds::D1_PRESSURE_RATIO
    }

    fn roll_day(usage: &mut Usage) {
        let today = chrono::Utc::now().format("%Y-%m-%d").to_string();
        if usage.day != today {
            usage.day = today;
            usage.rows_read = 0;
            usage.rows_written = 0;
            usage.blocked = false;
        }
    }

    fn record(&self, response: &Value) {
        let mut usage = self.usage.lock().unwrap();
        Self::roll_day(&mut usage);
        if let Some(results) = response.get("result").and_then(|r| r.as_array()) {
            for result in results {
                let Some(meta) = result.get("meta") else {
                    continue;
                };
                usage.rows_read += meta.get("rows_read").and_then(Value::as_u64).unwrap_or(0);
                usage.rows_written += meta
                    .get("rows_written")
                    .and_then(Value::as_u64)
                    .unwrap_or(0);
            }
        }
    }

    fn block(&self) {
        let mut usage = self.usage.lock().unwrap();
        Self::roll_day(&mut usage);
        usage.blocked = true;
    }

    fn call(&self, method: &str, path: &str, body: Option<Value>) -> Result<Value, String> {
        self.call_with_timeout(method, path, body, Duration::from_secs(20))
    }

    fn call_with_timeout(
        &self,
        method: &str,
        path: &str,
        body: Option<Value>,
        timeout: Duration,
    ) -> Result<Value, String> {
        let url = format!("{API}/accounts/{}{path}", self.account);
        let agent = ureq::AgentBuilder::new().timeout(timeout).build();
        let request = agent
            .request(method, &url)
            .set("Authorization", &format!("Bearer {}", self.token));

        let response = match body {
            Some(b) => request.send_json(b),
            None => request.call(),
        };

        match response {
            Ok(resp) => {
                let text = resp.into_string().map_err(|e| e.to_string())?;
                if text.trim().is_empty() {
                    return Ok(Value::Null);
                }
                let parsed: Value = serde_json::from_str(&text)
                    .map_err(|e| format!("réponse Cloudflare illisible : {e}"))?;
                if parsed.get("success").and_then(|s| s.as_bool()) == Some(false) {
                    let messages = parsed.get("errors").cloned().unwrap_or(Value::Null);
                    return Err(format!("Cloudflare API : {messages}"));
                }
                Ok(parsed)
            }
            Err(ureq::Error::Status(code, resp)) => {
                let detail = resp.into_string().unwrap_or_default();
                // 7500 = quota journalier D1 dépassé. Réessayer ne sert à rien
                // et chaque tentative coûte un aller-retour : on coupe.
                if detail.contains("\"code\":7500") || detail.contains("exceeded D1") {
                    self.block();
                }
                Err(format!(
                    "HTTP {code} : {}",
                    detail.chars().take(300).collect::<String>()
                ))
            }
            Err(e) => Err(e.to_string()),
        }
    }

    /// Exécute une requête SQL sur D1 et renvoie les lignes du premier résultat.
    pub fn d1_query(
        &self,
        database: &str,
        sql: &str,
        params: Vec<Value>,
    ) -> Result<Vec<Value>, String> {
        self.d1_query_with_timeout(database, sql, params, Duration::from_secs(20))
    }

    /// Comme `d1_query`, avec un délai adapté aux instructions longues
    /// (`CREATE INDEX` sur une grosse table).
    pub fn d1_query_with_timeout(
        &self,
        database: &str,
        sql: &str,
        params: Vec<Value>,
        timeout: Duration,
    ) -> Result<Vec<Value>, String> {
        if self.usage().blocked {
            return Err(
                "quota D1 journalier épuisé : requêtes suspendues jusqu'à minuit UTC".to_string(),
            );
        }
        let payload = json!({ "sql": sql, "params": params });
        let response = self.call_with_timeout(
            "POST",
            &format!("/d1/database/{database}/query"),
            Some(payload),
            timeout,
        )?;
        self.record(&response);
        let results = response
            .get("result")
            .and_then(|r| r.as_array())
            .and_then(|r| r.first())
            .and_then(|r| r.get("results"))
            .and_then(|r| r.as_array())
            .cloned()
            .unwrap_or_default();
        Ok(results)
    }

    pub fn kv_get(&self, namespace: &str, key: &str) -> Result<Option<String>, String> {
        match self.call(
            "GET",
            &format!("/storage/kv/namespaces/{namespace}/values/{key}"),
            None,
        ) {
            Ok(v) => Ok(v.as_str().map(str::to_string).or_else(|| {
                if v.is_null() {
                    None
                } else {
                    Some(v.to_string())
                }
            })),
            Err(e) if e.contains("HTTP 404") => Ok(None),
            Err(e) => Err(e),
        }
    }

    pub fn kv_put(&self, namespace: &str, key: &str, value: &str) -> Result<(), String> {
        let url = format!(
            "{API}/accounts/{}/storage/kv/namespaces/{namespace}/values/{key}",
            self.account
        );
        let agent = ureq::AgentBuilder::new()
            .timeout(Duration::from_secs(20))
            .build();
        agent
            .put(&url)
            .set("Authorization", &format!("Bearer {}", self.token))
            .set("Content-Type", "text/plain")
            .send_string(value)
            .map(|_| ())
            .map_err(|e| format!("KV put : {e}"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_blocked_account_stops_issuing_queries() {
        let client = Cloudflare::new("account", "token");
        assert!(client.has_budget());
        client.block();
        let err = client
            .d1_query("db", "SELECT 1", Vec::new())
            .expect_err("aucune requête ne doit partir");
        assert!(err.contains("quota D1"), "{err}");
        assert!(!client.has_budget());
    }

    #[test]
    fn usage_is_measured_against_the_daily_budget() {
        let client = Cloudflare::new("account", "token");
        client.record(&json!({
            "result": [{"meta": {"rows_read": 1_750_000, "rows_written": 35_000}}]
        }));
        let usage = client.usage();
        assert_eq!(usage.rows_read, 1_750_000);
        assert!((usage.read_ratio() - 0.5).abs() < 0.001);
        assert!((usage.write_ratio() - 0.5).abs() < 0.001);
        assert!(client.has_budget());
    }

    #[test]
    fn pressure_defers_optional_reads_before_the_hard_limit() {
        let client = Cloudflare::new("account", "token");
        client.record(&json!({
            "result": [{"meta": {"rows_read": 2_000_000, "rows_written": 0}}]
        }));
        assert!(client.has_budget(), "2 M restent sous le seuil de pression");
        client.record(&json!({
            "result": [{"meta": {"rows_read": 900_000, "rows_written": 0}}]
        }));
        assert!(!client.has_budget(), "2,9 M dépassent 80 % du budget");
    }
}
