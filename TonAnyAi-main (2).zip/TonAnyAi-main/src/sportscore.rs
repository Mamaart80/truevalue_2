//! Scores de secours via l'API publique SportScore.
//!
//! ESPN reste la source prioritaire. SportScore prend le relais pour les
//! compétitions qu'ESPN ne couvre pas (Serie C italienne, Super League 2
//! grecque, rencontres U20) : sans cela, leurs positions de simulation
//! resteraient ouvertes jusqu'au délai de grâce de 48 h.
//!
//! L'API est gratuite et sans clé. En contrepartie, elle demande une
//! attribution visible (`Powered by SportScore`) et ne garantit aucun SLA.
//! Le rapprochement reste strict : compétition, date et deux équipes.

use std::collections::{HashMap, HashSet};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use serde_json::Value;

use crate::enrich::{format_date, parse_kickoff};
use crate::model::{MatchResult, MatchState};
use crate::thresholds as th;

const BASE_URL: &str = "https://sportscore.com";
const FIXTURES_LIMIT: usize = 200;

/// Slugs SportScore des compétitions suivies, ou liste vide.
///
/// On ne devine pas un slug à partir du nom : une compétition inconnue doit
/// rester sans source plutôt que d'être rapprochée d'un autre championnat.
pub fn competition_slugs(name: &str) -> &'static [&'static str] {
    let n = name.to_lowercase();
    if (n.contains("italian") || n.contains("italy")) && n.contains("serie c") {
        return &["italian-serie-c"];
    }
    if (n.contains("greek") || n.contains("greece")) && n.contains("super league 2") {
        return &["greek-super-league-2"];
    }
    if n.contains("elite league") && n.contains("u20") {
        return &["elite-league-u20"];
    }
    // Une rencontre U20 « amicale » peut être classée dans l'Elite League U20
    // ou dans les amicaux internationaux ; les deux slugs sont donc demandés.
    if (n.contains("friendly") || n.contains("friendlies")) && n.contains("u20") {
        return &["elite-league-u20", "international-friendly"];
    }
    &[]
}

/// Vrai si SportScore peut fournir un score pour cette compétition.
pub fn covers_competition(name: &str) -> bool {
    !competition_slugs(name).is_empty()
}

/// Client SportScore avec cache mémoire par (jour, compétition).
pub struct SportScoreClient {
    ttl: Duration,
    cache: Mutex<HashMap<String, (Instant, Vec<MatchResult>)>>,
}

impl Default for SportScoreClient {
    fn default() -> Self {
        Self::new(Duration::from_secs(th::SPORTSCORE_CACHE_TTL_SECS))
    }
}

impl SportScoreClient {
    pub fn new(ttl: Duration) -> Self {
        Self {
            ttl,
            cache: Mutex::new(HashMap::new()),
        }
    }

    /// Rencontres d'une compétition pour un jour UTC (`AAAA-MM-JJ`).
    pub fn fixtures(&self, day: &str, competition: &str) -> Result<Vec<MatchResult>, String> {
        let cache_key = format!("{day}_{competition}");
        {
            let cache = self.cache.lock().unwrap();
            if let Some((at, events)) = cache.get(&cache_key) {
                if at.elapsed() < self.ttl {
                    return Ok(events.clone());
                }
            }
        }

        let url = format!(
            "{BASE_URL}/api/v1/fixtures/?sport=football&date={day}&competition={competition}&limit={FIXTURES_LIMIT}"
        );
        let response = ureq::get(&url)
            .set("User-Agent", "truevalue/0.1")
            .timeout(Duration::from_secs(th::SPORTSCORE_TIMEOUT_SECS))
            .call()
            .map_err(|e| format!("SportScore {competition} {day} : {e}"))?;
        let payload: Value = response
            .into_json()
            .map_err(|e| format!("SportScore {competition} {day} JSON : {e}"))?;
        let matches = payload
            .get("matches")
            .and_then(Value::as_array)
            .ok_or_else(|| format!("SportScore {competition} {day} : réponse inattendue"))?;

        let events: Vec<MatchResult> = matches
            .iter()
            .filter_map(|row| parse_fixture(row, competition))
            .collect();
        let mut cache = self.cache.lock().unwrap();
        cache.insert(cache_key, (Instant::now(), events.clone()));
        Ok(events)
    }

    /// Récupère plusieurs couples (jour, compétition), sans doublon.
    ///
    /// Une erreur sur une compétition devient un avertissement : les autres
    /// scores restent utilisables et la collecte ne perd pas son snapshot.
    pub fn many(&self, requests: &[(String, &'static str)]) -> (Vec<MatchResult>, Vec<String>) {
        let mut seen_requests: HashSet<(String, &str)> = HashSet::new();
        let mut seen_events: HashSet<String> = HashSet::new();
        let mut events = Vec::new();
        let mut warnings = Vec::new();
        let mut seen_warnings: HashSet<String> = HashSet::new();

        for (day, competition) in requests {
            if !seen_requests.insert((day.clone(), *competition)) {
                continue;
            }
            match self.fixtures(day, competition) {
                Ok(rows) => {
                    for row in rows {
                        if seen_events.insert(row.id.clone()) {
                            events.push(row);
                        }
                    }
                }
                Err(err) => {
                    if seen_warnings.insert(err.clone()) {
                        warnings.push(err);
                    }
                }
            }
        }
        (events, warnings)
    }
}

fn text(value: &Value, key: &str) -> Option<String> {
    value
        .get(key)
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|raw| !raw.is_empty())
        .map(str::to_string)
}

fn score(value: &Value, key: &str) -> Option<i64> {
    let raw = value.get(key)?;
    raw.as_i64()
        .or_else(|| raw.as_str().and_then(|s| s.trim().parse::<i64>().ok()))
}

fn state_of(row: &Value) -> MatchState {
    let status = text(row, "status").unwrap_or_default().to_lowercase();
    let detail = text(row, "status_text").unwrap_or_default().to_lowercase();
    let all = format!("{status} {detail}");

    if all.contains("postpon") || all.contains("suspend") {
        return MatchState::Postponed;
    }
    if all.contains("cancel") || all.contains("abandon") {
        return MatchState::Cancelled;
    }
    if matches!(
        status.as_str(),
        "finished" | "ft" | "full-time" | "full time" | "aet" | "pens"
    ) || detail == "ft"
        || detail.contains("finished")
    {
        return MatchState::Finished;
    }
    if status.contains("live")
        || status.contains("in_progress")
        || status.contains("inprogress")
        || matches!(status.as_str(), "1h" | "2h" | "ht" | "halftime")
        || detail.contains("live")
        || detail.contains("half")
    {
        return MatchState::InProgress;
    }
    MatchState::Scheduled
}

fn status_detail(state: MatchState) -> &'static str {
    match state {
        MatchState::Scheduled => "NS",
        MatchState::InProgress => "LIVE",
        MatchState::Finished => "FT",
        MatchState::Postponed => "POSTP",
        MatchState::Cancelled => "CANC",
    }
}

fn parse_fixture(row: &Value, competition: &str) -> Option<MatchResult> {
    let home = text(row, "home")?;
    let away = text(row, "away")?;
    let date = text(row, "time")?;
    let home_score = score(row, "home_score");
    let away_score = score(row, "away_score");

    let raw_state = state_of(row);
    // Un match annoncé terminé sans les deux scores n'est pas un résultat
    // exploitable : on le laisse en cours plutôt que de rendre la mise.
    let state = if raw_state == MatchState::Finished
        && (home_score.is_none() || away_score.is_none())
    {
        MatchState::InProgress
    } else {
        raw_state
    };
    let total_goals = match (home_score, away_score) {
        (Some(h), Some(a)) => Some(h + a),
        _ => None,
    };
    let btts = match (home_score, away_score) {
        (Some(h), Some(a)) => Some(h > 0 && a > 0),
        _ => None,
    };
    let url = text(row, "url").unwrap_or_default();
    let id = if url.is_empty() {
        format!("sportscore:{home}:{away}:{date}")
    } else {
        format!("sportscore:{url}")
    };

    Some(MatchResult {
        id,
        name: format!("{home} vs {away}"),
        date_label: format_date(&date),
        date,
        league_slug: competition.to_string(),
        league_name: text(row, "competition").unwrap_or_else(|| competition.to_string()),
        home_team: home,
        away_team: away,
        home_logo: text(row, "home_logo").unwrap_or_default(),
        away_logo: text(row, "away_logo").unwrap_or_default(),
        home_score,
        away_score,
        home_ht: None,
        away_ht: None,
        state,
        status_detail: status_detail(state).to_string(),
        completed: state == MatchState::Finished,
        total_goals,
        btts,
    })
}

/// Retrouve la rencontre SportScore correspondant à une affiche Arbworld.
///
/// Le seuil de similarité est plus bas que celui d'ESPN, car les noms fournis
/// par SportScore sont parfois plus longs (« Olympiakos Piraeus B » contre
/// « Olympiacos B »). La compétition et la date réduisent déjà fortement le
/// risque de confusion.
pub fn find_match<'a>(
    home: &str,
    away: &str,
    date: &str,
    league: &str,
    events: &'a [MatchResult],
) -> Option<&'a MatchResult> {
    let slugs = competition_slugs(league);
    if slugs.is_empty() {
        return None;
    }
    let Some(expected) = parse_kickoff(date) else {
        return None;
    };

    let mut best: Option<(&MatchResult, f64)> = None;
    for event in events {
        if !slugs.iter().any(|slug| event.league_slug == *slug) {
            continue;
        }
        let home_sim = crate::espn::similarity(home, &event.home_team);
        let away_sim = crate::espn::similarity(away, &event.away_team);
        if home_sim < th::SPORTSCORE_MATCH_MIN_SIMILARITY
            || away_sim < th::SPORTSCORE_MATCH_MIN_SIMILARITY
        {
            continue;
        }
        let Some(at) = parse_kickoff(&event.date) else {
            continue;
        };
        let seconds = (expected - at).num_seconds().abs();
        if seconds > th::SPORTSCORE_MATCH_MAX_HOURS * 3_600 {
            continue;
        }
        let mut scored = (home_sim + away_sim) / 2.0;
        scored -= (seconds as f64 / 86_400.0).min(1.0) * 0.02;
        if best.map(|(_, score)| scored > score).unwrap_or(true) {
            best = Some((event, scored));
        }
    }

    best.filter(|(_, score)| *score >= th::SPORTSCORE_MATCH_MIN_SIMILARITY)
        .map(|(event, _)| event)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn event(id: &str, home: &str, away: &str, date: &str, competition: &str) -> MatchResult {
        parse_fixture(
            &json!({
                "home": home,
                "away": away,
                "home_score": "2",
                "away_score": "0",
                "status": "finished",
                "status_text": "Finished",
                "time": date,
                "competition": "Greek Super League 2",
                "url": format!("https://sportscore.com/match/{id}")
            }),
            competition,
        )
        .expect("fixture")
    }

    #[test]
    fn maps_the_competitions_espn_does_not_cover() {
        assert_eq!(
            competition_slugs("Italian Serie C"),
            &["italian-serie-c"]
        );
        assert_eq!(
            competition_slugs("Greek Super League 2"),
            &["greek-super-league-2"]
        );
        assert_eq!(
            competition_slugs("Friendlies International U20"),
            &["elite-league-u20", "international-friendly"]
        );
        assert_eq!(competition_slugs("Elite League U20"), &["elite-league-u20"]);
        assert!(competition_slugs("Premier League").is_empty());
        assert!(competition_slugs("Brazilian Serie C").is_empty());
    }

    #[test]
    fn parses_a_finished_fixture_with_scores() {
        let parsed = parse_fixture(
            &json!({
                "home": "Perugia",
                "away": "Sassari Torres",
                "home_score": "0",
                "away_score": "1",
                "status": "finished",
                "status_text": "Finished",
                "time": "2026-11-16T19:45:00+00:00",
                "competition": "Italian Serie C",
                "url": "https://sportscore.com/match/perugia-torres"
            }),
            "italian-serie-c",
        )
        .expect("fixture");

        assert_eq!(parsed.home_team, "Perugia");
        assert_eq!(parsed.away_team, "Sassari Torres");
        assert_eq!((parsed.home_score, parsed.away_score), (Some(0), Some(1)));
        assert_eq!(parsed.state, MatchState::Finished);
        assert_eq!(parsed.total_goals, Some(1));
        assert_eq!(parsed.btts, Some(false));
        assert_eq!(parsed.league_slug, "italian-serie-c");
    }

    #[test]
    fn a_finished_fixture_without_score_is_not_settled() {
        let parsed = parse_fixture(
            &json!({
                "home": "A",
                "away": "B",
                "home_score": null,
                "away_score": null,
                "status": "finished",
                "time": "2026-11-16T19:45:00+00:00"
            }),
            "italian-serie-c",
        )
        .expect("fixture");
        assert_eq!(parsed.state, MatchState::InProgress);
        assert!(!parsed.completed);
    }

    #[test]
    fn postponed_and_cancelled_are_terminal() {
        for (status, expected) in [
            ("postponed", MatchState::Postponed),
            ("cancelled", MatchState::Cancelled),
        ] {
            let parsed = parse_fixture(
                &json!({
                    "home": "A",
                    "away": "B",
                    "status": status,
                    "time": "2026-11-16T19:45:00+00:00"
                }),
                "italian-serie-c",
            )
            .expect("fixture");
            assert_eq!(parsed.state, expected);
        }
    }

    #[test]
    fn finds_the_long_sportscore_team_name() {
        let events = vec![event(
            "panionios",
            "Panionios G.S.S.",
            "Olympiakos Piraeus B",
            "2026-11-16T12:45:00+00:00",
            "greek-super-league-2",
        )];
        assert!(find_match(
            "Panionios",
            "Olympiacos B",
            "2026-11-16T12:45:00Z",
            "Greek Super League 2",
            &events
        )
        .is_some());
    }

    #[test]
    fn refuses_another_competition_or_a_far_away_date() {
        let events = vec![event(
            "perugia",
            "Perugia",
            "Sassari Torres",
            "2026-11-16T19:45:00+00:00",
            "italian-serie-c",
        )];
        assert!(find_match(
            "Perugia",
            "Sassari Torres",
            "2026-11-16T19:45:00Z",
            "Italian Serie C",
            &events
        )
        .is_some());
        assert!(find_match(
            "Perugia",
            "Sassari Torres",
            "2026-11-16T19:45:00Z",
            "Greek Super League 2",
            &events
        )
        .is_none());
        assert!(find_match(
            "Perugia",
            "Sassari Torres",
            "2026-11-19T19:45:00Z",
            "Italian Serie C",
            &events
        )
        .is_none());
    }
}
