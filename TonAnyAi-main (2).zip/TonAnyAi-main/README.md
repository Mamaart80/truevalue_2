# Truevalue

Analyse des flux Betfair (via Arbworld) : détection de smart money, recoupement
multi-marchés et suivi de performance réel. Réécriture en Rust de l'application
`Truevalue` (React + Express).

- **Un seul binaire**, aucune dépendance système, assets embarqués.
- **Stockage Cloudflare** : D1 pour l'historique des signaux, KV pour le snapshot.
- **Déploiement** : Render (service web) + Cloudflare (cron, D1, KV).

## Ce que fait le service

1. `POST /api/refresh` collecte les 10 marchés football d'Arbworld, extrait le JSON
   embarqué et enrichit chaque rencontre (parts de volume, probabilités implicites,
   edge, variation de cote, typologie de signal).
2. Le moteur croise les marchés d'une même rencontre et produit un signal
   (`convergence +buts`, `convergence -buts`, `consensus favori`, `divergence`,
   `neutre`) avec un pari value et un pari sécurité **typés**.
3. Chaque signal est enregistré dans D1 avec `first_seen`; quand la rencontre est
   terminée, il est noté contre le score réel ESPN, avec SportScore en secours
   pour les compétitions qu'ESPN ne couvre pas (ROI calculé sur la cote réelle).
   Toute rencontre vue dans les signaux entre au **journal des matchs** (table
   `match_log`), recoupements neutres compris : le score est enregistré pour tous,
   seuls les signaux non neutres portent des propositions notées. Une rencontre
   sans score retrouvé reste sans score, jamais notée par défaut.
4. Une **simulation en points** suit les signaux à confiance élevée dont la
   cote est au moins égale à 1,30 : 10 points de départ, 1 point par position,
   ouverture dès le premier cycle éligible (1 minute minimum avant le coup
   d'envoi) et 10 positions ouvertes au maximum. La cote de la proposition sert de prix d'entrée ; le
   score règle la position, et une position sans résultat sous 48 h est rendue.
   Une compétition sans source de score (ESPN ou SportScore) n'est jamais
   ouverte, ou est rendue immédiatement si elle l'était déjà. Aucun ordre réel
   n'est envoyé. Un badge « Polymarket confirme » marque, parmi ces signaux,
   ceux dont la direction 1X2/DNB est aussi l'issue favorite du carnet
   Polymarket.
5. Le snapshot complet est écrit dans KV. Le tableau de bord ne lit que ce
   snapshot : une visite ne déclenche **aucun** appel vers Arbworld.

## Démarrage local

```bash
cp .env.example .env      # renseigner DASHBOARD_PASSWORD si besoin
cargo run -- refresh      # une collecte + calcul des signaux
cargo run -- serve        # http://localhost:8080
cargo run -- check        # configuration effective
```

Sans identifiants Cloudflare, le stockage bascule sur `data/snapshot.json` et
`data/signals.json` (mode développement). `CLOUDFLARE_API_TOKEN` peut être
complété par `D1_API_TOKEN` / `KV_API_TOKEN` si les droits sont séparés.

## API

| Méthode | Route | Rôle |
| --- | --- | --- |
| `GET` | `/api/health` | état, mode de stockage, âge du snapshot |
| `GET` | `/api/snapshot` | snapshot complet (marchés + signaux + bilan) |
| `GET` | `/api/markets` | liste des marchés et volumes |
| `GET` | `/api/markets/{key}` | rencontres d'un marché |
| `GET` | `/api/signals` | signaux croisés du dernier cycle |
| `GET` | `/api/track-record` | bilan persisté + 200 derniers signaux |
| `GET` | `/api/simulation` | simulation en points : positions ouvertes et historique réglé |
| `GET` | `/api/daily?date=AAAA-MM-JJ` | bilan d'une journée (défaut : aujourd'hui UTC) : rencontres enregistrées dans les signaux, scores connus, propositions notées, ROI/CLV du jour par niveau de confiance, et liste des journées disponibles |
| `POST` | `/api/refresh` | collecte + notation (jeton `x-refresh-token` pour le cron, ou opérateur connecté au tableau de bord ; réponse `deferred` si la cadence machine est en repos) |
| `POST` | `/api/ai/match` | analyse d'une rencontre |
| `POST` | `/api/ai/signal` | analyse d'un signal |

Authentification HTTP Basic sur toutes les routes dès que `DASHBOARD_PASSWORD`
est défini.

## Alertes Telegram (facultatif)

Deux variables suffisent : `TELEGRAM_BOT_TOKEN` (le bot créé via @BotFather) et
`TELEGRAM_CHAT_ID` (la discussion qui reçoit les messages). La collecte envoie
alors un message par signal à **confiance élevée** — ni les recoupements neutres,
ni les observations — une seule fois par signal, trois au maximum par cycle.
Sans ces variables, rien n'est envoyé et rien ne change. `GET /api/health`
indique `telegram: true|false`. `TELEGRAM_API_BASE` n'existe que pour pointer un
serveur de test local.

## Corrections apportées pendant le portage

- **Plus de fausses données** : l'application d'origine embarquait un jeu de
  secours (`marketFallbacks`, 2 800 lignes) injecté dans l'interface et dans les
  signaux comme s'il s'agissait de flux live. Ici la provenance est explicite
  (`live`, `cache`, `stale`, `snapshot`) et l'absence de données s'affiche.
- **Cotes intégrées à l'interprétation** : probabilités implicites, écarts entre
  marchés (1X2 ↔ double chance ↔ DNB, imbrication des lignes de buts, BTTS),
  score de cohérence, marge du marché et garde-fou contre les cotes trop
  courtes. Revue d'expert et limites détaillées au même endroit. Détail complet
  dans [`docs/INTERPRETATION.md`](docs/INTERPRETATION.md).
- **Seuils recalibrés** : le moteur jugeait une convergence à 52 % sur un marché
  à deux issues (soit un pile ou face) et à 65 % sur une double chance (dont le
  neutre est 33 %). Les décisions se prennent désormais en *conviction* (part
  dominante − part neutre) et en *edge* (part de volume − probabilité implicite).
- **Notation honnête** : l'ancienne fonction renvoyait « gagné » par défaut pour
  tout match terminé, ce qui gonflait le taux de réussite. Les paris sont typés
  (`TotalGoals`, `Btts`, `MatchResult`, `DoubleChance`, `DrawNoBet`,
  `ExactScore`, `NoBet`) et un `NoBet` n'est jamais gagné ; un DNB sur un nul est
  remboursé.
- **Score exact** : les marchés multi-issues ne sont plus déguisés en 1/X/2 avec
  des cotes inventées quand la ligne est vide.
- **Rapprochement des équipes** : la normalisation ne supprime plus « real » et
  n'accepte plus deux équipes à 55 % de similarité ; le Real Madrid ne peut plus
  être confondu avec l'Atlético, et l'ordre domicile/extérieur est vérifié.
- **Charge amont** : une seule collecte par cycle (single-flight), cache
  stale-while-revalidate, anti-rebond de 20 s sur `/api/refresh`, et lecture
  sans effet de bord. L'ancienne version scrapait à chaque visite et exposait
  `?force=true` sans limite.

## Politique de collecte (anti-blocage)

Le collecteur est conçu pour ne pas se faire couper par la source :

- **User-Agent identifiable** : `truevalue/<version> (+contact)`, jamais un faux
  navigateur. Renseigner `SCRAPER_CONTACT` (URL ou email) en production.
- **Back-off** : sur 403/429/503 ou panne réseau, aucune autre requête n'est
  émise pendant un délai exponentiel (60 s → 1 h), qui respecte `Retry-After`.
  Les données périmées restent servies en `stale` avec la raison de l'échec.
- **Requêtes conditionnelles** : `If-None-Match` / `If-Modified-Since` quand la
  source fournit des validateurs. Arbworld répond aujourd'hui `no-store` sans
  ETag, donc le 304 ne se déclenche pas encore — le chemin est implémenté.
- **Cadence adaptative** : collecte toutes les `ACTIVE_INTERVAL_SECS` (600 s)
  quand une rencontre est en cours ou démarre dans `ACTIVE_WINDOW_HOURS` (6 h),
  sinon toutes les `IDLE_INTERVAL_SECS` (1 800 s). Un jitter de `JITTER_SECS`
  (90 s) casse la régularité. Le cron reste à 10 min : le service répond
  `deferred` quand la passe n'est pas utile.
- **Vérifié le 9 novembre 2026** : `https://arbworld.net/robots.txt` contient
  `User-agent: *` sans aucun `Disallow`. Les conditions d'utilisation du site
  restent à relire avant un usage public ; ce dépôt n'extrait que des volumes
  agrégés et publie des signaux calculés, pas le contenu des pages.

Le cron s'appuie sur le jeton `x-refresh-token` pour cette cadence ; un opérateur
connecté au tableau de bord force toujours une collecte immédiate.
- **Suivi réel** : les signaux sont persistés (première vue, cote, résultat) au
  lieu d'être recalculés en mémoire à chaque requête, ce qui rendait le « taux
  de réussite » dépendant de l'instant de la requête.
- **Sécurité** : plus de `Access-Control-Allow-Origin: *`, authentification Basic,
  jeton de refresh pour le cron, en-têtes de sécurité de base.

## Tests

```bash
cargo test
```

Tous les tests sont hors ligne (fixtures synthétiques), y compris le scénario
complet enrichissement → signal → notation → bilan.

## Documentation

- [`DEPLOY.md`](DEPLOY.md) : Render + Cloudflare (D1, KV, cron).
- [`docs/INTERPRETATION.md`](docs/INTERPRETATION.md) : fonctionnement du moteur
  d'interprétation (indicateurs, catégories, cotes, écarts, limites).
