# Déploiement

Architecture : **Render** héberge le binaire Rust (lecture + collecte),
**Cloudflare** fournit le stockage (D1 pour l'historique, KV pour le snapshot) et
le déclencheur cron (Worker).

```
Cloudflare Worker (cron */10)
        │ POST /api/refresh  (x-refresh-token)
        ▼
Render — truevalue-dashboard  ──►  Arbworld (flux)  ──►  ESPN (scores)
        │                                   │
        │ lecture                           └─ notation
        ▼
Cloudflare KV (snapshot)  +  Cloudflare D1 (signaux, résultats)
```

## 1. Cloudflare — stockage

```bash
# Base D1 (l'historique des signaux)
npx wrangler d1 create truevalue
npx wrangler d1 execute truevalue --remote --file cloudflare/d1_schema.sql

# Namespace KV (le snapshot lu par le tableau de bord)
npx wrangler kv namespace create truevalue-snapshot
```

Relever `database_id` (D1) et `id` (KV) : ils deviennent `D1_DATABASE_ID` et
`KV_NAMESPACE_ID`. Le code applique lui-même le schéma au premier démarrage.

## 2. Render — service web

1. Créer le service à partir du blueprint `render.yaml` (runtime Docker).
2. Renseigner les variables (aucune n'est versionnée) :

| Variable | Rôle |
| --- | --- |
| `DASHBOARD_PASSWORD` | mot de passe Basic du tableau de bord (**obligatoire**) |
| `REFRESH_TOKEN` | jeton partagé avec le cron |
| `CLOUDFLARE_ACCOUNT_ID` | compte Cloudflare |
| `CLOUDFLARE_API_TOKEN` | jeton avec `D1:Edit` et `Workers KV Storage:Edit` |
| `D1_DATABASE_ID` | base créée à l'étape 1 |
| `KV_NAMESPACE_ID` | namespace créé à l'étape 1 |
| `GEMINI_API_KEY` | optionnel, active l'analyse enrichie |
| `TELEGRAM_BOT_TOKEN` | optionnel, alertes des signaux à confiance élevée |
| `TELEGRAM_CHAT_ID` | optionnel, discussion qui reçoit ces alertes |

3. Vérifier `GET /api/health` : `mode` doit indiquer `cloudflare (D1 + KV)`.
4. Première collecte : `curl -X POST -H "x-refresh-token: $REFRESH_TOKEN" https://<service>.onrender.com/api/refresh`.

## 3. Cloudflare — cron

```bash
cd cloudflare
# Renseigner RENDER_URL dans wrangler.toml (ou via `wrangler secret`)
npx wrangler secret put REFRESH_TOKEN     # même valeur que sur Render
npx wrangler deploy
```

Le Worker appelle `POST /api/refresh` toutes les 10 minutes (`*/10 * * * *`).
Il expose aussi `POST /refresh` pour un déclenchement manuel, protégé par le
même jeton.

Le service applique sa propre cadence : appelé par le cron, il répond
`{"ok": true, "deferred": true}` tant qu'aucune rencontre n'est en cours ou
imminente (`ACTIVE_WINDOW_HOURS`). Ce n'est pas une erreur — le cron continue de
passer toutes les 10 minutes et la collecte se fait à la première fenêtre utile.
Renseigner `SCRAPER_CONTACT` (URL ou email) pour que le User-Agent soit
identifiable par la source.

## 4. Exploitation

- `truevalue check` affiche le mode de stockage et la date du dernier snapshot.
- Une lecture ne modifie rien : seule la collecte écrit dans D1/KV.
- Si le snapshot est absent, l'API répond `503` et l'interface l'indique ; aucune
  donnée de secours n'est présentée comme live.
- Rotation des secrets : mettre à jour `REFRESH_TOKEN` sur Render **et** dans le
  Worker, puis redéployer le Worker.

## Coûts et limites

- Render plan gratuit : le service s'endort après inactivité ; le premier appel
  du cron après réveil peut dépasser le délai (le Worker renvoie alors 502, la
  collecte suivante rattrape).
- D1 et KV restent dans les quotas gratuits pour un usage personnel (une collecte
  toutes les 10 minutes, quelques centaines de signaux par mois).
- Si le quota D1 est atteint (`error 7500`), la collecte continue et le snapshot
  KV est bien publié, mais les relevés de la passe sont **perdus** : il n'y a
  aucun mécanisme de différé ou de rejeu. L'avertissement apparaît dans
  `warnings` et sur le tableau de bord. C'est la limite assumée documentée dans
  `docs/INTERPRETATION.md` (incident du 9 novembre 2026).
