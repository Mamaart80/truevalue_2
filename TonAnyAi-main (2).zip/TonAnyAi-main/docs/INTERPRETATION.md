# Truevalue — comment le système interprète les signaux

Ce document décrit ce que le moteur calcule, pourquoi, et comment lire un
signal. Il s'adresse autant à l'utilisateur du tableau de bord qu'à celui qui
veut modifier les seuils.

## 1. Principe général

Le produit part d'une hypothèse unique : **sur Betfair, l'argent informé arrive
avant que la cote ne bouge**. Le moteur mesure donc, à chaque collecte :

1. **où va l'argent** (répartition des volumes entre les issues) ;
2. **à quel prix** (cotes actuelles, cotes d'ouverture, probabilités implicites) ;
3. **ce qui vient d'entrer** (variation du volume entre deux relevés, et non
   seulement le cumul depuis l'ouverture).

Ces trois lectures sont ensuite confrontées. Un signal n'est proposé que si
elles se recoupent sur **au moins deux marchés** de la même rencontre, que les
données passent un filtre qualité, et que la cote est encore négociable.

Trois règles structurent tout le reste :

- **aucune donnée inventée** : si une cote, un volume ou un relevé manque, il
  n'apparaît pas et n'est pas mentionné. Une absence est affichée comme telle
  (`why`), jamais remplacée par un zéro ;
- **aucune donnée de secours présentée comme live** : la provenance est
  explicite (`live`, `cache`, `stale`, `snapshot`) ;
- **aucune donnée de repli ne produit de pari** : un marché rejeté par le
  filtre qualité reste visible, mais ne peut ni déclencher ni confirmer un
  signal.

## 2. Chaîne de traitement

```
Arbworld (10 marchés)              ESPN + SportScore (scores)
        │                                     │
        ▼                                     │
   scrape.rs ── cache 20 s, back-off, 304      │
        ▼                                     │
   enrich.rs ── volumes, cotes, implicite,    │
        │        variation, score, liquidité  │
        ▼                                     │
   storage.rs ── relevés (table snapshots) ───┤
        │                                     │
        ▼                                     │
   fresh.rs ── argent frais 1 h / 3 h         │
        ▼                                     │
   quality.rs ── marchés exploitables         │
        ▼                                     │
   signals.rs ── grille de scores, familles,  │
        │        confiance, type de signal    │
        ▼                                     │
   proposals.rs ── une proposition par groupe │
        ▼                                     │
   pipeline.rs ── notation + clôture + CLV ───┤
        ▼                                     ▼
   storage.rs ── KV (snapshot) + D1 (historique, relevés) ── track.rs
        ▼
   web.rs ── /api/snapshot, /api/signals, /api/v2, /api/track-record
        ▼
   interface (bloc `v2`)
```

La collecte est déclenchée par le cron Cloudflare (`POST /api/refresh`), jamais
par une visite : le tableau de bord ne lit que le snapshot persisté. La cadence
et le nombre de requêtes Arbworld **n'ont pas changé** : l'historisation
réutilise les relevés déjà collectés.

## 3. Vocabulaire

| Terme | Définition |
| --- | --- |
| **Volume** | Montant total échangé sur le marché, en livres (£). |
| **Part** (`share`) | Part du volume du marché allant sur une issue, en %. |
| **Cote** (`coef_new`) | Dernière cote connue de l'issue. |
| **Cote d'ouverture** (`coef`) | Première cote vue par le collecteur. |
| **Implicite** | Probabilité déduite de la cote, normalisée sur le marché (marge retirée). |
| **Conviction** | `part dominante − part neutre du marché`. Mesure l'écart au hasard, pas un pourcentage brut. |
| **Variation** (`drop`) | Évolution de la cote en % : négatif = cote qui se resserre. |
| **Argent frais** | Volume entré pendant une fenêtre récente (1 h et 3 h), pas le cumul. |
| **Liquidité** | Palier de volume : `LOW` < 1 200 £ ≤ `MEDIUM` < 7 000 £ ≤ `HIGH` < 30 000 £ ≤ `WHALE`. |
| **Cohérence** | 0-100 : alignement des prix entre marchés ; `null` si aucune comparaison n'est possible. |
| **Groupe** | `issue`, `buts`, `btts`, `hcp`, `mt`, `score` — vocabulaire exact de l'interface. |
| **Type de signal** | `steam`, `reversal`, `late`, `divergence`, `over`, `under`, `favorite`, `neutral`. |
| **Confiance** | `Faible`, `Moyen`, `Élevé` — calculée, jamais fixée à la main. |
| **CLV** | *Closing line value* : cote d'entrée / cote de clôture − 1, en %. |

### Pourquoi la conviction et pas le pourcentage brut

Sur un marché à deux issues, 52 % du volume, c'est un pile ou face : l'ancienne
version y voyait une convergence. Sur une double chance, le « neutre » n'est pas
50 % mais ~33 %. La conviction soustrait donc la part neutre **de la forme du
marché** :

```
conviction = max(0, part_dominante − neutre(marché))
neutre = 33,3 % (3 issues) · 50 % (2 issues) · 15 % (distribution)
```

## 4. Sémantique des marchés et groupes

Chaque marché porte le sens de ses issues (`MarketDef.slot_labels`), ce qui évite
de deviner la signification d'un libellé.

| Marché | Issue 1 | Issue X | Issue 2 | Groupe |
| --- | --- | --- | --- | --- |
| `1x2` | Domicile | Nul | Extérieur | `issue` |
| `Double chance` | 1X | X2 | 12 | `issue` |
| `+/- 1.5`, `+/- 2.5`, `+/- 3.5` | Moins (Under) | — | Plus (Over) | `buts` |
| `BTTS` | Oui | — | Non | `btts` |
| `DNB` | Domicile (remboursé si nul) | — | Extérieur | `hcp` |
| `Mi-temps` | Domicile MT | Nul MT | Extérieur MT | `mt` |
| `Score exact`, `MT/FM` | distribution (multi-issues) | | | `score` |

Le **DNB est le seul handicap** exposé : c'est un « handicap 0 », remboursé sur
un nul. Aucun autre handicap n'est collecté ni inventé.

Le groupe `score` **n'est jamais proposé ni noté** : un score exact sert de
corroboration (score le plus joué, scénario MT/FM), jamais de pari suivi. Il
n'apparaît donc ni dans `mstat`, ni dans les propositions, ni dans les
statistiques.

La mi-temps est une lecture **multi-issues** : elle est notée sur le score à la
mi-temps (voir §11), et le MT/FM ne se note pas.

## 5. Indicateurs calculés par marché

```
part_i        = volume_i / Σ volume × 100
implicite_i   = (1/cote_i) / Σ(1/cote_j) × 100      (issues actives seulement)
drop_i        = (cote_new_i − cote_open_i) / cote_open_i × 100
score         = 20 + 1,05 × conviction + 0,9 × edge
                + bonus de liquidité (0 à 8) + bonus de resserrement
                puis plafonné par le palier de liquidité
```

Le **plafond de liquidité** empêche qu'une concentration de 100 % sur 440 £
s'affiche avec un score de 100 : `LOW → 40`, `MEDIUM → 70`, `HIGH → 88`,
`WHALE → 100`.

`score` n'est pas une probabilité ni une confiance : c'est un **classement de
marché**, utilisé pour l'affichage. La confiance d'un signal est calculée
autrement (§10).

### Edge et espérance : dépréciés

`edge = part − implicite` et `ev_pct = (part/100 × cote − 1) × 100` restent
exposés dans le bloc `odds` pour la continuité de l'interface, mais **ils ne
décident plus de rien** : ni déclenchement, ni confirmation, ni classement.
L'ancien garde-fou « cote trop courte » (`edge < −3 pts`) a été supprimé : il
transformait une observation de flux en jugement de valeur, alors que le prix
est déjà porté par la cote et par le mouvement de cote.

## 6. Historisation des relevés (base de tout le reste)

Chaque collecte enregistre les relevés nécessaires à l'argent frais et au CLV.

- **Table `snapshots`** : `market_key`, `market_id`, `selection_id`,
  `fixture_key`, `captured_at`, `coef_new_1/x/2`, `volume_1/x/2`,
  `total_volume`, `kickoff`. Les migrations sont **idempotentes** (`ALTER TABLE`
  toléré si la colonne existe) : une base existante se met à jour seule.
- **Insertion groupée** par lots de 7 lignes, pour limiter les appels D1. Seules
  les lignes qui ont changé sont écrites (cote ±0,5 % ou volume ±1 £).
- **Horizon** : rencontres qui commencent dans les 48 h, plus celles en cours
  non notées dans la limite de 6 h.
- **Purge** : relevés de plus de 14 jours, sauf rencontres dont le signal n'est
  pas encore noté.
- **Repli local** : si D1 n'est pas configuré, les relevés vont dans
  `snapshots.json` (même format, même lecture).

- **Fenêtre en mémoire** : les relevés des 4 dernières heures
  (`SNAPSHOT_RECENT_HOURS`) sont gardés en mémoire après une seule lecture de la
  base, puis complétés par chaque collecte.

API interne : `selection_series` (série d'une sélection), `last_before`
(dernier relevé avant une heure donnée, utilisé pour la clôture, borné en SQL
par `captured_at`), `fresh_series` (fenêtre récente, servie depuis la mémoire),
`history_active` (au moins un relevé en base), `prime_stats` (alimente le cache
bilan/statistiques avec un historique déjà lu) et `recent_cached` (sert les
signaux depuis ce cache). `invalidate_stats` reste l'échappatoire quand aucune
ligne n'a pu être lue.

### Quota D1 : ce que coûtent les lectures

Le 14 novembre, Cloudflare a refusé les requêtes D1 (`code 7500`) : le compte
avait dépassé les **5 M de lignes lues par jour** du plan gratuit, vers 17 h 45
UTC. Le 18 novembre, le plafond a été atteint de nouveau vers 14 h : les
écritures et les notations ont été suspendues jusqu'à minuit UTC.

Diagnostic corrigé. La cause dominante n'était pas la relecture de l'historique
(quelques milliers de lignes par cycle), mais la **purge des relevés** :

```sql
DELETE FROM snapshots WHERE captured_at < ? AND fixture_key NOT IN (...)
```

`snapshots` n'avait **aucun index sur `captured_at`** : ce `DELETE`, exécuté à
chaque collecte, balayait la table entière. Une table de 40 000 lignes et
144 collectes par jour font 5,7 M de lignes lues à elles seules — le quota
complet, sans compter le reste. Plus l'historique grossissait, plus la facture
montait : c'est exactement la dérive observée (2,6 M le 12, 5,4 M le 17).

Trois corrections :

1. **Index `snapshots_captured_idx`** sur `captured_at` — la purge et le
   chargement de la fenêtre récente deviennent des recherches d'intervalle.
2. **Purge bornée et espacée** : au plus une fois par heure, au plus
   2 000 lignes à la fois (`DELETE ... WHERE id IN (SELECT ... LIMIT 2000)`).
3. **Écritures filtrées** : `match_log` n'est réécrit que si le merge change
   réellement quelque chose (`updated_at` exclu). Chaque collecte réécrivait
   ~400 lignes identiques, soit le plus gros poste des 100 k écritures/jour.

S'y ajoutent deux garde-fous : une lecture d'historique unique par cycle
(partagée entre journal, bilan et statistiques) et un compteur de consommation
`meta.rows_read`/`rows_written` exposé par `/api/health`. Au-delà de 80 % du
budget, les lectures facultatives (backfill, purge) sont différées ; si D1
répond `7500`, plus aucune requête n'est émise jusqu'à minuit UTC — le
processus démarre alors en mode dégradé et sert le dernier snapshot KV au lieu
de boucler sur des erreurs.

Le quota compte des **lignes parcourues**, pas des requêtes : grouper davantage
les `INSERT` réduit les appels, pas la facture. Un `SELECT` sans index coûte
l'intégralité de la table, quel que soit son `LIMIT`.

## 7. Argent frais

Pour chaque sélection, à partir des deux derniers relevés de la fenêtre :

```
f1 / f3   = part du nouvel argent allant sur l'issue dominante sur 1 h / 3 h (%)
in1 / in3 = montant entré sur cette issue sur 1 h / 3 h (£)
```

Trois lectures en découlent :

- **`steam`** : le nouvel argent arrive du même côté que le mouvement de cote
  (cote qui se resserre d'au moins 1 %) ;
- **`reversal`** : la cote et l'argent frais pointent des côtés opposés alors
  que le nouvel argent est majoritaire (≥ 55 %) sur un côté ;
- **`late`** : afflux anormal dans les 6 h avant le coup d'envoi (au moins 3×
  le rythme des heures précédentes). Sans rythme antérieur mesurable, il n'y a
  pas d'« anormal » : un premier relevé chargé n'est pas un afflux tardif.

**Moins de deux relevés dans la fenêtre ⇒ pas de signal de flux.** L'absence est
explicite (`fresh.ok = false` avec sa raison) ; le moteur n'écrit jamais un
`0 £` qui ressemblerait à une mesure. Un delta de volume négatif (reset de
compteur) est ignoré et journalisé, jamais interprété comme une sortie d'argent.

## 8. Filtre qualité

Quatre contrôles, appliqués **avant tout calcul** :

| Contrôle | Seuil |
| --- | --- |
| Somme des 1/cote (marchés partition) | 98 % – 108 % |
| Cote de l'issue dominante | 1,02 – 100 |
| Fraîcheur (`last_update`) | ≤ 120 min |
| Volume du marché | ≥ 250 £ |

Un marché rejeté reste **visible** dans le snapshot, avec ses raisons
(`quality.reasons`). Il est exclu de toute logique : il ne peut ni déclencher un
signal, ni le confirmer, ni porter une proposition. C'est le cas des exemples
réels qui ont motivé ce filtre : `1.56 / 1.21 / 1.26` (somme des 1/cote à
226 %) et `50 / 44 / 1.01` (1.01 n'est pas un prix).

La double chance et les marchés multi-issues ne passent pas le contrôle de
partition : leur somme de 1/cote n'en est pas une.

## 9. Détection des signaux

### 9.1 Filtres d'entrée

Une rencontre n'entre dans le moteur que si **au moins deux marchés
exploitables** la concernent, avec un volume ≥ 250 £ par marché. En dessous, le
bruit domine.

### 9.2 Catégories

| Catégorie | Condition principale | Corroboration exigée |
| --- | --- | --- |
| `Convergence +buts` | issue **Plus de 2.5** dominante, part ≥ 60 % | BTTS Oui, ou score exact à 3 buts+ (≥ 18 %), ou `+3.5` Over |
| `Convergence -buts` | issue **Moins de 2.5** dominante, part ≥ 60 % | BTTS Non, ou score exact à ≤ 2 buts (≥ 18 %), ou `+1.5` Under |
| `Consensus favori` | `1X2` dominante à part ≥ 60 % | DNB du même côté, **ou** double chance contenant ce côté |
| `Poids de marché` | volume de la rencontre ≥ 8 k£, ≥ 3× la médiane de **sa journée**, ≥ 65 % sur une famille, ≥ 3 marchés | — (jamais de pari) |
| `Match sans favori` | écart des probabilités implicites **normalisées** du 1X2 ≤ 5 pts, volume du 1X2 ≥ 3 k£ | — (jamais de pari) |
| `Alerte divergence` | deux marchés financent des scénarios incompatibles | — (pari interdit) |
| `Recoupement neutre` | rien de tout cela | — |

Les deux dernières lignes d'observation disent **où** et **comment** le marché
se forme, jamais dans quel sens jouer :

- `Poids de marché` compare le volume d'une rencontre à la **médiane des
  rencontres de la même journée** (médiane de toute la collecte si la journée
  compte moins de 8 rencontres ; aucun poids si aucune référence n'existe). Un
  volume concentré sur « Résultat » ou sur « Buts » localise l'argent du jour ;
  il ne montre pas un côté financé au-delà de son prix.
- `Match sans favori` mesure `|P(domicile) − P(extérieur)|` sur les probabilités
  **sans marge** du 1X2. L'écart de cotes brutes dépend du niveau du nul et ne
  se compare pas d'un match à l'autre. Sous 5 pts, avec un nul à 20 % ou plus,
  la part dominante reste sous 45 % : la règle « Consensus favori » (60 %) ne
  peut donc pas se déclencher sur le même match. Les deux observations peuvent
  se cumuler — gros volume **et** marché indécis — et c'est le cas le plus
  intéressant.

Ni l'une ni l'autre ne dégrade la confiance d'un signal directionnel : la
confiance mesure la qualité des données, pas l'équilibre de la rencontre. Un
signal de poids plafonne en revanche la confiance à `Moyen`, et aucune des deux
ne porte de proposition.

**Correction de la règle « Convergence -buts »** : la version précédente de ce
document recopiait la condition de `+buts` (`+2.5`, conviction ≥ 10, part ≥ 60)
pour la direction `-buts`, ce qui laissait croire que le moteur testait la même
issue dans les deux sens. Le code lit bien la **dominante du marché des buts** :
`Over 2.5` dominante pour `+buts`, `Under 2.5` dominante pour `-buts`, chacune
avec ses propres corroborations. Une rencontre dont les marchés de buts sont
partagés ne produit aucune des deux convergences ; elle retombe en neutre.

### 9.3 Divergences : grille de scores

Chaque issue financée (conviction ≥ 10) est traduite en **ensemble de scores**
(univers 0-6 buts par équipe, plus une cellule « 7+ »). Deux issues sont
contradictoires si **l'intersection de leurs ensembles est vide**. Un seul test
remplace les anciennes règles en dur :

- `Under 2.5` (0, 1 ou 2 buts) contre `Over 3.5` (4 buts et plus) → vide ;
- victoire extérieur contre `1X` → vide ;
- `Over 2.5` contre score exact `1-0` → vide ;
- `Under 2.5` contre `Over 1.5` → **non vide** (2 buts), donc pas de
  contradiction.

La mi-temps et le MT/FM sont **hors grille** : le score à la mi-temps n'est pas
comparable au score final, et le MT/FM combine deux scores. Ils ne participent
pas au test.

### 9.4 Divergences de prix

| Comparaison | Ce qui est vérifié |
| --- | --- |
| `1X2 ↔ double chance` | les trois probabilités reconstruites doivent coller au 1X2 (± 4 pts) |
| `1X2 ↔ DNB` | `P(domicile)/(P(domicile)+P(extérieur))` doit coller au DNB (± 4 pts) |
| `+1.5 ↔ +2.5 ↔ +3.5` | les lignes sont **imbriquées** : `P(Over 1.5) ≥ P(Over 2.5) ≥ P(Over 3.5)` |
| `BTTS Oui ↔ +1.5` | `P(BTTS)` ne peut pas dépasser `P(Over 1.5)` |

```
cohérence = 100 − Σ (dépassement − tolérance) × 1,1     borné à [0, 100]
```

Un écart ≥ 12 pts transforme une convergence en `Prix incohérents entre
marchés`. **`coherence` vaut `null` quand aucune comparaison n'a été possible** :
ce n'est pas un 100 par défaut, c'est une absence de mesure.

## 10. Groupes, familles et propositions

### 10.1 Familles de confirmation

| Famille | Marchés |
| --- | --- |
| `Résultat` | 1X2, DNB, double chance, mi-temps |
| `Buts` | lignes de buts, BTTS, score exact, MT/FM |

Plusieurs marchés de la même famille comptent pour **une seule** confirmation :
`Over 2.5` + `Over 1.5` + `BTTS` ne font qu'une famille. Un signal fort exige
deux familles différentes.

### 10.2 Une proposition par groupe

Pour chaque groupe (`issue`, `buts`, `btts`, `hcp`, `mt`, `score`), le moteur
retient le marché dont la **conviction est la plus forte** (à égalité, le volume
le plus élevé). Une proposition n'existe que si :

- le marché passe le filtre qualité ;
- la conviction atteint **15 pts** au-dessus du neutre de sa forme ;
- le signal est tradable (pas une divergence, pas un signal neutre) ;
- le coup d'envoi n'est pas donné ;
- la cote d'entrée est négociable (> 1.01).

Le groupe `score` ne produit **jamais** de proposition. L'ancien pari
« sécurité » n'existe plus : `safety` vaut toujours « S'abstenir », et une seule
proposition est exposée par groupe (`share`, `entry_odds`, `authorized`).

### 10.3 `authorized` : faux par défaut

`authorized` n'est vrai que si **le groupe ET le type de signal** ont chacun :

- un échantillon suffisant (**≥ 30** cas notés) ;
- un CLV moyen **positif**.

Tant que l'historique est vide, tout est donc en observation : `authorized =
false`. Ce n'est pas une case à cocher manuellement, c'est le résultat de
l'historique. Le booléen est recalculé à chaque collecte.

## 11. Confiance

```
score = 25 (qualité du marché de référence)
      + 0 / 10 / 18 / 25 (liquidité Low / Medium / High / Whale)
      + 0 / 10 / 20 (0 / 1 / 2 familles de confirmation)
      + 15 (argent frais confirmant le côté dominant sur 1 h)
      + 10 (historique du type de signal avec CLV positif et n > 0)
```

- `Faible` sous 45, `Moyen` sous 70, `Élevé` à partir de 70 ;
- **plafonnée à `Moyen` si moins de deux familles** : une confiance élevée
  exige un recoupement réel ;
- aucune valeur n'est constante : elle baisse dès qu'un ingrédient manque
  (marché rejeté, liquidité faible, pas d'argent frais, historique absent).

## 12. Notation, CLV, ROI

### 12.1 Notation par proposition

Chaque proposition est notée **selon son groupe**, jamais par recherche de
texte :

| Groupe | Règle |
| --- | --- |
| `issue` | score final : gagné / perdu (nul possible sur 1X2) |
| `buts` | total de buts contre la ligne 1.5 / 2.5 / 3.5 |
| `btts` | les deux équipes marquent ou non |
| `hcp` | DNB : nul = **remboursé** (jamais gagné) |
| `mt` | score **à la mi-temps** ; mi-temps absente = **Inconnu** |
| `score` | jamais noté (aucune proposition) |

Statuts possibles : `Gagné`, `Perdu`, `Remboursé`, `En attente`, `Inconnu`. Un
`Inconnu` est exclu des statistiques : il n'est jamais compté comme gagné.

### 12.2 Clôture et CLV

La **cote de clôture** est le dernier relevé enregistré **avant le coup
d'envoi**. Elle ne remplace jamais la cote d'entrée : le ROI reste calculé sur
la cote de première détection, pour être reproductible.

```
clv_pct        = (cote_entrée / cote_clôture − 1) × 100
clv_novig_pct  = (implicite_entrée / implicite_clôture − 1) × 100
```

Le CLV sans marge isole le mouvement de prix de la marge du marché. Si aucun
relevé n'existe avant le coup d'envoi, les deux champs restent à `null` : un CLV
absent n'est jamais un CLV nul.

La sélection du dernier relevé compare des **horodatages**, jamais des chaînes :
la date Arbworld peut être au format `AAAA-MM-JJ HH:MM:SS` alors que
`captured_at` est en RFC 3339 UTC.

### 12.3 Statistiques (`/api/track-record`, bloc v2)

Agrégats par **groupe** et par **type de signal**, plus un total :

```
n     = propositions réglées (Gagné + Perdu + Remboursé)
hit   = Gagné / (Gagné + Perdu) × 100
roi   = Σ profit / n × 100, sur cote d'entrée, remboursé = 0
clv   = moyenne des CLV disponibles
```

`sample_sufficient` = 30 cas, `reliable` = 200 cas. Sous 30 cas, une statistique
s'affiche mais ne s'interprète pas.

Seuls les signaux **non neutres** sont persistés et notés (`SignalKind::flagged`) :
les observations `weight` et `even` en sont exclues, faute de pari à noter — elles
ne vivent que dans le snapshot courant.
La cote d'entrée et les propositions sont **figées à la première détection** :
une collecte ultérieure ne met à jour que `last_seen` et la clôture. Un match
neutre n'entre ni dans les résultats, ni dans l'historique.

### 12.4 Backtest des seuils (`/api/backtest`)

Chaque rencontre du journal porte ses **mesures de contexte**, figées au dernier
relevé d'avant-match : volume, médiane de la journée, multiple, famille
dominante, probabilités implicites du 1X2, écart domicile / extérieur, marge, et
les cotes utilisées. Elles sont enregistrées **même quand aucun seuil n'est
franchi** : sans les valeurs situées sous le seuil, impossible de savoir si le
seuil discrimine.

```
GET /api/backtest?days=14      (défaut 14, plafond 60)
```

Trois tableaux, une question chacun :

| Tableau | Question | Colonnes |
| --- | --- | --- |
| `by_multiple` | une rencontre à 3× le volume médian produit-elle plus de buts ? | `n`, `avg_goals`, `over_25_pct`, `over_25_implied_pct`, `over_25_roi_pct`, `btts_pct` |
| `by_gap` | un 1X2 « sans favori » est-il un vrai pile ou face, et le nul y est-il sous-payé ? | `n`, `home_pct`, `draw_pct`, `away_pct`, `implied_*_pct`, `draw_roi_pct` |
| `by_favorite_odds` | la probabilité implicite du favori est-elle calibrée ? | `n`, `hit_pct`, `implied_pct`, `roi_pct` |

Lecture : `over_25_pct` (réalisé) contre `over_25_implied_pct` (prix moyen du
marché au moment de la mesure). Un écart durable dans une tranche signifie que
le marché n'y est pas calibré. Les ROI sont ceux d'une mise de 1 unité à la cote
enregistrée, commission non comprise.

Rien n'est extrapolé : une rencontre sans mesure n'entre dans aucun tableau, une
rencontre sans score final n'entre dans aucun taux, et un taux sans cas vaut
`null`, jamais `0`. Les rencontres journalisées avant l'ajout de la calibration
n'ont pas de mesures : `measured` le dit, et l'échantillon se remplit à chaque
collecte.

## 13. Le bloc `v2`

Exposé par `/api/v2` et dans `/api/snapshot`, il n'apparaît que si
l'historisation est active (au moins un relevé en base). Sans série temporelle,
l'interface doit afficher « indisponible » plutôt qu'un bloc vide qui
ressemblerait à des zéros mesurés. Il ne déclenche **aucun appel de score** : un
get du tableau de bord ne doit pas dépendre d'une source externe.

| Clé | Contenu |
| --- | --- |
| `kind` | identifiant de signal → `steam\|reversal\|late\|divergence\|under\|over\|favorite\|neutral` |
| `sig` | `conf`, `fam`, `f1`, `f3`, `in1`, `in3`, `q {ok, why}`, `proposals` |
| `mk` | par rencontre : `f` (part du nouvel argent sur 1 h), `d` (direction), `ok` (qualité) |
| `mstat` | statistiques par groupe, `null` pour `score` |
| `perf` | statistiques par type de signal |
| `hist` | propositions notées (200 max) : marché, type, cote, clôture, CLV, résultat |
| `quality` | rencontres dont des marchés sont rejetés, avec la raison |

Les nouvelles clés sont sérialisées avec `#[serde(default)]` : les snapshots
écrits avant cette version restent lisibles.

## 14. Lire un signal

```
Scénario fermé confirmé
Uruguay · 10 nov. 17:00 · 12 k£ · confiance Élevé
Moins de 2.5 buts financé à 66 %, BTTS Non à 66 %, score exact 1-0 à 22 %.
Recoupement de 3 marchés pour 12 k£ échangés.
[ Cote 1.78 · implicite 55.1 % · flux 66 % ]
[ cohérence 92/100 ]
[ Argent frais : +2 400 £ sur 1 h, 100 % sur Moins de 2.5 · steam ]
[ Issue du match : Moins de 2.5 @1.78 · observation ]
Value : Moins de 2.5 buts @1.78
Sécurité : S'abstenir
```

À lire dans cet ordre :

1. **Type et confiance** : steam / late / convergence, et sur combien de
   familles elle repose ;
2. **Synthèse** : quels marchés financent quoi, et quelles données ont été
   écartées ;
3. **Prix** : la cohérence entre marchés (`null` = non mesurée) ;
4. **Argent frais** : ce qui est entré récemment, ou son absence explicite ;
5. **Propositions** : une par groupe, avec la cote d'entrée et `authorized`.

## 15. Utilisation

### Tableau de bord

`cargo run -- serve` (ou `./target/release/truevalue serve`) → `http://localhost:8080`.

- **Aperçu** : volumes, parts, dominante, cote, variation, qualité, argent frais.
- **Signaux** : cartes avec le bloc de prix, les écarts et les propositions.
  Un badge « Polymarket confirme » distingue les signaux à confiance élevée
  dont la direction 1X2/DNB est aussi la favorite du carnet.
- **Simulation** : portefeuille de 10 points, 1 point par position, réservé aux
  signaux à confiance élevée dont la cote est au moins égale à 1,30. L'ouverture
  se fait dès le premier cycle où le signal est éligible, quelle que soit la
  distance au coup d'envoi (une minute de marge minimum), dans la limite de
  10 positions simultanées. Le score règle la position ; aucun ordre réel n'est
  envoyé.
- **Historique** : propositions notées, CLV, ROI par groupe et par type.

### API

```bash
curl -u "$DASHBOARD_USER:$DASHBOARD_PASSWORD" localhost:8080/api/snapshot
curl -u "$DASHBOARD_USER:$DASHBOARD_PASSWORD" localhost:8080/api/v2
curl -u "$DASHBOARD_USER:$DASHBOARD_PASSWORD" localhost:8080/api/track-record
curl -X POST -H "x-refresh-token: $REFRESH_TOKEN" localhost:8080/api/refresh
```

### CLI

```bash
truevalue refresh     # collecte + signaux + notation
truevalue snapshot    # résumé du dernier snapshot
truevalue check       # configuration effective
truevalue serve       # API + tableau de bord
```

## 16. Réglages

Variables d'environnement : **aucune nouveauté** pour cette version.

| Variable | Défaut | Effet |
| --- | --- | --- |
| `CACHE_TTL_SECS` | 20 | fraîcheur du cache par marché |
| `STALE_TTL_SECS` | 900 | âge maximal d'une donnée servie en `stale` |
| `ACTIVE_INTERVAL_SECS` | 600 | cadence quand une rencontre est imminente |
| `IDLE_INTERVAL_SECS` | 1800 | cadence de repos |
| `JITTER_SECS` | 90 | désynchronisation des collectes |
| `ACTIVE_WINDOW_HOURS` | 6 | horizon d'une rencontre « imminente » |
| `SCRAPER_CONTACT` | — | contact publié dans le User-Agent |

Tous les seuils du moteur vivent dans **`src/thresholds.rs`**, et nulle part
ailleurs :

| Constante | Valeur | Rôle |
| --- | --- | --- |
| `MIN_MARKET_VOLUME` / `QUALITY_MIN_VOLUME` | 250 £ | entrée dans le moteur / filtre qualité |
| `MIN_CONVICTION` | 10 pts | tendance exploitable |
| `MIN_MARKETS` | 2 | recoupement minimal |
| `MIN_PROPOSAL_CONVICTION` | 15 pts | une proposition par groupe |
| `OVERROUND_MIN_PCT` / `OVERROUND_MAX_PCT` | 98 / 108 | partition plausible |
| `ABERRANT_ODDS_MIN` / `ABERRANT_ODDS_MAX` | 1.02 / 100 | cote plausible |
| `MAX_DATA_AGE_MINUTES` | 120 | fraîcheur d'un marché |
| `FRESH_WINDOW_SHORT_HOURS` / `_LONG_HOURS` | 1 / 3 | fenêtres d'argent frais |
| `MIN_FRESH_MONEY` | 150 £ | plancher d'un flux |
| `FRESH_MIN_OBSERVATIONS` | 2 | relevés nécessaires |
| `STEAM_MIN_DROP_PCT` | −1 % | seuil « steam » |
| `FRESH_SIDE_MIN_SHARE` | 55 % | côté majoritaire d'une inversion |
| `LATE_SURGE_HOURS` / `LATE_SURGE_MULTIPLE` | 6 h / 3× | afflux tardif |
| `SNAPSHOT_HORIZON_HOURS` / `_LIVE_GRACE_HOURS` | 48 / 6 | historisation |
| `SNAPSHOT_PURGE_DAYS` | 14 j | purge des relevés |
| `SNAPSHOT_MIN_ODDS_CHANGE_PCT` / `_MIN_VOLUME_CHANGE` | 0.5 % / 1 £ | relevé « changé » |
| `SNAPSHOT_BATCH_ROWS` | 7 | lignes par `INSERT` |
| `GAP_TOLERANCE_PP` / `GAP_DIVERGENCE_PP` | 4 / 12 pts | écarts de prix |
| `CONF_*` | 25 / [0,10,18,25] / [0,10,20] / 15 / 10 | confiance |
| `CONFIDENCE_FAIBLE_MAX` / `_ELEVE_MIN` | 45 / 70 | frontières |
| `SAMPLE_MIN_DISPLAY` / `SAMPLE_MIN_RELIABLE` | 30 / 200 | lecture des stats |

## 17. Ce qui n'est pas calibré

Ces valeurs sont des **hypothèses de travail**, pas des résultats mesurés. Le
dépôt n'a pas encore assez d'historique noté pour les valider :

- `OVERROUND_MIN_PCT` / `OVERROUND_MAX_PCT` (98-108 %) : fourchette large ;
- `MAX_DATA_AGE_MINUTES` (120 min) : déduit de la fraîcheur observée ;
- `FRESH_WINDOW_*`, `MIN_FRESH_MONEY`, `STEAM_MIN_DROP_PCT`,
  `FRESH_SIDE_MIN_SHARE` : aucun backtest de ces fenêtres ;
- `LATE_SURGE_HOURS` / `LATE_SURGE_MULTIPLE` (6 h / 3×) : choix de prudence ;
- `CONF_*` et les frontières 45 / 70 : il n'est pas encore démontré que
  « Élevé » gagne plus souvent que « Faible » ;
- `SNAPSHOT_PURGE_DAYS` (14 j) : arbitrage stockage / profondeur d'historique ;
- les seuils 30 / 200 cas : convention statistique, pas une mesure du produit.

Tant que ces seuils ne sont pas calibrés, `authorized` reste faux et l'interface
doit présenter les propositions comme des **observations**.

## 18. Limites connues

- **La part de volume n'est pas une probabilité.** C'est un indicateur de flux ;
  l'espérance affichée en hérite et ne sert qu'à comparer deux paris.
- **Le CLV dépend des relevés.** Sans collecte dans les heures précédant le
  coup d'envoi, `closing_odds` et `clv_pct` restent `null`. La purge à 14 jours
  limite la profondeur d'analyse.
- **La notation interroge ESPN puis SportScore, par compétitions et par jours.**
  Seules les compétitions des signaux en attente sont demandées, sur au plus
  quatre jours (aujourd'hui, hier, et les dates des rencontres en attente sur
  10 jours). SportScore couvre en secours la Serie C italienne, la Super League 2
  grecque et les rencontres U20. Une compétition absente des deux catalogues ne
  peut pas être notée : le signal reste `En attente`, jamais gagné par défaut.
  L'API SportScore est gratuite, sans clé, avec environ 10 000 requêtes par
  24 h et par IP, mais sans SLA ; elle impose une attribution visible.
- **Statuts d'un résultat** : `scheduled`, `live`, `finished`, `postponed`.
  Une rencontre reportée ou annulée n'est jamais présentée comme programmée.
- **Marchés non exclusifs** : seule la double chance est traitée spécialement ;
  le score exact reste une distribution partielle (les scores non listés
  manquent) et sert uniquement de corroboration.
- **Marge du bookmaker** : les probabilités implicites sont normalisées par
  marché, ce qui suppose une marge proportionnelle. Les écarts sous 4 pts ne
  sont pas interprétés, et `coherence` peut être `null`.
- **Commission** : les cotes Betfair sont nettes de marge mais pas de commission
  (2-5 %). Un CLV ou un ROI de +1 pt peut disparaître après commission.
- **Arbworld est la seule source de volumes et de cotes** ; ESPN et SportScore
  ne servent qu'à la notation. Une panne, un blocage ou un changement de
  structure HTML dégrade la collecte (servie en `stale`, avec back-off) — et
  donc l'argent frais.
- **Échantillon** : il faut 200 à 300 paris pour distinguer un ROI de 5 % du
  hasard. Un signal gagnant ne prouve rien.
- **Aucune garantie de gain** : un CLV positif est une preuve de prix, pas une
  prédiction de résultat.

## 19. Fichiers concernés

| Fichier | Rôle |
| --- | --- |
| `src/scrape.rs` | collecte, cache, back-off, requêtes conditionnelles |
| `src/enrich.rs` | volumes, cotes, implicite, variation, libellés |
| `src/market.rs` | définition et sémantique des 10 marchés |
| `src/thresholds.rs` | **tous** les seuils, nommés et documentés |
| `src/quality.rs` | filtre qualité des marchés |
| `src/grid.rs` | grille de scores et test de contradiction |
| `src/fresh.rs` | argent frais (fenêtres, steam / reversal / late) |
| `src/signals.rs` | recoupements, catégories, familles, confiance, type |
| `src/proposals.rs` | une proposition par groupe, `authorized` |
| `src/verify.rs` | notation typée par groupe |
| `src/track.rs` | statistiques par groupe et par type |
| `src/v2.rs` | bloc `v2` de l'interface |
| `src/storage.rs` | snapshot KV, historique D1, relevés, CLV |
| `src/pipeline.rs` | orchestration, clôture, notation |
| `src/polymarket.rs` | appariement et prix du carnet Polymarket (carte de signal) |
| `src/simulation.rs` | simulation en points (ouverture dès l'éligibilité, mise 1, règlement) |
| `src/telegram.rs` | alertes Telegram des signaux à confiance élevée |
| `src/web.rs` | `/api/snapshot`, `/api/v2`, `/api/track-record`, `/api/backtest`, `/api/exchange` |
| `tests/` | scénarios hors ligne (aucun appel réseau) |

## 20. Prix Polymarket dans la carte de signal

La carte de chaque rencontre affiche, sous les marchés recoupés, le **carnet
public de Polymarket** comparé aux probabilités implicites de la collecte
Betfair. Il ne produit ni proposition ni cote exécutable : c'est un second prix, pour
juger si celui de Betfair est cher ou non. Le résumé — issue la plus écartée,
volume échangé, écart notable — reste visible ; le détail (bid/ask, liquidité,
intérêt ouvert, prix par issue) est replié dessous. La jointure se fait sur
l'identifiant du signal : chaque ligne de prix vient d'une rencontre réellement
collectée, aucune n'est ajoutée pour remplir la liste.

- **Appariement.** Recherche par noms d'équipes, puis double vérification :
  tous les jetons significatifs des deux noms doivent apparaître dans
  l'intitulé ou le slug, **et** l'heure de fin de l'événement doit tomber à
  moins de 6 h du coup d'envoi. Une affiche qui revient la saison suivante
  porte le même intitulé : seule la date distingue les deux événements.
  Les mots de forme (« FC », « AC », « Club ») sont ignorés ; aucun nom de club
  ne l'est, « Nacional » et « City » identifient une équipe.
- **Prix lus.** Milieu du carnet `(bid + ask) / 2` ; à défaut le dernier prix
  traité ; à défaut le prix affiché. Le prix n'est ni lissé ni converti.
- **Ce qui est comparé.** Les trois issues 1X2. Les marchés de buts Polymarket
  portent leurs propres lignes : ils ne sont pas appariés à un triplet 1X2, donc
  ils sont **absents** de la carte, pas estimés.
- **Écart.** `Polymarket − Betfair` en points de probabilité. Négatif :
  Polymarket paie mieux que la cote collectée. Positif : il paie moins. Un écart
  impossible à calculer (probabilité manquante d'un côté) reste `null`, jamais 0.
- **Confirmation.** Pour une proposition 1X2 ou DNB, `confirmed` vaut vrai si
  l'issue recommandée est aussi la plus chère sur Polymarket. Les trois prix
  doivent être présents. L'interface ne montre le badge « Polymarket confirme »
  que parmi les signaux à confiance élevée ; un total de buts ou un BTTS ne peut
  pas être confirmé par un triplet 1X2.
- **Positions.** Aucun portefeuille n'est branché : la carte ne lit aucune
  position personnelle. `openInterest` est la position agrégée de tous les
  participants, affichée comme telle.
- **Fraîcheur et coût.** Lecture à la demande, cache mémoire de 5 min, 12
  rencontres maximum par appel, horizon de 48 h. Comptez une requête de
  recherche par rencontre non cachée.
- **Limite assumée.** Aucun prix Polymarket n'est journalisé : ces écarts ne
  peuvent donc pas encore être rétro-calibrés. Ils servent à lire le marché en
  direct, pas à valider un seuil.

## 21. Alertes Telegram (confiance élevée)

Un message part quand un signal réunit : confiance **Élevé**
(`CONFIDENCE_ELEVE_MIN`, 70 points, non calibré), pari porté par une proposition
(ni recoupement neutre, ni poids de marché, ni match sans favori) et cote d'entrée
au moins égale à `MIN_BET_ODDS` (1,30 inclus). Les alertes et la simulation
partagent ce plancher de cote via `simulation::primary_proposal`, **mais pas le
critère de couverture** : une alerte part même si ESPN et SportScore ne peuvent
pas fournir de score. Dans ce cas aucune position de simulation ne sera ouverte
(`simulation::candidate` exige `league_covered`), et la raison est indiquée dans
les `warnings` du snapshot. Le message dit l'affiche, la compétition, l'horaire
UTC, le type, la convergence, la proposition de value quand sa cote existe, et
les deux premiers marchés dominants.

- **Une seule fois par signal.** Les identifiants envoyés sont mémorisés
  (`truevalue/alerts.json`, en KV ou en fichier local) : un redémarrage ne
  renvoie pas les mêmes alertes. La liste est bornée à `TELEGRAM_SEEN_MAX`.
- **Rafale bornée.** `TELEGRAM_MAX_ALERTS_PER_RUN` (3) messages au plus par
  cycle, dans l'ordre des signaux ; le reste attend le cycle suivant.
- **Panne isolée.** Un envoi qui échoue (réseau, jeton révoqué, discussion
  fermée) devient un avertissement de collecte visible dans l'interface, et le
  snapshot est enregistré normalement. Un seul message d'erreur par cycle.
- **Aucun secret en base.** Le jeton et la discussion ne vivent que dans
  l'environnement ; `GET /api/health` n'expose qu'un booléen
  (`telegram: true|false`).

Le filtre `Confiance élevée` de l'interface applique la même règle côté écran :
il ne montre que les cartes dont la confiance est Élevé.

Limite assumée : le seuil de 70 points n'est pas calibré, et le canal ne sait
pas encore si une alerte « Élevé » gagne plus souvent qu'un signal « Moyen » —
c'est exactement ce que la performance par type mesurera quand l'historique noté
sera suffisant.

## 22. Simulation de trading en points

L'ancien onglet Résultats et ses routes `/api/results*` ont été supprimés. ESPN
reste une source **interne** de scores, utilisée uniquement pour régler les
positions et le bilan quotidien ; il n'alimente plus aucune vue de scores.

La simulation applique ces règles :

| Règle | Valeur |
| --- | --- |
| Capital initial | 10 points |
| Mise par position | 1 point |
| Positions simultanées | 10 au maximum, et jamais plus que le capital disponible |
| Confiance | `Élevé` uniquement |
| Cote d'entrée | plancher commun `MIN_BET_ODDS` = 1,30 (1,30 est accepté), identique aux alertes |
| Ouverture | premier cycle où le signal est éligible, sans borne haute (même 44 h à l'avance) ; une minute de marge minimum, jamais après le coup d'envoi |
| Positions par rencontre | une seule |
| Candidats | si la capacité manque, le signal reste mémorisé (`sim_candidates`) et est réessayé à chaque cycle ; la décision est datée du début du cycle, pas de la fin des appels réseau |

Il n'y a plus de créneau horaire à manquer : l'ordonnanceur est la capacité
(10 positions, capital disponible). Les candidats sont triés par coup d'envoi
le plus proche, donc les rencontres imminentes passent avant les lointaines.
Le prix d'entrée est celui du dernier cycle où le signal était dans le flux :
les propositions étant recalculées chaque cycle, une position ouverte longtemps
à l'avance n'utilise pas une cote périmée.

Une position est ouverte sur la **première proposition éligible** du signal
(ordre des groupes : issue, buts, BTTS, handicap, mi-temps). Le filtre
`authorized` n'est volontairement pas appliqué : la simulation teste la règle
demandée (confiance Élevé, cote ≥ 1,30), pas l'autorisation par échantillon. La cote enregistrée
de cette proposition sert de prix d'entrée ; elle est figée à l'ouverture. Le
règlement utilise `verify::grade_proposal` : gagné = `mise × (cote − 1)`,
perdu = `−mise`, remboursé = 0. Une rencontre reportée, annulée, ou terminée
sans résultat notable rend la mise (`VOID`) au lieu d'inventer un gain. Une
position n'est ouverte que si sa compétition possède une source de score
connue (ESPN, ou SportScore en secours) ; une position déjà ouverte sur une
compétition non couverte est immédiatement rendue. Une position encore ouverte
48 h après le coup d'envoi sans résultat est également rendue : une compétition
non couverte ne peut pas immobiliser une place indéfiniment.

L'identifiant d'une position contient la date UTC et la compétition, pas
seulement l'affiche : une nouvelle saison ou un match de coupe entre les mêmes
équipes peut donc être simulé. Le rapprochement ESPN ou SportScore exige la même compétition
et un coup d'envoi à moins de 24 h ; un match futur des mêmes équipes ne peut
pas remplacer le résultat du match courant.

Quand un signal à confiance élevée ne peut pas être simulé (compétition sans
source, cote sous le plancher, type descriptif, coup d'envoi passé), la raison
est reportée dans les `warnings` du snapshot. Un signal éligible qui attend une
place reste, lui, dans `sim_candidates` et n'est pas signalé comme une erreur.
Aucun appel à D1 n'est nécessaire pour comprendre un écart alerte/simulation.

`GET /api/simulation` est une lecture seule et ne déclenche aucun appel amont.
Les positions sont persistées dans D1 (`sim_positions`) et, en développement,
dans `data/simulation.json`. Le capital et le ROI sont calculés sur **tout**
l'historique par agrégat D1 ; seules les 500 dernières positions réglées sont
renvoyées pour l'affichage. Aucun ordre réel n'est envoyé : la cote vient du
signal, pas d'un carnet d'ordres Polymarket. Une position ouverte n'est pas
marquée au marché ; le capital affiché est le capital réalisé, et le disponible
retire les mises encore engagées.
