-- Schéma D1 complet de Truevalue.
-- Source de vérité : src/storage.rs (SCHEMA, SNAPSHOTS_SCHEMA, MATCH_LOG_SCHEMA,
-- SIM_SCHEMA, SIM_CANDIDATES_SCHEMA, META_SCHEMA et MIGRATIONS).
-- Ce fichier est fourni pour l'initialisation manuelle ; le binaire applique le
-- même schéma via `ensure_schema()` au démarrage et refuse de continuer si
-- l'initialisation échoue.

CREATE TABLE IF NOT EXISTS signals (
    id TEXT PRIMARY KEY,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    match_date TEXT NOT NULL DEFAULT '',
    home TEXT NOT NULL,
    away TEXT NOT NULL,
    league TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,
    convergence_score REAL NOT NULL DEFAULT 0,
    value_play TEXT NOT NULL,
    value_label TEXT NOT NULL,
    value_odds REAL,
    safety_play TEXT NOT NULL,
    safety_label TEXT NOT NULL,
    safety_odds REAL,
    value_outcome TEXT NOT NULL DEFAULT 'PENDING',
    safety_outcome TEXT NOT NULL DEFAULT 'PENDING',
    value_explanation TEXT NOT NULL DEFAULT '',
    home_score INTEGER,
    away_score INTEGER,
    confidence TEXT NOT NULL DEFAULT '',
    graded_at TEXT,
    -- Migrations (appliquées aussi par le code sur une base existante)
    fixture_key TEXT NOT NULL DEFAULT '',
    signal_kind TEXT NOT NULL DEFAULT '',
    proposals TEXT NOT NULL DEFAULT '[]',
    closing_odds REAL,
    clv_pct REAL,
    clv_novig_pct REAL,
    signal_family TEXT NOT NULL DEFAULT '',
    minutes_before_kickoff INTEGER,
    liquidity_tier TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS signals_date_idx ON signals(match_date);
CREATE INDEX IF NOT EXISTS signals_outcome_idx ON signals(value_outcome);
CREATE INDEX IF NOT EXISTS signals_category_idx ON signals(category);
CREATE INDEX IF NOT EXISTS signals_fixture_idx ON signals(fixture_key);
CREATE INDEX IF NOT EXISTS signals_kind_idx ON signals(signal_kind);

-- Relevés de marché : matière première de l'argent frais et du CLV.
CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    market_key TEXT NOT NULL,
    market_id INTEGER NOT NULL,
    selection_id INTEGER NOT NULL,
    fixture_key TEXT NOT NULL,
    captured_at TEXT NOT NULL,
    coef_new_1 REAL NOT NULL DEFAULT 0,
    coef_new_x REAL NOT NULL DEFAULT 0,
    coef_new_2 REAL NOT NULL DEFAULT 0,
    volume_1 REAL NOT NULL DEFAULT 0,
    volume_x REAL NOT NULL DEFAULT 0,
    volume_2 REAL NOT NULL DEFAULT 0,
    total_volume REAL NOT NULL DEFAULT 0,
    kickoff TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS snapshots_fixture_idx ON snapshots(fixture_key, captured_at);
CREATE INDEX IF NOT EXISTS snapshots_selection_idx
    ON snapshots(market_key, market_id, selection_id, captured_at);
-- Indispensable : sans lui, la purge et le chargement de la fenêtre récente
-- balayaient toute la table à chaque collecte (quota D1 de 5 M de lignes lues
-- par jour dépassé).
CREATE INDEX IF NOT EXISTS snapshots_captured_idx ON snapshots(captured_at);

-- Journal des rencontres suivies, recoupements neutres compris.
CREATE TABLE IF NOT EXISTS match_log (
    fixture_key TEXT NOT NULL,
    match_date TEXT NOT NULL,
    day TEXT NOT NULL DEFAULT '',
    home TEXT NOT NULL DEFAULT '',
    away TEXT NOT NULL DEFAULT '',
    league TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT '',
    flagged INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'SCHEDULED',
    status_detail TEXT NOT NULL DEFAULT '',
    home_score INTEGER,
    away_score INTEGER,
    source TEXT NOT NULL DEFAULT '',
    metrics TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (fixture_key, match_date)
);

CREATE INDEX IF NOT EXISTS match_log_day_idx ON match_log(day);

-- Positions de la simulation de trading en points.
CREATE TABLE IF NOT EXISTS sim_positions (
    id TEXT PRIMARY KEY,
    signal_id TEXT NOT NULL,
    fixture_key TEXT NOT NULL DEFAULT '',
    match_date TEXT NOT NULL DEFAULT '',
    day TEXT NOT NULL DEFAULT '',
    home TEXT NOT NULL DEFAULT '',
    away TEXT NOT NULL DEFAULT '',
    league TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT '',
    grp TEXT NOT NULL DEFAULT '',
    market TEXT NOT NULL DEFAULT '',
    pick TEXT NOT NULL DEFAULT '',
    entry_odds REAL NOT NULL,
    stake REAL NOT NULL DEFAULT 1,
    play TEXT NOT NULL DEFAULT '{}',
    opened_at TEXT NOT NULL,
    minutes_before_kickoff INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'OPEN',
    settled_at TEXT,
    pnl REAL,
    home_score INTEGER,
    away_score INTEGER,
    note TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS sim_positions_status_idx ON sim_positions(status);
CREATE UNIQUE INDEX IF NOT EXISTS sim_positions_fixture_idx
    ON sim_positions(fixture_key, match_date, league);

-- Candidats de simulation en attente d'une place.
CREATE TABLE IF NOT EXISTS sim_candidates (
    id TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    match_date TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS sim_candidates_date_idx ON sim_candidates(match_date);

-- Marqueur des migrations déjà appliquées.
CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
