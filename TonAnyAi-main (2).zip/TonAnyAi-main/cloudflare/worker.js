/**
 * Worker Cloudflare : déclencheur cron qui demande une collecte au service Render.
 *
 * Les données (D1 + KV) vivent dans Cloudflare ; le Worker ne fait qu'appeler
 * `POST /api/refresh` avec un jeton, et refuse tout appel non autorisé.
 */
export default {
  async scheduled(_event, env, ctx) {
    // Le cron renvoie sa réponse immédiatement : sans waitUntil, un Render
    // endormi qui dépasse le délai du Worker fait échouer la passe (502).
    ctx.waitUntil(refresh(env));
  },

  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== '/refresh') {
      return json({ ok: false, error: 'Route inconnue' }, 404);
    }
    if (request.method !== 'POST') {
      return json({ ok: false, error: 'POST attendu' }, 405);
    }
    const token = request.headers.get('x-refresh-token');
    if (!env.REFRESH_TOKEN || token !== env.REFRESH_TOKEN) {
      return json({ ok: false, error: 'Non autorisé' }, 403);
    }
    const result = await refresh(env);
    return json(result.body, result.status);
  },
};

async function refresh(env) {
  if (!env.RENDER_URL) {
    return { status: 500, body: { ok: false, error: 'RENDER_URL non configurée' } };
  }
  try {
    const response = await fetch(`${env.RENDER_URL.replace(/\/$/, '')}/api/refresh`, {
      method: 'POST',
      headers: {
        'x-refresh-token': env.REFRESH_TOKEN || '',
        'content-type': 'application/json',
      },
    });
    const body = await response.json().catch(() => ({}));
    return { status: response.status, body };
  } catch (error) {
    return { status: 502, body: { ok: false, error: String(error) } };
  }
}

function json(body, status) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}
