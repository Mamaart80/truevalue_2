//! Tests d'intégration hors ligne : aucun appel réseau.
//!
//! Le scénario complet est rejoué avec des lignes Arbworld synthétiques :
//! enrichissement → signaux croisés → notation → bilan.

use serde_json::json;
use truevalue::enrich::{enrich, parse_kickoff};
use truevalue::fresh::{selection_key, Observation, Series};
use truevalue::market::MarketKey;
use truevalue::model::{
    BetOutcome, MarketSnapshot, MatchResult, MatchState, Play, SignalKind, Snapshot, Source,
    TrackedSignal,
};
use truevalue::proposals::{Authorizer, MarketGroup};
use truevalue::signals;
use truevalue::storage::compute_track_record;
use truevalue::track::StatsBundle;
use truevalue::verify::{grade, grade_proposal};

fn row(home: &str, away: &str, extra: serde_json::Value) -> serde_json::Value {
    let mut base = json!({
        "home": home, "away": away, "league": "Premier League", "country": "eng",
        "date": "2026-11-09T20:00:00Z", "market_id": 91, "selection_id": 92,
    });
    if let (Some(obj), Some(more)) = (base.as_object_mut(), extra.as_object()) {
        for (k, v) in more {
            obj.insert(k.clone(), v.clone());
        }
    }
    base
}

fn snapshot_of(key: MarketKey, rows: Vec<serde_json::Value>) -> MarketSnapshot {
    let matches = enrich(&rows, key, Source::Live, 0);
    MarketSnapshot {
        market: Some(key),
        key: key.slug().to_string(),
        label: key.def().label.to_string(),
        short: key.def().short.to_string(),
        total_volume: matches.iter().map(|m| m.total_volume).sum(),
        matches,
        source: Source::Live,
        updated_at: "2026-11-09T19:00:00Z".to_string(),
        error: None,
    }
}

#[test]
fn full_cycle_produces_signal_then_grades_it() {
    let over = row(
        "Arsenal",
        "Chelsea",
        json!({
            "coef_1": 1.90, "coef_2": 2.00, "coef_1_new": 1.92, "coef_2_new": 1.98,
            "volume_1": 3100, "volume_2": 9200
        }),
    );
    let btts = row(
        "Arsenal",
        "Chelsea",
        json!({
            "coef_1": 1.72, "coef_2": 2.20, "coef_1_new": 1.62, "coef_2_new": 2.35,
            "volume_1": 8400, "volume_2": 1900
        }),
    );
    // La couverture suggérée doit exister pour être notée : sans ce marché, le
    // moteur la retire (elle n'a pas de cote).
    let ou15 = row(
        "Arsenal",
        "Chelsea",
        json!({
            "coef_1": 2.40, "coef_2": 1.55, "coef_1_new": 2.38, "coef_2_new": 1.57,
            "volume_1": 3900, "volume_2": 5100
        }),
    );

    let markets = vec![
        snapshot_of(MarketKey::OverUnder25, vec![over]),
        snapshot_of(MarketKey::Btts, vec![btts]),
        snapshot_of(MarketKey::OverUnder15, vec![ou15]),
    ];
    let signals = signals::compute(&markets, "2026-11-09T19:00:00Z");
    assert_eq!(signals.len(), 1);
    let signal = &signals[0];
    assert_eq!(
        signal.value.play,
        Play::TotalGoals {
            line: 2.5,
            over: true
        }
    );

    let snapshot = Snapshot {
        computed_at: "2026-11-09T19:00:00Z".to_string(),
        markets,
        signals: signals.clone(),
        ..Default::default()
    };
    let encoded = serde_json::to_string(&snapshot).expect("snapshot sérialisable");
    let decoded: Snapshot = serde_json::from_str(&encoded).expect("snapshot relisible");
    assert_eq!(decoded.signals.len(), 1);

    let result = MatchResult {
        id: "1".into(),
        name: "Arsenal vs Chelsea".into(),
        date: "2026-11-09T20:00:00Z".into(),
        date_label: "9 nov. 20:00".into(),
        league_slug: "eng.1".into(),
        league_name: "Premier League".into(),
        home_team: "Arsenal".into(),
        away_team: "Chelsea".into(),
        home_logo: String::new(),
        away_logo: String::new(),
        home_score: Some(2),
        away_score: Some(1),
        home_ht: Some(1),
        away_ht: Some(0),
        state: MatchState::Finished,
        status_detail: "FT".into(),
        completed: true,
        total_goals: Some(3),
        btts: Some(true),
    };

    let value = grade(&signal.value.play, Some(&result));
    assert_eq!(value.outcome, BetOutcome::Won);
    // Plus de pari « sécurité » : une seule proposition par groupe.
    assert_eq!(signal.safety.play, Play::NoBet);

    let tracked = TrackedSignal {
        id: signal.id.clone(),
        first_seen: "2026-11-09T19:00:00Z".into(),
        last_seen: "2026-11-09T19:00:00Z".into(),
        date: signal.date.clone(),
        home: signal.home.clone(),
        away: signal.away.clone(),
        league: signal.league.clone(),
        category: signal.category.label().to_string(),
        convergence_score: signal.convergence_score,
        value: signal.value.clone(),
        safety: signal.safety.clone(),
        value_outcome: value.outcome,
        safety_outcome: BetOutcome::Unknown,
        value_explanation: value.explanation,
        home_score: result.home_score,
        away_score: result.away_score,
        graded_at: Some("2026-11-09T22:05:00Z".into()),
        confidence: Some(signal.confidence),
        fixture_key: signal.fixture_key.clone(),
        kind: signal.kind.key().to_string(),
        proposals: signal.proposals.clone(),
        closing_odds: None,
        clv_pct: None,
        clv_novig_pct: None,
        signal_family: signal.families.first().cloned().unwrap_or_default(),
        minutes_before_kickoff: Some(60),
        liquidity_tier: signal.liquidity_tier.key().to_string(),
    };

    let record = compute_track_record(&[tracked]);
    assert_eq!(record.signals, 1);
    assert_eq!(record.settled_value, 1);
    assert_eq!(record.value_won, 1);
    assert!(record.value_roi > 0.0);
}

#[test]
fn fresh_money_then_clv_then_v2_round_trip() {
    // Une cote qui raccourcit et de l'argent frais du même côté : « steam ».
    let one = row(
        "Arsenal",
        "Chelsea",
        json!({
            "coef_1": 1.90, "coef_x": 3.70, "coef_2": 4.40,
            "coef_1_new": 1.70, "coef_x_new": 4.00, "coef_2_new": 5.00,
            "volume_1": 7000, "volume_x": 1200, "volume_2": 1500
        }),
    );
    let dnb = row(
        "Arsenal",
        "Chelsea",
        json!({
            "coef_1": 1.40, "coef_2": 3.00, "coef_1_new": 1.38, "coef_2_new": 3.10,
            "volume_1": 6000, "volume_2": 1200
        }),
    );
    let markets = vec![
        snapshot_of(MarketKey::OneXTwo, vec![one]),
        snapshot_of(MarketKey::DrawNoBet, vec![dnb]),
    ];

    let key = selection_key(MarketKey::OneXTwo, 91, 92);
    let mut series = Series::default();
    series.push(
        &key,
        Observation {
            captured_at: "2026-11-09T19:30:00Z".into(),
            coef: [1.90, 3.70, 4.40],
            volume: [5000.0, 1200.0, 1500.0],
        },
    );
    series.push(
        &key,
        Observation {
            captured_at: "2026-11-09T19:50:00Z".into(),
            coef: [1.70, 4.00, 5.00],
            volume: [7000.0, 1200.0, 1500.0],
        },
    );

    let signals = signals::compute_with_context(
        &markets,
        &series,
        &Authorizer::default(),
        "2026-11-09T19:55:00Z",
    );
    assert_eq!(signals.len(), 1);
    let signal = &signals[0];
    assert_eq!(signal.kind, SignalKind::Steam, "{}", signal.analysis_summary);
    assert_eq!(signal.fresh.in1, Some(2000.0));
    assert_eq!(signal.fresh.f1, Some(100.0));
    assert!(signal.fresh.steam);
    assert!(!signal.proposals.is_empty());
    assert!(
        signal.proposals.iter().all(|p| !p.authorized),
        "sans historique, aucun pari n'est autorisé"
    );

    // DNB sur un nul : remboursé, jamais gagné ni perdu.
    let dnb_proposal = signal
        .proposals
        .iter()
        .find(|p| p.group == MarketGroup::Hcp)
        .expect("proposition DNB");
    let draw = MatchResult {
        id: "1".into(),
        name: "Arsenal vs Chelsea".into(),
        date: "2026-11-09T20:00:00Z".into(),
        date_label: String::new(),
        league_slug: "eng.1".into(),
        league_name: String::new(),
        home_team: "Arsenal".into(),
        away_team: "Chelsea".into(),
        home_logo: String::new(),
        away_logo: String::new(),
        home_score: Some(1),
        away_score: Some(1),
        home_ht: None,
        away_ht: None,
        state: MatchState::Finished,
        status_detail: "FT".into(),
        completed: true,
        total_goals: Some(2),
        btts: Some(true),
    };
    assert_eq!(
        grade_proposal("hcp", &dnb_proposal.play, Some(&draw)).outcome,
        BetOutcome::Push
    );

    // CLV : entrée 1.80 (cote à la première détection), clôture 1.70.
    let mut proposal = signal.proposals[0].clone();
    proposal.entry_odds = Some(1.80);
    proposal.set_closing(Some(1.70), None);
    assert_eq!(proposal.clv_pct, Some(5.9));

    // Le bloc v2 expose la nouvelle typologie et les propositions du moteur.
    let snapshot = Snapshot {
        computed_at: "2026-11-09T19:55:00Z".into(),
        markets,
        signals: signals.clone(),
        ..Default::default()
    };
    let block = truevalue::v2::build(&snapshot, &[], &StatsBundle::default());
    let encoded = serde_json::to_value(&block).expect("bloc v2 sérialisable");
    assert_eq!(encoded["kind"][&signal.id], "steam");
    assert!(encoded["sig"][&signal.id]["proposals"].is_array());
    assert_eq!(encoded["mstat"]["issue"]["n"], 0);
    assert!(encoded["quality"].is_array());
    let _ = parse_kickoff("2026-11-09T19:55:00Z");
}

#[test]
fn contradictory_markets_never_produce_a_bet() {
    let one = row(
        "Lyon",
        "Paris",
        json!({
            "coef_1": 3.30, "coef_x": 3.40, "coef_2": 2.05,
            "coef_1_new": 3.90, "coef_x_new": 3.70, "coef_2_new": 2.05,
            "volume_1": 1800, "volume_x": 2200, "volume_2": 13000
        }),
    );
    let dc = row(
        "Lyon",
        "Paris",
        json!({
            "coef_1": 1.45, "coef_x": 1.55, "coef_2": 1.85,
            "coef_1_new": 1.38, "coef_x_new": 1.60, "coef_2_new": 1.95,
            "volume_1": 15000, "volume_x": 2600, "volume_2": 2400
        }),
    );
    let signals = signals::compute(
        &[
            snapshot_of(MarketKey::OneXTwo, vec![one]),
            snapshot_of(MarketKey::DoubleChance, vec![dc]),
        ],
        "2026-11-09T19:00:00Z",
    );
    assert_eq!(signals.len(), 1);
    assert_eq!(signals[0].value.play, Play::NoBet);
    assert_eq!(signals[0].safety.play, Play::NoBet);

    let record = compute_track_record(&[TrackedSignal {
        id: signals[0].id.clone(),
        first_seen: "2026-11-09T19:00:00Z".into(),
        last_seen: "2026-11-09T19:00:00Z".into(),
        date: signals[0].date.clone(),
        home: signals[0].home.clone(),
        away: signals[0].away.clone(),
        league: signals[0].league.clone(),
        category: signals[0].category.label().to_string(),
        convergence_score: signals[0].convergence_score,
        value: signals[0].value.clone(),
        safety: signals[0].safety.clone(),
        value_outcome: BetOutcome::Unknown,
        safety_outcome: BetOutcome::Unknown,
        value_explanation: String::new(),
        home_score: None,
        away_score: None,
        graded_at: None,
        confidence: Some(signals[0].confidence),
        fixture_key: signals[0].fixture_key.clone(),
        kind: signals[0].kind.key().to_string(),
        proposals: signals[0].proposals.clone(),
        closing_odds: None,
        clv_pct: None,
        clv_novig_pct: None,
        signal_family: String::new(),
        minutes_before_kickoff: None,
        liquidity_tier: String::new(),
    }]);
    assert_eq!(record.settled_value, 0);
    assert_eq!(record.value_win_rate, 0.0);
}
